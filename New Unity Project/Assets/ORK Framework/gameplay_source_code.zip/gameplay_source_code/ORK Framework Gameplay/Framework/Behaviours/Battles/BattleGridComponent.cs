﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Battles/Battle Grid")]
	public class BattleGridComponent : MonoBehaviour
	{
		// generation settings
		public int rows = 10;

		public int columns = 10;

		public TextAnchor positionAnchor = TextAnchor.MiddleCenter;

		public bool generateKeepOldCells = false;

		// cell settings
		public bool useSlope = false;

		[ORKEditorInfo(ORKDataType.BattleGridCellType)]
		public int cellTypeID = 0;

		[ORKEditorInfo(ORKDataType.BattleGridCellType)]
		public int emptyCellTypeID = 0;

		public bool useBlockedType = false;

		public float blockedTypeSlope = 45;

		[ORKEditorInfo(ORKDataType.BattleGridCellType)]
		public int blockedCellTypeID = 0;

		// raycast settings
		public LayerMask rayLayerMask = -1;

		public Vector3 raySourceOffset = new Vector3(0, 0, 0);

		public float rayDistance = 100;

		public Vector3 rayHitOffset = Vector3.zero;

		// editor display
		public bool showEditorGrid = false;

		public bool showEditorPrefabs = false;

		public bool showEditorUnselected = false;

		private bool editorPrefabsShowing = false;


		// generated battle grid
		public bool autoShowGrid = false;

		public BattleGridCellRow[] cellRow;


		// in-game
		private bool highlightsHidden = false;

		private bool markFireChanged = false;

		private Dictionary<CubeCoord, BattleGridCellComponent> cellLookup;

		private List<BattleGridCellComponent> deploymentCells;

		private Dictionary<GridHighlightType, RuntimeLineGridHighlight> lineHighlight;

		// notify
		private Notify gridChangedHandler;
		public event Notify GridChanged
		{
			add { this.gridChangedHandler += value; }
			remove { this.gridChangedHandler -= value; }
		}

		public void FireGridChanged()
		{
			if(this.gridChangedHandler != null)
			{
				this.gridChangedHandler();
			}
			this.markFireChanged = false;
		}

		public void MarkFireChanged()
		{
			this.markFireChanged = true;
		}

		public void Start()
		{
			this.CreateLookup();
			if(this.autoShowGrid)
			{
				this.ShowGridPrefabs();
			}
		}

		public void Init()
		{
			this.CreateLookup();
			if(ORK.Battle.BattleArena != null)
			{
				this.JoinDeploymentCombatants(ORK.Battle.BattleArena.battleType);
			}
		}

		protected void CreateLookup()
		{
			if(this.cellLookup == null)
			{
				this.cellLookup = new Dictionary<CubeCoord, BattleGridCellComponent>();
				for(int i = 0; i < this.cellRow.Length; i++)
				{
					for(int j = 0; j < this.cellRow[i].cell.Length; j++)
					{
						if(this.cellRow[i].cell[j] != null)
						{
							this.cellLookup.Add(this.cellRow[i].cell[j].CubeCoord, this.cellRow[i].cell[j]);
						}
					}
				}
			}
		}

		protected void Update()
		{
			if(this.markFireChanged)
			{
				this.FireGridChanged();
			}
		}


		/*
		============================================================================
		Grid functions
		============================================================================
		*/
		public void RemoveGrid()
		{
			if(this.cellRow != null)
			{
				for(int i = 0; i < this.cellRow.Length; i++)
				{
					for(int j = 0; j < this.cellRow[i].cell.Length; j++)
					{
						if(this.cellRow[i].cell[j] != null)
						{
							GameObject.DestroyImmediate(this.cellRow[i].cell[j].gameObject);
						}
					}
				}
			}
			this.cellRow = null;
		}

		public BattleGridCellComponent GetCell(int row, int column)
		{
			if(this.cellRow != null &&
				row >= 0 && row < this.cellRow.Length &&
				column >= 0 && column < this.cellRow[row].cell.Length)
			{
				return this.cellRow[row].cell[column];
			}
			return null;
		}

		public BattleGridCellComponent GetCell(CubeCoord coord)
		{
			BattleGridCellComponent cell;
			if(this.cellLookup.TryGetValue(coord, out cell))
			{
				return cell;
			}
			return null;
		}

		public void GetCells(ref List<BattleGridCellComponent> cells, GridCellCheck check)
		{
			for(int i = 0; i < this.cellRow.Length; i++)
			{
				if(this.cellRow[i] != null)
				{
					for(int j = 0; j < this.cellRow[i].cell.Length; j++)
					{
						if(this.cellRow[i].cell[j] != null &&
							(check == null || check(this.cellRow[i].cell[j])))
						{
							cells.Add(this.cellRow[i].cell[j]);
						}
					}
				}
			}
		}

		public BattleGridCellComponent GetNearestCell(Vector3 position, float maxDistance,
			NearestCheck<BattleGridCellComponent> check)
		{
			BattleGridCellComponent nearest = null;

			if(this.cellRow != null)
			{
				float distance = Mathf.Infinity;
				int rowMax = (this.cellRow.Length / 2) - 1;
				int columnMax = (this.cellRow[0].cell.Length / 2) - 1;
				int row = -1;
				int column = -1;
				BattleGridHelper.GetRoughArea(this, position,
					0, 0, this.cellRow.Length, this.cellRow[0].cell.Length,
					ref row, ref column, ref rowMax, ref columnMax);

				if(row > 0 && column > 0)
				{
					for(int i = row - rowMax; i < row + rowMax; i++)
					{
						if(i >= 0 && i < this.cellRow.Length)
						{
							for(int j = column - columnMax; j < column + columnMax; j++)
							{
								if(j >= 0 && j < this.cellRow[i].cell.Length &&
									this.cellRow[i].cell[j] != null &&
									this.cellRow[i].cell[j].enabled &&
									this.cellRow[i].cell[j].gameObject.activeInHierarchy &&
									(check == null || check(this.cellRow[i].cell[j])))
								{
									float tmp = Vector3.Distance(position,
										this.cellRow[i].cell[j].transform.position);
									if(tmp < distance &&
										tmp <= maxDistance)
									{
										nearest = this.cellRow[i].cell[j];
										distance = tmp;
									}
								}
							}
						}
					}
				}

				// check all cells if not yet found
				if(nearest == null)
				{
					distance = Mathf.Infinity;
					for(int i = 0; i < this.cellRow.Length; i++)
					{
						for(int j = 0; j < this.cellRow[i].cell.Length; j++)
						{
							if(this.cellRow[i].cell[j] != null &&
								this.cellRow[i].cell[j].enabled &&
								this.cellRow[i].cell[j].gameObject.activeInHierarchy &&
								(check == null || check(this.cellRow[i].cell[j])))
							{
								float tmp = Vector3.Distance(position,
									this.cellRow[i].cell[j].transform.position);
								if(tmp < distance &&
									tmp <= maxDistance)
								{
									nearest = this.cellRow[i].cell[j];
									distance = tmp;
								}
							}
						}
					}
				}
			}
			return nearest;
		}

		public BattleGridCellComponent GetNearestFreeCell(Combatant combatant)
		{
			BattleGridCellComponent nearest = null;

			if(this.cellRow != null &&
				combatant != null)
			{
				Vector3 position = combatant.GameObject != null ?
					combatant.GameObject.transform.position :
					(combatant.Object.BattleSpot != null ?
						combatant.Object.BattleSpot.transform.position :
						this.transform.position);

				float distance = Mathf.Infinity;
				int rowMax = (this.cellRow.Length / 2) - 1;
				int columnMax = (this.cellRow[0].cell.Length / 2) - 1;
				int row = -1;
				int column = -1;
				BattleGridHelper.GetRoughArea(this, position,
					0, 0, this.cellRow.Length, this.cellRow[0].cell.Length,
					ref row, ref column, ref rowMax, ref columnMax);

				if(row > 0 && column > 0)
				{
					for(int i = row - rowMax; i < row + rowMax; i++)
					{
						if(i >= 0 && i < this.cellRow.Length)
						{
							for(int j = column - columnMax; j < column + columnMax; j++)
							{
								if(j >= 0 && j < this.cellRow[i].cell.Length &&
									this.cellRow[i].cell[j] != null &&
									this.cellRow[i].cell[j].enabled &&
									this.cellRow[i].cell[j].gameObject.activeInHierarchy &&
									!this.cellRow[i].cell[j].IsBlocked &&
									this.cellRow[i].cell[j].IsEmpty)
								{
									float tmp = Vector3.Distance(position,
										this.cellRow[i].cell[j].transform.position);
									if(tmp < distance)
									{
										nearest = this.cellRow[i].cell[j];
										distance = tmp;
									}
								}
							}
						}
					}
				}

				if(nearest == null)
				{
					for(int i = 0; i < this.cellRow.Length; i++)
					{
						for(int j = 0; j < this.cellRow[i].cell.Length; j++)
						{
							if(this.cellRow[i].cell[j] != null &&
								this.cellRow[i].cell[j].enabled &&
								this.cellRow[i].cell[j].gameObject.activeInHierarchy &&
								!this.cellRow[i].cell[j].IsBlocked &&
								this.cellRow[i].cell[j].IsEmpty)
							{
								float tmp = Vector3.Distance(position,
									this.cellRow[i].cell[j].transform.position);
								if(tmp < distance)
								{
									nearest = this.cellRow[i].cell[j];
									distance = tmp;
								}
							}
						}
					}
				}
			}
			return nearest;
		}

		public BattleGridCellComponent GetNearestDeploymentCell(Combatant combatant, bool checkMemberIndex)
		{
			BattleGridCellComponent nearest = null;

			if(this.cellRow != null &&
				combatant != null)
			{
				this.FindDeploymentCells();

				float distance = Mathf.Infinity;
				Vector3 position = combatant.GameObject != null ?
					combatant.GameObject.transform.position :
					(combatant.Object.BattleSpot != null ?
						combatant.Object.BattleSpot.transform.position :
						this.transform.position);
				int memberIndex = checkMemberIndex ? combatant.Group.GetBattleMemberIndex(combatant) : -1;

				for(int i = 0; i < this.deploymentCells.Count; i++)
				{
					if(this.deploymentCells[i] != null &&
						this.deploymentCells[i].enabled &&
						this.deploymentCells[i].gameObject.activeInHierarchy &&
						this.deploymentCells[i].CanDeploy(combatant) &&
						(!checkMemberIndex || this.deploymentCells[i].Deployment.preferredMemberIndex == memberIndex))
					{
						float tmp = Vector3.Distance(position,
							this.deploymentCells[i].transform.position);
						if(tmp < distance)
						{
							nearest = this.deploymentCells[i];
							distance = tmp;
						}
					}
				}

				if(checkMemberIndex &&
					nearest == null)
				{
					return this.GetNearestDeploymentCell(combatant, false);
				}
			}

			return nearest;
		}

		public virtual void JoinDeploymentCombatants(BattleSystemType battleType)
		{
			this.FindDeploymentCells();

			for(int i = 0; i < this.deploymentCells.Count; i++)
			{
				if(this.deploymentCells[i] != null &&
					this.deploymentCells[i].enabled &&
					this.deploymentCells[i].gameObject.activeInHierarchy &&
					GridDeploymentType.Combatant == this.deploymentCells[i].Deployment.type)
				{
					Combatant combatant = this.deploymentCells[i].Deployment.GetDeploymentCombatant(battleType);
					if(combatant != null)
					{
						this.deploymentCells[i].SetCombatant(combatant, false);
						ORK.Battle.Join(combatant);
					}
				}
			}
		}

		protected virtual void FindDeploymentCells()
		{
			if(this.deploymentCells == null)
			{
				this.deploymentCells = new List<BattleGridCellComponent>();

				for(int i = 0; i < this.cellRow.Length; i++)
				{
					for(int j = 0; j < this.cellRow[i].cell.Length; j++)
					{
						if(this.cellRow[i].cell[j] != null &&
							this.cellRow[i].cell[j].IsDeployment)
						{
							this.deploymentCells.Add(this.cellRow[i].cell[j]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public void ShowGridPrefabs()
		{
			for(int i = 0; i < this.cellRow.Length; i++)
			{
				if(this.cellRow[i] != null)
				{
					for(int j = 0; j < this.cellRow[i].cell.Length; j++)
					{
						if(this.cellRow[i].cell[j] != null)
						{
							this.cellRow[i].cell[j].ShowPrefab();
						}
					}
				}
			}
		}

		public void HideGridPrefabs()
		{
			for(int i = 0; i < this.cellRow.Length; i++)
			{
				if(this.cellRow[i] != null)
				{
					for(int j = 0; j < this.cellRow[i].cell.Length; j++)
					{
						if(this.cellRow[i].cell[j] != null)
						{
							this.cellRow[i].cell[j].HidePrefab();
						}
					}
				}
			}
		}

		public void RemoveGridPrefabs()
		{
			for(int i = 0; i < this.cellRow.Length; i++)
			{
				if(this.cellRow[i] != null)
				{
					for(int j = 0; j < this.cellRow[i].cell.Length; j++)
					{
						if(this.cellRow[i].cell[j] != null)
						{
							this.cellRow[i].cell[j].DestroyPrefab();
						}
					}
				}
			}
		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public bool HighlightsHidden
		{
			get { return this.highlightsHidden; }
			set
			{
				if(this.highlightsHidden != value)
				{
					this.highlightsHidden = value;

					for(int i = 0; i < this.cellRow.Length; i++)
					{
						if(this.cellRow[i] != null)
						{
							for(int j = 0; j < this.cellRow[i].cell.Length; j++)
							{
								if(this.cellRow[i].cell[j] != null)
								{
									this.cellRow[i].cell[j].HideHighlights(this.highlightsHidden);
								}
							}
						}
					}

					if(this.lineHighlight != null)
					{
						foreach(KeyValuePair<GridHighlightType, RuntimeLineGridHighlight> pair in this.lineHighlight)
						{
							pair.Value.Hidden = ORK.Battle.SystemSettings.gridHighlights.IsHidden(pair.Key);
						}
					}
				}
			}
		}

		public void LineHighlight(GridHighlightType type, LineGridHighlight settings, BattleGridCellComponent cell)
		{
			if(this.lineHighlight == null)
			{
				this.lineHighlight = new Dictionary<GridHighlightType, RuntimeLineGridHighlight>();
			}
			RuntimeLineGridHighlight highlight;
			if(!this.lineHighlight.TryGetValue(type, out highlight))
			{
				highlight = new RuntimeLineGridHighlight(settings, type);
				this.lineHighlight.Add(type, highlight);
			}
			highlight.Highlight(cell);
		}

		public void LineHighlight(GridHighlightType type, LineGridHighlight settings, List<BattleGridCellComponent> cells)
		{
			if(this.lineHighlight == null)
			{
				this.lineHighlight = new Dictionary<GridHighlightType, RuntimeLineGridHighlight>();
			}
			RuntimeLineGridHighlight highlight;
			if(!this.lineHighlight.TryGetValue(type, out highlight))
			{
				highlight = new RuntimeLineGridHighlight(settings, type);
				this.lineHighlight.Add(type, highlight);
			}
			highlight.Highlight(cells);
		}

		public void StopLineHighlight(GridHighlightType type, LineGridHighlight settings, BattleGridCellComponent cell)
		{
			if(this.lineHighlight != null)
			{
				RuntimeLineGridHighlight highlight;
				if(this.lineHighlight.TryGetValue(type, out highlight))
				{
					highlight.StopHighlight(cell);
				}
			}
		}

		public void StopLineHighlight(GridHighlightType type, LineGridHighlight settings, List<BattleGridCellComponent> cells)
		{
			if(this.lineHighlight != null)
			{
				RuntimeLineGridHighlight highlight;
				if(this.lineHighlight.TryGetValue(type, out highlight))
				{
					highlight.StopHighlight(cells);
				}
			}
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "BattleGrid.psd");

			if(this.showEditorGrid &&
				this.showEditorPrefabs &&
				this.showEditorUnselected &&
				!Application.isPlaying)
			{
				this.EditorShowPrefabs();
			}
		}

		public void EditorShowPrefabs()
		{
			if(this.cellRow != null &&
				!this.editorPrefabsShowing)
			{
				this.editorPrefabsShowing = true;

				for(int i = 0; i < this.cellRow.Length; i++)
				{
					if(this.cellRow[i] != null)
					{
						for(int j = 0; j < this.cellRow[i].cell.Length; j++)
						{
							if(this.cellRow[i].cell[j] != null)
							{
								this.cellRow[i].cell[j].EditorShowPrefab();
							}
						}
					}
				}
			}
		}

		public void EditorDestroyPrefabs()
		{
			this.editorPrefabsShowing = false;

			if(this.cellRow != null)
			{
				for(int i = 0; i < this.cellRow.Length; i++)
				{
					if(this.cellRow[i] != null)
					{
						for(int j = 0; j < this.cellRow[i].cell.Length; j++)
						{
							if(this.cellRow[i].cell[j] != null &&
								this.cellRow[i].cell[j].PrefabInstance != null)
							{
								GameObject.DestroyImmediate(this.cellRow[i].cell[j].PrefabInstance);
							}
						}
					}
				}
			}
		}
	}
}
