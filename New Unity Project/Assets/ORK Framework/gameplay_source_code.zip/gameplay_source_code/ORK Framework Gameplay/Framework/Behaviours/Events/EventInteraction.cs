
using ORKFramework;
using ORKFramework.Events;
using System.Collections;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Events/Event Interaction")]
	public class EventInteraction : BaseInteraction, IEventStarter
	{
		public ORKGameEvent eventAsset;

		public InteractionType interactionType = InteractionType.Event;

		public bool repeatExecution = false;

		public bool deactivateAfter = false;

		public bool turnToEvent = true;

		public bool turnToPlayer = false;

		public bool stopOnDestroy = false;

		public Transform[] actor = new Transform[0];

		public Transform[] waypoint = new Transform[0];

		public GameObject[] prefab = new GameObject[0];

		public AudioClip[] audioClip = new AudioClip[0];

		// time settings
		public float timeBefore = 0.0f;

		public float timeAfter = 0.0f;


		// ingame
		public GameEvent gameEvent;

		private bool markSceneChangeDestroy = false;

		private bool sceneChangedDestroy = false;

		public GameObject GameObject
		{
			get { return this.gameObject; }
		}


		/*
		============================================================================
		Interaction type functions
		============================================================================
		*/
		public override InteractionType Type
		{
			get { return this.interactionType; }
		}


		/*
		============================================================================
		Event file functions
		============================================================================
		*/
		public bool EventFound
		{
			get { return this.gameEvent != null; }
		}

		public void LoadEvent()
		{
			this.gameEvent = null;
			if(this.eventAsset != null)
			{
				this.gameEvent = new GameEvent();
				this.gameEvent.SetData(this.eventAsset.GetData().ToDataObject());

				// match inspector settings
				if(this.gameEvent != null &&
					Application.isEditor && !Application.isPlaying)
				{
					// actors
					Transform[] tmp = this.actor;
					this.actor = new Transform[this.gameEvent.actor.Length];
					for(int i = 0; i < this.actor.Length; i++)
					{
						if(i < tmp.Length &&
							ActorType.Object == this.gameEvent.actor[i].type &&
							!this.gameEvent.actor[i].isFindObject &&
							!this.gameEvent.actor[i].isEventObject)
						{
							this.actor[i] = tmp[i];
						}
					}
					// waypoints
					tmp = this.waypoint;
					this.waypoint = new Transform[this.gameEvent.waypoint.Length];
					for(int i = 0; i < this.waypoint.Length; i++)
					{
						if(i < tmp.Length &&
							!this.gameEvent.waypoint[i].findObject)
						{
							this.waypoint[i] = tmp[i];
						}
					}
					// prefabs
					GameObject[] tmp2 = this.prefab;
					this.prefab = new GameObject[this.gameEvent.prefab.Length];
					for(int i = 0; i < this.prefab.Length; i++)
					{
						if(i < tmp2.Length &&
							this.gameEvent.prefab[i].prefab == null)
						{
							this.prefab[i] = tmp2[i];
						}
					}
					// audio clips
					AudioClip[] tmp3 = this.audioClip;
					this.audioClip = new AudioClip[this.gameEvent.audioClip.Length];
					for(int i = 0; i < this.audioClip.Length; i++)
					{
						if(i < tmp3.Length &&
							this.gameEvent.audioClip[i].clip == null)
						{
							this.audioClip[i] = tmp3[i];
						}
					}
				}
			}
		}

		void Start()
		{
			if(!this.CheckAutoDestroy())
			{
				this.LoadEvent();
				this.CheckAutoStart();
			}
		}

		void OnDestroy()
		{
			if(this.stopOnDestroy && 
				this.eventStarted &&
				this.gameEvent != null)
			{
				this.gameEvent.StopEvent(true);
				this.SetVariables();
			}
		}

		private void CheckAutoStart()
		{
			if(EventStartType.Autostart == this.startType)
			{
				if(this.CheckConditions())
				{
					this.DoAutoStart();
				}
				else if(this.repeatExecution)
				{
					StartCoroutine(this.CheckAutoStart2());
				}
			}
		}

		private IEnumerator CheckAutoStart2()
		{
			if(this.timeAfter > 0)
			{
				yield return new WaitForSeconds(this.timeAfter);
			}
			else
			{
				yield return new WaitForSeconds(0.1f);
			}
			this.CheckAutoStart();
		}

		void Update()
		{
			if(!ORK.Game.Paused && this.eventStarted &&
				this.gameEvent != null && this.gameEvent.Executing)
			{
				this.gameEvent.Tick(ORK.Game.DeltaTime);
			}
			else
			{
				this.KeyPress();
			}
		}

		public override void StartEvent(GameObject startingObject)
		{
			this.CancelInvoke("AutoDestroy");
			this.isInvoking = false;

			this.StartCoroutine(this.StartEvent2(startingObject));
		}

		private IEnumerator StartEvent2(GameObject startingObject)
		{
			if(!this.eventStarted && this.gameEvent != null &&
				(ORK.Control.CanInteract || !this.gameEvent.blockingEvent))
			{
				this.eventStarted = true;

				// do turns
				GameObject p = startingObject != null ? startingObject : ORK.Game.GetPlayer();
				if(this.turnToEvent && p != null)
				{
					if(HorizontalPlaneType.XY == ORK.GameSettings.horizontalPlane)
					{
						p.transform.LookAt(new Vector3(this.transform.position.x, 
							this.transform.position.y, p.transform.position.z));
					}
					else
					{
						p.transform.LookAt(new Vector3(this.transform.position.x, 
							p.transform.position.y, this.transform.position.z));
					}
				}
				if(this.turnToPlayer && p != null)
				{
					if(HorizontalPlaneType.XY == ORK.GameSettings.horizontalPlane)
					{
						this.transform.LookAt(new Vector3(p.transform.position.x, p.transform.position.y, this.transform.position.z));
					}
					else
					{
						this.transform.LookAt(new Vector3(p.transform.position.x, this.transform.position.y, p.transform.position.z));
					}
				}

				if(this.timeBefore > 0)
				{
					yield return new WaitForSeconds(this.timeBefore);
				}
				this.gameEvent.StartEvent(this, startingObject);
			}
		}

		public void DontDestroy()
		{
			this.markSceneChangeDestroy = true;
			this.sceneChangedDestroy = false;
			this.gameObject.transform.SetParent(null);
			GameObject.DontDestroyOnLoad(this.transform.root);
		}

		public void OnSceneLoaded()
		{
			if(this.markSceneChangeDestroy)
			{
				this.sceneChangedDestroy = true;
			}
		}

		public void EventEnded()
		{
			this.StartCoroutine(this.EventEnded2());
		}

		private IEnumerator EventEnded2()
		{
			if(this.timeAfter > 0)
			{
				yield return new WaitForSeconds(this.timeAfter);
			}
			else
			{
				yield return new WaitForSeconds(0);
			}

			this.SetVariables();

			this.eventStarted = false;

			if(this.deactivateAfter)
			{
				this.gameObject.SetActive(false);
			}
			else
			{
				if(EventStartType.Autostart == this.startType &&
					this.repeatExecution)
				{
					this.CheckAutoStart();
				}
				if(this.repeatDestroy)
				{
					this.CheckAutoDestroy();
				}
			}

			if(this.markSceneChangeDestroy)
			{
				if(this.sceneChangedDestroy)
				{
					UnityWrapper.Destroy(this.gameObject);
				}
			}
		}

		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "GameEvent.psd");
		}
	}
}
