
using ORKFramework;
using System.Collections.Generic;
using System.Collections;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	public delegate void GetColorFade(ref float time, ref bool reverting);

	[AddComponentMenu("")]
	public class ColorFader : MonoBehaviour
	{
		protected FadeColorSettings settings;

		protected bool inPause = false;

		protected Renderer rendererComponent;

		protected List<Renderer> childRenderers;

		protected bool renderersInitialized = false;


		// time
		protected GetColorFade linkedTime;

		protected float time;

		protected float time2;


		// fade
		protected bool fadeChildren;


		// colors
		protected Color color;

		protected Color start;


		// options
		protected bool fading = false;

		protected bool flash = false;

		protected bool blink = false;

		protected bool reverting = false;


		// current
		protected bool useCurrent = false;

		protected int currentIndex = 0;

		protected List<Color> currentColors;


		// material
		protected bool useShared = false;

		protected string materialProperty = "_Color";

		protected bool isFloat = false;


		// display texts
		protected FlyingText displayText;

		protected Color displayTextStart;

		private void IsFading(bool fade)
		{
			this.fading = fade;
			this.enabled = fade;
		}

		public void Clear(bool initRenderers)
		{
			this.fading = false;
			this.flash = false;
			this.blink = false;
			this.reverting = false;

			this.useCurrent = false;
			this.useShared = false;
			this.isFloat = false;
			this.materialProperty = "_Color";

			if(initRenderers)
			{
				if(!this.renderersInitialized)
				{
					if(this.fadeChildren)
					{
						ArrayHelper.GetBlank<Renderer>(ref this.childRenderers);
						this.GetComponentsInChildren<Renderer>(this.childRenderers);
					}
					else
					{
						this.rendererComponent = this.GetComponent<Renderer>();
					}

					this.displayText = this.transform.root.GetComponentInChildren<FlyingText>();
				}

				if(this.displayText != null)
				{
					this.displayTextStart = this.displayText.Color;
				}
			}
		}

		public void OneTimeInit()
		{
			if(!this.renderersInitialized)
			{
				ArrayHelper.GetBlank<Renderer>(ref this.childRenderers);
				this.GetComponentsInChildren<Renderer>(this.childRenderers);

				this.rendererComponent = this.GetComponent<Renderer>();

				this.displayText = this.transform.root.GetComponentInChildren<FlyingText>();

				this.renderersInitialized = true;
			}
		}

		public GetColorFade LinkedTime
		{
			get { return this.linkedTime; }
			set { this.linkedTime = value; }
		}


		/*
		============================================================================
		Fade functions
		============================================================================
		*/
		public void Fade(FadeColorSettings settings, bool fadeChildren, bool shared, string matProp, bool iflo)
		{
			this.fadeChildren = fadeChildren;
			this.Clear(true);

			this.settings = settings;
			this.start = new Color(1, 1, 1, 1);
			this.settings.GetStart(ref this.start);

			this.time = 0;
			this.time2 = this.settings.time;
			this.useShared = shared;
			this.materialProperty = matProp;
			this.isFloat = iflo;

			if(this.settings.fromCurrent)
			{
				this.currentColors = null;
				this.StoreCurrentColors();
				this.useCurrent = true;
			}
			else if(this.displayText)
			{
				this.displayTextStart = this.start;
			}

			this.IsFading(true);
		}


		/*
		============================================================================
		Flash functions
		============================================================================
		*/
		public void Flash(FadeColorSettings settings, bool fadeChildren, bool shared, string matProp, bool iflo)
		{
			this.fadeChildren = fadeChildren;
			this.Clear(true);

			this.settings = settings;
			this.start = new Color(1, 1, 1, 1);
			this.settings.GetStart(ref this.start);

			this.time = 0;
			this.time2 = this.settings.time / 2;
			this.useShared = shared;
			this.materialProperty = matProp;
			this.isFloat = iflo;

			if(this.settings.fromCurrent)
			{
				this.currentColors = null;
				this.StoreCurrentColors();
				this.useCurrent = true;
			}
			else if(this.displayText)
			{
				this.displayTextStart = this.start;
			}

			this.flash = true;
			this.IsFading(true);
		}


		/*
		============================================================================
		Blink functions
		============================================================================
		*/
		public void Blink(FadeColorSettings settings, bool fadeChildren)
		{
			this.fadeChildren = fadeChildren;
			this.Clear(true);

			this.settings = settings;
			this.start = new Color(1, 1, 1, 1);
			this.settings.GetStart(ref this.start);

			this.time = 0;
			this.time2 = this.settings.time;

			if(this.settings.fromCurrent)
			{
				this.currentColors = null;
				this.StoreCurrentColors();
				this.useCurrent = true;
			}
			else if(this.displayText)
			{
				this.displayTextStart = this.start;
			}

			this.flash = true;
			this.blink = true;
			this.IsFading(true);
		}

		public void StopBlink()
		{
			if(this.blink)
			{
				if(this.useCurrent)
				{
					this.time = this.time2;
					this.reverting = true;
					this.currentIndex = 0;

					if(this.fadeChildren &&
						this.childRenderers != null)
					{
						for(int i = 0; i < this.childRenderers.Count; i++)
						{
							if(this.childRenderers[i] != null)
							{
								this.DoFadeCurrent(this.childRenderers[i]);
							}
						}
					}
					else if(this.rendererComponent != null)
					{
						this.DoFadeCurrent(this.rendererComponent);
					}
				}
				else
				{
					this.color = this.start;

					if(this.fadeChildren &&
						this.childRenderers != null)
					{
						for(int i = 0; i < this.childRenderers.Count; i++)
						{
							if(this.childRenderers[i] != null)
							{
								this.DoFade(this.childRenderers[i]);
							}
						}
					}
					else if(this.rendererComponent != null)
					{
						this.DoFade(this.rendererComponent);
					}
				}
				this.Clear(false);
			}
		}


		/*
		============================================================================
		Change functions
		============================================================================
		*/
		void Update()
		{
			if(this.fading && !ORK.Game.Paused)
			{
				if(this.linkedTime != null)
				{
					this.linkedTime(ref this.time, ref this.reverting);
				}
				else
				{
					this.time += this.inPause ? ORK.Core.GUITimeDelta : ORK.Game.DeltaTime;
				}

				if(this.useCurrent)
				{
					this.currentIndex = 0;

					if(this.displayText)
					{
						if(this.reverting)
						{
							Color c = this.displayText.Color;
							this.settings.RevertFade(ref c, this.displayTextStart, this.time, this.time2);
							this.displayText.Color = c;
						}
						else
						{
							Color c = this.displayText.Color;
							this.settings.Fade(ref c, this.displayTextStart, this.time, this.time2);
							this.displayText.Color = c;
						}
					}
					if(this.fadeChildren &&
						this.childRenderers != null)
					{
						for(int i = 0; i < this.childRenderers.Count; i++)
						{
							if(this.childRenderers[i] != null)
							{
								this.DoFadeCurrent(this.childRenderers[i]);
							}
						}
					}
					else if(this.rendererComponent != null)
					{
						this.DoFadeCurrent(this.rendererComponent);
					}
				}
				else
				{
					if(this.reverting)
					{
						this.settings.RevertFade(ref this.color, this.start, this.time, this.time2);
					}
					else
					{
						this.settings.Fade(ref this.color, this.start, this.time, this.time2);
					}

					if(this.displayText)
					{
						Color c = this.displayText.Color;
						if(this.settings.alpha)
						{
							c.a = this.color.a;
						}
						if(this.settings.red)
						{
							c.r = this.color.r;
						}
						if(this.settings.green)
						{
							c.g = this.color.g;
						}
						if(this.settings.blue)
						{
							c.b = this.color.b;
						}
						this.displayText.Color = c;
					}
					if(this.fadeChildren &&
						this.childRenderers != null)
					{
						for(int i = 0; i < this.childRenderers.Count; i++)
						{
							if(this.childRenderers[i] != null)
							{
								this.DoFade(this.childRenderers[i]);
							}
						}
					}
					else if(this.rendererComponent != null)
					{
						this.DoFade(this.rendererComponent);
					}
				}

				if(this.time >= this.time2)
				{
					if(this.flash)
					{
						this.reverting = true;
						this.time = 0;
						this.flash = false;
					}
					else if(this.blink)
					{
						this.reverting = false;
						this.time = 0;
						this.flash = true;
					}
					else
					{
						this.currentColors = null;
						this.IsFading(false);
					}
				}
			}
		}


		/*
		============================================================================
		Fading functions
		============================================================================
		*/
		protected void DoFade(Renderer rend)
		{
			if(rend is SpriteRenderer && !this.isFloat &&
				this.materialProperty == "_Color")
			{
				Color c = ((SpriteRenderer)rend).color;
				if(this.settings.alpha)
				{
					c.a = this.color.a;
				}
				if(this.settings.red)
				{
					c.r = this.color.r;
				}
				if(this.settings.green)
				{
					c.g = this.color.g;
				}
				if(this.settings.blue)
				{
					c.b = this.color.b;
				}
				((SpriteRenderer)rend).color = c;
			}
			else
			{
				Material[] materials;
				if(this.useShared)
				{
					materials = rend.sharedMaterials;
				}
				else
				{
					materials = rend.materials;
				}

				for(int i = 0; i < materials.Length; i++)
				{
					if(materials[i].HasProperty(this.materialProperty))
					{
						if(this.isFloat)
						{
							materials[i].SetFloat(this.materialProperty, this.color.a);
						}
						else
						{
							Color c = materials[i].GetColor(this.materialProperty);
							if(this.settings.alpha)
							{
								c.a = this.color.a;
							}
							if(this.settings.red)
							{
								c.r = this.color.r;
							}
							if(this.settings.green)
							{
								c.g = this.color.g;
							}
							if(this.settings.blue)
							{
								c.b = this.color.b;
							}
							materials[i].SetColor(this.materialProperty, c);
						}
					}
				}
			}
		}

		protected void DoFadeCurrent(Renderer rend)
		{
			if(rend is SpriteRenderer && !this.isFloat &&
				this.materialProperty == "_Color")
			{
				Color c = ((SpriteRenderer)rend).color;
				if(this.reverting)
				{
					this.settings.RevertFade(ref c, this.currentColors[this.currentIndex], this.time, this.time2);
				}
				else
				{
					this.settings.Fade(ref c, this.currentColors[this.currentIndex], this.time, this.time2);
				}
				((SpriteRenderer)rend).color = c;
			}
			else
			{
				Material[] materials;
				if(this.useShared)
				{
					materials = rend.sharedMaterials;
				}
				else
				{
					materials = rend.materials;
				}

				for(int i = 0; i < materials.Length; i++)
				{
					if(materials[i].HasProperty(this.materialProperty) &&
					this.currentIndex < this.currentColors.Count)
					{
						if(this.isFloat)
						{
							Color c = new Color(0, 0, 0, materials[i].GetFloat(this.materialProperty));
							if(this.reverting)
							{
								this.settings.RevertFade(ref c, this.currentColors[this.currentIndex], this.time, this.time2);
							}
							else
							{
								this.settings.Fade(ref c, this.currentColors[this.currentIndex], this.time, this.time2);
							}
							materials[i].SetFloat(this.materialProperty, c.a);
						}
						else
						{
							Color c = materials[i].GetColor(this.materialProperty);
							if(this.reverting)
							{
								this.settings.RevertFade(ref c, this.currentColors[this.currentIndex], this.time, this.time2);
							}
							else
							{
								this.settings.Fade(ref c, this.currentColors[this.currentIndex], this.time, this.time2);
							}
							materials[i].SetColor(this.materialProperty, c);
						}
						this.currentIndex++;
					}
				}
			}
		}


		/*
		============================================================================
		Store functions
		============================================================================
		*/
		public void StoreCurrentColors()
		{
			if(this.currentColors == null)
			{
				this.currentColors = new List<Color>();

				if(this.fadeChildren &&
					this.childRenderers != null)
				{
					for(int i = 0; i < this.childRenderers.Count; i++)
					{
						if(this.childRenderers[i] != null)
						{
							this.StoreRenderer(this.childRenderers[i]);
						}
					}
				}
				else if(this.rendererComponent != null)
				{
					this.StoreRenderer(this.rendererComponent);
				}
			}
		}

		protected void StoreRenderer(Renderer rend)
		{
			if(rend is SpriteRenderer && !this.isFloat &&
				this.materialProperty == "_Color")
			{
				this.currentColors.Add(((SpriteRenderer)rend).color);
			}
			else
			{
				Material[] materials;
				if(this.useShared)
				{
					materials = rend.sharedMaterials;
				}
				else
				{
					materials = rend.materials;
				}

				for(int i = 0; i < materials.Length; i++)
				{
					if(materials[i].HasProperty(this.materialProperty))
					{
						if(this.isFloat)
						{
							this.currentColors.Add(new Color(0, 0, 0, materials[i].GetFloat(this.materialProperty)));
						}
						else
						{
							this.currentColors.Add(materials[i].GetColor(this.materialProperty));
						}
					}
				}
			}
		}


		/*
		============================================================================
		Store functions
		============================================================================
		*/
		public void RestoreCurrentColors()
		{
			if(this.currentColors != null)
			{
				int index = 0;
				if(this.fadeChildren &&
					this.childRenderers != null)
				{
					for(int i = 0; i < this.childRenderers.Count; i++)
					{
						if(this.childRenderers[i] != null)
						{
							this.RestoreRenderer(this.childRenderers[i], ref index);
						}
					}
				}
				else if(this.rendererComponent != null)
				{
					this.RestoreRenderer(this.rendererComponent, ref index);
				}
			}
		}

		protected void RestoreRenderer(Renderer rend, ref int index)
		{
			if(index < this.currentColors.Count)
			{
				if(rend is SpriteRenderer && !this.isFloat &&
					this.materialProperty == "_Color")
				{
					((SpriteRenderer)rend).color = this.currentColors[index++];
				}
				else
				{
					Material[] materials;
					if(this.useShared)
					{
						materials = rend.sharedMaterials;
					}
					else
					{
						materials = rend.materials;
					}

					for(int i = 0; i < materials.Length; i++)
					{
						if(materials[i].HasProperty(this.materialProperty))
						{
							if(this.isFloat)
							{
								materials[i].SetFloat(this.materialProperty, this.currentColors[index++].a);
							}
							else
							{
								materials[i].SetColor(this.materialProperty, this.currentColors[index++]);
							}
						}
					}
				}
			}
		}
	}
}
