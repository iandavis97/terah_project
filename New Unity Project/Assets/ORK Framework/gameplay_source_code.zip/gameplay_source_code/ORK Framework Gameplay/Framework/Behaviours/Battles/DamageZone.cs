
using ORKFramework;
using ORKFramework.Events;
using UnityEngine;
using System.Collections.Generic;
using System;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Battles/Damage Zone")]
	public class DamageZone : DamageBase, IEventStarter
	{
		public float damageFactor = 1.0f;


		// block settings
		public bool blockDamage = false;

		public bool showBlockNotification = false;


		// sound settings
		public bool playSound = false;

		public PlayAudioCombatantForComponent sound;


		// game event settings
		public ORKGameEvent eventAsset;

		public void Damage(BaseAction action)
		{
			if(this.playSound && this.sound != null)
			{
				this.sound.Play(this.combatant);
			}

			if(this.blockDamage)
			{
				if(this.showBlockNotification &&
					!this.combatant.Setting.blockFlyingTextsBlocking)
				{
					ORK.BattleTexts.ShowBlockFlyingText("", this.combatant, this.gameObject);
				}
			}
			else if(TargetHelper.CheckDeath(this.combatant, action.TargetDead))
			{
				List<Combatant> target = new List<Combatant>();
				target.Add(this.combatant);

				DamageDealerActivation ddActivation = action.GetDamageDealerActivation();
				if(ddActivation != null &&
					ddActivation.battleAnimation.animate)
				{
					List<BattleEvent> events = new List<BattleEvent>();
					ddActivation.battleAnimation.GetBattleAnimation(action.User, ref events);
					new DamageDealerAction(action, target, events).PerformAction();
				}
				else
				{
					action.Calculate(target, this.damageFactor, true);
				}
			}

			if(this.eventAsset != null)
			{
				ORK.Core.GameObject.AddComponent<GameEventTicker>().StartEvent(
					this.eventAsset, this,
					action.User != null ? action.User.GameObject : this.gameObject,
					null, false);
			}
		}

		public void EventEnded()
		{

		}

		public void DontDestroy()
		{
			GameObject.DontDestroyOnLoad(this.transform.root);
		}

		public void OnSceneLoaded()
		{

		}

		public GameObject GameObject
		{
			get
			{
				return this.gameObject;
			}
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(this.transform.position, "DamageZone.psd");
		}
	}
}
