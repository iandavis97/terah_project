
using UnityEngine;
using ORKFramework;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Events/Music Player")]
	public class MusicPlayer : BaseInteraction
	{
		public int channel = 0;

		[ORKEditorInfo(ORKDataType.MusicClip)]
		public int musicID = 0;

		public float targetVolume = 1;

		public bool fromCurrentTime = false;

		public MusicPlayType playType = MusicPlayType.Play;

		public float fadeTime = 1;

		public EaseType interpolate = EaseType.Linear;

		public override void StartEvent(GameObject startingObject)
		{
			this.CancelInvoke("AutoDestroy");
			this.isInvoking = false;

			if(MusicPlayType.Play == this.playType)
			{
				ORK.Music[this.channel].Play(this.musicID,
					this.targetVolume, this.fromCurrentTime);
			}
			else if(MusicPlayType.Stop == this.playType)
			{
				ORK.Music[this.channel].Stop();
			}
			else if(MusicPlayType.FadeIn == this.playType)
			{
				ORK.Music[this.channel].FadeIn(this.musicID,
					this.targetVolume, this.fromCurrentTime,
					this.fadeTime, this.interpolate);
			}
			else if(MusicPlayType.FadeOut == this.playType)
			{
				ORK.Music[this.channel].FadeOut(this.fadeTime, this.interpolate);
			}
			else if(MusicPlayType.FadeTo == this.playType)
			{
				ORK.Music[this.channel].FadeTo(this.musicID,
					this.targetVolume, this.fromCurrentTime, 
					this.fadeTime, this.interpolate);
			}

			this.SetVariables();
		}

		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "MusicPlayer.psd");
		}


		/*
		============================================================================
		Interaction type functions
		============================================================================
		*/
		public override InteractionType Type
		{
			get { return InteractionType.MusicPlayer; }
		}
	}
}
