
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using ORKFramework;
using ORKFramework.UI;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	public class GUIBoxComponent : MonoBehaviour
	{
		// box/gui
		private GUIBox box;

		private RectTransform containerTransform;

		private RectTransform boxTransform;

		private CanvasGroup canvasGroup;

		private GameObject nameBox;


		// updates
		private bool contentUpdated = false;

		private Color lastColor;

		private List<CanvasRenderer> canvasRenderer = new List<CanvasRenderer>();

		private bool[] doFlash;


		// pooling recalculate
		private List<Text> textLabels = new List<Text>();

		private List<RawImage> imageLabels = new List<RawImage>();

		private List<RectTransform> noPrefabs = new List<RectTransform>();

		private List<UIPoolComponent> prefabs = new List<UIPoolComponent>();

		private RawImage portraitLabel;


		// pooling unregister
		private List<Text> unregisterTextLabels = new List<Text>();

		private List<RawImage> unregisterImageLabels = new List<RawImage>();

		private List<UIPoolComponent> unregisterPrefabs = new List<UIPoolComponent>();


		// shortcuts
		private List<ShortcutLabel> shortcuts;

		public void Init(GUIBox guiBox, RectTransform containerTransform, RectTransform boxTransform, CanvasGroup canvasGroup)
		{
			this.box = guiBox;
			this.containerTransform = containerTransform;
			this.boxTransform = boxTransform;
			this.canvasGroup = canvasGroup;

			this.UpdateBox();
		}

		public void Clear()
		{
			this.textLabels.Clear();
			this.imageLabels.Clear();
			this.noPrefabs.Clear();
			this.prefabs.Clear();
			this.unregisterImageLabels.Clear();
			this.unregisterPrefabs.Clear();
			if(this.shortcuts != null)
			{
				this.shortcuts.Clear();
			}
		}


		/*
		============================================================================
		Pool functions
		============================================================================
		*/
		public void ToPoolRecalculate()
		{
			ORK.GUI.NewUIPool.Add(this.textLabels, this.imageLabels, this.prefabs);
			for(int i = 0; i < this.noPrefabs.Count; i++)
			{
				UnityWrapper.Destroy(this.noPrefabs[i].gameObject);
			}
			this.textLabels.Clear();
			this.imageLabels.Clear();
			this.noPrefabs.Clear();
			this.prefabs.Clear();
			if(this.shortcuts != null)
			{
				this.shortcuts.Clear();
			}

			this.canvasRenderer.Clear();
			this.doFlash = null;
		}

		public void ToPoolUnregister()
		{
			this.box = null;
			this.ToPoolRecalculate();
			this.PortraitLabelToPool();
			ORK.GUI.NewUIPool.Add(this.unregisterTextLabels, this.unregisterImageLabels, this.unregisterPrefabs);
			this.unregisterTextLabels.Clear();
			this.unregisterImageLabels.Clear();
			this.unregisterPrefabs.Clear();

			if(this.nameBox != null &&
				this.nameBox.GetComponent<UIPoolComponent>() == null)
			{
				UnityWrapper.Destroy(this.nameBox);
			}
		}

		public void AddTextLabel(Text label)
		{
			this.textLabels.Add(label);
		}

		public void AddTextLabelUnregister(Text label)
		{
			this.unregisterTextLabels.Add(label);
		}

		public void AddImageLabel(RawImage label)
		{
			this.imageLabels.Add(label);
		}

		public void AddImageLabelUnregister(RawImage label)
		{
			this.unregisterImageLabels.Add(label);
		}

		public void AddNoPrefab(RectTransform instance)
		{
			this.noPrefabs.Add(instance);
		}

		public void AddPrefab(GameObject prefab, GameObject instance)
		{
			UIPoolComponent comp = ComponentHelper.Get<UIPoolComponent>(instance);
			comp.Prefab = prefab;
			this.prefabs.Add(comp);
		}

		public void AddPrefabUnregister(GameObject prefab, GameObject instance)
		{
			UIPoolComponent comp = ComponentHelper.Get<UIPoolComponent>(instance);
			comp.Prefab = prefab;
			this.unregisterPrefabs.Add(comp);
		}

		public void AddShortcutLabel(ShortcutLabel shortcutLabel)
		{
			if(this.shortcuts == null)
			{
				this.shortcuts = new List<ShortcutLabel>();
			}
			if(!this.shortcuts.Contains(shortcutLabel))
			{
				this.shortcuts.Add(shortcutLabel);
			}
		}

		public void SetPortraitLabel(RawImage label)
		{
			this.portraitLabel = label;
		}

		public void PortraitLabelToPool()
		{
			ORK.GUI.NewUIPool.AddImageLabel(this.portraitLabel);
			this.portraitLabel = null;
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public bool ContentUpdated
		{
			get { return this.contentUpdated; }
			set
			{
				this.canvasRenderer.Clear();
				this.doFlash = null;
				this.contentUpdated = value;
			}
		}

		public GUIBox GUIBox
		{
			get { return this.box; }
		}

		public GameObject NameBox
		{
			get { return this.nameBox; }
			set
			{
				this.nameBox = value;
				this.canvasRenderer.Clear();
				this.doFlash = null;
			}
		}

		public void CloseBox()
		{
			if(this.box != null &&
				!this.box.IsClosing && !this.box.IsClosed)
			{
				this.box.InitOut();
			}
		}

		public void UpdateBox()
		{
			if(this.box != null)
			{
				// scale display
				if(this.box.currentScale != Vector2.one)
				{
					Vector3 guiScale = this.box.GUILayer.useFullScreen ?
						new Vector3(ORK.Core.RealScale.x * this.box.currentScale.x,
							ORK.Core.RealScale.y * this.box.currentScale.y, 1) :
						new Vector3(this.box.GUILayer.UIMatrix.Scale.x * this.box.currentScale.x,
							this.box.GUILayer.UIMatrix.Scale.y * this.box.currentScale.y, 1);
					if(guiScale.x <= 0.0001f)
					{
						guiScale.x = 0.0001f;
					}
					if(guiScale.y <= 0.0001f)
					{
						guiScale.y = 0.0001f;
					}

					Vector3 tmpPos = GUIHelper.GetRectAnchor(this.box.windowRect, this.box.scaleAnchor);
					tmpPos.x *= this.box.GUILayer.UIMatrix.Scale.x;
					tmpPos.y *= -this.box.GUILayer.UIMatrix.Scale.y;

					// set position of container
					this.containerTransform.anchoredPosition = Matrix4x4.TRS(
						(this.box.GUILayer.useFullScreen ? Vector3.zero : this.box.GUILayer.UIMatrix.NewUITranslate) + tmpPos -
							new Vector3(tmpPos.x * this.box.currentScale.x, tmpPos.y * this.box.currentScale.y, 0),
						Quaternion.identity, guiScale).MultiplyPoint3x4(new Vector2(
								this.box.windowRect.x,
								-this.box.windowRect.y));

					// set size of box
					this.boxTransform.sizeDelta = new Vector2(
						this.box.windowRect.width,
						this.box.windowRect.height);

					// set scale of container
					this.containerTransform.localScale = guiScale;
				}
				// non scale display
				else
				{
					// set position of container
					if(this.box.GUILayer.useFullScreen)
					{
						this.containerTransform.anchoredPosition = ORK.Core.FullScreenMatrix.MultiplyPoint3x4(
							new Vector2(
								this.box.windowRect.x,
								-this.box.windowRect.y));
					}
					else
					{
						this.containerTransform.anchoredPosition = this.box.GUILayer.UIMatrix.NewUIMatrix.MultiplyPoint3x4(
							new Vector2(
								this.box.windowRect.x,
								-this.box.windowRect.y));
					}


					// set size of box
					this.boxTransform.sizeDelta = new Vector2(
						this.box.windowRect.width,
						this.box.windowRect.height);

					// set scale of container
					this.containerTransform.localScale = this.box.GUILayer.GetScale();
				}

				// set color
				this.UpdateColors();

				// interactions
				if(this.contentUpdated)
				{
					this.canvasGroup.interactable = !this.canvasGroup.interactable;
				}
				this.canvasGroup.interactable = !this.box.blocked && this.box.controlable &&
					(this.box.inPause || !ORK.Game.Paused) &&
					(!this.box.focusable || this.box.Focused);

				this.contentUpdated = false;
			}
		}

		public void UpdateColors()
		{
			if(this.canvasRenderer.Count == 0)
			{
				this.GetComponentsInChildren<CanvasRenderer>(this.canvasRenderer);
				this.doFlash = new bool[this.canvasRenderer.Count];
				for(int i = 0; i < this.canvasRenderer.Count; i++)
				{
					this.doFlash[i] = this.canvasRenderer[i].GetComponent<NoFlashComponent>() == null;
				}
			}

			if(this.box.doFlash)
			{
				for(int i = 0; i < this.canvasRenderer.Count; i++)
				{
					if(this.doFlash[i] && this.canvasRenderer[i] != null)
					{
						this.canvasRenderer[i].SetColor(this.box.flashColor);
					}
				}
				this.lastColor = this.box.flashColor;
			}
			else
			{
				Color color = this.box.controlable && this.box.focusable &&
					!this.box.IsClosing && !this.box.Focused &&
					this.box.InactiveColor.setColor ?
						this.box.InactiveColor.color : this.box.color;

				if(this.lastColor != color || this.contentUpdated)
				{
					for(int i = 0; i < this.canvasRenderer.Count; i++)
					{
						if(this.canvasRenderer[i] != null)
						{
							this.canvasRenderer[i].SetColor(color);
						}
					}
					this.lastColor = color;
				}
			}

			if(this.shortcuts != null)
			{
				for(int i = 0; i < this.shortcuts.Count; i++)
				{
					this.shortcuts[i].NewUIUpdateColor(this.lastColor);
				}
			}
		}
	}
}
