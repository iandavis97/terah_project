
using ORKFramework;
using ORKFramework.Animations;
using ORKFramework.Events;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Events/Item Collector")]
	public class ItemCollector : BaseInteraction, IEventStarter
	{
		// collection type settings
		public CollectionType collectionType = CollectionType.Single;

		public string boxID = "";

		public bool blockControl = true;

		// single item
		public bool destroyObject = true;


		// faction
		public bool useFaction = false;

		[ORKEditorInfo(ORKDataType.Faction)]
		public int factionID = 0;


		// game events
		public ORKGameEvent startGameEvent;

		public bool startEventUsePrefab = true;

		public ORKGameEvent endGameEvent;

		public bool endEventUsePrefab = true;

		public bool useCancelEndGameEvent = false;

		public ORKGameEvent cancelEndGameEvent;

		public ORKGameEvent collectedGameEvent;


		// place on ground
		public bool onGround = true;

		public float distance = 100.0f;

		public LayerMask layerMask = -1;


		// item
		public bool setVariablesOnChance = false;

		public bool destroyEmptyBox = false;

		public bool showDialogue = true;

		public bool showNotification = true;

		public bool showConsole = true;

		public bool useLoot = false;

		public bool autoTakeAll = false;

		public int lootID = 0;

		public ItemGain[] item = new ItemGain[] {new ItemGain()};

		public bool spawnPrefab = true;

		public bool doMount = false;

		public MountSettings mount = new MountSettings();

		public bool spawnUseConditions = false;

		public bool repeatCheckSpawn = false;

		public float repeatCheckTime = 0.0f;


		// ingame
		private GameObject prefabInstance;

		private DropInfo dropInfo;

		private List<IShortcut> itemList;

		private IEventStarter starter;

		private bool startEventRunning = false;

		private bool endEventRunning = false;

		private bool collectionFinishedOk = false;

		public void SetOnGround()
		{
			if(this.onGround)
			{
				RaycastOutput hit;
				if(RaycastHelper.Raycast(transform.position, -Vector3.up, out hit, this.distance, this.layerMask))
				{
					transform.position = hit.point;
				}
			}
		}


		/*
		============================================================================
		Interaction type functions
		============================================================================
		*/
		public override InteractionType Type
		{
			get
			{
				if(CollectionType.Box == this.collectionType)
				{
					return InteractionType.ItemBox;
				}
				else
				{
					return InteractionType.Item;
				}
			}
		}


		/*
		============================================================================
		Item list functions
		============================================================================
		*/
		public List<IShortcut> ItemList
		{
			get
			{
				if(this.itemList == null)
				{
					this.itemList = new List<IShortcut>();
				}
				return this.itemList;
			}
		}

		private void AddItemCheck(ItemGain i)
		{
			if(i.CheckChance())
			{
				ShortcutHelper.Add(ref this.itemList, i.CreateShortcut(),
					ORK.InventorySettings.itemBoxCollection.useInventoryAddType);
			}
		}

		public void SetDropInfo(DropInfo info)
		{
			this.dropInfo = info;
			ArrayHelper.GetBlank(ref this.itemList);
			this.itemList.Add(this.dropInfo.Item);
			this.useSceneID = false;
			this.collectionType = CollectionType.Single;
			this.startType = ORK.InventorySettings.dropStartType;
			this.onGround = ORK.InventorySettings.dropOnGround;
			this.layerMask = ORK.InventorySettings.dropMask;
		}

		private void Update()
		{
			if(this.dropInfo != null &&
				ORK.InventorySettings.dropSaveUpdatedPosition)
			{
				this.dropInfo.position = this.transform.position;
				this.dropInfo.rotation = this.transform.eulerAngles;
			}
		}

		public void SetItemList(List<IShortcut> list)
		{
			ArrayHelper.GetBlank(ref this.itemList);
			this.itemList.AddRange(list);
		}


		/*
		============================================================================
		Interaction functions
		============================================================================
		*/
		void Start()
		{
			if(this.dropInfo != null)
			{
				this.SetOnGround();
				this.StartCheck();
			}
			else if(!this.CheckAutoDestroy())
			{
				if(CollectionType.Box != this.collectionType &&
					this.useSceneID && ORK.Game.Scene.IsItemCollected(
						SceneManager.GetActiveScene().name, this.sceneID))
				{
					if(this.destroyObject)
					{
						UnityWrapper.Destroy(this.gameObject);
					}
					else
					{
						ORK.Core.GameObject.AddComponent<GameEventTicker>().StartEvent(
							this.collectedGameEvent, this, ORK.Game.GetPlayer(), null, false);
						GameObject.Destroy(this);
					}
				}
				else if(CollectionType.Box == this.collectionType &&
					this.useLoot &&
					ORK.Game.ActiveGroup.Leader == null)
				{
					this.StartCoroutine(this.InitWaitForPlayer());
				}
				else
				{
					this.InitItemList();
				}
			}
		}

		private IEnumerator InitWaitForPlayer()
		{
			yield return null;
			if(ORK.Game.ActiveGroup.Leader != null)
			{
				this.InitItemList();
			}
			else
			{
				this.StartCoroutine(this.InitWaitForPlayer());
			}
		}

		private void InitItemList()
		{
			bool destroy = false;
			this.itemList = new List<IShortcut>();

			if(CollectionType.Single == this.collectionType)
			{
				this.AddItemCheck(this.item[0]);
			}
			else if(CollectionType.Random == this.collectionType)
			{
				this.AddItemCheck(this.item[UnityWrapper.Range(0, this.item.Length)]);
			}
			else if(CollectionType.Box == this.collectionType)
			{
				if(!ORK.Game.Scene.GetItemBox(this.boxID, ref this.itemList))
				{
					if(this.useLoot)
					{
						ORK.Loot.Get(this.lootID).Get(ref this.itemList,
							ORK.Game.ActiveGroup.Leader,
							ORK.InventorySettings.itemBoxCollection.useInventoryAddType);
					}
					else
					{
						for(int i = 0; i < this.item.Length; i++)
						{
							this.AddItemCheck(this.item[i]);
						}
					}
					ORK.Game.Scene.SetItemBox(this.boxID, this.itemList);
				}
			}

			if(this.itemList.Count > 0)
			{
				this.SetOnGround();
			}
			else
			{
				if(this.setVariablesOnChance)
				{
					this.SetVariables();
					if(this.useSceneID &&
						CollectionType.Box != this.collectionType)
					{
						ORK.Game.Scene.ItemCollected(
							SceneManager.GetActiveScene().name,
							this.sceneID, true);
					}
				}
				if(CollectionType.Box != this.collectionType ||
					this.destroyEmptyBox)
				{
					if(this.destroyObject)
					{
						UnityWrapper.Destroy(this.gameObject);
					}
					else
					{
						GameObject.Destroy(this);
					}
					destroy = true;
				}
			}

			if(!destroy)
			{
				this.StartCheck();
			}
		}

		private void StartCheck()
		{
			if(this.itemList == null ||
				this.itemList.Count == 0)
			{
				if(CollectionType.Box == this.collectionType)
				{
					if(this.destroyEmptyBox)
					{
						UnityWrapper.Destroy(this.gameObject);
					}
				}
				else if(this.destroyObject)
				{
					UnityWrapper.Destroy(this.gameObject);
				}
				else
				{
					GameObject.Destroy(this);
				}
			}
			else if(EventStartType.Autostart == this.startType)
			{
				if(this.CheckConditions())
				{
					this.DoAutoStart();
				}
				else
				{
					if(this.destroyObject)
					{
						UnityWrapper.Destroy(this.gameObject);
					}
					else
					{
						GameObject.Destroy(this);
					}
				}
			}
			else
			{
				this.CheckSpawnPrefab();
			}
		}

		private void CheckSpawnPrefab()
		{
			if(this.spawnPrefab &&
				CollectionType.Box != this.collectionType)
			{
				if(!this.spawnUseConditions || this.CheckConditions())
				{
					Vector3 offset = Vector3.zero;
					if(this.itemList[0] is MoneyShortcut)
					{
						this.prefabInstance = ((MoneyShortcut)this.itemList[0]).Setting.itemPrefab.CreatePrefabInstance();
						offset = ((MoneyShortcut)this.itemList[0]).Setting.itemPrefab.spawnOffset;
					}
					else if(this.itemList[0] is ItemShortcut)
					{
						this.prefabInstance = ((ItemShortcut)this.itemList[0]).Setting.itemPrefab.CreatePrefabInstance();
						offset = ((ItemShortcut)this.itemList[0]).Setting.itemPrefab.spawnOffset;
					}
					else if(this.itemList[0] is EquipShortcut)
					{
						this.prefabInstance = ((EquipShortcut)this.itemList[0]).CreatePrefabInstance(ref offset, false);
					}
					else if(this.itemList[0] is AIBehaviourShortcut)
					{
						this.prefabInstance = ((AIBehaviourShortcut)this.itemList[0]).Setting.itemPrefab.CreatePrefabInstance();
						offset = ((AIBehaviourShortcut)this.itemList[0]).Setting.itemPrefab.spawnOffset;
					}
					else if(this.itemList[0] is AIRulesetShortcut)
					{
						this.prefabInstance = ((AIRulesetShortcut)this.itemList[0]).Setting.itemPrefab.CreatePrefabInstance();
						offset = ((AIRulesetShortcut)this.itemList[0]).Setting.itemPrefab.spawnOffset;
					}
					else if(this.itemList[0] is CraftingRecipeShortcut)
					{
						this.prefabInstance = ((CraftingRecipeShortcut)this.itemList[0]).Setting.itemPrefab.CreatePrefabInstance();
						offset = ((CraftingRecipeShortcut)this.itemList[0]).Setting.itemPrefab.spawnOffset;
					}

					if(this.prefabInstance != null)
					{
						if(this.doMount)
						{
							this.mount.MountTo(this.transform, this.prefabInstance.transform);
						}
						else
						{
							this.mount.Place(this.transform, this.prefabInstance.transform);
						}
						this.prefabInstance.transform.position += offset;
						InteractionForwarder fw = this.prefabInstance.AddComponent<InteractionForwarder>();
						fw.baseInteraction = this;
						fw.startType = this.startType;
					}
				}
				else if(this.repeatCheckSpawn)
				{
					StartCoroutine(this.CheckSpawnPrefab2());
				}
			}
		}

		private IEnumerator CheckSpawnPrefab2()
		{
			if(this.repeatCheckTime > 0)
			{
				yield return new WaitForSeconds(this.repeatCheckTime);
			}
			else
			{
				yield return new WaitForSeconds(0.1f);
			}
			this.CheckSpawnPrefab();
		}

		public override bool CanInteract(EventStartType type, GameObject gameObject)
		{
			return base.CanInteract(type, gameObject) &&
				((CollectionType.Box == this.collectionType &&
					(ORK.InventorySettings.itemBoxCollection.useInventoryExchangeMenu ||
						!ORK.InventorySettings.itemBoxCollection.autoClose ||
						this.itemList.Count > 0)) ||
				(CollectionType.Box != this.collectionType &&
					(!this.useSceneID || !ORK.Game.Scene.IsItemCollected(
						SceneManager.GetActiveScene().name, this.sceneID))));
		}

		public override void StartEvent(GameObject startingObject)
		{
			this.StartEvent2();
		}

		public void StartEvent(IEventStarter starter)
		{
			this.starter = starter;
			this.StartEvent2();
		}

		private void StartEvent2()
		{
			this.CancelInvoke("AutoDestroy");
			this.isInvoking = false;

			if(!this.eventStarted)
			{
				this.eventStarted = true;

				if(this.startGameEvent != null)
				{
					this.startEventRunning = true;
					ORK.Core.GameObject.AddComponent<GameEventTicker>().StartEvent(
						this.startGameEvent, this, ORK.Game.GetPlayer(), null, false);
				}
				else
				{
					this.startEventRunning = false;
					this.StartCoroutine(this.StartCollection());
				}
			}
		}

		private IEnumerator StartCollection()
		{
			if(this.blockControl)
			{
				ORK.Control.SetBlockControl(1, true);
				ORK.Control.SetBlockControlMaps(1);
			}
			if(CollectionType.Box == this.collectionType)
			{
				float waitTime = ORK.InventorySettings.itemBoxCollection.animateBefore.Play(ORK.Game.ActiveGroup.Leader);
				if(waitTime >= 0)
				{
					yield return new WaitForSeconds(waitTime);
				}

				ORK.Game.Scene.GetItemBox(this.boxID, ref this.itemList);

				if(this.autoTakeAll)
				{
					this.TakeAll();
					this.CollectionFinished(true);
				}
				else
				{
					ORK.InventorySettings.itemBoxCollection.Show(this);
				}
			}
			else if(this.itemList.Count > 0)
			{
				float waitTime = ORK.InventorySettings.itemCollection.animateBefore.Play(ORK.Game.ActiveGroup.Leader);
				if(waitTime >= 0)
				{
					yield return new WaitForSeconds(waitTime);
				}


				if(this.showDialogue)
				{
					ORK.InventorySettings.itemCollection.Show(this, this.itemList[0]);
				}
				else if(ORK.Game.ActiveGroup.Leader.Inventory.CanCollect(this.itemList[0]))
				{
					this.CollectionFinished(true);
				}
				else
				{
					ORK.InventorySettings.notifications.full.Show(
						ORK.Game.ActiveGroup.Leader, this.itemList[0], this.itemList[0].Quantity);
					this.CollectionFinished(false);
				}
			}
		}

		public void CollectionFinished(bool ok)
		{
			if(this.useCancelEndGameEvent)
			{
				if(ok)
				{
					if(this.endGameEvent != null)
					{
						this.startEventRunning = false;
						this.endEventRunning = true;
						this.collectionFinishedOk = ok;
						ORK.Core.GameObject.AddComponent<GameEventTicker>().StartEvent(
							this.endGameEvent, this, ORK.Game.GetPlayer(), null, false);
					}
					else
					{
						this.StartCoroutine(this.CollectionFinished2(ok));
					}
				}
				else
				{
					if(this.cancelEndGameEvent != null)
					{
						this.startEventRunning = false;
						this.endEventRunning = true;
						this.collectionFinishedOk = ok;
						ORK.Core.GameObject.AddComponent<GameEventTicker>().StartEvent(
							this.cancelEndGameEvent, this, ORK.Game.GetPlayer(), null, false);
					}
					else
					{
						this.StartCoroutine(this.CollectionFinished2(ok));
					}
				}
			}
			else if(this.endGameEvent != null)
			{
				this.startEventRunning = false;
				this.endEventRunning = true;
				this.collectionFinishedOk = ok;
				ORK.Core.GameObject.AddComponent<GameEventTicker>().StartEvent(
					this.endGameEvent, this, ORK.Game.GetPlayer(), null, false);
			}
			else
			{
				this.StartCoroutine(this.CollectionFinished2(ok));
			}
		}

		private IEnumerator CollectionFinished2(bool ok)
		{
			if(CollectionType.Box == this.collectionType)
			{
				float waitTime = ORK.InventorySettings.itemBoxCollection.animateAfter.Play(ORK.Game.ActiveGroup.Leader);
				if(waitTime >= 0)
				{
					yield return new WaitForSeconds(waitTime);
				}

				ORK.Game.Scene.SetItemBox(this.boxID, this.itemList);

				this.SetVariables();

				if(this.destroyEmptyBox && this.itemList.Count == 0)
				{
					UnityWrapper.Destroy(this.gameObject);
				}
				else if(this.autoDestroy)
				{
					this.CheckAutoDestroy();
				}
			}
			else
			{
				if(ok)
				{
					float waitTime = ORK.InventorySettings.itemCollection.animateAfterOk.Play(ORK.Game.ActiveGroup.Leader);
					if(waitTime >= 0)
					{
						yield return new WaitForSeconds(waitTime);
					}

					this.SetVariables();
					if(this.useSceneID)
					{
						ORK.Game.Scene.ItemCollected(
							SceneManager.GetActiveScene().name,
							this.sceneID, true);
					}

					this.CollectItem(0, ORK.Game.ActiveGroup.Leader);

					if(this.dropInfo != null)
					{
						ORK.Game.Scene.Collected(this.dropInfo);
					}
					if(this.prefabInstance != null)
					{
						UnityWrapper.Destroy(this.prefabInstance);
					}
					if(this.destroyObject)
					{
						UnityWrapper.Destroy(this.gameObject);
					}
					else
					{
						GameObject.Destroy(this);
					}
				}
				else
				{
					float waitTime = ORK.InventorySettings.itemCollection.animateAfterCancel.Play(ORK.Game.ActiveGroup.Leader);
					if(waitTime >= 0)
					{
						yield return new WaitForSeconds(waitTime);
					}
					if(this.autoDestroy)
					{
						this.CheckAutoDestroy();
					}
				}
			}
			if(this.blockControl)
			{
				ORK.Control.SetBlockControl(-1, true);
				ORK.Control.SetBlockControlMaps(-1);
			}

			if(ComponentHelper.IsAlive(this.starter))
			{
				this.starter.EventEnded();
				this.starter = null;
			}
			this.eventStarted = false;
		}

		private void CollectItem(int index, Combatant combatant)
		{
			if(index >= 0 && index < this.itemList.Count)
			{
				// change sympathy for player
				if(this.useFaction)
				{
					ShortcutHelper.TakeFromFaction(this.itemList[index], this.factionID, combatant.Group.FactionID);
				}
				combatant.Inventory.Add(this.itemList[index], this.showNotification, this.showConsole, true);
				this.itemList.RemoveAt(index);
			}
		}

		public bool HasItems()
		{
			for(int i = 0; i < this.itemList.Count; i++)
			{
				if(this.itemList[i] is ItemShortcut ||
					this.itemList[i] is EquipShortcut ||
					this.itemList[i] is MoneyShortcut ||
					this.itemList[i] is AIBehaviourShortcut ||
					this.itemList[i] is AIRulesetShortcut ||
					this.itemList[i] is CraftingRecipeShortcut)
				{
					return true;
				}
			}
			return false;
		}

		public void TakeAll()
		{
			int index = 0;
			while(index < this.itemList.Count)
			{
				if(ORK.Game.ActiveGroup.Leader.Inventory.CanCollect(this.itemList[index]))
				{
					this.CollectItem(index, ORK.Game.ActiveGroup.Leader);
				}
				else
				{
					ORK.InventorySettings.notifications.full.Show(
						ORK.Game.ActiveGroup.Leader, this.itemList[index], this.itemList[index].Quantity);
					index++;
				}
			}
		}

		public void AddItem(IShortcut shortcut)
		{
			ShortcutHelper.Add(ref this.itemList, shortcut,
				ORK.InventorySettings.itemBoxCollection.useInventoryAddType);
		}

		public void DestroySpawnedPrefab()
		{
			if(this.prefabInstance != null)
			{
				UnityWrapper.Destroy(this.prefabInstance);
			}
		}


		/*
		============================================================================
		Event starter functions
		============================================================================
		*/
		public void EventEnded()
		{
			if(this.startEventRunning)
			{
				this.startEventRunning = false;
				this.StartCoroutine(this.StartCollection());
			}
			else if(this.endEventRunning)
			{
				this.endEventRunning = true;
				this.StartCoroutine(this.CollectionFinished2(this.collectionFinishedOk));
			}
		}

		public void DontDestroy()
		{

		}

		public void OnSceneLoaded()
		{

		}

		public GameObject GameObject
		{
			get
			{
				if(this.startEventRunning)
				{
					if(this.startEventUsePrefab &&
						CollectionType.Box != this.collectionType &&
						this.prefabInstance != null)
					{
						return this.prefabInstance;
					}
				}
				else if(this.endEventRunning)
				{
					if(this.endEventUsePrefab &&
						CollectionType.Box != this.collectionType &&
						this.prefabInstance != null)
					{
						return this.prefabInstance;
					}
				}
				return this.gameObject;
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "ItemCollector.psd");
		}
	}
}
