﻿
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Battles/Combatant Trigger")]
	public class CombatantTriggerComponent : MonoBehaviour
	{
		public string[] tags = new string[0];


		// in-game
		private Combatant owner;

		private List<Combatant> registered = new List<Combatant>();

		private Dictionary<Combatant, float> combatants = new Dictionary<Combatant, float>();

		private void Update()
		{
			float delta = ORK.Game.DeltaBattleTime;

			for(int i = 0; i < this.registered.Count; i++)
			{
				this.combatants[this.registered[i]] += delta;
			}
		}

		private void OnDisable()
		{
			this.registered.Clear();
			this.combatants.Clear();
		}

		public Combatant Owner
		{
			get { return this.owner; }
			set
			{
				if(this.owner != value)
				{
					this.owner = value;
					this.RemoveCombatant(this.owner);
				}
			}
		}

		public List<Combatant> InTrigger
		{
			get { return this.registered; }
		}

		public bool IsActive
		{
			get { return this.enabled && this.gameObject.activeInHierarchy; }
		}

		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		private void AddCombatant(Combatant combatant)
		{
			if(combatant != null &&
				this.owner != combatant &&
				!this.combatants.ContainsKey(combatant))
			{
				this.registered.Add(combatant);
				this.combatants.Add(combatant, 0);
			}
		}

		private void RemoveCombatant(Combatant combatant)
		{
			if(combatant != null &&
				this.combatants.ContainsKey(combatant))
			{
				this.registered.Remove(combatant);
				this.combatants.Remove(combatant);
			}
		}

		public bool Contains(Combatant combatant)
		{
			return combatant != null &&
				this.combatants.ContainsKey(combatant);
		}

		public float GetTime(Combatant combatant)
		{
			if(combatant != null &&
				this.combatants.ContainsKey(combatant))
			{
				return this.combatants[combatant];
			}
			return -1;
		}

		public bool CheckTag(string tag)
		{
			for(int i = 0; i < this.tags.Length; i++)
			{
				if(this.tags[i] == tag)
				{
					return true;
				}
			}
			return false;
		}

		public bool CheckTags(string[] checkTags, Needed needed)
		{
			if(checkTags.Length > 0)
			{
				for(int i = 0; i < checkTags.Length; i++)
				{
					if(this.CheckTag(checkTags[i]))
					{
						if(Needed.One == needed)
						{
							return true;
						}
					}
					else if(Needed.All == needed)
					{
						return false;
					}
				}
				if(Needed.All == needed)
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		void OnTriggerEnter(Collider other)
		{
			this.AddCombatant(ComponentHelper.GetCombatant(other.gameObject));
		}

		void OnTriggerExit(Collider other)
		{
			this.RemoveCombatant(ComponentHelper.GetCombatant(other.gameObject));
		}


		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		void OnTriggerEnter2D(Collider2D other)
		{
			this.AddCombatant(ComponentHelper.GetCombatant(other.gameObject));
		}

		void OnTriggerExit2D(Collider2D other)
		{
			this.RemoveCombatant(ComponentHelper.GetCombatant(other.gameObject));
		}
	}
}
