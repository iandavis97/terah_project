
using ORKFramework;
using System.Collections.Generic;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class CenterEventMover : MonoBehaviour
	{
		private List<GameObject> targets;
		
		private bool localSpace = false;
		
		private Vector3 offset = Vector3.zero;

		private float time = 0;
		
		private float time2 = 0;
		
		public void SetCenter(List<GameObject> list, bool ls, Vector3 o, float t)
		{
			this.targets = list;
			this.localSpace = ls;
			this.offset = o;
			this.time = 0;
			this.time2 = t;
			
			this.ToCenter();
		}
		
		public void ToCenter()
		{
			TransformHelper.SetCenterPosRot(this.transform, this.targets);
			if(this.localSpace)
			{
				this.transform.position = this.transform.TransformPoint(this.offset);
			}
			else
			{
				this.transform.position = this.transform.position + this.offset;
			}
		}
		
		
		/*
		============================================================================
		Update functions
		============================================================================
		*/
		void Update()
		{
			if(!ORK.Game.Paused && this.targets != null)
			{
				this.time += ORK.Game.DeltaTime;
				
				this.ToCenter();
				
				if(this.time >= this.time2)
				{
					UnityWrapper.Destroy(this.gameObject);
				}
			}
		}
	}
}
