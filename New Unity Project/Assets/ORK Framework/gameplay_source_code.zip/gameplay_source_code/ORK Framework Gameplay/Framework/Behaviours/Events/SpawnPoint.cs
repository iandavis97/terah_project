
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Scenes/Spawn Point")]
	public class SpawnPoint : SceneID
	{
		// spawn on ground
		public bool onGround = true;

		public float distance = 100.0f;

		public LayerMask layerMask = -1;

		public Vector3 offset = Vector3.zero;


		// placement
		public bool useYRotation = true;

		public bool useScale = false;


		// in-game
		private bool isOnGround = false;

		void Start()
		{
			this.SetOnGround();
		}

		public void SetOnGround()
		{
			if(this.onGround)
			{
				RaycastOutput hit;
				if(RaycastHelper.Raycast(transform.position, -Vector3.up, out hit, this.distance, this.layerMask))
				{
					transform.position = hit.point + this.offset;
				}
			}
			this.isOnGround = true;
		}

		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "SpawnPoint.psd");
		}

		public static SpawnPoint GetSpawnPoint(int spawnID)
		{
			Scene activeScene = SceneManager.GetActiveScene();
			SpawnPoint[] sp = UnityEngine.Object.FindObjectsOfType<SpawnPoint>();
			List<SpawnPoint> list = new List<SpawnPoint>();
			for(int i = 0; i < sp.Length; i++)
			{
				if(sp[i].sceneID == spawnID &&
					sp[i].gameObject.scene == activeScene)
				{
					if(!sp[i].isOnGround)
					{
						sp[i].SetOnGround();
					}
					list.Add(sp[i]);
				}
			}
			if(list.Count == 0)
			{
				for(int i = 0; i < sp.Length; i++)
				{
					if(sp[i].sceneID == spawnID)
					{
						if(!sp[i].isOnGround)
						{
							sp[i].SetOnGround();
						}
						list.Add(sp[i]);
					}
				}
			}
			if(list.Count > 0)
			{
				return list[UnityWrapper.Range(0, list.Count)];
			}
			return null;
		}
	}
}
