﻿
using UnityEngine;
using UnityEngine.AI;
using ORKFramework;
using System.Collections.Generic;
using System.Reflection;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class MoveToInteractionComponent : MonoBehaviour
	{
		// player
		private Combatant combatant;


		// interaction
		private BaseInteraction interaction;

		private bool isMoving = false;

		private Vector3 destination = Vector3.zero;


		// move components
		private SimpleMove simpleMove;

		private NavMeshAgent navMeshAgent;

		private Component customComponent;

		private MethodInfo customSpeedMethod;

		private MethodInfo customPositionMethod;

		private MethodInfo customStopMethod;


		public void Init(Combatant combatant)
		{
			this.combatant = combatant;
			this.InitMoveComponent();
		}


		/*
		============================================================================
		Movement functions
		============================================================================
		*/
		public void MoveToInteraction(BaseInteraction interaction)
		{
			if(interaction != null)
			{
				this.interaction = interaction;

				if(this.interaction.destinationObject != null)
				{
					if(!this.SetDestination(this.interaction.destinationObject.transform.position, true))
					{
						this.StartInteraction();
					}
				}
				else if(!this.SetDestination(this.interaction.transform.position -
						(this.interaction.transform.position - this.transform.position).normalized *
							(this.combatant.Object.BoxRadius + this.interaction.MoveDestinationOffset), false))
				{
					this.StartInteraction();
				}
			}
		}

		void Update()
		{
			if(!ORK.Game.Paused &&
				this.isMoving &&
				this.interaction != null &&
				this.combatant != null)
			{
				if(ORK.GameControls.interaction.moveToInteraction.CancelMovement())
				{
					this.Stop();
					this.interaction = null;
				}
				else if(this.interaction.destinationObject)
				{
					if(VectorHelper.Distance(this.gameObject, this.interaction.destinationObject,
						ORK.GameControls.interaction.moveToInteraction.ignoreHeightDistance) <
						ORK.GameControls.interaction.moveToInteraction.interactionDistance)
					{
						this.StartInteraction();
					}
				}
				else if(VectorHelper.Distance(this.transform.position, this.destination,
						ORK.GameControls.interaction.moveToInteraction.ignoreHeightDistance) <
						ORK.GameControls.interaction.moveToInteraction.interactionDistance)
				{
					this.StartInteraction();
				}
			}
		}

		private void StartInteraction()
		{
			this.Stop();
			BaseInteraction tmpInteraction = this.interaction;
			this.interaction = null;
			tmpInteraction.StartEvent(this.gameObject);
		}


		/*
		============================================================================
		Component functions
		============================================================================
		*/
		public bool SetDestination(Vector3 position, bool force)
		{
			if(force ||
				VectorHelper.Distance(position, this.interaction.transform.position,
					ORK.GameControls.interaction.moveToInteraction.ignoreHeightDistance) <
				VectorHelper.Distance(this.gameObject, this.interaction.gameObject,
					ORK.GameControls.interaction.moveToInteraction.ignoreHeightDistance))
			{
				BasePlayerControl[] control = this.gameObject.GetComponentsInChildren<BasePlayerControl>();
				if(control != null)
				{
					for(int i = 0; i < control.Length; i++)
					{
						control[i].MoveToInteractionStartet(this.interaction);
					}
				}
				if(ORK.GameControls.interaction.moveToInteraction.blockPlayer)
				{
					ORK.Control.SetBlockPlayer(1, true);
				}
				if(ORK.GameControls.interaction.moveToInteraction.blockCamera)
				{
					ORK.Control.SetBlockCamera(1, true);
				}

				this.isMoving = true;
				float speed = this.interaction.overrideMoveToSpeed ?
					this.interaction.moveToSpeed.GetSpeed(this.combatant) :
					ORK.GameControls.interaction.moveToInteraction.speed.GetSpeed(this.combatant);
				this.destination = position;

				// simple direct move
				if(MoveComponentType.Default == ORK.GameControls.interaction.moveToInteraction.compType)
				{
					if(this.simpleMove != null)
					{
						this.simpleMove.MoveTo(speed, this.destination);
						return true;
					}
				}
				// Nav Mesh Agent
				else if(MoveComponentType.NavMeshAgent == ORK.GameControls.interaction.moveToInteraction.compType)
				{
					if(this.navMeshAgent != null &&
						this.navMeshAgent.isOnNavMesh)
					{
						// get nearest NavMesh position
						NavMeshHit hit;
						if(NavMesh.SamplePosition(this.destination, out hit,
							ORK.GameControls.interaction.moveToInteraction.navMeshSampleDistance,
							ORK.GameControls.interaction.moveToInteraction.navMeshSampleAreaMask))
						{
							this.destination = hit.position;
						}

						this.navMeshAgent.speed = speed;
						this.navMeshAgent.SetDestination(this.destination);
						this.navMeshAgent.isStopped = false;
						return true;
					}
				}
				// custom component
				else if(MoveComponentType.Custom == ORK.GameControls.interaction.moveToInteraction.compType)
				{
					// set speed
					if(this.customSpeedMethod != null)
					{
						this.customSpeedMethod.Invoke(this.customComponent, new System.Object[] { speed });
					}
					// set position
					if(this.customPositionMethod != null)
					{
						this.customPositionMethod.Invoke(this.customComponent, new System.Object[] { this.destination });
						return true;
					}
				}
			}
			return false;
		}

		public void Stop()
		{
			if(this.isMoving)
			{
				this.isMoving = false;

				if(MoveComponentType.Default == ORK.GameControls.interaction.moveToInteraction.compType)
				{
					if(this.simpleMove != null)
					{
						this.simpleMove.Stop();
					}
				}
				// Nav Mesh Agent
				else if(MoveComponentType.NavMeshAgent == ORK.GameControls.interaction.moveToInteraction.compType)
				{
					if(this.navMeshAgent != null &&
						this.navMeshAgent.isOnNavMesh)
					{
						this.navMeshAgent.isStopped = true;
					}
				}
				// custom component
				else if(MoveComponentType.Custom == ORK.GameControls.interaction.moveToInteraction.compType)
				{
					if(this.customStopMethod != null)
					{
						this.customStopMethod.Invoke(this.customComponent, null);
					}
				}

				if(ORK.GameControls.interaction.moveToInteraction.blockPlayer)
				{
					ORK.Control.SetBlockPlayer(-1, true);
				}
				if(ORK.GameControls.interaction.moveToInteraction.blockCamera)
				{
					ORK.Control.SetBlockCamera(-1, true);
				}
			}
		}

		private void InitMoveComponent()
		{
			this.simpleMove = null;
			this.navMeshAgent = null;
			this.customComponent = null;
			this.customSpeedMethod = null;
			this.customPositionMethod = null;
			this.customStopMethod = null;

			// simple direct move
			if(MoveComponentType.Default == ORK.GameControls.interaction.moveToInteraction.compType)
			{
				if(this.simpleMove == null)
				{
					this.simpleMove = this.transform.root.GetComponentInChildren<SimpleMove>();
					if(this.simpleMove == null &&
						ORK.GameControls.interaction.moveToInteraction.compAdd)
					{
						this.simpleMove = this.gameObject.AddComponent<SimpleMove>();
					}
				}
			}
			// Nav Mesh Agent
			else if(MoveComponentType.NavMeshAgent == ORK.GameControls.interaction.moveToInteraction.compType)
			{
				if(this.navMeshAgent == null)
				{
					this.navMeshAgent = this.transform.root.GetComponentInChildren<NavMeshAgent>();
					if(this.navMeshAgent == null &&
						ORK.GameControls.interaction.moveToInteraction.compAdd)
					{
						this.navMeshAgent = this.gameObject.AddComponent<NavMeshAgent>();
					}

					if(this.navMeshAgent != null &&
						!this.navMeshAgent.isOnNavMesh)
					{
						this.navMeshAgent.enabled = false;
						this.navMeshAgent.enabled = true;
					}
				}
			}
			// custom component
			else if(MoveComponentType.Custom == ORK.GameControls.interaction.moveToInteraction.compType &&
				ORK.GameControls.interaction.moveToInteraction.compName != "" &&
				this.customComponent == null)
			{
				System.Type type = ORK.Core.TypeHandler.GetType(
					ORK.GameControls.interaction.moveToInteraction.compName,
					typeof(Component));
				if(type != null)
				{
					this.customComponent = this.transform.root.GetComponentInChildren(type);
					if(this.customComponent == null &&
						ORK.GameControls.interaction.moveToInteraction.compAdd)
					{
						this.customComponent = this.gameObject.AddComponent(type);
					}
				}
				if(this.customComponent != null)
				{
					if(ORK.GameControls.interaction.moveToInteraction.compSpeedMethod != "")
					{
						this.customSpeedMethod = this.customComponent.GetType().GetMethod(
							ORK.GameControls.interaction.moveToInteraction.compSpeedMethod,
							new System.Type[] { typeof(float) });
					}
					if(ORK.GameControls.interaction.moveToInteraction.compPositionMethod != "")
					{
						this.customPositionMethod = this.customComponent.GetType().GetMethod(
							ORK.GameControls.interaction.moveToInteraction.compPositionMethod,
							new System.Type[] { typeof(Vector3) });
					}
					if(ORK.GameControls.interaction.moveToInteraction.compStopMethod != "")
					{
						this.customStopMethod = this.customComponent.GetType().GetMethod(
							ORK.GameControls.interaction.moveToInteraction.compStopMethod,
							new System.Type[] { });
					}
				}
			}
		}
	}
}
