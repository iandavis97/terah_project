
using ORKFramework;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Camera: Top Down Border")]
	public class TopDownBorderCamera : BaseCameraControl
	{
		public bool initialDamping = true;

		public string onChild = "";

		public float positionDamping = 0;

		public Vector4 positionPadding = new Vector4(0, 0, 0, 0);

		public HorizontalPlaneType horizontalPlane = HorizontalPlaneType.XZ;


		// distance
		public float distance = 10.0f;


		// height
		public float height = 5.0f;

		public float heightDamping = 2.0f;

		public float distanceDamping = 2.0f;

		public float rotationDamping = 2.0f;


		// rotation
		public float rotation = 0;

		private float originalRotation = 0;

		private float inputRotation = 0;


		// rotation input
		public UseableIn useRotationIn = UseableIn.None;

		public float rotationInputChange = 90;

		public bool rotateDeltaTime = false;

		public AxisControl rotationAxis = new AxisControl();

		public float rotationFactor = 1;

		public MouseTouchControl rotationMouseTouch = new MouseTouchControl(false, 1, false, 2, 1, MouseTouch.Move);

		public bool cameraTargetChangeResetRotation = false;

		public bool cameraTargetChangeBlockRotation = false;


		// panning
		public UseableIn usePanningIn = UseableIn.None;

		public float panningSpeed = 10;

		public int horizontalPanningKeyID = 0;

		public int verticalPanningKeyID = 0;

		public int centerPanningKeyID = 0;

		public bool limitPanning = true;

		public float panningDistanceLimitField = 20;

		public float panningDistanceLimitBattle = 20;

		public bool cameraTargetChangeResetPanning = false;

		public bool cameraTargetChangeBlockPanning = false;

		private Vector3 inputPanning = Vector3.zero;

		// screen edge panning
		public UseableIn useScreenEdgePanningIn = UseableIn.None;

		public bool screenEdgePanningUIBlock = false;

		public float screenEdgePanningSpeed = 10;

		public Vector4 screenEdgeDistance = new Vector4(100, 100, 100, 100);

		public ValueSetter screenEdgeValueSetter = ValueSetter.Value;


		// zooming
		public UseableIn useZoomingIn = UseableIn.None;

		public bool zoomUIBlock = false;

		public float zoomHeightInputChange = 3;

		public float zoomDistanceInputChange = 3;

		public bool zoomDeltaTime = false;

		public AxisControl zoomAxis = new AxisControl();

		public float zoomMinHeightField = 5;

		public float zoomMaxHeightField = 15;

		public float zoomMinDistanceField = 5;

		public float zoomMaxDistanceField = 15;

		public float zoomMinHeightBattle = 5;

		public float zoomMaxHeightBattle = 15;

		public float zoomMinDistanceBattle = 5;

		public float zoomMaxDistanceBattle = 15;

		public bool cameraTargetChangeResetZoom = false;

		public bool cameraTargetChangeBlockZoom = false;

		private Vector2 inputZoom = Vector2.zero;


		// in-game
		private CameraBorder[] cameraBorder;

		private bool firstUpdate = true;

		private int lastIndex = -1;

		private float lastTargetRotation = 0;

		private float lastTargetDistance = 0;

		void Start()
		{
			this.originalRotation = this.rotation;
			this.cameraBorder = GameObject.FindObjectsOfType<CameraBorder>();

			this.ResetZoom();
			this.lastTargetDistance = this.height;

			if(this.cameraBorder != null)
			{
				int index = this.ClosestBorderIndex(TransformHelper.GetChildObject(this.onChild, this.CameraTarget));
				if(index >= 0 &&
					this.cameraBorder[index].setRotation)
				{
					this.rotation = this.cameraBorder[index].rotation;
				}
				this.lastTargetRotation = this.rotation;
				this.lastIndex = index;
			}
		}

		public override void CameraTargetChanged(GameObject oldTarget, GameObject newTarget)
		{
			if(this.cameraTargetChangeResetRotation)
			{
				this.ResetRotation();
			}
			if(this.cameraTargetChangeResetPanning)
			{
				this.ResetPanning();
			}
			if(this.cameraTargetChangeResetZoom)
			{
				this.ResetZoom();
			}
		}

		public virtual void ResetRotation()
		{
			this.inputRotation = 0;
		}

		public virtual void ResetPanning()
		{
			this.inputPanning = Vector3.zero;
		}

		public virtual void ResetZoom()
		{
			this.inputZoom = new Vector2(this.distance, this.height);
		}

		private int ClosestBorderIndex(GameObject targetObject)
		{
			if(this.cameraBorder != null &&
				this.cameraBorder.Length > 0)
			{
				if(this.cameraBorder.Length == 1)
				{
					return 0;
				}
				else
				{
					if(targetObject != null)
					{
						int index = -1;
						float distance = Mathf.Infinity;
						for(int i = 0; i < this.cameraBorder.Length; i++)
						{
							if(this.cameraBorder[i] != null &&
								this.cameraBorder[i].enabled)
							{
								float tmp = this.cameraBorder[i].DistanceToCameraTarget(targetObject.transform.position);
								if(tmp < distance)
								{
									distance = tmp;
									index = i;
								}
							}
						}
						return index;
					}
				}
			}
			return -1;
		}

		private bool IsUseable(UseableIn useable)
		{
			return UseableIn.Both == useable ||
				(UseableIn.Field == useable && !ORK.Control.InBattle) ||
				(UseableIn.Battle == useable && ORK.Control.InBattle);
		}

		private void CheckRotationInput()
		{
			if(this.inputRotation < -36000)
			{
				int change = (this.inputRotation > -36000 ?
					1 : (int)(-this.inputRotation / 36000)) * 36000;
				this.inputRotation += change;
				this.lastTargetRotation += change;
			}
			else if(this.inputRotation >= 36000)
			{
				int change = ((int)(this.inputRotation / 36000)) * 36000;
				this.inputRotation -= change;
				this.lastTargetRotation -= change;
			}
		}

		void LateUpdate()
		{
			GameObject targetObject = TransformHelper.GetChildObject(this.onChild, this.CameraTarget);
			if(targetObject != null)
			{
				Vector3 targetPosition = targetObject.transform.position;

				int index = this.ClosestBorderIndex(targetObject);
				if(index != this.lastIndex)
				{
					this.firstUpdate = true;
					if(index >= 0 &&
						this.cameraBorder[index].setRotation)
					{
						this.rotation = this.cameraBorder[index].rotation;
						this.inputRotation = 0;
					}
					else
					{
						this.rotation = this.originalRotation;
					}
				}
				this.lastIndex = index;

				// panning
				if(this.IsUseable(this.usePanningIn) &&
					(!this.cameraTargetChangeBlockPanning ||
						!this.IsCameraTargetTransition) &&
					(this.cameraBorder == null ||
						index < 0 ||
						!this.cameraBorder[index].blockPanning))
				{
					if(ORK.InputKeys.Get(this.centerPanningKeyID).GetButton())
					{
						this.inputPanning = Vector3.zero;
					}
					else
					{
						Vector3 forward = this.transform.TransformDirection(Vector3.forward);
						forward.y = 0;
						forward = forward.normalized;
						Vector3 right = new Vector3(forward.z, 0, -forward.x);

						this.inputPanning += (ORK.InputKeys.Get(this.horizontalPanningKeyID).GetAxis() * right +
							ORK.InputKeys.Get(this.verticalPanningKeyID).GetAxis() * forward) * this.panningSpeed * Time.deltaTime;

						// edge panning
						if(this.IsUseable(this.useScreenEdgePanningIn) &&
							(!this.screenEdgePanningUIBlock ||
								!ORK.GUI.IsCursorOver))
						{
							Vector2 edgeInput = Vector2.zero;
							Vector4 edgeDistance = this.screenEdgeDistance;
							if(ValueSetter.Percent == this.screenEdgeValueSetter)
							{
								edgeDistance.x = (ORK.GameSettings.defaultScreen.x * edgeDistance.x) / 100.0f;
								edgeDistance.z = (ORK.GameSettings.defaultScreen.x * edgeDistance.z) / 100.0f;
								edgeDistance.y = (ORK.GameSettings.defaultScreen.y * edgeDistance.y) / 100.0f;
								edgeDistance.w = (ORK.GameSettings.defaultScreen.y * edgeDistance.w) / 100.0f;
							}
							if(ORK.Control.MousePosition.x < edgeDistance.x)
							{
								edgeInput.x -= Mathf.Min(edgeDistance.x,
									edgeDistance.x - ORK.Control.MousePosition.x) / edgeDistance.x;
							}
							else if(ORK.Control.MousePosition.x > (ORK.GameSettings.defaultScreen.x - edgeDistance.z))
							{
								edgeInput.x += Mathf.Min(edgeDistance.z,
									edgeDistance.z - (ORK.GameSettings.defaultScreen.x - ORK.Control.MousePosition.x)) / edgeDistance.z;
							}
							if(ORK.Control.MousePosition.y < edgeDistance.y)
							{
								edgeInput.y += Mathf.Min(edgeDistance.y,
									edgeDistance.y - ORK.Control.MousePosition.y) / edgeDistance.y;
							}
							else if(ORK.Control.MousePosition.y > (ORK.GameSettings.defaultScreen.y - edgeDistance.w))
							{
								edgeInput.y -= Mathf.Min(edgeDistance.w,
									edgeDistance.w - (ORK.GameSettings.defaultScreen.y - ORK.Control.MousePosition.y)) / edgeDistance.w;
							}
							this.inputPanning += (edgeInput.x * right + edgeInput.y * forward) *
								this.screenEdgePanningSpeed * Time.deltaTime;
						}
						// limit panning
						if(this.limitPanning)
						{
							if(ORK.Control.InBattle)
							{
								VectorHelper.LimitVector3(ref this.inputPanning,
									-this.panningDistanceLimitBattle, this.panningDistanceLimitBattle);
							}
							else
							{
								VectorHelper.LimitVector3(ref this.inputPanning,
									-this.panningDistanceLimitField, this.panningDistanceLimitField);
							}

							if(HorizontalPlaneType.XZ == this.horizontalPlane)
							{
								this.inputPanning.y = 0;
							}
							else if(HorizontalPlaneType.XY == this.horizontalPlane)
							{
								this.inputPanning.z = 0;
							}
						}
						if(this.inputPanning.sqrMagnitude > 0.1 &&
							this.cameraBorder != null && index >= 0)
						{
							this.inputPanning += targetPosition;
							this.cameraBorder[index].UpdatePosition(ref this.inputPanning,
								this.positionPadding, this.horizontalPlane);
							this.inputPanning -= targetPosition;
						}
						targetPosition += this.inputPanning;
					}
				}

				// rotation input
				if(this.IsUseable(this.useRotationIn) &&
					(!this.cameraTargetChangeBlockRotation ||
						!this.IsCameraTargetTransition) &&
					(this.cameraBorder == null ||
						index < 0 ||
						(!this.cameraBorder[index].setRotation &&
							!this.cameraBorder[index].blockRotationInput)))
				{
					float lastInput = this.inputRotation;
					float tmpInput = this.rotationAxis.GetAxis(false);
					if(tmpInput != 0)
					{
						this.inputRotation += tmpInput *
							(this.rotateDeltaTime ?
								this.rotationInputChange * Time.deltaTime :
								this.rotationInputChange);
						this.CheckRotationInput();
					}

					if(this.rotationMouseTouch.Active())
					{
						Vector3 add = Vector3.zero;
						if(this.rotationMouseTouch.Interacted(ref add))
						{
							add = this.rotationMouseTouch.GetLastChange();
							this.inputRotation += add.x * this.rotationFactor;
							this.CheckRotationInput();
						}
					}
				}
				// rotation damping
				float targetRotation = this.rotation + this.inputRotation;
				if(this.rotationDamping > 0 &&
					(this.initialDamping || !this.firstUpdate))
				{
					targetRotation = Mathf.Lerp(this.lastTargetRotation, targetRotation,
						this.rotationDamping * Time.deltaTime);
				}

				// zooming
				if(this.IsUseable(this.useZoomingIn) &&
					(!this.zoomUIBlock ||
						!ORK.GUI.IsCursorOver) &&
					(!this.cameraTargetChangeBlockZoom ||
						!this.IsCameraTargetTransition) &&
					(this.cameraBorder == null ||
						index < 0 ||
						!this.cameraBorder[index].blockZooming))
				{
					float tmpInput = this.zoomAxis.GetAxis(false);
					if(tmpInput != 0)
					{
						this.inputZoom.x += tmpInput *
							(this.zoomDeltaTime ?
								this.zoomDistanceInputChange * Time.deltaTime :
								this.zoomDistanceInputChange);
						this.inputZoom.y += tmpInput *
							(this.zoomDeltaTime ?
								this.zoomHeightInputChange * Time.deltaTime :
								this.zoomHeightInputChange);
					}

					// limit zoom
					if(ORK.Control.InBattle)
					{
						ValueHelper.Limit(ref this.inputZoom.x,
							this.zoomMinDistanceBattle, this.zoomMaxDistanceBattle);
						ValueHelper.Limit(ref this.inputZoom.y,
							this.zoomMinHeightBattle, this.zoomMaxHeightBattle);
					}
					else
					{
						ValueHelper.Limit(ref this.inputZoom.x,
							this.zoomMinDistanceField, this.zoomMaxDistanceField);
						ValueHelper.Limit(ref this.inputZoom.y,
							this.zoomMinHeightField, this.zoomMaxHeightField);
					}
				}


				if(this.cameraBorder != null && index >= 0)
				{
					this.cameraBorder[index].UpdatePosition(ref targetPosition,
						this.positionPadding, this.horizontalPlane);
				}

				Vector3 lookTargetPosition = targetPosition;

				if(HorizontalPlaneType.XZ == this.horizontalPlane)
				{
					// calculate the new height
					float targetHeight = targetPosition.y + this.inputZoom.y;
					if(this.heightDamping > 0 &&
						(this.initialDamping || !this.firstUpdate))
					{
						targetHeight = Mathf.Lerp(this.transform.position.y, targetHeight,
							this.heightDamping * Time.deltaTime);
					}
					// calculate the new distance
					float targetDistance = this.inputZoom.x;
					if(this.distanceDamping > 0 &&
						(this.initialDamping || !this.firstUpdate))
					{
						targetDistance = Mathf.Lerp(this.lastTargetDistance, targetDistance,
							this.distanceDamping * Time.deltaTime);
					}

					// update camera position
					this.lastTargetRotation = targetRotation;
					this.lastTargetDistance = targetDistance;
					targetPosition -= Quaternion.Euler(0, targetRotation, 0) * Vector3.forward * targetDistance;
					targetPosition.y = targetHeight;
				}
				else if(HorizontalPlaneType.XY == this.horizontalPlane)
				{
					// calculate the new height
					float targetHeight = targetPosition.z + this.inputZoom.y;
					if(this.heightDamping > 0 &&
						(this.initialDamping || !this.firstUpdate))
					{
						targetHeight = Mathf.Lerp(this.transform.position.z, targetHeight,
							this.heightDamping * Time.deltaTime);
					}
					// calculate the new distance
					float targetDistance = this.inputZoom.x;
					if(this.distanceDamping > 0 &&
						(this.initialDamping || !this.firstUpdate))
					{
						targetDistance = Mathf.Lerp(this.lastTargetDistance, targetDistance,
							this.distanceDamping * Time.deltaTime);
					}

					// update camera position
					this.lastTargetRotation = targetRotation;
					this.lastTargetDistance = targetDistance;
					targetPosition -= Quaternion.Euler(0, 0, targetRotation) * Vector3.forward * targetDistance;
					targetPosition.z = targetHeight;
				}

				if(this.cameraBorder != null && index >= 0)
				{
					this.cameraBorder[index].UpdateCameraHeight(ref targetPosition,
						this.horizontalPlane, this.IsUseable(this.useZoomingIn));
				}


				if(this.positionDamping > 0 &&
					(this.initialDamping || !this.firstUpdate))
				{
					targetPosition = Vector3.Lerp(this.transform.position, targetPosition,
						this.positionDamping * Time.deltaTime);
				}

				this.UpdatePosition(targetPosition,
					VectorHelper.LookAt(targetPosition, lookTargetPosition));

				this.firstUpdate = false;
			}
			else
			{
				this.firstUpdate = true;
			}
		}
	}
}
