
using ORKFramework;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Camera: Smooth Follow")]
	public class SmoothFollow : BaseCameraControl
	{
		public string onChild = "";

		public float distance = 10.0f;

		public float height = 5.0f;

		public float heightDamping = 2.0f;

		public float rotationDamping = 3.0f;

		void LateUpdate()
		{
			GameObject targetObject = TransformHelper.GetChildObject(this.onChild, this.CameraTarget);
			if(targetObject != null)
			{
				float wantedRotationAngle = targetObject.transform.eulerAngles.y;
				float wantedHeight = targetObject.transform.position.y + this.height;

				float currentRotationAngle = this.transform.eulerAngles.y;
				float currentHeight = this.transform.position.y;

				if(this.rotationDamping > 0)
				{
					currentRotationAngle = Mathf.LerpAngle(
						currentRotationAngle, wantedRotationAngle,
						this.rotationDamping * Time.deltaTime);
				}
				else
				{
					currentRotationAngle = wantedRotationAngle;
				}

				if(this.heightDamping > 0)
				{
					currentHeight = Mathf.Lerp(currentHeight, wantedHeight, this.heightDamping * Time.deltaTime);
				}
				else
				{
					currentHeight = wantedHeight;
				}

				Quaternion currentRotation = Quaternion.Euler(0, currentRotationAngle, 0);

				Vector3 position = targetObject.transform.position;
				position -= currentRotation * Vector3.forward * this.distance;
				position.y = currentHeight;

				this.UpdatePosition(position,
					VectorHelper.LookAt(position, targetObject.transform.position));
			}
		}
	}
}
