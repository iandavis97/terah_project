﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CursorSettings : BaseData
	{
		// default cursor
		[ORKEditorInfo("Default Cursor", "The default cursor is used whenever no other cursor is being used.\n" +
			"If no cursor texture is selected, the system cursor is used.", "",
			endFoldout=true)]
		public CursorChange defaultCursor = new CursorChange();


		// valid target cursors
		[ORKEditorHelp("Over Origin Box", "The 'Valid' cursors will also be displayed when " +
			"hovering over the origin GUI box that started the target selection " +
			"(e.g. a 'Combatant' HUD with a 'Shortcut' element starting the target selection through 'Click Use').", "")]
		[ORKEditorInfo("Target Selection Cursors (Valid)", "The target selection cursors are used during target selection.\n" +
			"The 'Valid' cursors are used when hovering over a valid target.", "")]
		public bool targetValidOriginBox = false;

		[ORKEditorHelp("Over Origin Shortcut", "The 'Valid' cursors will also be displayed when hovering over the shortcut slot " +
			"that started the target selection (e.g. using a shortcut slot through 'Click Use' in a HUD or a control map key).", "")]
		[ORKEditorLayout("targetValidOriginBox", false, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool targetValidOriginShortcut = false;

		[ORKEditorInfo("Target Self Cursor", "The target self cursor is used when hovering over a valid target for 'Self' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "",
			endFoldout=true)]
		public CursorChange targetSelfValid = new CursorChange();

		[ORKEditorInfo("Target Ally Cursor", "The target ally cursor is used when hovering over a valid target for 'Ally' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "",
			endFoldout=true)]
		public CursorChange targetAllyValid = new CursorChange();

		[ORKEditorInfo("Target Enemy Cursor", "The target enemy cursor is used when hovering over a valid target for 'Enemy' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "",
			endFoldout=true)]
		public CursorChange targetEnemyValid = new CursorChange();

		[ORKEditorInfo("Target All Cursor", "The target all cursor is used when hovering over a valid target for 'All' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "",
			endFoldout=true, endFolds=2)]
		public CursorChange targetAllValid = new CursorChange();


		// invalid target cursors
		[ORKEditorInfo("Target Selection Cursors (Invalid)", "The target selection cursors are used during target selection.\n" +
			"The 'Invalid' cursors are used when hovering over an invalid target.", "",
			"Target Self Cursor", "The target self cursor is used when hovering over an invalid target for 'Self' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "",
			endFoldout=true)]
		public CursorChange targetSelfInvalid = new CursorChange();

		[ORKEditorInfo("Target Ally Cursor", "The target ally cursor is used when hovering over an invalid target for 'Ally' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "",
			endFoldout=true)]
		public CursorChange targetAllyInvalid = new CursorChange();

		[ORKEditorInfo("Target Enemy Cursor", "The target enemy cursor is used when hovering over an invalid target for 'Enemy' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "",
			endFoldout=true)]
		public CursorChange targetEnemyInvalid = new CursorChange();

		[ORKEditorInfo("Target All Cursor", "The target all cursor is used when hovering over an invalid target for 'All' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "",
			endFoldout=true, endFolds=2)]
		public CursorChange targetAllInvalid = new CursorChange();


		// none target cursors
		[ORKEditorInfo("Target Selection Cursors (None)", "The target selection cursors are used during target selection.\n" +
			"The 'None' cursors are used when not hovering over any target.", "",
			"Target Self Cursor", "The target self cursor is used when not hovering over any target for 'Self' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "",
			endFoldout=true)]
		public CursorChange targetSelfNone = new CursorChange();

		[ORKEditorInfo("Target Ally Cursor", "The target ally cursor is used when not hovering over any target for 'Ally' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "",
			endFoldout=true)]
		public CursorChange targetAllyNone = new CursorChange();

		[ORKEditorInfo("Target Enemy Cursor", "The target enemy cursor is used when not hovering over any target for 'Enemy' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "",
			endFoldout=true)]
		public CursorChange targetEnemyNone = new CursorChange();

		[ORKEditorInfo("Target All Cursor", "The target all cursor is used when not hovering over any target for 'All' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "",
			endFoldout=true, endFolds=2)]
		public CursorChange targetAllNone = new CursorChange();


		// in action cursors
		[ORKEditorHelp("Ignore Death", "Death actions don't use in action cursors.", "")]
		[ORKEditorInfo("In Action Cursors", "The in action cursors are used while a combatant is in action.", "")]
		public bool inActionIgnoreDeath = false;

		[ORKEditorInfo("Player In Action Cursor", "The player in action cursor is used when a player controlled combatant is in action.\n" +
			"If no cursor texture is selected, the default cursor is used.", "",
			endFoldout=true)]
		public CursorChange inActionPlayer = new CursorChange();

		[ORKEditorInfo("Ally In Action Cursor", "The ally in action cursor is used when an ally of the player is in action.\n" +
			"If no cursor texture is selected, the default cursor is used.", "",
			endFoldout=true)]
		public CursorChange inActionAlly = new CursorChange();

		[ORKEditorInfo("Enemy In Action Cursor", "The enemy in action cursor is used when an enemy of the player is in action.\n" +
			"If no cursor texture is selected, the default cursor is used.", "",
			endFoldout=true, endFolds=2)]
		public CursorChange inActionEnemy = new CursorChange();


		// attack range cursors
		[ORKEditorHelp("Show Attack Range", "The attack range cursors will be displayed.\n" +
			"If disabled, the attack range cursors will not be displayed.", "")]
		[ORKEditorInfo("Attack Range Cursors", "The attack range cursors are used while a player controlled combatant " +
			"selects battle actions (not during target selection).\n" +
			"The cursor indicates if valid targets are within use range of the combatant's base attack or not.", "")]
		public bool showAttackRangeCursor = false;

		[ORKEditorHelp("Cursor Over", "Only show the attack range cursor while hovering the cursor over a valid target.", "")]
		[ORKEditorLayout("showAttackRangeCursor", true)]
		public bool attackRangeCursorOver = false;

		[ORKEditorInfo("In Range Cursor", "The in range cursor is used when valid targets are within use range of the combatant's base attack.\n" +
			"If no cursor texture is selected, the default cursor is used.", "",
			endFoldout=true)]
		public CursorChange inAttackRange = new CursorChange();

		[ORKEditorInfo("Out Of Range Cursor", "The out of range cursor is used when no valid targets are within use range of the combatant's base attack.\n" +
			"If no cursor texture is selected, the default cursor is used.", "",
			endFoldout=true, endFolds=2)]
		[ORKEditorLayout(endCheckGroup=true)]
		public CursorChange outOfAttackRange = new CursorChange();


		// in-game
		private List<CursorType> currentCursor = new List<CursorType>();

		private List<CursorChange> customCursors = new List<CursorChange>();

		private CursorTypeSorter sorter = new CursorTypeSorter();


		// attack range cursor
		private List<Combatant> attackRangeCombatants = new List<Combatant>();

		private bool isInAttackRange = false;

		public CursorSettings()
		{

		}


		/*
		============================================================================
		Cursor functions
		============================================================================
		*/
		public bool ShowCursor(CursorType type)
		{
			if(!this.currentCursor.Contains(type))
			{
				if(CursorType.Default == type)
				{
					this.currentCursor.Clear();
					this.customCursors.Clear();
				}
				else
				{
					if(this.IsTargetSelection(type))
					{
						this.RemoveTargetSelection();
					}

					this.currentCursor.Add(type);
					this.currentCursor.Sort(this.sorter);
				}

				return this.ShowCurrentCursor();
			}
			return true;
		}

		public void RemoveCursor(CursorType type)
		{
			if(this.currentCursor.Contains(type))
			{
				for(int i = this.currentCursor.Count - 1; i >= 0; i--)
				{
					if(this.currentCursor[i] == type)
					{
						this.currentCursor.RemoveAt(i);
						break;
					}
				}

				this.ShowCurrentCursor();
			}
		}

		private bool ShowCurrentCursor()
		{
			return this.DoShowCursor(this.currentCursor.Count > 0 ?
				this.currentCursor[this.currentCursor.Count - 1] :
				CursorType.Default);
		}


		/*
		============================================================================
		Show functions
		============================================================================
		*/
		private bool DoShowCursor(CursorType type)
		{
			// default
			if(CursorType.Default == type)
			{
				return this.ShowFallbackReset(this.defaultCursor);
			}
			// valid target
			else if(CursorType.TargetSelfValid == type)
			{
				return this.ShowFallbackDefault(this.targetSelfValid);
			}
			else if(CursorType.TargetAllyValid == type)
			{
				return this.ShowFallbackDefault(this.targetAllyValid);
			}
			else if(CursorType.TargetEnemyValid == type)
			{
				return this.ShowFallbackDefault(this.targetEnemyValid);
			}
			else if(CursorType.TargetAllValid == type)
			{
				return this.ShowFallbackDefault(this.targetAllValid);
			}
			// invalid target
			else if(CursorType.TargetSelfInvalid == type)
			{
				return this.ShowFallbackDefault(this.targetSelfInvalid);
			}
			else if(CursorType.TargetAllyInvalid == type)
			{
				return this.ShowFallbackDefault(this.targetAllyInvalid);
			}
			else if(CursorType.TargetEnemyInvalid == type)
			{
				return this.ShowFallbackDefault(this.targetEnemyInvalid);
			}
			else if(CursorType.TargetAllInvalid == type)
			{
				return this.ShowFallbackDefault(this.targetAllInvalid);
			}
			// none target
			else if(CursorType.TargetSelfNone == type)
			{
				return this.ShowFallbackDefault(this.targetSelfNone);
			}
			else if(CursorType.TargetAllyNone == type)
			{
				return this.ShowFallbackDefault(this.targetAllyNone);
			}
			else if(CursorType.TargetEnemyNone == type)
			{
				return this.ShowFallbackDefault(this.targetEnemyNone);
			}
			else if(CursorType.TargetAllNone == type)
			{
				return this.ShowFallbackDefault(this.targetAllNone);
			}
			// in action
			else if(CursorType.InActionPlayer == type)
			{
				return this.ShowFallbackDefault(this.inActionPlayer);
			}
			else if(CursorType.InActionAlly == type)
			{
				return this.ShowFallbackDefault(this.inActionAlly);
			}
			else if(CursorType.InActionEnemy == type)
			{
				return this.ShowFallbackDefault(this.inActionEnemy);
			}
			// attack range cursors
			else if(CursorType.AttackRange == type)
			{
				if(this.showAttackRangeCursor)
				{
					return this.ShowFallbackDefault(this.isInAttackRange ?
							this.inAttackRange : this.outOfAttackRange);
				}
			}
			// custom
			else if(CursorType.Custom == type)
			{
				if(this.customCursors.Count > 0)
				{
					return this.ShowFallbackDefault(this.customCursors[this.customCursors.Count - 1]);
				}
			}
			return false;
		}

		private void Reset()
		{
			Cursor.SetCursor(null, Vector2.zero, CursorMode.Auto);
		}

		private void ShowDefaultCursor()
		{
			if(!this.defaultCursor.SetCursor())
			{
				this.Reset();
			}
		}
		private bool ShowFallbackReset(CursorChange cursor)
		{
			if(cursor.SetCursor())
			{
				return true;
			}
			else
			{
				this.Reset();
				return false;
			}
		}

		private bool ShowFallbackDefault(CursorChange cursor)
		{
			if(cursor.SetCursor())
			{
				return true;
			}
			else
			{
				this.ShowDefaultCursor();
				return false;
			}
		}


		/*
		============================================================================
		Target selection functions
		============================================================================
		*/
		private bool IsTargetSelection(CursorType type)
		{
			return CursorType.TargetSelfValid == type ||
				CursorType.TargetAllyValid == type ||
				CursorType.TargetEnemyValid == type ||
				CursorType.TargetAllValid == type ||
				CursorType.TargetSelfInvalid == type ||
				CursorType.TargetAllyInvalid == type ||
				CursorType.TargetEnemyInvalid == type ||
				CursorType.TargetAllInvalid == type ||
				CursorType.TargetSelfNone == type ||
				CursorType.TargetAllyNone == type ||
				CursorType.TargetEnemyNone == type ||
				CursorType.TargetAllNone == type;
		}

		public bool ShowTargetValid(TargetSettings targetSettings)
		{
			if(targetSettings != null)
			{
				if(targetSettings.TargetSelf())
				{
					return this.ShowCursor(CursorType.TargetSelfValid);
				}
				else if(targetSettings.TargetAlly())
				{
					return this.ShowCursor(CursorType.TargetAllyValid);
				}
				else if(targetSettings.TargetEnemy())
				{
					return this.ShowCursor(CursorType.TargetEnemyValid);
				}
				else if(targetSettings.TargetAll())
				{
					return this.ShowCursor(CursorType.TargetAllValid);
				}
			}
			return false;
		}

		public bool ShowTargetInvalid(TargetSettings targetSettings)
		{
			if(targetSettings != null)
			{
				if(targetSettings.TargetSelf())
				{
					return this.ShowCursor(CursorType.TargetSelfInvalid);
				}
				else if(targetSettings.TargetAlly())
				{
					return this.ShowCursor(CursorType.TargetAllyInvalid);
				}
				else if(targetSettings.TargetEnemy())
				{
					return this.ShowCursor(CursorType.TargetEnemyInvalid);
				}
				else if(targetSettings.TargetAll())
				{
					return this.ShowCursor(CursorType.TargetAllInvalid);
				}
			}
			return false;
		}

		public bool ShowTargetNone(TargetSettings targetSettings)
		{
			if(targetSettings != null)
			{
				if(targetSettings.TargetSelf())
				{
					return this.ShowCursor(CursorType.TargetSelfNone);
				}
				else if(targetSettings.TargetAlly())
				{
					return this.ShowCursor(CursorType.TargetAllyNone);
				}
				else if(targetSettings.TargetEnemy())
				{
					return this.ShowCursor(CursorType.TargetEnemyNone);
				}
				else if(targetSettings.TargetAll())
				{
					return this.ShowCursor(CursorType.TargetAllNone);
				}
			}
			return false;
		}

		public bool ShowTargetOverBox(Combatant user, IShortcut shortcut)
		{
			GUIBox overBox = ORK.GUI.GetCursorOverBox(ORK.Control.MousePosition);
			if(user != null &&
				((ORK.Control.Cursor.targetValidOriginBox &&
					user.Battle.BattleMenu != null &&
					user.Battle.BattleMenu.targetOriginBox != null &&
					user.Battle.BattleMenu.targetOriginBox == overBox) ||
				(ORK.Control.Cursor.targetValidOriginShortcut &&
					GUIBox.IsHoveringOver(overBox, shortcut))))
			{
				return this.ShowTargetValid(TargetSettings.Get(shortcut));
			}
			else if(overBox != null)
			{
				this.RemoveTargetSelection();
				return true;
			}
			return false;
		}

		public void RemoveTargetSelection()
		{
			this.DoRemoveTargetSelection();
			this.ShowCurrentCursor();
		}

		private void DoRemoveTargetSelection()
		{
			for(int i = this.currentCursor.Count - 1; i >= 0; i--)
			{
				if(this.IsTargetSelection(this.currentCursor[i]))
				{
					this.currentCursor.RemoveAt(i);
				}
			}
		}


		/*
		============================================================================
		In action functions
		============================================================================
		*/
		private bool CheckAction(BaseAction action)
		{
			return action != null && action.User != null &&
				(!this.inActionIgnoreDeath || !action.IsType(ActionType.Death));
		}

		public bool ShowInAction(BaseAction action)
		{
			if(this.CheckAction(action))
			{
				if(CombatantAffiliationType.Player == action.ActionAffiliation)
				{
					return this.ShowCursor(CursorType.InActionPlayer);
				}
				else if(CombatantAffiliationType.Ally == action.ActionAffiliation)
				{
					return this.ShowCursor(CursorType.InActionAlly);
				}
				else if(CombatantAffiliationType.Enemy == action.ActionAffiliation)
				{
					return this.ShowCursor(CursorType.InActionEnemy);
				}
			}
			return false;
		}

		public void RemoveInAction(BaseAction action)
		{
			if(this.CheckAction(action))
			{
				if(CombatantAffiliationType.Player == action.ActionAffiliation)
				{
					this.RemoveCursor(CursorType.InActionPlayer);
				}
				else if(CombatantAffiliationType.Ally == action.ActionAffiliation)
				{
					this.RemoveCursor(CursorType.InActionAlly);
				}
				else if(CombatantAffiliationType.Enemy == action.ActionAffiliation)
				{
					this.RemoveCursor(CursorType.InActionEnemy);
				}
			}
		}


		/*
		============================================================================
		Attack range cursor functions
		============================================================================
		*/
		public bool ShowAttackRange(Combatant combatant)
		{
			if(this.showAttackRangeCursor &&
				!this.attackRangeCursorOver &&
				combatant != null &&
				!combatant.IsAIControlled() &&
				combatant.IsPlayerControlled())
			{
				if(this.attackRangeCombatants.Contains(combatant))
				{
					this.RemoveCursor(CursorType.AttackRange);
				}
				else
				{
					this.attackRangeCombatants.Add(combatant);
				}

				return this.DoShowAttackRange(combatant);
			}
			return false;
		}

		public void RemoveAttackRange(Combatant combatant)
		{
			if(this.showAttackRangeCursor &&
				!this.attackRangeCursorOver &&
				combatant != null)
			{
				if(this.attackRangeCombatants.Contains(combatant))
				{
					this.attackRangeCombatants.Remove(combatant);
					this.RemoveCursor(CursorType.AttackRange);
					if(this.attackRangeCombatants.Count > 0)
					{
						this.DoShowAttackRange(this.attackRangeCombatants[this.attackRangeCombatants.Count - 1]);
					}
				}
			}
		}

		private bool DoShowAttackRange(Combatant combatant)
		{
			if(combatant != null)
			{
				AbilityShortcut ability = combatant.Abilities.GetCurrentBaseAttack();
				this.isInAttackRange = ability.CanUse(combatant,
						AbilityActionType.CounterAttack != ability.Type, true) &&
					(ability.IsNoneTarget() || ability.HasPossibleTargets(combatant, null));
				return this.ShowCursor(CursorType.AttackRange);
			}
			return false;
		}

		public bool ShowAttackRangeCursorOver(Combatant combatant, Combatant target)
		{
			if(this.showAttackRangeCursor &&
				this.attackRangeCursorOver &&
				combatant != null &&
				target != null &&
				!combatant.IsAIControlled() &&
				combatant.IsPlayerControlled())
			{
				if(this.attackRangeCombatants.Count > 0)
				{
					this.attackRangeCombatants.Clear();
				}
				this.attackRangeCombatants.Add(combatant);

				this.RemoveCursor(CursorType.AttackRange);
				AbilityShortcut ability = combatant.Abilities.GetCurrentBaseAttack();
				if(ability.CanTarget(combatant, target))
				{
					this.isInAttackRange = ability.CanUse(combatant,
							AbilityActionType.CounterAttack != ability.Type, true) &&
						(ability.IsNoneTarget() || ability.InRange(combatant, target));
					return this.ShowCursor(CursorType.AttackRange);
				}
			}
			return false;
		}

		public void RemoveAttackRangeCursorOver(Combatant combatant)
		{
			if(this.showAttackRangeCursor &&
				this.attackRangeCursorOver &&
				this.attackRangeCombatants.Contains(combatant))
			{
				this.attackRangeCombatants.Clear();
				this.RemoveCursor(CursorType.AttackRange);
			}
		}


		/*
		============================================================================
		Custom cursor functions
		============================================================================
		*/
		public bool ShowCustomCursor(CursorChange cursor)
		{
			if(!this.customCursors.Contains(cursor))
			{
				this.currentCursor.Add(CursorType.Custom);
				this.currentCursor.Sort(this.sorter);
				this.customCursors.Add(cursor);

				this.ShowCurrentCursor();
				return true;
			}
			return false;
		}

		public void RemoveCustomCursor(CursorChange cursor)
		{
			if(this.customCursors.Contains(cursor))
			{
				this.customCursors.Remove(cursor);
				for(int i = this.currentCursor.Count - 1; i >= 0; i--)
				{
					if(this.currentCursor[i] == CursorType.Custom)
					{
						this.currentCursor.RemoveAt(i);
						break;
					}
				}

				this.ShowCurrentCursor();
			}
		}
	}
}
