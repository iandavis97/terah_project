﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;
using System.Collections;

namespace ORKFramework
{
	public enum MoveRangeType { Current, Max, All };

	public class BattleGridPathFinder
	{
		private Combatant user;

		private bool checkMarkedForAI = false;


		// flags
		private bool blockTargetDiagonalDistance1 = false;

		private bool keepBlockedCells = false;

		private bool ignoreBlockingCombatants = false;

		private bool ignoreFormationCombatants = false;

		private bool noMoveOver = false;

		private bool useActionCost = false;

		private bool moveRangeCreated = false;

		private bool considerGridFormation = false;

		private ConsiderFormationCombatants considerGridFormationCombatants = ConsiderFormationCombatants.None;

		private bool considerGridFormationReachable = false;

		private bool considerGridFormationCellType = false;


		// cells
		public BattleGridCellComponent startCell;

		public List<BattleGridCellComponent> availableTargets;

		public List<BattleGridCellComponent> blockedCells;

		public List<BattleGridCellComponent> passableCells;

		private Dictionary<BattleGridCellComponent, PathCell> cameFrom;


		// checks
		private CombatantCheck occupantCheck;

		private GridCellCheck cellCheck;

		public BattleGridPathFinder()
		{
			this.occupantCheck = this.CheckCellOccupant;
			this.cellCheck = this.CheckCell;
			this.useActionCost = ORK.Battle.IsTurnBased() || ORK.Battle.IsPhase();
		}

		public BattleGridPathFinder(bool keepBlockedCells)
		{
			this.keepBlockedCells = keepBlockedCells;

			this.occupantCheck = this.CheckCellOccupant;
			this.cellCheck = this.CheckCell;
			this.useActionCost = ORK.Battle.IsTurnBased() || ORK.Battle.IsPhase();
		}

		public BattleGridPathFinder(bool keepBlockedCells, bool blockTargetDiagonalDistance1)
		{
			this.keepBlockedCells = keepBlockedCells;
			this.blockTargetDiagonalDistance1 = blockTargetDiagonalDistance1;

			this.occupantCheck = this.CheckCellOccupant;
			this.cellCheck = this.CheckCell;
			this.useActionCost = ORK.Battle.IsTurnBased() || ORK.Battle.IsPhase();
		}

		public void Clear()
		{
			this.user = null;
			this.startCell = null;
			if(this.availableTargets != null)
			{
				this.availableTargets.Clear();
			}
			if(this.blockedCells != null)
			{
				this.blockedCells.Clear();
			}
			if(this.passableCells != null)
			{
				this.passableCells.Clear();
			}
			if(this.cameFrom != null)
			{
				this.cameFrom.Clear();
			}
			this.moveRangeCreated = false;
		}

		public bool MoveRangeCreated
		{
			get { return this.moveRangeCreated; }
		}

		public bool IgnoreBlockingCombatants
		{
			get { return this.ignoreBlockingCombatants; }
			set { this.ignoreBlockingCombatants = value; }
		}

		public bool IgnoreFormationCombatants
		{
			get { return this.ignoreFormationCombatants; }
			set { this.ignoreFormationCombatants = value; }
		}

		public bool NoMoveOver
		{
			get { return this.noMoveOver; }
			set { this.noMoveOver = value; }
		}

		public void SetConsiderGridFormation(bool consider,
			ConsiderFormationCombatants checkCombatants, bool checkReachable, bool sameCellType)
		{
			this.considerGridFormation = consider;
			this.considerGridFormationCombatants = checkCombatants;
			this.considerGridFormationReachable = checkReachable;
			this.considerGridFormationCellType = sameCellType;
		}


		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		public List<Combatant> GetCombatantsOnPath(BattleGridCellComponent toCell)
		{
			List<Combatant> list = new List<Combatant>();
			this.GetCombatantsOnPath(toCell, ref list);
			return list;
		}

		public void GetCombatantsOnPath(BattleGridCellComponent toCell, ref List<Combatant> list)
		{
			if(list.Count > 0)
			{
				list.Clear();
			}
			if(toCell != null && this.cameFrom != null &&
				this.cameFrom.ContainsKey(toCell))
			{
				BattleGridCellComponent current = toCell;
				current.GetCombatants(ref list, null);
				while(current != this.startCell)
				{
					current = this.cameFrom[current].cell;
					if(current != this.startCell)
					{
						current.GetCombatants(ref list, null);
					}
				}
				list.Reverse();
			}
		}

		public bool IsMarkedForAI(BattleGridCellComponent cell)
		{
			return this.checkMarkedForAI &&
				cell.MarkedForAI != null &&
				cell.MarkedForAI != this.user;
		}


		/*
		============================================================================
		Path functions
		============================================================================
		*/
		public bool CheckCosts(BattleGridCellComponent toCell)
		{
			return this.cameFrom.ContainsKey(toCell) ?
				(this.cameFrom[toCell].moveCost <= this.user.Battle.GridMoveRange &&
				(!this.useActionCost ||
					this.user.Battle.UsedActionBar + this.cameFrom[toCell].actionCost <= this.user.Battle.ActionBar)) :
				false;
		}

		public float GetMoveCost(BattleGridCellComponent toCell)
		{
			return this.cameFrom.ContainsKey(toCell) ? this.cameFrom[toCell].moveCost : 0;
		}

		public float GetActionCost(BattleGridCellComponent toCell)
		{
			return this.useActionCost ?
				(this.cameFrom.ContainsKey(toCell) ? this.cameFrom[toCell].actionCost : 0) : 0;
		}

		public List<BattleGridCellComponent> GetPath(BattleGridCellComponent toCell)
		{
			List<BattleGridCellComponent> path = new List<BattleGridCellComponent>();
			this.GetPath(toCell, ref path);
			return path;
		}

		public void GetPath(BattleGridCellComponent toCell, ref List<BattleGridCellComponent> path)
		{
			if(path.Count > 0)
			{
				path.Clear();
			}
			if(toCell != null && this.cameFrom != null &&
				this.cameFrom.ContainsKey(toCell))
			{
				BattleGridCellComponent current = toCell;
				path.Add(current);
				while(current != this.startCell)
				{
					current = this.cameFrom[current].cell;
					if(current != this.startCell)
					{
						path.Add(current);
					}
				}
				path.Reverse();
			}
		}

		public int GetPathLength(BattleGridCellComponent toCell)
		{
			int length = 0;
			if(toCell != null && this.cameFrom != null &&
				this.cameFrom.ContainsKey(toCell))
			{
				BattleGridCellComponent current = toCell;
				while(current != this.startCell)
				{
					current = this.cameFrom[current].cell;
					if(current != this.startCell)
					{
						length++;
					}
				}
			}
			return length;
		}

		public BattleGridCellComponent GetLastReachablePathCell(BattleGridCellComponent toCell,
			bool directMoveOnly, ref bool canReach, BattleGridCellComponent targetCell,
			List<BattleGridCellComponent> ignoreCells, List<BattleGridCellComponent> allowCells,
			GridCellCheck check)
		{
			BattleGridCellComponent current = null;
			if(toCell != null &&
				this.cameFrom != null &&
				this.cameFrom.ContainsKey(toCell))
			{
				if(toCell.IsEmpty &&
					!this.IsMarkedForAI(toCell) &&
					!toCell.IsBlocked)
				{
					current = toCell;
				}
				if(this.ignoreBlockingCombatants &&
					current == null)
				{
					current = toCell;
				}
				if(current != null)
				{
					canReach = true;

					if(directMoveOnly &&
						current != toCell)
					{
						return null;
					}

					// blocking combatant
					if(this.ignoreBlockingCombatants)
					{
						BattleGridCellComponent tmpCell = current;
						current = null;
						while(tmpCell != this.startCell)
						{
							if(!tmpCell.IsPassable ||
								!this.CheckCellOccupant(tmpCell.Combatant) ||
								(this.checkMarkedForAI &&
									!this.CheckCellOccupant(tmpCell.MarkedForAI)))
							{
								current = null;
							}
							if(current == null &&
								tmpCell.IsEmpty &&
								!this.IsMarkedForAI(tmpCell) &&
								!tmpCell.IsBlocked)
							{
								current = tmpCell;
							}
							tmpCell = this.cameFrom[tmpCell].cell;
						}

						if(directMoveOnly &&
							current != toCell)
						{
							return null;
						}
					}
					if(current != null)
					{
						// last reachable
						while(current != this.startCell &&
							(this.cameFrom[current].moveCost > this.user.Battle.GridMoveRange ||
							(this.useActionCost &&
								this.user.Battle.UsedActionBar + this.cameFrom[current].actionCost > this.user.Battle.ActionBar) ||
							(check != null && !check(current))))
						{
							current = this.cameFrom[current].cell;


							if(directMoveOnly &&
								current != toCell)
							{
								return null;
							}

							while(current != this.startCell &&
								(!current.IsEmpty ||
									current.IsBlocked ||
									this.IsMarkedForAI(current)))
							{
								current = this.cameFrom[current].cell;

								if(directMoveOnly &&
									current != toCell)
								{
									return null;
								}
							}
						}
						// grid formation
						if(this.considerGridFormation)
						{
							while(current != this.startCell &&
								!this.user.Group.GridFormation.CheckFormationPossible(
									current, this.considerGridFormationCombatants,
									BattleGridHelper.GetCellDirection(current,
										targetCell != null ? targetCell : this.cameFrom[current].cell, false),
									this.considerGridFormationReachable, this.keepBlockedCells,
									this.considerGridFormationCellType, ignoreCells, allowCells))
							{
								current = this.cameFrom[current].cell;

								if(directMoveOnly &&
									current != toCell)
								{
									return null;
								}

								while(current != this.startCell &&
									(!current.IsEmpty ||
										current.IsBlocked ||
										this.IsMarkedForAI(current)))
								{
									current = this.cameFrom[current].cell;

									if(directMoveOnly &&
										current != toCell)
									{
										return null;
									}
								}
							}
						}
						// final check
						if(current == this.startCell ||
							(current != null &&
								(!current.IsEmpty ||
									current.IsBlocked ||
									this.IsMarkedForAI(current)) ||
									(check != null && !check(current))))
						{
							current = null;
						}
					}
				}
			}
			return current;
		}

		public BattleGridCellComponent GetMostDistantCell(BattleGridCellComponent fromCell, GridCellCheck check)
		{
			BattleGridCellComponent current = null;
			if(fromCell != null)
			{
				float maxDistance = Mathf.Infinity;
				for(int i = 0; i < this.availableTargets.Count; i++)
				{
					if(this.availableTargets[i] != null)
					{
						float tmpDistance = fromCell.CubeCoord.Distance(this.availableTargets[i].CubeCoord);
						if(tmpDistance < maxDistance &&
							(check == null || check(this.availableTargets[i])))
						{
							tmpDistance = maxDistance;
							current = this.availableTargets[i];
						}
					}
				}
			}
			return current;
		}


		/*
		============================================================================
		Move range functions
		============================================================================
		*/
		public GridMoveAction GetMoveAction(BattleGridCellComponent toCell, GridMoveShortcut gridMoveShortcut, Combatant target)
		{
			return new GridMoveAction(this.user, target, this.GetPath(toCell), this.GetMoveCost(toCell),
				this.useActionCost ? this.GetActionCost(toCell) : 0, gridMoveShortcut);
		}

		public bool CheckCell(BattleGridCellComponent cell)
		{
			return cell != null && cell.CheckOccupants(this.occupantCheck) &&
				(!this.checkMarkedForAI || this.occupantCheck(cell.MarkedForAI));
		}

		public bool CheckCellOccupant(Combatant combatant)
		{
			return combatant == null || (!this.noMoveOver &&
				((ORK.BattleSystem.gridSettings.moveCommand.moveOverAllies &&
					!this.user.IsEnemy(combatant)) ||
				(ORK.BattleSystem.gridSettings.moveCommand.moveOverEnemies &&
					this.user.IsEnemy(combatant)) ||
				(this.ignoreFormationCombatants &&
					this.user.Group.InFormation &&
					this.user.Group.GridFormation.IsInFormation(combatant))));
		}

		public void CreateMoveRange(Combatant user, MoveRangeType moveRangeType,
			List<BattleGridCellComponent> ignoreCells, List<BattleGridCellComponent> allowCells)
		{
			if(user != null && user.Grid.Cell != null)
			{
				this.user = user;
				this.startCell = this.user.Grid.Cell;
				this.checkMarkedForAI = this.user.IsAIControlled();

				if(this.keepBlockedCells)
				{
					ArrayHelper.GetBlank(ref this.blockedCells);
					ArrayHelper.GetBlank(ref this.passableCells);
				}

				Queue<BattleGridCellComponent> frontier = new Queue<BattleGridCellComponent>();
				frontier.Enqueue(this.startCell);

				ArrayHelper.GetBlank(ref this.cameFrom);
				this.cameFrom.Add(this.startCell, new PathCell(null, 0,
					this.useActionCost ? ORK.Battle.GetGridMoveActionCost(this.user) : 0));

				List<BattleGridCellComponent> neighbours = new List<BattleGridCellComponent>();
				HashSet<BattleGridCellComponent> used = new HashSet<BattleGridCellComponent>();

				if(ignoreCells != null)
				{
					for(int i = 0; i < ignoreCells.Count; i++)
					{
						if(ignoreCells[i] != this.startCell &&
							(allowCells == null ||
								!allowCells.Contains(ignoreCells[i])))
						{
							used.Add(ignoreCells[i]);
						}
					}
				}

				float moveRange = 0;
				float actionRange = 0;
				if(MoveRangeType.Current == moveRangeType)
				{
					moveRange = this.user.Battle.GridMoveRange;
					if(this.useActionCost)
					{
						actionRange = this.user.Battle.ActionBar - this.user.Battle.UsedActionBar;
					}
				}
				else if(MoveRangeType.Max == moveRangeType)
				{
					moveRange = this.user.Battle.GridMoveRangeMax;
					if(this.useActionCost)
					{
						actionRange = this.user.Battle.ActionBar;
					}
				}
				else if(MoveRangeType.All == moveRangeType)
				{
					moveRange = Mathf.Infinity;
					if(this.useActionCost)
					{
						actionRange = Mathf.Infinity;
					}
				}

				while(frontier.Count > 0)
				{
					BattleGridCellComponent current = frontier.Dequeue();
					bool costLimit = this.cameFrom[current].moveCost >= moveRange ||
						this.cameFrom[current].actionCost >= actionRange;

					if(!used.Contains(current))
					{
						used.Add(current);

						// get neighbours
						if(neighbours.Count > 0)
						{
							neighbours.Clear();
						}

						if(this.keepBlockedCells &&
							!costLimit)
						{
							BattleGridHelper.GetNeighbourCells(current, ref neighbours, ref this.blockedCells, true, false,
								ORK.BattleSystem.gridSettings.moveCommand.squareDiagonalMove,
								this.ignoreBlockingCombatants ? null : this.cellCheck,
								ORK.BattleSystem.gridSettings.moveCommand.squareDiagonalMoveBlockingCombatants ? this.cellCheck : null);
						}
						else
						{
							BattleGridHelper.GetNeighbourCells(current, ref neighbours, true, false,
								ORK.BattleSystem.gridSettings.moveCommand.squareDiagonalMove,
								this.ignoreBlockingCombatants ? null : this.cellCheck,
								ORK.BattleSystem.gridSettings.moveCommand.squareDiagonalMoveBlockingCombatants ? this.cellCheck : null);
						}

						for(int i = 0; i < neighbours.Count; i++)
						{
							if(neighbours[i].Settings.CanMoveFrom(current))
							{
								// check cost
								float newMoveCost = this.cameFrom[current].moveCost +
									neighbours[i].Settings.GetMoveCost(this.user, current);
								float newActionCost = this.useActionCost ?
									(this.cameFrom[current].actionCost +
										neighbours[i].Settings.GetActionCost(this.user, current)) :
									0;

								if(newMoveCost <= moveRange &&
									(!this.useActionCost || newActionCost <= actionRange))
								{
									// new cell
									if(!this.cameFrom.ContainsKey(neighbours[i]))
									{
										frontier.Enqueue(neighbours[i]);
										this.cameFrom.Add(neighbours[i], new PathCell(current, newMoveCost, newActionCost));
									}
									// check replace old cell
									else
									{
										float oldMoveCost = this.cameFrom[neighbours[i]].moveCost;
										float oldActionCost = this.cameFrom[neighbours[i]].actionCost;
										if((newMoveCost < oldMoveCost &&
												newActionCost == oldActionCost) ||
											(this.useActionCost &&
												newMoveCost == oldMoveCost &&
												newActionCost < oldActionCost) ||
											(newMoveCost == oldMoveCost &&
												(!this.useActionCost ||
													newActionCost == oldActionCost) &&
												// not diagonal
												((ORK.BattleSystem.gridSettings.moveCommand.squareDiagonalMove &&
													!CubeCoord.IsSquareDiagonal(current.CubeCoord, neighbours[i].CubeCoord)) ||
												// shorter path
												(ORK.BattleSystem.gridSettings.moveCommand.useShortestPath &&
													this.GetPathLength(current) + 1 < this.GetPathLength(neighbours[i])))))
										{
											frontier.Enqueue(neighbours[i]);
											this.cameFrom[neighbours[i]] = new PathCell(current, newMoveCost, newActionCost);
										}
									}
								}
							}
						}
					}
				}

				// generate available target cells
				ArrayHelper.GetBlank(ref this.availableTargets);
				foreach(BattleGridCellComponent cell in this.cameFrom.Keys)
				{
					if(cell != null &&
						!cell.IsBlocked &&
						(cell.IsEmpty ||
							(this.ignoreFormationCombatants &&
								user.Group.InFormation &&
								user.Group.GridFormation.IsInFormation(cell.Combatant))) &&
						(!this.checkMarkedForAI ||
							cell.MarkedForAI == null ||
							cell.MarkedForAI == user ||
							(this.ignoreFormationCombatants &&
								user.Group.InFormation &&
								user.Group.GridFormation.IsInFormation(cell.MarkedForAI))))
					{
						this.availableTargets.Add(cell);
					}
					else if(this.keepBlockedCells)
					{
						this.passableCells.Add(cell);
					}
				}
				this.moveRangeCreated = true;
			}
		}

		public void CreatePathTo(Combatant user, BattleGridCellComponent toCell)
		{
			if(user != null && user.Grid.Cell != null)
			{
				this.user = user;
				this.startCell = this.user.Grid.Cell;
				this.checkMarkedForAI = this.user.IsAIControlled();

				Queue<BattleGridCellComponent> frontier = new Queue<BattleGridCellComponent>();
				frontier.Enqueue(this.startCell);

				ArrayHelper.GetBlank(ref this.cameFrom);
				this.cameFrom.Add(this.startCell, new PathCell(null, 0,
					this.useActionCost ? ORK.Battle.GetGridMoveActionCost(this.user) : 0));

				List<BattleGridCellComponent> neighbours = new List<BattleGridCellComponent>();
				HashSet<BattleGridCellComponent> used = new HashSet<BattleGridCellComponent>();
				used.Add(toCell);

				while(frontier.Count > 0)
				{
					// sort frontier
					BattleGridCellComponent current = frontier.Dequeue();

					if(!used.Contains(current))
					{
						used.Add(current);

						// get neighbours
						if(neighbours.Count > 0)
						{
							neighbours.Clear();
						}
						BattleGridHelper.GetNeighbourCells(current, ref neighbours,
							true, false, ORK.BattleSystem.gridSettings.moveCommand.squareDiagonalMove, null,
							ORK.BattleSystem.gridSettings.moveCommand.squareDiagonalMoveBlockingCombatants ? this.cellCheck : null);

						for(int i = 0; i < neighbours.Count; i++)
						{
							// check cell combatant
							if(neighbours[i].Settings.CanMoveFrom(current) &&
								(neighbours[i] == toCell ||
									this.ignoreBlockingCombatants ||
									neighbours[i].CheckOccupants(this.occupantCheck)))
							{
								float newMoveCost = this.cameFrom[current].moveCost +
									neighbours[i].Settings.GetMoveCost(this.user, current);
								float newActionCost = this.useActionCost ?
									(this.cameFrom[current].actionCost +
										neighbours[i].Settings.GetActionCost(this.user, current)) :
									0;

								// new cell
								if(!this.cameFrom.ContainsKey(neighbours[i]))
								{
									frontier.Enqueue(neighbours[i]);
									this.cameFrom.Add(neighbours[i], new PathCell(current, newMoveCost, newActionCost));
								}
								// check replace old cell
								else
								{
									float oldMoveCost = this.cameFrom[neighbours[i]].moveCost;
									float oldActionCost = this.cameFrom[neighbours[i]].actionCost;
									if((newMoveCost < oldMoveCost && newActionCost == oldActionCost) ||
										(this.useActionCost && newMoveCost == oldMoveCost && newActionCost < oldActionCost) ||
										(newMoveCost == oldMoveCost &&
											(!this.useActionCost || newActionCost == oldActionCost) &&
											// not diagonal
											((ORK.BattleSystem.gridSettings.moveCommand.squareDiagonalMove &&
												!CubeCoord.IsSquareDiagonal(current.CubeCoord, neighbours[i].CubeCoord)) ||
											// shorter path
											(ORK.BattleSystem.gridSettings.moveCommand.useShortestPath &&
												this.GetPathLength(current) + 1 < this.GetPathLength(neighbours[i])))) ||
										// use free cell
										(neighbours[i] == toCell &&
											current.IsEmpty &&
											(!ORK.BattleSystem.gridSettings.squareDiagonalDistanceOne ||
												current.CubeCoord.Distance(toCell.CubeCoord, this.blockTargetDiagonalDistance1) == 1) &&
											!this.cameFrom[neighbours[i]].cell.IsEmpty))
									{
										frontier.Enqueue(neighbours[i]);
										this.cameFrom[neighbours[i]] = new PathCell(current, newMoveCost, newActionCost);
									}
								}
							}
						}
					}
				}
			}
		}

		public static bool CanReach(Combatant combatant, BattleGridCellComponent cell,
			bool keepBlockedCells, bool ignoreFormationCombatants, MoveRangeType moveRangeType,
			List<BattleGridCellComponent> ignoreCells, List<BattleGridCellComponent> allowCells)
		{
			if(combatant != null &&
				combatant.Grid.Cell != null &&
				ORK.Battle.Grid != null)
			{
				BattleGridPathFinder path = new BattleGridPathFinder(keepBlockedCells);
				path.ignoreFormationCombatants = ignoreFormationCombatants;
				path.CreateMoveRange(combatant, moveRangeType, ignoreCells, allowCells);
				return path.availableTargets.Contains(cell);
			}
			return false;
		}

		private struct PathCell
		{
			public BattleGridCellComponent cell;

			public float moveCost;

			public float actionCost;

			public PathCell(BattleGridCellComponent cell, float moveCost, float actionCost)
			{
				this.cell = cell;
				this.moveCost = moveCost;
				this.actionCost = actionCost;
			}
		}
	}
}
