﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class SquareGridHelper : IGridHelper
	{
		private bool diagonalDistanceOne = false;

		public SquareGridHelper(BattleSystemSettings settings)
		{
			this.diagonalDistanceOne = settings.gridSettings.squareDiagonalDistanceOne;
		}


		/*
		============================================================================
		Direction functions
		============================================================================
		*/
		public CubeCoord GetDirection(int direction)
		{
			if(direction < 0)
			{
				direction += (int)(Mathf.Ceil((-direction) / (float)BattleGridHelper.SquareDirections.Length)) *
					BattleGridHelper.SquareDirections.Length;
			}
			else if(direction > BattleGridHelper.SquareDirections.Length - 1)
			{
				direction -= (int)(Mathf.Floor(direction / (float)BattleGridHelper.SquareDirections.Length)) *
					BattleGridHelper.SquareDirections.Length;
			}
			return BattleGridHelper.SquareDirections[direction];
		}

		public CubeCoord GetDirectionNonDiagonal(int direction)
		{
			if(direction < 0)
			{
				direction += (int)(Mathf.Ceil((-direction) / (float)BattleGridHelper.SquareDirectionsNonDiagonal.Length)) *
					BattleGridHelper.SquareDirectionsNonDiagonal.Length;
			}
			else if(direction > BattleGridHelper.SquareDirectionsNonDiagonal.Length - 1)
			{
				direction -= (int)(Mathf.Floor(direction / (float)BattleGridHelper.SquareDirectionsNonDiagonal.Length)) *
					BattleGridHelper.SquareDirectionsNonDiagonal.Length;
			}
			return BattleGridHelper.SquareDirectionsNonDiagonal[direction];
		}


		/*
		============================================================================
		Rotation functions
		============================================================================
		*/
		public int AngleToDirection(float angle, bool allowSquareDiagonal)
		{
			float tmp = 360.0f / (allowSquareDiagonal ? BattleGridHelper.SquareDirections.Length : 4);
			angle += tmp / 2;
			ValueHelper.SecureRotation(ref angle);
			return (int)(angle / tmp);
		}

		public float DirectionToAngle(int direction, bool allowSquareDiagonal)
		{
			if(direction < 0)
			{
				direction += (allowSquareDiagonal ? BattleGridHelper.SquareDirections.Length : 4);
			}
			else if(direction > (allowSquareDiagonal ? BattleGridHelper.SquareDirections.Length : 4) - 1)
			{
				direction -= (allowSquareDiagonal ? BattleGridHelper.SquareDirections.Length : 4);
			}
			float angle = direction * (360.0f / (allowSquareDiagonal ? BattleGridHelper.SquareDirections.Length : 4));
			ValueHelper.SecureRotation(ref angle);
			return angle;
		}


		/*
		============================================================================
		Neighbour functions
		============================================================================
		*/
		public float GetNeighbourAngle()
		{
			return 90.0f;
		}

		public float GetNeighbourAngleOffset()
		{
			return 0.0f;
		}

		public BattleGridCellComponent GetNeighbourCell(BattleGridCellComponent cell, int index)
		{
			if(cell != null && index >= 0)
			{
				if(index < BattleGridHelper.SquareDirections.Length)
				{
					return cell.parentGrid.GetCell(
						cell.CubeCoord + BattleGridHelper.SquareDirections[index]);
				}
			}
			return cell;
		}

		public bool IsNeighbourCell(BattleGridCellComponent origin,
			BattleGridCellComponent cell, bool allowSquareDiagonal, GridCellCheck check)
		{
			if(origin != null && cell != null)
			{
				CubeCoord[] directions = allowSquareDiagonal ?
					BattleGridHelper.SquareDirectionsDiagonal :
					BattleGridHelper.SquareDirectionsNonDiagonal;
				CubeCoord coord = new CubeCoord();

				for(int i = 0; i < directions.Length; i++)
				{
					coord.SetAdd(origin.CubeCoord, directions[i]);
					BattleGridCellComponent tmpCell = origin.parentGrid.GetCell(coord);

					if(cell == tmpCell &&
						(check == null || check(cell)))
					{
						return true;
					}
				}
			}
			return false;
		}

		public void UsePathNeighbourCells(BattleGridCellComponent origin, UsePathCell useCell,
			bool allowSquareDiagonal, GridCellCheck check, GridCellCheck checkDiagonal)
		{
			CubeCoord coord = new CubeCoord();
			if(allowSquareDiagonal)
			{
				for(int i = 0; i < BattleGridHelper.SquareDirectionsDiagonal.Length; i++)
				{
					coord.SetAdd(origin.CubeCoord, BattleGridHelper.SquareDirectionsDiagonal[i]);
					BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

					if(cell != null)
					{
						BattleGridCellComponent cell2 = null;
						BattleGridCellComponent cell3 = null;
						if(CubeCoord.IsSquareDiagonal(origin.CubeCoord, cell.CubeCoord))
						{
							coord.SetAdd(origin.CubeCoord,
								BattleGridHelper.SquareDirectionsDiagonal[i - 1 < 0 ?
									BattleGridHelper.SquareDirectionsDiagonal.Length - 1 : i - 1]);
							cell2 = origin.parentGrid.GetCell(coord);
							coord.SetAdd(origin.CubeCoord,
								BattleGridHelper.SquareDirectionsDiagonal[
									i + 1 >= BattleGridHelper.SquareDirectionsDiagonal.Length ?
										0 : i + 1]);
							cell3 = origin.parentGrid.GetCell(coord);
						}

						if(cell.IsPassable &&
							(cell2 == null || (!cell2.BlockDiagonalMove &&
								(checkDiagonal == null || checkDiagonal(cell2)))) &&
							(cell3 == null || (!cell3.BlockDiagonalMove &&
								(checkDiagonal == null || checkDiagonal(cell3)))) &&
							(check == null || check(cell)))
						{
							useCell(cell, i);
						}
					}
				}
			}
			else
			{
				for(int i = 0; i < BattleGridHelper.SquareDirectionsNonDiagonal.Length; i++)
				{
					coord.SetAdd(origin.CubeCoord, BattleGridHelper.SquareDirectionsNonDiagonal[i]);
					BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

					if(cell != null &&
						cell.IsPassable &&
						(check == null || check(cell)))
					{
						useCell(cell, i);
					}
				}
			}
		}

		public void UsePathNeighbourCells(BattleGridCellComponent origin,
			UsePathCell useCell, ref List<BattleGridCellComponent> blockedList,
			bool allowSquareDiagonal, bool blockedOccupied, GridCellCheck check, GridCellCheck checkDiagonal)
		{
			CubeCoord coord = new CubeCoord();

			if(allowSquareDiagonal)
			{
				for(int i = 0; i < BattleGridHelper.SquareDirectionsDiagonal.Length; i++)
				{
					coord.SetAdd(origin.CubeCoord, BattleGridHelper.SquareDirectionsDiagonal[i]);

					BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

					if(cell != null)
					{
						BattleGridCellComponent cell2 = null;
						BattleGridCellComponent cell3 = null;
						if(CubeCoord.IsSquareDiagonal(origin.CubeCoord, cell.CubeCoord))
						{
							coord.SetAdd(origin.CubeCoord,
								BattleGridHelper.SquareDirectionsDiagonal[i - 1 < 0 ?
									BattleGridHelper.SquareDirectionsDiagonal.Length - 1 : i - 1]);
							cell2 = origin.parentGrid.GetCell(coord);

							coord.SetAdd(origin.CubeCoord,
								BattleGridHelper.SquareDirectionsDiagonal[
									i + 1 >= BattleGridHelper.SquareDirectionsDiagonal.Length ?
										0 : i + 1]);
							cell3 = origin.parentGrid.GetCell(coord);
						}

						if((cell2 == null || (!cell2.BlockDiagonalMove &&
								(checkDiagonal == null || checkDiagonal(cell2)))) &&
							(cell3 == null || (!cell3.BlockDiagonalMove &&
								(checkDiagonal == null || checkDiagonal(cell3)))))
						{
							if(cell.IsPassable &&
								(check == null || check(cell)))
							{
								useCell(cell, i);
							}
							else if((blockedOccupied || cell.IsEmpty) && 
								!blockedList.Contains(cell))
							{
								blockedList.Add(cell);
							}
						}
					}
				}
			}
			else
			{
				for(int i = 0; i < BattleGridHelper.SquareDirectionsNonDiagonal.Length; i++)
				{
					coord.SetAdd(origin.CubeCoord, BattleGridHelper.SquareDirectionsNonDiagonal[i]);
					BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

					if(cell != null)
					{
						if(cell.IsPassable &&
							(check == null || check(cell)))
						{
							useCell(cell, i);
						}
						else if((blockedOccupied || cell.IsEmpty) && 
							!blockedList.Contains(cell))
						{
							blockedList.Add(cell);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Range functions
		============================================================================
		*/
		public void GetRange(BattleGridCellComponent origin, int minDistance, int maxDistance,
			ref List<BattleGridCellComponent> list, ref HashSet<BattleGridCellComponent> contains,
			bool addOrigin, bool addBlocked, bool addNotPassable, bool allowSquareDiagonal, GridCellCheck check)
		{
			if(origin != null)
			{
				CubeCoord coord = new CubeCoord();
				if(allowSquareDiagonal &&
					this.diagonalDistanceOne)
				{
					for(int dx = -maxDistance; dx <= maxDistance; dx++)
					{
						for(int dy = -maxDistance; dy <= maxDistance; dy++)
						{
							int tmpDistance = CubeCoord.ZeroDistanceSquareDiagonal(dx, dy);
							if(tmpDistance >= minDistance &&
								tmpDistance <= maxDistance)
							{
								coord.SetAdd(origin.CubeCoord, dx, dy, 0);
								BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

								if(cell != null &&
									(addOrigin || origin != cell) &&
									(addBlocked || !cell.IsBlocked) &&
									(addNotPassable || cell.IsPassable) &&
									(check == null || check(cell)) &&
									!contains.Contains(cell))
								{
									list.Add(cell);
									contains.Add(cell);
								}
							}
						}
					}
				}
				else
				{
					for(int dx = -maxDistance; dx <= maxDistance; dx++)
					{
						for(int dy = -maxDistance; dy <= maxDistance; dy++)
						{
							int tmpDistance = CubeCoord.ZeroDistanceSquareNonDiagonal(dx, dy);
							if(tmpDistance >= minDistance &&
								tmpDistance <= maxDistance)
							{
								coord.SetAdd(origin.CubeCoord, dx, dy, 0);
								BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

								if(cell != null &&
									(addOrigin || origin != cell) &&
									(addBlocked || !cell.IsBlocked) &&
									(addNotPassable || cell.IsPassable) &&
									(check == null || check(cell)) &&
									!contains.Contains(cell))
								{
									list.Add(cell);
									contains.Add(cell);
								}
							}
						}
					}
				}
			}
		}

		public void GetRange(Combatant user, int minDistance, int maxDistance,
			ref List<BattleGridCellComponent> list, ref HashSet<BattleGridCellComponent> contains,
			bool allowSquareDiagonal, GridCellOriginCheck check)
		{
			if(user != null &&
				user.Grid.Cell != null)
			{
				CubeCoord coord = new CubeCoord();
				for(int dx = -maxDistance; dx <= maxDistance; dx++)
				{
					for(int dy = -maxDistance; dy <= maxDistance; dy++)
					{
						for(int i = 0; i < user.Grid.CellCount; i++)
						{
							BattleGridCellComponent origin = user.Grid.GetCell(i);
							if(origin != null)
							{
								coord.SetAdd(origin.CubeCoord, dx, dy, 0);
								BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

								if(cell != null &&
									user.Grid.InRange(cell, !allowSquareDiagonal, minDistance, maxDistance, check) &&
									!contains.Contains(cell))
								{
									list.Add(cell);
									contains.Add(cell);
								}
							}
						}
					}
				}
			}
		}

		public void GetRangeCombatants(BattleGridCellComponent origin, int minDistance, int maxDistance,
		   ref List<Combatant> list, bool addOrigin, bool addBlocked, bool addNotPassable,
		   bool allowSquareDiagonal, GridCellCheck check)
		{
			CubeCoord coord = new CubeCoord();
			if(allowSquareDiagonal &&
				this.diagonalDistanceOne)
			{
				for(int dx = -maxDistance; dx <= maxDistance; dx++)
				{
					for(int dy = -maxDistance; dy <= maxDistance; dy++)
					{
						int tmpDistance = CubeCoord.ZeroDistanceSquareDiagonal(dx, dy);
						if(tmpDistance >= minDistance &&
							tmpDistance <= maxDistance)
						{
							coord.SetAdd(origin.CubeCoord, dx, dy, 0);
							BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

							if(cell != null &&
								!cell.IsEmpty &&
								(addOrigin || origin != cell) &&
								(addBlocked || !cell.IsBlocked) &&
								(addNotPassable || cell.IsPassable) &&
								(check == null || check(cell)))
							{
								cell.GetCombatants(ref list, null);
							}
						}
					}
				}
			}
			else
			{
				for(int dx = -maxDistance; dx <= maxDistance; dx++)
				{
					for(int dy = -maxDistance; dy <= maxDistance; dy++)
					{
						int tmpDistance = CubeCoord.ZeroDistanceSquareNonDiagonal(dx, dy);
						if(tmpDistance >= minDistance &&
							tmpDistance <= maxDistance)
						{
							coord.SetAdd(origin.CubeCoord, dx, dy, 0);
							BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

							if(cell != null &&
								!cell.IsEmpty &&
								(addOrigin || origin != cell) &&
								(addBlocked || !cell.IsBlocked) &&
								(addNotPassable || cell.IsPassable) &&
								(check == null || check(cell)))
							{
								cell.GetCombatants(ref list, null);
							}
						}
					}
				}
			}
		}

		public void GetRangeCombatants(Combatant user, int minDistance, int maxDistance,
		   ref List<Combatant> list, bool allowSquareDiagonal, GridCellOriginCheck check)
		{
			if(user != null &&
				user.Grid.Cell != null)
			{
				CubeCoord coord = new CubeCoord();
				for(int dx = -maxDistance; dx <= maxDistance; dx++)
				{
					for(int dy = -maxDistance; dy <= maxDistance; dy++)
					{
						for(int i = 0; i < user.Grid.CellCount; i++)
						{
							BattleGridCellComponent origin = user.Grid.GetCell(i);
							if(origin != null)
							{
								coord.SetAdd(origin.CubeCoord, dx, dy, 0);
								BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

								if(cell != null &&
									!cell.IsEmpty &&
									user.Grid.InRange(cell, !allowSquareDiagonal, minDistance, maxDistance, check))
								{
									cell.GetCombatants(ref list, null);
								}
							}
						}
					}
				}
			}
		}

		public bool CheckRange(BattleGridCellComponent origin, int minDistance, int maxDistance,
			bool addOrigin, bool addBlocked, bool addNotPassable, bool allowSquareDiagonal, GridCellCheck check)
		{
			if(origin != null)
			{
				CubeCoord coord = new CubeCoord();
				if(allowSquareDiagonal &&
					this.diagonalDistanceOne)
				{
					for(int dx = -maxDistance; dx <= maxDistance; dx++)
					{
						for(int dy = -maxDistance; dy <= maxDistance; dy++)
						{
							int tmpDistance = CubeCoord.ZeroDistanceSquareDiagonal(dx, dy);
							if(tmpDistance >= minDistance &&
								tmpDistance <= maxDistance)
							{
								coord.SetAdd(origin.CubeCoord, dx, dy, 0);
								BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

								if(cell == null ||
									(!addOrigin && origin == cell) ||
									(!addBlocked && cell.IsBlocked) ||
									(!addNotPassable && !cell.IsPassable) ||
									(check != null && !check(cell)))
								{
									return false;
								}
							}
						}
					}
				}
				else
				{
					for(int dx = -maxDistance; dx <= maxDistance; dx++)
					{
						for(int dy = -maxDistance; dy <= maxDistance; dy++)
						{
							int tmpDistance = CubeCoord.ZeroDistanceSquareNonDiagonal(dx, dy);
							if(tmpDistance >= minDistance &&
								tmpDistance <= maxDistance)
							{
								coord.SetAdd(origin.CubeCoord, dx, dy, 0);
								BattleGridCellComponent cell = origin.parentGrid.GetCell(coord);

								if(cell == null ||
									(!addOrigin && origin == cell) ||
									(!addBlocked && cell.IsBlocked) ||
									(!addNotPassable && !cell.IsPassable) ||
									(check != null && !check(cell)))
								{
									return false;
								}
							}
						}
					}
				}
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Ring functions
		============================================================================
		*/
		public void GetRing(BattleGridCellComponent center, int radius,
			ref List<BattleGridCellComponent> list, ref HashSet<BattleGridCellComponent> contains,
			bool addOrigin, bool addBlocked, bool addNotPassable,
			bool allowSquareDiagonal, GridCellCheck check)
		{
			if(center != null)
			{
				if(radius <= 0)
				{
					list.Add(center);
				}
				else
				{
					if(allowSquareDiagonal &&
						this.diagonalDistanceOne)
					{
						CubeCoord coord = center.CubeCoord + BattleGridHelper.GetDirection(5) * radius;
						radius *= 2;

						for(int i = 0; i < 4; i++)
						{
							for(int j = 0; j < radius; j++)
							{
								BattleGridCellComponent cell = center.parentGrid.GetCell(coord);
								if(cell != null &&
									(addOrigin || center != cell) &&
									(addBlocked || !cell.IsBlocked) &&
									(addNotPassable || cell.IsPassable) &&
									(check == null || check(cell)) &&
									!contains.Contains(cell))
								{
									list.Add(cell);
									contains.Add(cell);
								}
								coord.Add(BattleGridHelper.GetDirection(i * 2));
							}
						}
					}
					else
					{
						CubeCoord coord = center.CubeCoord + BattleGridHelper.GetDirectionNonDiagonal(3) * radius;

						for(int i = 0; i < 4; i++)
						{
							for(int j = 0; j < radius; j++)
							{
								BattleGridCellComponent cell = center.parentGrid.GetCell(coord);
								if(cell != null &&
									(addOrigin || center != cell) &&
									(addBlocked || !cell.IsBlocked) &&
									(addNotPassable || cell.IsPassable) &&
									(check == null || check(cell)) &&
									!contains.Contains(cell))
								{
									list.Add(cell);
									contains.Add(cell);
								}
								coord.Add(BattleGridHelper.GetDirectionNonDiagonal(i));
								coord.Add(BattleGridHelper.GetDirectionNonDiagonal(i + 1));
							}
						}
					}
				}
			}
		}

		public void GetRingCombatants(BattleGridCellComponent center, int radius,
			ref List<Combatant> list, bool addOrigin, bool addBlocked, bool addNotPassable,
			bool allowSquareDiagonal, GridCellCheck check)
		{
			if(center != null)
			{
				if(radius <= 0)
				{
					center.GetCombatants(ref list, null);
				}
				else
				{
					if(allowSquareDiagonal &&
						this.diagonalDistanceOne)
					{
						CubeCoord coord = center.CubeCoord + BattleGridHelper.GetDirection(5) * radius;
						radius *= 2;

						for(int i = 0; i < 4; i++)
						{
							for(int j = 0; j < radius; j++)
							{
								BattleGridCellComponent cell = center.parentGrid.GetCell(coord);
								if(cell != null &&
									!cell.IsEmpty &&
									(addOrigin || center != cell) &&
									(addBlocked || !cell.IsBlocked) &&
									(addNotPassable || cell.IsPassable) &&
									(check == null || check(cell)))
								{
									cell.GetCombatants(ref list, null);
								}
								coord.Add(BattleGridHelper.GetDirection(i * 2));
							}
						}
					}
					else
					{
						CubeCoord coord = center.CubeCoord + BattleGridHelper.GetDirectionNonDiagonal(3) * radius;

						for(int i = 0; i < 4; i++)
						{
							for(int j = 0; j < radius; j++)
							{
								BattleGridCellComponent cell = center.parentGrid.GetCell(coord);
								if(cell != null &&
									!cell.IsEmpty &&
									(addOrigin || center != cell) &&
									(addBlocked || !cell.IsBlocked) &&
									(addNotPassable || cell.IsPassable) &&
									(check == null || check(cell)))
								{
									cell.GetCombatants(ref list, null);
								}
								coord.Add(BattleGridHelper.GetDirectionNonDiagonal(i));
								coord.Add(BattleGridHelper.GetDirectionNonDiagonal(i + 1));
							}
						}
					}
				}
			}
		}

		public bool CheckRing(BattleGridCellComponent center, int radius,
			bool addOrigin, bool addBlocked, bool addNotPassable,
			bool allowSquareDiagonal, GridCellCheck check)
		{
			if(center != null)
			{
				if(radius <= 0)
				{
					return true;
				}
				else
				{
					if(allowSquareDiagonal &&
						this.diagonalDistanceOne)
					{
						CubeCoord coord = center.CubeCoord + BattleGridHelper.GetDirection(5) * radius;
						radius *= 2;

						for(int i = 0; i < 4; i++)
						{
							for(int j = 0; j < radius; j++)
							{
								BattleGridCellComponent cell = center.parentGrid.GetCell(coord);
								if(cell == null ||
									(!addOrigin && center == cell) ||
									(!addBlocked && cell.IsBlocked) ||
									(!addNotPassable && !cell.IsPassable) ||
									(check != null && !check(cell)))
								{
									return false;
								}
								coord.Add(BattleGridHelper.GetDirection(i * 2));
							}
						}
					}
					else
					{
						CubeCoord coord = center.CubeCoord + BattleGridHelper.GetDirectionNonDiagonal(3) * radius;

						for(int i = 0; i < 4; i++)
						{
							for(int j = 0; j < radius; j++)
							{
								BattleGridCellComponent cell = center.parentGrid.GetCell(coord);
								if(cell == null ||
									(!addOrigin && center == cell) ||
									(!addBlocked && cell.IsBlocked) ||
									(!addNotPassable && !cell.IsPassable) ||
									(check != null && !check(cell)))
								{
									return false;
								}
								coord.Add(BattleGridHelper.GetDirectionNonDiagonal(i));
								coord.Add(BattleGridHelper.GetDirectionNonDiagonal(i + 1));
							}
						}
					}
				}
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Line functions
		============================================================================
		*/
		public void GetLine(BattleGridCellComponent origin, BattleGridCellComponent target,
			ref List<BattleGridCellComponent> list, ref HashSet<BattleGridCellComponent> contains,
			bool ignoreBlocked)
		{
			int dx = Mathf.Abs(target.row - origin.row);
			int dy = Mathf.Abs(target.column - origin.column);
			int row = origin.row;
			int column = origin.column;
			int n = 1 + dx + dy;
			int rowIncrease = (target.row > origin.row) ? 1 : -1;
			int columnIncrease = (target.column > origin.column) ? 1 : -1;
			int error = dx - dy;
			dx *= 2;
			dy *= 2;

			for(; n > 0; --n)
			{
				BattleGridCellComponent cell = origin.parentGrid.GetCell(row, column);

				if(cell != null)
				{
					if(!ignoreBlocked && cell.IsBlocked)
					{
						return;
					}
					else if(!contains.Contains(cell))
					{
						list.Add(cell);
					}
				}

				if(error > 0)
				{
					row += rowIncrease;
					error -= dy;
				}
				else
				{
					column += columnIncrease;
					error += dx;
				}
			}
		}


		/*
		============================================================================
		Line of sight functions
		============================================================================
		*/
		public bool CheckLineOfSight(Combatant user, BattleGridCellComponent origin, BattleGridCellComponent target,
			GridCellOriginCheck blockLOS, float cellArea)
		{
			bool valid = true;
			if(origin != target)
			{
				int distanceRow = Mathf.Abs(target.row - origin.row);
				int distanceColumn = Mathf.Abs(target.column - origin.column);
				int row = origin.row;
				int column = origin.column;
				int nStart = 1 + distanceRow + distanceColumn;
				int increaseRow = (target.row > origin.row) ? 1 : -1;
				int increaseColumn = (target.column > origin.column) ? 1 : -1;
				int error = distanceRow - distanceColumn;
				distanceRow *= 2;
				distanceColumn *= 2;

				for(int n = nStart; n > 0; --n)
				{
					BattleGridCellComponent cell = origin.parentGrid.GetCell(row, column);
					if(cell != null &&
						cell != origin &&
						cell != target &&
						blockLOS != null &&
						blockLOS(user, origin, cell))
					{
						valid = false;
						break;
					}
					if(error > 0)
					{
						row += increaseRow;
						error -= distanceColumn;
					}
					else
					{
						column += increaseColumn;
						error += distanceRow;
					}
				}

				if(!valid && cellArea > 0)
				{
					valid = true;

					// row+
					if(!this.CheckLineOfSightOffset(
						user, origin, target, blockLOS,
							nStart, increaseRow, increaseColumn, cellArea, 0) &&
						// row-
						!this.CheckLineOfSightOffset(
							user, origin, target, blockLOS,
							nStart, increaseRow, increaseColumn, -cellArea, 0) &&
						// column+
						!this.CheckLineOfSightOffset(
							user, origin, target, blockLOS,
							nStart, increaseRow, increaseColumn, 0, cellArea) &&
						// column-
						!this.CheckLineOfSightOffset(
							user, origin, target, blockLOS,
							nStart, increaseRow, increaseColumn, 0, -cellArea))
					{
						valid = false;
					}
				}
			}
			return valid;
		}

		private bool CheckLineOfSightOffset(Combatant user,
			BattleGridCellComponent origin, BattleGridCellComponent target,
			GridCellOriginCheck blockLOS, int nStart, int increaseRow, int increaseColumn, float rowOffset, float columnOffset)
		{
			float distanceRow = Mathf.Abs((target.row + rowOffset) - origin.row);
			float distanceColumn = Mathf.Abs((target.column + columnOffset) - origin.column);
			int row = origin.row;
			int column = origin.column;
			float error = distanceRow - distanceColumn;
			distanceRow *= 2;
			distanceColumn *= 2;

			for(int n = nStart; n > 0; --n)
			{
				BattleGridCellComponent cell = origin.parentGrid.GetCell(row, column);
				if(cell != null &&
					cell != origin &&
					cell != target &&
					blockLOS != null &&
					blockLOS(user, origin, cell))
				{
					return false;
				}
				if(error > 0)
				{
					row += increaseRow;
					error -= distanceColumn;
				}
				else
				{
					column += increaseColumn;
					error += distanceRow;
				}
			}
			return true;
		}


		/*
		============================================================================
		CubeCoord functions
		============================================================================
		*/
		public CubeCoord Rotate(CubeCoord origin, int turns)
		{
			if(turns >= 4 ||
				turns <= -4)
			{
				turns -= (turns / 4) * 4;
			}
			if(turns < 0)
			{
				turns += 4;
			}

			if(turns == 0)
			{
				return new CubeCoord(origin);
			}
			else if(turns == 1)
			{
				return new CubeCoord(origin.y, -origin.x, 0);
			}
			else if(turns == 2)
			{
				return new CubeCoord(-origin.x, -origin.y, 0);
			}
			else if(turns == 3)
			{
				return new CubeCoord(-origin.y, origin.x, 0);
			}
			return new CubeCoord(origin);
		}

		public int Distance(CubeCoord origin, CubeCoord target)
		{
			if(this.diagonalDistanceOne)
			{
				return Mathf.Max(Mathf.Abs(origin.x - target.x), Mathf.Abs(origin.y - target.y));
			}
			else
			{
				return Mathf.Abs(origin.x - target.x) + Mathf.Abs(origin.y - target.y);
			}
		}

		public int Distance(CubeCoord origin, CubeCoord target, bool blockDiagonalDistance1)
		{
			if(!blockDiagonalDistance1 &&
				this.diagonalDistanceOne)
			{
				return Mathf.Max(Mathf.Abs(origin.x - target.x), Mathf.Abs(origin.y - target.y));
			}
			else
			{
				return Mathf.Abs(origin.x - target.x) + Mathf.Abs(origin.y - target.y);
			}
		}
	}
}
