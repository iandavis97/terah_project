﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public delegate void SelectGridCell(BattleGridCellComponent cell);

	public delegate void SelectGridCellBool(BattleGridCellComponent cell, bool isHover);

	public delegate void SelectGridDirection(int direction);

	public class GridCellSelectionSettings : BaseData
	{
		// input keys
		[ORKEditorHelp("Use Input Keys", "Use input keys to select a cell.", "")]
		[ORKEditorInfo("Input Key Settings", "You can use input keys to select a cell (e.g. as target for the move command).", "")]
		public bool useInputSelection = false;

		[ORKEditorHelp("Vertical Axis", "The key used to move the cell selection vertically.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("useInputSelection", true)]
		public int verticalAxisID = 0;

		[ORKEditorHelp("Horizontal Axis", "The key used to move the cell selection horizontally.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int horizontalAxisID = 0;

		[ORKEditorHelp("Axis Minimum", "Define the minimum value an axis must have to trigger a selection change.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float axisMinimum = 0.3f;

		[ORKEditorHelp("Use Camera Direction", "The axis keys will change the cell selection based on the camera view.", "")]
		public bool useCameraDirection = false;

		[ORKEditorHelp("Camera Direction Offset", "Define the angle in degrees that will be added to the camera direction.\n" +
			"E.g. use 45 to shift the selection 45 degrees to the camera view.", "")]
		[ORKEditorLayout("useCameraDirection", true, endCheckGroup=true)]
		public float cameraDirectionOffset = 0;

		[ORKEditorHelp("Cursor Timeout (s)", "The time in seconds that has to pass " +
			"between 2 cursor moves.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public float cursorTimeout = 0.25f;


		// mouse/touch
		[ORKEditorInfo("Mouse/Touch Control", "Input settings for mouse and touch control.", "")]
		public MouseTouchControl mouseTouch = new MouseTouchControl();

		[ORKEditorHelp("Hover Select", "Select cells by hovering the mouse over them.\n" +
			"The selected cell can be accepted with a mouse click or touch.", "")]
		[ORKEditorInfo(separator=true)]
		public bool mouseHoverSelect = false;

		[ORKEditorHelp("UI Blocks Selection", "Hover selection is blocked when the cursor is over a GUI box (e.g. a HUD).", "")]
		[ORKEditorLayout("mouseHoverSelect", true)]
		public bool mouseHoverUIBlock = false;

		[ORKEditorHelp("Cursor Move Only", "Only check for hover selection when the cursor has actually been moved.\n" +
			"If disabled, hover selection is checked at all times.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool mouseMoveOnly = false;

		[ORKEditorHelp("Accept Only Selected", "Mouse/touch input can only accept already selected cells.\n" +
			"E.g. first click will select, 2nd click (on selected cell) will accept the cell.", "")]
		public bool mouseAcceptOnlySelected = false;

		[ORKEditorHelp("Limit Selection Range", "Limit the range of mouse/touch selection to use " +
			"the nearest cell within a defined distance to the click/touch position.\n" +
			"If disabled, the selection will use the nearest cell without a distance check (i.e. even using far away cells).", "")]
		public bool mouseLimitSelectionRange = false;

		[ORKEditorHelp("Selection Range", "Define the range in which the nearest cell will be searched.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("mouseLimitSelectionRange", true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float mouseSelectionRange = 5.0f;


		// audio settings
		[ORKEditorHelp("Select Audio", "Played when the selected cell is changed.", "")]
		[ORKEditorInfo("Audio Settings", "Define audio clips that will be played for selecting and accepting cells.", "")]
		public AudioClip selectAudio;

		[ORKEditorHelp("Select Volume", "The volume (0-1) used to play the select clip.", "")]
		[ORKEditorLayout("selectAudio", null, elseCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float selectVolume = 1.0f;

		[ORKEditorHelp("Play Hover Select", "Play the select clip when using mouse hover for cell selection.", "")]
		[ORKEditorLayout("mouseHoverSelect", true, endCheckGroup=true, endGroups=2)]
		public bool playHoverSelectAudio = false;

		[ORKEditorHelp("Accept Audio", "Played when the selected cell is accepted.", "")]
		[ORKEditorInfo(separator=true)]
		public AudioClip acceptAudio;

		[ORKEditorHelp("Accept Volume", "The volume (0-1) used to play the accept clip.", "")]
		[ORKEditorLayout("acceptAudio", null, elseCheckGroup=true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float acceptVolume = 1.0f;

		[ORKEditorHelp("Cancel Audio", "Played when the cell selection is canceled.", "")]
		[ORKEditorInfo(separator=true)]
		public AudioClip cancelAudio;

		[ORKEditorHelp("Cancel Volume", "The volume (0-1) used to play the cancel clip.", "")]
		[ORKEditorLayout("cancelAudio", null, elseCheckGroup=true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float cancelVolume = 1.0f;

		[ORKEditorHelp("Fail Audio", "Played when an unselectable cell is accepted.", "")]
		[ORKEditorInfo(separator=true)]
		public AudioClip failAudio;

		[ORKEditorHelp("Fail Volume", "The volume (0-1) used to play the fail clip.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("failAudio", null, elseCheckGroup=true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float failVolume = 1.0f;


		// in-game
		private float timeout = 0;

		public GridCellSelectionSettings()
		{

		}


		/*
		============================================================================
		Audio functions
		============================================================================
		*/
		public void PlaySelectAudio()
		{
			if(this.selectAudio != null &&
				ORK.Audio != null)
			{
				ORK.Audio.PlayOneShot(this.selectAudio,
					this.selectVolume * ORK.Game.SoundVolume);
			}
		}

		public void PlayAcceptAudio()
		{
			if(this.acceptAudio != null &&
				ORK.Audio != null)
			{
				ORK.Audio.PlayOneShot(this.acceptAudio,
					this.acceptVolume * ORK.Game.SoundVolume);
			}
		}

		public void PlayCancelAudio()
		{
			if(this.cancelAudio != null &&
				ORK.Audio != null)
			{
				ORK.Audio.PlayOneShot(this.cancelAudio,
					this.cancelVolume * ORK.Game.SoundVolume);
			}
		}

		public void PlayFailAudio()
		{
			if(this.failAudio != null &&
				ORK.Audio != null)
			{
				ORK.Audio.PlayOneShot(this.failAudio,
					this.failVolume * ORK.Game.SoundVolume);
			}
		}


		/*
		============================================================================
		Selection functions
		============================================================================
		*/
		public void SelectCell(BattleGridCellComponent startCell, BattleGridCellComponent currentCell,
			SelectGridCellBool selectCell, SelectGridCell acceptCell, GridCellCheck acceptCheck,
			SelectGridDirection selectDirection, bool neighbourMode, bool blockDiagonalDistance1)
		{
			// mouse click
			Vector3 point = Vector3.zero;
			if(ORK.Game.Camera != null && 
				this.mouseTouch.Interacted(ref point))
			{
				Ray ray = ORK.Game.Camera.ScreenPointToRay(point);
				RaycastOutput hit;

				if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit,
					ORK.Battle.SystemSettings.gridSettings.rayDistance, ORK.Battle.SystemSettings.gridSettings.rayLayerMask))
				{
					NearestCheck<BattleGridCellComponent> check = null;
					if(neighbourMode)
					{
						check = delegate (BattleGridCellComponent checkCell)
						{
							return BattleGridHelper.IsNeighbourCell(startCell, checkCell,
								!blockDiagonalDistance1 && ORK.Battle.SystemSettings.gridSettings.squareDiagonalDistanceOne, null);
						};
					}
					BattleGridCellComponent tmpCell = ORK.Battle.Grid.GetNearestCell(hit.point,
						this.mouseLimitSelectionRange ? this.mouseSelectionRange : Mathf.Infinity, check);

					if(tmpCell != null)
					{
						if(this.mouseAcceptOnlySelected)
						{
							if(currentCell == tmpCell)
							{
								if(acceptCheck == null ||
									acceptCheck(tmpCell))
								{
									this.PlayAcceptAudio();
									acceptCell(tmpCell);
								}
								else
								{
									this.PlayFailAudio();
								}
							}
							else
							{
								this.PlaySelectAudio();
								selectCell(tmpCell, false);
							}
						}
						else
						{
							if(acceptCheck == null ||
								acceptCheck(tmpCell))
							{
								this.PlayAcceptAudio();
								acceptCell(tmpCell);
							}
							else
							{
								this.PlayFailAudio();
								selectCell(tmpCell, false);
							}
						}
						return;
					}
				}
			}
			// input keys
			else if(this.useInputSelection)
			{
				if(ORK.GameControls.menuControls.AcceptKey.GetButton())
				{
					if(acceptCheck == null || acceptCheck(currentCell))
					{
						this.PlayAcceptAudio();
						acceptCell(currentCell);
					}
					else
					{
						this.PlayFailAudio();
					}
					return;
				}
				else if(this.timeout < Time.realtimeSinceStartup)
				{
					float h = ORK.InputKeys.Get(this.horizontalAxisID).GetAxis();
					float v = ORK.InputKeys.Get(this.verticalAxisID).GetAxis();

					if(h <= -this.axisMinimum || h >= this.axisMinimum ||
						v <= -this.axisMinimum || v >= this.axisMinimum)
					{
						this.timeout = Time.realtimeSinceStartup + this.cursorTimeout;

						Vector3 input = this.useCameraDirection && ORK.Game.Camera != null ?
							InputHelper.GetDirectionJoystick(h, v, ORK.Game.Camera.transform,
								HorizontalPlaneType.XZ, this.cameraDirectionOffset) :
							new Vector3(h, 0, v);

						int direction = BattleGridHelper.AngleToDirection(
							InputHelper.JoystickToAngle(input.x, input.z,
								BattleGridHelper.GetNeighbourAngleOffset()), true);
						BattleGridCellComponent tmpCell = BattleGridHelper.GetNeighbourCell(
							neighbourMode ? startCell : currentCell, direction);

						if(tmpCell != null &&
							currentCell != tmpCell)
						{
							this.PlaySelectAudio();
							selectCell(tmpCell, false);
						}
						else if(tmpCell == null &&
							selectDirection != null)
						{
							selectDirection(direction);
						}
						return;
					}
				}
			}

			// hover selection
			if(ORK.Game.Camera != null && 
				this.mouseHoverSelect &&
				(!this.mouseMoveOnly || ORK.Control.MouseMoved) &&
				(!this.mouseHoverUIBlock || !ORK.GUI.IsCursorOver))
			{
				Ray ray = ORK.Game.Camera.ScreenPointToRay(Input.mousePosition);
				RaycastOutput hit;

				if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit,
					ORK.Battle.SystemSettings.gridSettings.rayDistance, ORK.Battle.SystemSettings.gridSettings.rayLayerMask))
				{
					NearestCheck<BattleGridCellComponent> check = null;
					if(neighbourMode)
					{
						check = delegate (BattleGridCellComponent checkCell)
						{
							return ORK.Battle.Grid == checkCell.parentGrid &&
								BattleGridHelper.IsNeighbourCell(startCell, checkCell,
									!blockDiagonalDistance1 && ORK.Battle.SystemSettings.gridSettings.squareDiagonalDistanceOne, null);
						};
					}
					else
					{
						check = delegate (BattleGridCellComponent checkCell)
						{
							return ORK.Battle.Grid == checkCell.parentGrid;
						};
					}
					BattleGridCellComponent tmpCell = ORK.Battle.Grid.GetNearestCell(hit.point,
						this.mouseLimitSelectionRange ?this.mouseSelectionRange : Mathf.Infinity, check);

					if(tmpCell != null &&
						currentCell != tmpCell)
					{
						if(this.playHoverSelectAudio)
						{
							this.PlaySelectAudio();
						}
						selectCell(tmpCell, true);
					}
				}
			}
		}
	}
}
