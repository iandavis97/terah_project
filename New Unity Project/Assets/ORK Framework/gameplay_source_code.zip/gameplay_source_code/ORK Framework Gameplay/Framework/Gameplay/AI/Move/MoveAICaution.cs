﻿
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class MoveAICaution : BaseData
	{
		[ORKEditorHelp("Use Caution", "The caution settings are enabled.\n" +
			"The combatant will move toward a target until a defined range is reached.\n" +
			"If the target enters a critical range, the combatant will flee from the target.", "")]
		public bool enabled = false;


		// caution range
		[ORKEditorHelp("Use Caution Range", "The combatant will only be cautious within a range of its start position " +
			"(i.e. the position it has been spawned at).\n" +
			"When leaving the caution range, the combatant will return to its start position." +
			"If disabled, there is no limit to the caution range.", "")]
		[ORKEditorInfo("Caution Range", "Optionally only use caution within a defined range of the combatant's start position.", "")]
		[ORKEditorLayout("enabled", true)]
		public bool useRange = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useRange", true, endCheckGroup=true, autoInit=true)]
		public Range range;


		// critical range
		[ORKEditorInfo("Critical Range", "The combatant will flee from the target when it's within critical range.\n" +
			"The combatant will flee until the target is outside of the stop range.\n" +
			"The critical range must be smaller than the stop range.", "")]
		public Range criticalRange = new Range(3);

		[ORKEditorHelp("Cancel Casting", "Cancel casting an ability (if possible).", "")]
		[ORKEditorInfo(separator=true)]
		public bool criticalCancelCasting = false;

		[ORKEditorHelp("Prevent Cornered", "The combatant will try to prevent being cornered.\n" +
			"I.e. if the combatant can't move, it'll try to move into different directions, e.g. fleeing toward the enemy.", "")]
		public bool preventCornered = false;

		[ORKEditorHelp("Always Check Critical", "The critical range is checked in all modes.\n" +
			"If disabled, the critical range is only checked when being in caution mode and during casting.", "")]
		public bool criticalAlwaysCheck = false;

		[ORKEditorHelp("Use All Detected", "The combatant will flee from all detected targets that enter the critical range.\n" +
			"If disabled, the combatant only flees from the current target.", "")]
		public bool criticalUseAllDetected = false;

		[ORKEditorHelp("Ignore Conditions", "Ignore the caution conditions for the critical range, " +
			"i.e. the combatant will flee from all detected targets entering the critical range.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("criticalUseAllDetected", true, endCheckGroup=true)]
		public bool criticalIgnoreConditions = false;


		// stop range
		[ORKEditorInfo("Stop Range", "The combatant will hunt the target until reaching the stop range.\n" +
			"The stop range must be greater than the critical range.", "")]
		public Range stopRange = new Range(5);

		[ORKEditorHelp("Use Action Range", "The use range of a selected action is used when moving into range.\n" +
			"A combatant will only move into range when the used action is out of range to the target.\n" +
			"If the action doesn't have a use range, the stop range will be used.", "")]
		public bool useActionStopRange = false;

		// target angle
		[ORKEditorHelp("Use Stop Angle", "The target position (based on the stop range) will be placed at a defined angle to the target.", "")]
		[ORKEditorInfo(separator=true, labelText="Stop Angle")]
		public bool useStopAngle = false;

		[ORKEditorHelp("Local Space", "The stop angle is used in local space of the target.\n" +
			"E.g. 0 will always be in front, 90 on the right side." +
			"If disabled, world space is used, e.g. 0 being north, 90 being east.\n" +
			"Depending on the used horizontal plane, a different rotation axis is used for determining the local space:\n" +
			"- XZ: The Y-axis.\n" +
			"- XY: The Z-axis.", "")]
		[ORKEditorLayout("useStopAngle", true)]
		public bool stopAngleLocal = false;

		[ORKEditorHelp("Stop Angle", "The angle used to determine the target position.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public float stopAngle = 0;


		// conditions
		[ORKEditorHelp("Conditions Needed", "Select if all or just one condition must be valid to be cautious of the target.", "")]
		[ORKEditorInfo("Caution Conditions", "Optionally only use caution when defined conditions are valid.", "",
			isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.One;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorArray(false, "Add Caution Condition", "Adds a caution condition.\n" +
			"You can use multiple conditions to determine if the combatant is cautious of the target.", "",
			"Remove", "Removes this caution condition.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Caution Condition", "Caution conditions determine if the combatant is cautious of the target.", ""
			})]
		public MoveCondition[] condition = new MoveCondition[0];

		public MoveAICaution()
		{

		}


		/*
		============================================================================
		Caution functions
		============================================================================
		*/
		public bool IsCautious(Combatant combatant, Combatant target)
		{
			if(this.enabled && combatant.IsAggressive)
			{
				if(this.condition != null && this.condition.Length > 0)
				{
					for(int i = 0; i < this.condition.Length; i++)
					{
						if(this.condition[i].IsValid(combatant, target))
						{
							if(Needed.One == this.needed)
							{
								return true;
							}
						}
						else if(Needed.All == this.needed)
						{
							return false;
						}
					}

					if(Needed.All == this.needed)
					{
						return true;
					}
					else if(Needed.One == this.needed)
					{
						return false;
					}
				}
				return true;
			}
			return false;
		}

		public bool IsInRange(Vector3 startPosition, Combatant combatant)
		{
			return !this.useRange ||
				this.range == null ||
				this.range.InRange(startPosition, combatant);
		}

		public bool IsOutOfRange(Vector3 startPosition, Combatant combatant)
		{
			return this.useRange &&
				this.range != null &&
				this.range.OutOfRange(startPosition, combatant);
		}

		public void Use(MoveAIComponent moveAI)
		{
			// out of caution range, back to start position
			if(this.IsOutOfRange(moveAI.startPosition, moveAI.combatant))
			{
				moveAI.targetLostTimeout = -1;
				moveAI.ClearTarget(false);

				moveAI.SetMode(MoveAIMode.Waypoint);
				moveAI.SetMovePosition(moveAI.startPosition);
			}
			// fleeing
			else if(MoveAIMode.CautionFlee == moveAI.mode)
			{
				if(moveAI.CautionStopRange.OutOfRange(moveAI.combatant, moveAI.TargetCombatant))
				{
					moveAI.targetPosTimeout = -1;
					moveAI.targetLostTimeout = -1;
					moveAI.SetMode(MoveAIMode.CautionHunt);
				}
				else if(this.preventCornered)
				{
					moveAI.CheckStuck();
				}
			}
			// hunting
			else if(MoveAIMode.CautionHunt == moveAI.mode)
			{
				if(!this.CheckCritical(moveAI))
				{
					Vector3 targetPosition = this.GetTargetPosition(moveAI);

					if(moveAI.CautionStopRange.InRange(targetPosition, moveAI.combatant, 0.1f))
					{
						moveAI.targetPosTimeout = -1;
						moveAI.Stop();
					}
					else if(!moveAI.IsTargetLost())
					{
						moveAI.UpdateTargetPosition(true);
					}
				}
			}
		}

		public bool CheckCritical(MoveAIComponent moveAI)
		{
			if(this.enabled)
			{
				if(this.criticalRange.InRange(moveAI.combatant, moveAI.TargetCombatant))
				{
					if(this.criticalCancelCasting)
					{
						moveAI.combatant.Actions.CancelCast();
					}
					moveAI.targetPosTimeout = -1;
					moveAI.targetLostTimeout = -1;
					moveAI.SetActionTarget(null);
					moveAI.SetMode(MoveAIMode.CautionFlee);
					return true;
				}
				else if(this.criticalUseAllDetected)
				{
					for(int i = 0; i < moveAI.DetectedTargets.Count; i++)
					{
						if((this.criticalIgnoreConditions ||
							this.IsCautious(moveAI.combatant, moveAI.DetectedTargets[i])) &&
							this.criticalRange.InRange(moveAI.combatant, moveAI.DetectedTargets[i]))
						{
							if(this.criticalCancelCasting)
							{
								moveAI.combatant.Actions.CancelCast();
							}
							moveAI.targetPosTimeout = -1;
							moveAI.targetLostTimeout = -1;
							moveAI.SetActionTarget(null);
							moveAI.SetTarget(moveAI.DetectedTargets[i], MoveAIMode.CautionFlee);
							return true;
						}
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Target functions
		============================================================================
		*/
		public Vector3 GetTargetPosition(MoveAIComponent moveAI)
		{
			if(moveAI.TargetCombatant != null &&
				moveAI.TargetCombatant.GameObject != null)
			{
				if(this.useStopAngle)
				{
					return moveAI.CautionStopRange.GetAngledPosition(
						moveAI.TargetCombatant,
						this.stopAngle, this.stopAngleLocal,
						moveAI.settings.horizontalPlane);
				}
				else
				{
					return Vector3.MoveTowards(
						moveAI.TargetCombatant.GameObject.transform.position,
						moveAI.combatant.GameObject.transform.position,
						moveAI.CautionStopRange.GetRange(moveAI.TargetCombatant));
				}
			}
			else
			{
				return moveAI.combatant.GameObject.transform.position;
			}
		}

		public bool ReachedTarget(MoveAIComponent moveAI)
		{
			if(this.enabled)
			{
				if(moveAI.CautionStopRange.InRange(this.GetTargetPosition(moveAI), moveAI.combatant, 0.1f))
				{
					return true;
				}
				return false;
			}
			return true;
		}
	}
}
