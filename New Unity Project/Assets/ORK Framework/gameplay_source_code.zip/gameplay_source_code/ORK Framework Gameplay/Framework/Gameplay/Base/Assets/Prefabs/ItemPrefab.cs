﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ItemPrefab : BaseData
	{
		[ORKEditorHelp("Item Prefab ", "The prefab used to display this item in scenes.\n" +
			"The prefab is used by 'Item Collector' components to spawn the item in a scene.", "")]
		public AssetSource<GameObject> prefab = new AssetSource<GameObject>();

		[ORKEditorHelp("Spawn Offset", "Offset added to the game object's position when spawning.", "")]
		public Vector3 spawnOffset = Vector3.zero;

		public ItemPrefab()
		{

		}

		public void Upgrade(DataObject data, string prefabField, string offsetField)
		{
			if(data != null)
			{
				this.prefab.Upgrade(data, prefabField);
				float[] offset = null;
				data.Get(offsetField, out offset);
				if(offset != null)
				{
					this.spawnOffset = ArrayHelper.GetVector3(offset);
				}
			}
		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public GameObject GetPrefab()
		{
			return this.prefab;
		}

		public GameObject CreatePrefabInstance()
		{
			GameObject prefabObject = this.prefab;
			if(prefabObject != null)
			{
				return UnityWrapper.Instantiate(prefabObject);
			}
			return null;
		}
	}
}
