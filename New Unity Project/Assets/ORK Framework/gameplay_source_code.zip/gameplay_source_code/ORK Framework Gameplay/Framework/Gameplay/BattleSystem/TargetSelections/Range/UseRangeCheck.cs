﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class UseRangeCheck : BaseData
	{
		[ORKEditorHelp("Use Range", "Select which use range to check:\n" +
			"- Attack: The use range of the combatant's base attack.\n" +
			"- Counter Attack: The use range of the combatant's counter attack.\n" +
			"- Abiltiy: The use range of an ability.\n" +
			"- Class Abiltiy: The use range of the combatant's class ability.\n" +
			"- Item: The use range of an item.\n" +
			"- Shortcut Slot: The use range of a shortcut slot's attack, ability or item.\n" +
			"- Battle Range Template: A battle range template.\n" +
			"- Custom: A custom battle range.", "")]
		public UseRangeOriginType type = UseRangeOriginType.Ability;

		[ORKEditorHelp("Only Can Target", "Only check target combatants that can be targeted by the action.", "")]
		[ORKEditorLayout(new string[] { "type", "type" },
			new object[] { UseRangeOriginType.BattleRangeTemplate, UseRangeOriginType.Custom },
			needed=Needed.One, elseCheckGroup=true, endCheckGroup=true)]
		public bool onlyCanTarget = false;


		// attack
		[ORKEditorLayout("type", UseRangeOriginType.Attack, endCheckGroup=true, autoInit=true)]
		public BaseAttackSelection attack;


		// ability
		[ORKEditorHelp("Ability", "Select the ability that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Ability, labelText="Ability Settings")]
		[ORKEditorLayout("type", UseRangeOriginType.Ability)]
		public int abilityID = 0;

		[ORKEditorHelp("Ability Level", "The level of the ability that will be used.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorLimit(1, false)]
		public int abilityLevel = 1;


		// item
		[ORKEditorHelp("Item", "Select the item that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Item)]
		[ORKEditorLayout("type", UseRangeOriginType.Item, endCheckGroup=true)]
		public int itemID = 0;


		// shortcut slot
		[ORKEditorLayout("type", UseRangeOriginType.ShortcutSlot, endCheckGroup=true, autoInit=true)]
		public ShortcutSlot slot;


		// battle range template
		[ORKEditorHelp("Battle Range Template", "Select the battle range template that will be used.", "")]
		[ORKEditorInfo(ORKDataType.BattleRangeTemplate)]
		[ORKEditorLayout("type", UseRangeOriginType.BattleRangeTemplate, endCheckGroup=true)]
		public int templateID = 0;


		// custom
		[ORKEditorLayout("type", UseRangeOriginType.Custom, endCheckGroup=true, autoInit=true)]
		public BattleRangeSetting range;

		public UseRangeCheck()
		{

		}


		/*
		============================================================================
		Check single functions
		============================================================================
		*/
		public bool Check(Combatant user, Combatant target)
		{
			if(UseRangeOriginType.ShortcutSlot == this.type)
			{
				Combatant owner = null;
				IShortcut shortcut = this.slot.GetShortcut(user, out owner);

				if(shortcut != null &&
					!shortcut.IsUseable(UseableIn.None))
				{
					TargetSettings targetSettings = TargetSettings.Get(shortcut);

					if(targetSettings != null)
					{
						if(this.CheckTarget(owner, target, targetSettings.InRange,
							this.onlyCanTarget ? targetSettings.CanTarget : (InRangeCombatant)null))
						{
							return true;
						}
					}
				}
			}
			else if(UseRangeOriginType.BattleRangeTemplate == this.type)
			{
				BattleRangeTemplate template = ORK.BattleRangeTemplates.Get(this.templateID);
				if(this.CheckTarget(user, target, template.range.InRange, null))
				{
					return true;
				}
			}
			else if(UseRangeOriginType.Attack == this.type)
			{
				AbilityShortcut ability = this.attack.GetAttack(user);

				if(ability != null &&
					!ability.IsUseable(UseableIn.None))
				{
					TargetSettings targetSettings = TargetSettings.Get(ability);

					if(targetSettings != null)
					{
						if(this.CheckTarget(user, target, targetSettings.InRange,
							this.onlyCanTarget ? targetSettings.CanTarget : (InRangeCombatant)null))
						{
							return true;
						}
					}
				}
			}
			else if(UseRangeOriginType.CounterAttack == this.type)
			{
				AbilityShortcut ability = user.Abilities.GetCounterAttack();

				if(ability != null &&
					!ability.IsUseable(UseableIn.None))
				{
					TargetSettings targetSettings = TargetSettings.Get(ability);

					if(targetSettings != null)
					{
						if(this.CheckTarget(user, target, targetSettings.InRange,
							this.onlyCanTarget ? targetSettings.CanTarget : (InRangeCombatant)null))
						{
							return true;
						}
					}
				}
			}
			else if(UseRangeOriginType.ClassAbility == this.type)
			{
				AbilityShortcut ability = user.Abilities.GetClassAbility();

				if(ability != null &&
					!ability.IsUseable(UseableIn.None))
				{
					TargetSettings targetSettings = TargetSettings.Get(ability);

					if(targetSettings != null)
					{
						if(this.CheckTarget(user, target, targetSettings.InRange,
							this.onlyCanTarget ? targetSettings.CanTarget : (InRangeCombatant)null))
						{
							return true;
						}
					}
				}
			}
			else
			{
				TargetSettings targetSettings = null;

				if(UseRangeOriginType.Ability == this.type)
				{
					Ability ability = ORK.Abilities.Get(this.abilityID);
					if(!ability.IsUseable(UseableIn.None))
					{
						ActiveAbility level = ability.GetLevel(this.abilityLevel - 1).active;
						if(level != null)
						{
							targetSettings = level.targetSettings;
						}
					}
				}
				else if(UseRangeOriginType.Item == this.type)
				{
					Item item = ORK.Items.Get(this.itemID);
					if(!item.IsUseable(UseableIn.None))
					{
						targetSettings = item.targetSettings;
					}
				}

				if(targetSettings != null)
				{
					if(this.CheckTarget(user, target, targetSettings.InRange,
						this.onlyCanTarget ? targetSettings.CanTarget : (InRangeCombatant)null))
					{
						return true;
					}
				}
			}

			return false;
		}

		private bool CheckTarget(Combatant user, Combatant target,
			InRangeCombatant checkCombatant, InRangeCombatant checkCanTarget)
		{
			return target != null &&
				checkCombatant(user, target) &&
				(checkCanTarget == null ||
					checkCanTarget(user, target));
		}


		/*
		============================================================================
		Check list functions
		============================================================================
		*/
		public bool Check(List<Combatant> user, List<GameObject> target)
		{
			if(UseRangeOriginType.ShortcutSlot == this.type)
			{
				for(int i = 0; i < user.Count; i++)
				{
					if(user[i] != null)
					{
						Combatant owner = null;
						IShortcut shortcut = this.slot.GetShortcut(user[i], out owner);

						if(shortcut != null &&
							!shortcut.IsUseable(UseableIn.None))
						{
							TargetSettings targetSettings = TargetSettings.Get(shortcut);

							if(targetSettings != null)
							{
								if(this.CheckTargets(owner, target, targetSettings.InRange, targetSettings.InRange,
									this.onlyCanTarget ? targetSettings.CanTarget : (InRangeCombatant)null))
								{
									return true;
								}
							}
						}
					}
				}
			}
			else if(UseRangeOriginType.BattleRangeTemplate == this.type)
			{
				BattleRangeTemplate template = ORK.BattleRangeTemplates.Get(this.templateID);
				for(int i = 0; i < user.Count; i++)
				{
					if(user[i] != null)
					{
						if(this.CheckTargets(user[i], target, template.range.InRange,
							template.range.InRange, null))
						{
							return true;
						}
					}
				}
			}
			else if(UseRangeOriginType.Attack == this.type)
			{
				for(int i = 0; i < user.Count; i++)
				{
					if(user[i] != null)
					{
						AbilityShortcut ability = this.attack.GetAttack(user[i]);

						if(ability != null &&
							!ability.IsUseable(UseableIn.None))
						{
							TargetSettings targetSettings = TargetSettings.Get(ability);

							if(targetSettings != null)
							{
								if(this.CheckTargets(user[i], target, targetSettings.InRange, targetSettings.InRange,
									this.onlyCanTarget ? targetSettings.CanTarget : (InRangeCombatant)null))
								{
									return true;
								}
							}
						}
					}
				}
			}
			else if(UseRangeOriginType.CounterAttack == this.type)
			{
				for(int i = 0; i < user.Count; i++)
				{
					if(user[i] != null)
					{
						AbilityShortcut ability = user[i].Abilities.GetCounterAttack();

						if(ability != null &&
							!ability.IsUseable(UseableIn.None))
						{
							TargetSettings targetSettings = TargetSettings.Get(ability);

							if(targetSettings != null)
							{
								if(this.CheckTargets(user[i], target, targetSettings.InRange, targetSettings.InRange,
									this.onlyCanTarget ? targetSettings.CanTarget : (InRangeCombatant)null))
								{
									return true;
								}
							}
						}
					}
				}
			}
			else if(UseRangeOriginType.ClassAbility == this.type)
			{
				for(int i = 0; i < user.Count; i++)
				{
					if(user[i] != null)
					{
						AbilityShortcut ability = user[i].Abilities.GetClassAbility();

						if(ability != null &&
							!ability.IsUseable(UseableIn.None))
						{
							TargetSettings targetSettings = TargetSettings.Get(ability);

							if(targetSettings != null)
							{
								if(this.CheckTargets(user[i], target, targetSettings.InRange, targetSettings.InRange,
									this.onlyCanTarget ? targetSettings.CanTarget : (InRangeCombatant)null))
								{
									return true;
								}
							}
						}
					}
				}
			}
			else
			{
				TargetSettings targetSettings = null;

				if(UseRangeOriginType.Ability == this.type)
				{
					Ability ability = ORK.Abilities.Get(this.abilityID);
					if(!ability.IsUseable(UseableIn.None))
					{
						ActiveAbility level = ability.GetLevel(this.abilityLevel - 1).active;
						if(level != null)
						{
							targetSettings = level.targetSettings;
						}
					}
				}
				else if(UseRangeOriginType.Item == this.type)
				{
					Item item = ORK.Items.Get(this.itemID);
					if(!item.IsUseable(UseableIn.None))
					{
						targetSettings = item.targetSettings;
					}
				}

				if(targetSettings != null)
				{
					for(int i = 0; i < user.Count; i++)
					{
						if(user[i] != null)
						{
							if(this.CheckTargets(user[i], target, targetSettings.InRange, targetSettings.InRange,
								this.onlyCanTarget ? targetSettings.CanTarget : (InRangeCombatant)null))
							{
								return true;
							}
						}
					}
				}
			}

			return false;
		}

		private bool CheckTargets(Combatant user, List<GameObject> target,
			InRangeCombatant checkCombatant, InRangeGridCell checkCell, InRangeCombatant checkCanTarget)
		{
			for(int j = 0; j < target.Count; j++)
			{
				if(target[j] != null)
				{
					Combatant targetCom = ComponentHelper.GetCombatant(target[j]);
					if(targetCom != null)
					{
						if(checkCombatant(user, targetCom) &&
							(checkCanTarget == null ||
								checkCanTarget(user, targetCom)))
						{
							return true;
						}
					}
					else if(ORK.Battle.Grid != null)
					{
						BattleGridCellComponent targetCell = BattleGridHelper.GetCell(target[j]);
						if(targetCell != null &&
							checkCell(user, targetCell))
						{
							return true;
						}
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Check add list functions
		============================================================================
		*/
		public bool CheckGetUsers(List<Combatant> user, GameObject target,
			ref List<Combatant> userList, bool filterInRange)
		{
			bool valid = false;

			if(target != null &&
				userList != null)
			{
				if(UseRangeOriginType.ShortcutSlot == this.type)
				{
					for(int i = 0; i < user.Count; i++)
					{
						if(user[i] != null)
						{
							Combatant owner = null;
							IShortcut shortcut = this.slot.GetShortcut(user[i], out owner);

							if(shortcut != null &&
								!shortcut.IsUseable(UseableIn.None))
							{
								TargetSettings targetSettings = TargetSettings.Get(shortcut);

								if(targetSettings != null)
								{
									if(this.CheckTarget(owner, target, targetSettings.InRange, targetSettings.InRange,
										this.onlyCanTarget ? targetSettings.CanTarget : (InRangeCombatant)null))
									{
										valid = true;
										if(filterInRange &&
											!userList.Contains(user[i]))
										{
											userList.Add(user[i]);
										}
									}
									else if(!filterInRange &&
										!userList.Contains(user[i]))
									{
										userList.Add(user[i]);
									}
								}
							}
						}
					}
				}
				else if(UseRangeOriginType.BattleRangeTemplate == this.type)
				{
					BattleRangeTemplate template = ORK.BattleRangeTemplates.Get(this.templateID);
					for(int i = 0; i < user.Count; i++)
					{
						if(user[i] != null)
						{
							if(this.CheckTarget(user[i], target, template.range.InRange,
								template.range.InRange, null))
							{
								valid = true;
								if(filterInRange &&
									!userList.Contains(user[i]))
								{
									userList.Add(user[i]);
								}
							}
							else if(!filterInRange &&
								!userList.Contains(user[i]))
							{
								userList.Add(user[i]);
							}
						}
					}
				}
				else if(UseRangeOriginType.Attack == this.type)
				{
					for(int i = 0; i < user.Count; i++)
					{
						if(user[i] != null)
						{
							AbilityShortcut ability = this.attack.GetAttack(user[i]);

							if(ability != null &&
								!ability.IsUseable(UseableIn.None))
							{
								TargetSettings targetSettings = TargetSettings.Get(ability);

								if(targetSettings != null)
								{
									if(this.CheckTarget(user[i], target, targetSettings.InRange, targetSettings.InRange,
										this.onlyCanTarget ? targetSettings.CanTarget : (InRangeCombatant)null))
									{
										valid = true;
										if(filterInRange &&
											!userList.Contains(user[i]))
										{
											userList.Add(user[i]);
										}
									}
									else if(!filterInRange &&
										!userList.Contains(user[i]))
									{
										userList.Add(user[i]);
									}
								}
							}
						}
					}
				}
				else if(UseRangeOriginType.CounterAttack == this.type)
				{
					for(int i = 0; i < user.Count; i++)
					{
						if(user[i] != null)
						{
							AbilityShortcut ability = user[i].Abilities.GetCounterAttack();

							if(ability != null &&
								!ability.IsUseable(UseableIn.None))
							{
								TargetSettings targetSettings = TargetSettings.Get(ability);

								if(targetSettings != null)
								{
									if(this.CheckTarget(user[i], target, targetSettings.InRange, targetSettings.InRange,
										this.onlyCanTarget ? targetSettings.CanTarget : (InRangeCombatant)null))
									{
										valid = true;
										if(filterInRange &&
											!userList.Contains(user[i]))
										{
											userList.Add(user[i]);
										}
									}
									else if(!filterInRange &&
										!userList.Contains(user[i]))
									{
										userList.Add(user[i]);
									}
								}
							}
						}
					}
				}
				else if(UseRangeOriginType.ClassAbility == this.type)
				{
					for(int i = 0; i < user.Count; i++)
					{
						if(user[i] != null)
						{
							AbilityShortcut ability = user[i].Abilities.GetClassAbility();

							if(ability != null &&
								!ability.IsUseable(UseableIn.None))
							{
								TargetSettings targetSettings = TargetSettings.Get(ability);

								if(targetSettings != null)
								{
									if(this.CheckTarget(user[i], target, targetSettings.InRange, targetSettings.InRange,
										this.onlyCanTarget ? targetSettings.CanTarget : (InRangeCombatant)null))
									{
										valid = true;
										if(filterInRange &&
											!userList.Contains(user[i]))
										{
											userList.Add(user[i]);
										}
									}
									else if(!filterInRange &&
										!userList.Contains(user[i]))
									{
										userList.Add(user[i]);
									}
								}
							}
						}
					}
				}
				else
				{
					TargetSettings targetSettings = null;

					if(UseRangeOriginType.Ability == this.type)
					{
						Ability ability = ORK.Abilities.Get(this.abilityID);
						if(!ability.IsUseable(UseableIn.None))
						{
							ActiveAbility level = ability.GetLevel(this.abilityLevel - 1).active;
							if(level != null)
							{
								targetSettings = level.targetSettings;
							}
						}
					}
					else if(UseRangeOriginType.Item == this.type)
					{
						Item item = ORK.Items.Get(this.itemID);
						if(!item.IsUseable(UseableIn.None))
						{
							targetSettings = item.targetSettings;
						}
					}

					if(targetSettings != null)
					{
						for(int i = 0; i < user.Count; i++)
						{
							if(user[i] != null)
							{
								if(this.CheckTarget(user[i], target, targetSettings.InRange, targetSettings.InRange,
									this.onlyCanTarget ? targetSettings.CanTarget : (InRangeCombatant)null))
								{
									valid = true;
									if(filterInRange &&
										!userList.Contains(user[i]))
									{
										userList.Add(user[i]);
									}
								}
								else if(!filterInRange &&
									!userList.Contains(user[i]))
								{
									userList.Add(user[i]);
								}
							}
						}
					}
				}
			}

			return valid;
		}

		private bool CheckTarget(Combatant user, GameObject target,
			InRangeCombatant checkCombatant, InRangeGridCell checkCell, InRangeCombatant checkCanTarget)
		{
			Combatant targetCom = ComponentHelper.GetCombatant(target);
			if(targetCom != null)
			{
				if(checkCombatant(user, targetCom) &&
					(checkCanTarget == null ||
						checkCanTarget(user, targetCom)))
				{
					return true;
				}
			}
			else if(ORK.Battle.Grid != null)
			{
				BattleGridCellComponent targetCell = BattleGridHelper.GetCell(target);
				if(targetCell != null &&
					checkCell(user, targetCell))
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			if(UseRangeOriginType.Ability == this.type)
			{
				return ORK.Abilities.GetName(this.abilityID);
			}
			else if(UseRangeOriginType.Item == this.type)
			{
				return ORK.Items.GetName(this.itemID);
			}
			else if(UseRangeOriginType.ShortcutSlot == this.type)
			{
				return this.slot.GetInfoText();
			}
			else if(UseRangeOriginType.BattleRangeTemplate == this.type)
			{
				return ORK.BattleRangeTemplates.GetName(this.templateID);
			}
			return this.type.ToString();
		}
	}
}
