﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GroupGridFormation
	{
		private Group owner;

		private BattleGridFormation formation;

		private bool finishedEffectsUsed = false;


		// combatants
		private Combatant leader;

		private List<GroupGridFormationPosition> position = new List<GroupGridFormationPosition>();

		public GroupGridFormation(Group owner)
		{
			this.owner = owner;
		}

		public BattleGridFormation Formation
		{
			get { return this.formation; }
		}


		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		public Combatant Leader
		{
			get { return this.leader; }
		}

		public bool IsInFormation(Combatant combatant)
		{
			if(this.formation != null &&
				combatant != null)
			{
				if(this.leader == combatant)
				{
					return true;
				}
				for(int i = 0; i < this.position.Count; i++)
				{
					if(this.position[i].Combatant == combatant)
					{
						return true;
					}
				}
			}
			return false;
		}

		public bool IsInPosition(Combatant combatant)
		{
			if(this.formation != null &&
				combatant != null &&
				combatant.Grid.Cell != null)
			{
				if(this.leader == combatant)
				{
					return true;
				}
				else
				{
					for(int i = 0; i < this.position.Count; i++)
					{
						if(this.position[i].Combatant == combatant)
						{
							return this.position[i].OnPosition;
						}
					}
				}
			}
			return false;
		}

		public List<Combatant> GetUnpositionedCombatants()
		{
			List<Combatant> list = new List<Combatant>();
			this.owner.GetBattle(ref list);
			list.Remove(this.leader);
			for(int i = 0; i < this.position.Count; i++)
			{
				if(this.position[i].Combatant != null)
				{
					list.Remove(this.position[i].Combatant);
				}
			}
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i].Dead ||
					!list[i].Battle.InBattle)
				{
					list.RemoveAt(i--);
				}
			}
			return list;
		}

		public void CombatantDied(Combatant combatant)
		{
			if(this.formation != null &&
				combatant != null &&
				combatant.Dead)
			{
				// leader
				if(this.leader == combatant)
				{
					if(BattleGridFormationLeaderDeath.Break == this.formation.leader.onDeath)
					{
						this.EndFormation(-1);
					}
					else if(BattleGridFormationLeaderDeath.Select == this.formation.leader.onDeath)
					{
						this.leader = null;
						this.FindNewLeader();
					}
				}
				// positions
				else
				{
					bool freed = false;
					for(int i = 0; i < this.position.Count; i++)
					{
						if(this.position[i].Combatant == combatant)
						{
							if(this.position[i].Settings.freeOnDeath)
							{
								this.position[i].Combatant = null;
								freed = true;
								break;
							}
						}
					}
					if(freed)
					{
						this.FindPositionCombatants();
					}
				}
			}
		}

		public void CombatantRemoved(Combatant combatant)
		{
			if(this.formation != null &&
				combatant != null)
			{
				// leader
				if(this.leader == combatant)
				{
					if(BattleGridFormationLeaderDeath.Select == this.formation.leader.onDeath)
					{
						this.leader = null;
						this.FindNewLeader();
					}
					else
					{
						this.EndFormation(-1);
					}
				}
				// positions
				else
				{
					bool freed = false;
					for(int i = 0; i < this.position.Count; i++)
					{
						if(this.position[i].Combatant == combatant)
						{
							this.position[i].Combatant = null;
							freed = true;
							break;
						}
					}
					if(freed)
					{
						this.FindPositionCombatants();
					}
				}
			}
		}

		public void CombatantCellChanged(Combatant combatant)
		{
			if(this.formation != null &&
				combatant != null &&
				combatant.Grid.Cell != null)
			{
				if(this.leader == combatant)
				{
					this.UpdatePositionCoords();
				}
				else
				{
					for(int i = 0; i < this.position.Count; i++)
					{
						if(this.position[i].Combatant == combatant)
						{
							if(this.position[i].CubeCoord == combatant.Grid.Cell.CubeCoord)
							{
								this.position[i].Settings.UseRotation(combatant, this);
							}
							break;
						}
					}
				}

				this.CheckFinishedEffects();
			}
		}

		public void CheckFinishedEffects()
		{
			if(this.formation.CheckFinishStatusEffects(this))
			{
				if(!this.finishedEffectsUsed)
				{
					this.finishedEffectsUsed = true;

					this.formation.UseFinishedStatusEffects(this.leader, this);
					for(int i = 0; i < this.position.Count; i++)
					{
						if(this.position[i].Combatant != null)
						{
							this.formation.UseFinishedStatusEffects(this.position[i].Combatant, this);
						}
					}
				}
			}
			else if(this.finishedEffectsUsed)
			{
				this.finishedEffectsUsed = false;

				this.formation.UseEndFinishedStatusEffects(this.leader, this);
				for(int i = 0; i < this.position.Count; i++)
				{
					if(this.position[i].Combatant != null)
					{
						this.formation.UseEndFinishedStatusEffects(this.position[i].Combatant, this);
					}
				}
			}
		}

		public BattleGridCellComponent GetMoveToPositionCell(Combatant combatant)
		{
			if(this.formation != null &&
				combatant != null &&
				combatant.Grid.Cell != null &&
				this.leader != combatant &&
				ORK.Battle.Grid != null)
			{
				for(int i = 0; i < this.position.Count; i++)
				{
					if(this.position[i].Combatant == combatant)
					{
						if(this.position[i].CubeCoord != combatant.Grid.Cell.CubeCoord)
						{
							return ORK.Battle.Grid.GetCell(this.position[i].CubeCoord);
						}
						break;
					}
				}
			}
			return null;
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool InFormation
		{
			get { return this.formation != null; }
		}

		public bool IsFormation(int formationID)
		{
			return this.formation != null &&
				this.formation.RealID == formationID;
		}

		public bool PositionsFilled(bool onlyFilled, bool checkRotation, int gridDistance)
		{
			if(this.formation != null)
			{
				for(int i = 0; i < this.position.Count; i++)
				{
					if((!onlyFilled ||
							this.position[i].Combatant != null) &&
						(!this.position[i].OnPosition ||
							(checkRotation &&
								!this.position[i].Settings.CheckRotation(this.position[i].Combatant, this))) &&
						(gridDistance < 0 ||
							this.position[i].DistanceToPosition <= gridDistance))
					{
						return false;
					}
				}
				return true;
			}
			return false;
		}

		public bool IsFormationPossible()
		{
			if(this.formation != null)
			{
				for(int i = 0; i < this.position.Count; i++)
				{
					if(this.position[i].Cell == null ||
						this.position[i].Cell.IsBlocked)
					{
						return false;
					}
				}
				return true;
			}
			return false;
		}

		public bool CheckFormationPossible(BattleGridCellComponent cell,
			ConsiderFormationCombatants checkCombatants, int rotations,
			bool checkReachable, bool keepBlockedCells, bool sameCellType,
			List<BattleGridCellComponent> ignoreCells, List<BattleGridCellComponent> allowCells)
		{
			if(this.formation != null &&
				cell != null)
			{
				if(this.formation.leader.isLocalSpace)
				{
					for(int i = 0; i < this.position.Count; i++)
					{
						BattleGridCellComponent positionCell = cell.parentGrid.GetCell(
							cell.CubeCoord + this.position[i].Settings.coord.Rotate(rotations));
						if(positionCell == null ||
							positionCell.IsBlocked ||
							(sameCellType &&
								cell.CellType.RealID != positionCell.CellType.RealID) ||
							(ConsiderFormationCombatants.All == checkCombatants &&
								!positionCell.IsEmpty) ||
							(ConsiderFormationCombatants.IgnoreFormation == checkCombatants &&
								!positionCell.IsEmpty &&
								!this.IsInFormation(positionCell.Combatant)) ||
							(checkReachable &&
								this.position[i].Combatant != null &&
								!BattleGridPathFinder.CanReach(this.position[i].Combatant, positionCell,
									keepBlockedCells, true, MoveRangeType.Max, ignoreCells, allowCells)))
						{
							return false;
						}
					}
				}
				else
				{
					for(int i = 0; i < this.position.Count; i++)
					{
						BattleGridCellComponent positionCell = cell.parentGrid.GetCell(
							cell.CubeCoord + this.position[i].Settings.coord);
						if(positionCell == null ||
							positionCell.IsBlocked ||
							(sameCellType &&
								cell.CellType.RealID != positionCell.CellType.RealID) ||
							(ConsiderFormationCombatants.All == checkCombatants &&
								!positionCell.IsEmpty) ||
							(ConsiderFormationCombatants.IgnoreFormation == checkCombatants &&
								!positionCell.IsEmpty &&
								!this.IsInFormation(positionCell.Combatant)) ||
							(checkReachable &&
								this.position[i].Combatant != null &&
								!BattleGridPathFinder.CanReach(this.position[i].Combatant, positionCell,
								keepBlockedCells, true, MoveRangeType.Max, ignoreCells, allowCells)))
						{
							return false;
						}
					}
				}
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Formation functions
		============================================================================
		*/
		public void InitFormation(int formationID, Combatant leader)
		{
			this.formation = ORK.BattleGridFormations.Get(formationID);
			this.finishedEffectsUsed = false;

			if(this.formation.leader.isGroupLeader ||
				leader == null ||
				!this.owner.IsMember(leader))
			{
				this.leader = this.owner.BattleLeader;
			}
			else
			{
				this.leader = leader;
			}

			if(this.leader != null &&
				this.leader.Grid.Cell != null)
			{
				this.position.Clear();
				for(int i = 0; i < this.formation.position.Length; i++)
				{
					this.position.Add(new GroupGridFormationPosition(i, this.formation.position[i]));
				}
				this.position.Sort(new GroupGridFormationSorter());
				this.UpdatePositionCoords();
				this.FindPositionCombatants();

				// call effects
				this.formation.UseCallStatusEffects(this.leader, this);
				for(int i = 0; i < this.position.Count; i++)
				{
					if(this.position[i].Combatant != null)
					{
						this.formation.UseCallStatusEffects(this.position[i].Combatant, this);
					}
				}
				this.CheckFinishedEffects();
			}
			else
			{
				this.formation = null;
			}
		}

		public void EndFormation(int formationID)
		{
			if(this.formation != null)
			{
				// break effects
				this.formation.UseBreakStatusEffects(this.leader, this);
				for(int i = 0; i < this.position.Count; i++)
				{
					if(this.position[i].Combatant != null)
					{
						this.formation.UseBreakStatusEffects(this.position[i].Combatant, this);
					}
				}

				if(formationID == -1)
				{
					this.formation = null;
				}
				else if(this.formation.RealID == formationID)
				{
					this.formation = null;
				}

				this.finishedEffectsUsed = false;
				this.leader = null;
				this.position.Clear();
			}
		}


		/*
		============================================================================
		Position functions
		============================================================================
		*/
		public void UpdatePositionCoords()
		{
			if(this.formation != null &&
				this.leader != null &&
				this.leader.Grid.Cell != null)
			{
				if(this.formation.leader.isLocalSpace)
				{
					int turns = BattleGridHelper.GetCombatantDirection(this.leader, false);
					for(int i = 0; i < this.position.Count; i++)
					{
						this.position[i].CubeCoord = this.leader.Grid.Cell.CubeCoord + this.position[i].Settings.coord.Rotate(turns);
					}
				}
				else
				{
					for(int i = 0; i < this.position.Count; i++)
					{
						this.position[i].CubeCoord = this.leader.Grid.Cell.CubeCoord + this.position[i].Settings.coord;
					}
				}
			}
		}

		public void FindNewLeader()
		{
			if(this.formation != null &&
				BattleGridFormationLeaderDeath.Select == this.formation.leader.onDeath)
			{
				List<Combatant> list = this.GetUnpositionedCombatants();
				// check requirements
				if(list.Count > 0)
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(this.formation.leader.newLeaderRequirement.Check(list[i]))
						{
							this.leader = list[i];
							break;
						}
					}
				}
				// from positions
				if(this.leader == null &&
					this.formation.leader.fromPositions)
				{
					for(int i = 0; i < this.position.Count; i++)
					{
						if(this.position[i].Combatant != null &&
							this.formation.leader.newLeaderRequirement.Check(this.position[i].Combatant))
						{
							this.leader = this.position[i].Combatant;
							this.position[i].Combatant = null;
							break;
						}
					}
				}
				// ignore requirements
				if(this.leader == null &&
					this.formation.leader.ignoreRequirements &&
					list.Count > 0)
				{
					this.leader = list[0];
				}
				// from positions > ignore requirements
				if(this.leader == null &&
					this.formation.leader.fromPositions &&
					this.formation.leader.ignoreRequirements)
				{
					for(int i = 0; i < this.position.Count; i++)
					{
						if(this.position[i].Combatant != null)
						{
							this.leader = this.position[i].Combatant;
							this.position[i].Combatant = null;
							break;
						}
					}
				}

				if(this.leader != null)
				{
					this.UpdatePositionCoords();
					this.FindPositionCombatants();
				}
				else
				{
					this.EndFormation(-1);
				}
			}
		}

		public void FindPositionCombatants()
		{
			if(this.formation != null)
			{
				// rearrange
				if(this.formation.allowRearranging)
				{
					for(int i = 0; i < this.position.Count; i++)
					{
						BattleGridCellComponent cell = this.position[i].Cell;
						if(cell != null &&
							cell.Combatant != null &&
							!cell.Combatant.Dead &&
							cell.Combatant != this.position[i].Combatant &&
							this.position[i].Settings.CheckRequirements(cell.Combatant) &&
							this.CanRearrange(cell.Combatant, true))
						{
							this.position[i].Combatant = cell.Combatant;
						}
					}
				}

				List<Combatant> list = this.GetUnpositionedCombatants();

				// prioritize combatants already on the cell
				for(int i = 0; i < this.position.Count; i++)
				{
					if(this.position[i].Combatant == null)
					{
						BattleGridCellComponent cell = this.position[i].Cell;
						if(cell != null &&
							cell.Combatant != null &&
							!cell.Combatant.Dead &&
							list.Contains(cell.Combatant) &&
							this.position[i].Settings.CheckRequirements(cell.Combatant))
						{
							this.position[i].Combatant = cell.Combatant;
							list.Remove(cell.Combatant);
						}
					}
				}

				// fill cells
				for(int i = 0; i < this.position.Count; i++)
				{
					if(this.position[i].Combatant == null)
					{
						// fill by requirements
						for(int j = 0; j < list.Count; j++)
						{
							if(this.position[i].Settings.CheckRequirements(list[j]))
							{
								this.position[i].Combatant = list[j];
								list.RemoveAt(j);
								break;
							}
						}
						// from positions
						if(this.position[i].Combatant == null &&
							this.position[i].Settings.fromPositions)
						{
							for(int j = i + 1; j < this.position.Count; j++)
							{
								if(this.position[j].Combatant != null &&
									this.position[i].Settings.priority > this.position[j].Settings.priority &&
									this.position[i].Settings.CheckRequirements(this.position[j].Combatant))
								{
									this.position[i].Combatant = this.position[j].Combatant;
									this.position[j].Combatant = null;
									break;
								}
							}
						}
						// ignore requirements
						if(this.position[i].Combatant == null &&
							this.position[i].Settings.useRequirements &&
							this.position[i].Settings.ignoreRequirements &&
							list.Count > 0)
						{
							this.position[i].Combatant = list[0];
							list.RemoveAt(0);
						}
						// from positions > ignore requirements
						if(this.position[i].Combatant == null &&
							this.position[i].Settings.fromPositions &&
							this.position[i].Settings.ignoreRequirements)
						{
							for(int j = i + 1; j < this.position.Count; j++)
							{
								if(this.position[j].Combatant != null &&
									this.position[i].Settings.priority > this.position[j].Settings.priority)
								{
									this.position[i].Combatant = this.position[j].Combatant;
									this.position[j].Combatant = null;
									break;
								}
							}
						}
					}
				}
			}
		}

		private bool CanRearrange(Combatant combatant, bool freePosition)
		{
			if(this.formation != null)
			{
				for(int i = 0; i < this.position.Count; i++)
				{
					if(this.position[i].Combatant == combatant)
					{
						if(this.formation.rearrangeUseRequired ||
							!this.position[i].Settings.useRequirements)
						{
							if(freePosition)
							{
								this.position[i].Combatant = null;
							}
							return true;
						}
						else
						{
							return false;
						}
					}
				}
			}
			return true;
		}

		public void AssignToFreePosition(Combatant combatant)
		{
			if(this.formation != null)
			{
				for(int i = 0; i < this.position.Count; i++)
				{
					if(this.position[i].Combatant == null)
					{
						// fill by requirements
						if(this.position[i].Settings.CheckRequirements(combatant))
						{
							this.position[i].Combatant = combatant;
							return;
						}
						// ignore requirements
						if(this.position[i].Settings.useRequirements &&
							this.position[i].Settings.ignoreRequirements)
						{
							this.position[i].Combatant = combatant;
							return;
						}
					}
				}
			}
		}

		public void ReassignPosition(Combatant combatant)
		{
			if(this.formation != null)
			{
				for(int i = 0; i < this.position.Count; i++)
				{
					if(this.position[i].Combatant == combatant)
					{
						BattleGridCellComponent cell = this.position[i].Cell;

						// rearrange
						if(this.formation.allowRearranging)
						{
							if(cell != null &&
								cell.Combatant != null &&
								!cell.Combatant.Dead &&
								cell.Combatant != this.position[i].Combatant &&
								this.position[i].Settings.CheckRequirements(cell.Combatant) &&
								this.CanRearrange(cell.Combatant, true))
							{
								this.position[i].Combatant = cell.Combatant;
								return;
							}
						}

						List<Combatant> list = this.GetUnpositionedCombatants();

						// prioritize combatants already on the cell
						if(cell != null &&
							cell.Combatant != null &&
							!cell.Combatant.Dead &&
							list.Contains(cell.Combatant) &&
							this.position[i].Settings.CheckRequirements(cell.Combatant))
						{
							this.position[i].Combatant = cell.Combatant;
							return;
						}

						// fill cells
						// fill by requirements
						for(int j = 0; j < list.Count; j++)
						{
							if(this.position[i].Settings.CheckRequirements(list[j]))
							{
								this.position[i].Combatant = list[j];
								return;
							}
						}
						// from positions
						if(this.position[i].Settings.fromPositions)
						{
							for(int j = i + 1; j < this.position.Count; j++)
							{
								if(this.position[j].Combatant != null &&
									this.position[i].Settings.priority > this.position[j].Settings.priority &&
									this.position[i].Settings.CheckRequirements(this.position[j].Combatant))
								{
									this.position[i].Combatant = this.position[j].Combatant;
									this.position[j].Combatant = null;
									return;
								}
							}
						}
						// ignore requirements
						if(this.position[i].Settings.useRequirements &&
							this.position[i].Settings.ignoreRequirements &&
							list.Count > 0)
						{
							this.position[i].Combatant = list[0];
							return;
						}
						// from positions > ignore requirements
						if(this.position[i].Settings.fromPositions &&
							this.position[i].Settings.ignoreRequirements)
						{
							for(int j = i + 1; j < this.position.Count; j++)
							{
								if(this.position[j].Combatant != null &&
									this.position[i].Settings.priority > this.position[j].Settings.priority)
								{
									this.position[i].Combatant = this.position[j].Combatant;
									this.position[j].Combatant = null;
									return;
								}
							}
						}
						this.position[i].Combatant = null;
						return;
					}
				}
			}
		}

		public void UsePositionRotations()
		{
			if(this.formation != null)
			{
				for(int i = 0; i < this.position.Count; i++)
				{
					if(this.position[i].OnPosition)
					{
						this.position[i].Settings.UseRotation(this.position[i].Combatant, this);
					}
				}

				if(this.formation.finishedEffectCheckRotation)
				{
					this.CheckFinishedEffects();
				}
			}
		}

		public void UsePositionRotations(Combatant combatant)
		{
			if(this.formation != null)
			{
				for(int i = 0; i < this.position.Count; i++)
				{
					if(this.position[i].Combatant == combatant &&
						this.position[i].OnPosition)
					{
						this.position[i].Settings.UseRotation(this.position[i].Combatant, this);
						break;
					}
				}

				if(this.formation.finishedEffectCheckRotation)
				{
					this.CheckFinishedEffects();
				}
			}
		}

		public int GetLowestGridDistance(BattleGridCellComponent cell, bool blockDiagonalDistance1, bool onlyFilled, bool onlyOnPosition)
		{
			int distance = int.MaxValue;

			if(this.formation != null &&
				this.leader != null)
			{
				distance = this.leader.Grid.Cell.CubeCoord.Distance(cell.CubeCoord, blockDiagonalDistance1);

				for(int i = 0; i < this.position.Count; i++)
				{
					if(this.position[i].Cell != null &&
						(!onlyFilled ||
							(this.position[i].Combatant != null &&
								(!onlyOnPosition || this.position[i].OnPosition))))
					{
						int tmpDistance = this.position[i].Cell.CubeCoord.Distance(cell.CubeCoord, blockDiagonalDistance1);
						if(tmpDistance < distance)
						{
							distance = tmpDistance;
						}
					}
				}
			}

			return distance;
		}

		public bool CheckGridDistance(BattleGridCellComponent cell,
			float checkFor, float checkFor2, VariableValueCheck check,
			bool blockDiagonalDistance1, bool onlyFilled, bool onlyOnPosition)
		{
			if(this.formation != null &&
				this.leader != null)
			{
				if(ValueHelper.CheckVariableValue(
					this.leader.Grid.Cell.CubeCoord.Distance(cell.CubeCoord, blockDiagonalDistance1),
					checkFor, checkFor2, check))
				{
					return true;
				}

				for(int i = 0; i < this.position.Count; i++)
				{
					if(this.position[i].Cell != null &&
						(!onlyFilled ||
							(this.position[i].Combatant != null &&
								(!onlyOnPosition || this.position[i].OnPosition))))
					{
						if(ValueHelper.CheckVariableValue(
							this.position[i].Cell.CubeCoord.Distance(cell.CubeCoord, blockDiagonalDistance1),
							checkFor, checkFor2, check))
						{
							return true;
						}
					}
				}
			}

			return false;
		}
	}
}
