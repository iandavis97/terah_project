﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class FactionEventSetting : BaseData
	{
		[ORKEditorHelp("Player Event", "Select the game event asset used for combatants of the player group.", "")]
		public ORKGameEvent playerEvent;

		[ORKEditorHelp("Ally Event", "Select the game event asset used for groups that are allies of the player.", "")]
		public ORKGameEvent allyEvent;

		[ORKEditorHelp("Enemy Event", "Select the game event asset used for groups that are enemies of the player.", "")]
		public ORKGameEvent enemyEvent;

		public FactionEventSetting()
		{

		}

		public bool HasEvent(Combatant combatant)
		{
			if(combatant != null)
			{
				if(combatant.IsPlayerControlled())
				{
					return this.playerEvent != null;
				}
				else if(combatant.IsEnemy(ORK.Game.ActiveGroup.Leader))
				{
					return this.enemyEvent != null;
				}
				else
				{
					return this.allyEvent != null;
				}
			}
			return false;
		}

		public void StartEvent(Combatant combatant, Notify finishedCallback)
		{
			bool done = false;

			if(combatant != null)
			{
				ORKGameEvent gameEvent = null;

				// get faction event
				if(combatant.IsPlayerControlled())
				{
					gameEvent = this.playerEvent;
				}
				else if(combatant.IsEnemy(ORK.Game.ActiveGroup.Leader))
				{
					gameEvent = this.enemyEvent;
				}
				else
				{
					gameEvent = this.allyEvent;
				}

				// perform event
				if(gameEvent != null)
				{
					done = true;
					if(combatant.GameObject != null)
					{
						combatant.GameObject.AddComponent<GameEventTicker>().StartEvent(
							gameEvent, combatant, null, false, finishedCallback);
					}
					else
					{
						ORK.Core.GameObject.AddComponent<GameEventTicker>().StartEvent(
							gameEvent, combatant, null, false, finishedCallback);
					}
				}
			}

			// callback
			if(!done &&
				finishedCallback != null)
			{
				finishedCallback();
			}
		}
	}
}
