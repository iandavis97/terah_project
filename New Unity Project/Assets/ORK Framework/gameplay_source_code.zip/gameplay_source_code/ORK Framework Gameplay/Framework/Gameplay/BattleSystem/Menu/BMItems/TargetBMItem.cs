
using System.Collections.Generic;
using UnityEngine;

namespace ORKFramework.UI
{
	public class TargetBMItem : BMItem
	{
		private List<Combatant> targets;

		private IShortcut shortcut;

		private bool blockBattleCamera = false;

		public TargetBMItem(ChoiceContent content, IShortcut shortcut, List<Combatant> targets, bool blockBattleCamera)
		{
			this.content = content;
			this.shortcut = shortcut;
			this.targets = targets;
			this.blockBattleCamera = blockBattleCamera;
		}

		public override void CreateDrag(Combatant owner)
		{
			// portrait
			if(this.content.portrait == null && this.targets != null &&
				owner.Battle.BattleMenu.Settings.showTargetPortraits)
			{
				for(int i = 0; i < this.targets.Count; i++)
				{
					if(this.targets[i] != null)
					{
						this.content.portrait = this.targets[i].UI.GetPortrait(
							owner.Battle.BattleMenu.Settings.targetPortraitTypeID);
						if(this.content.portrait != null)
						{
							return;
						}
					}
				}
			}
		}

		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = false;

			if(this.shortcut is AbilityShortcut &&
				this.shortcut.CanUse(owner,
					AbilityActionType.CounterAttack != ((AbilityShortcut)this.shortcut).Type,
					true))
			{
				ActiveAbility level = ((AbilityShortcut)this.shortcut).GetActiveLevel();
				for(int i = 0; i < this.targets.Count; i++)
				{
					if(level.targetSettings.CanTarget(owner, this.targets[i]) &&
						level.targetSettings.InUseRange(owner, this.targets[i]))
					{
						tmp = true;
						break;
					}
				}
			}
			else if(this.shortcut is ItemShortcut &&
				this.shortcut.CanUse(owner, true, true) &&
				owner.Inventory.Items.Has(this.shortcut.ID, 1))
			{
				ItemShortcut item = (ItemShortcut)this.shortcut;
				for(int i = 0; i < this.targets.Count; i++)
				{
					if(item.Setting.targetSettings.CanTarget(owner, this.targets[i]) &&
						item.Setting.targetSettings.InUseRange(owner, this.targets[i]))
					{
						tmp = true;
						break;
					}
				}
			}
			if(tmp != this.content.Active)
			{
				this.content.Active = tmp;
				return true;
			}
			return false;
		}

		public override void Selected(Combatant owner)
		{
			owner.Battle.BattleMenu.TargetHighlight.AcceptAction(this.shortcut);
			owner.Battle.BattleMenu.TargetHighlight.AcceptHighlights();
			owner.Battle.BattleMenu.TargetHighlight.SelectTargets(this.targets, this.shortcut);
		}

		public override bool Accepted(Combatant owner)
		{
			BaseAction action = null;
			if(this.shortcut is AbilityShortcut)
			{
				action = new AbilityAction(owner, this.shortcut as AbilityShortcut);
			}
			else if(this.shortcut is ItemShortcut)
			{
				action = new ItemAction(owner, this.shortcut as ItemShortcut);
			}
			action.blockBattleCamera = this.blockBattleCamera;
			action.SetTargets(this.targets);
			owner.Battle.BattleMenu.AddAction(action);
			return true;
		}

		public override bool Contains(Combatant owner, Combatant target)
		{
			return this.targets.Contains(target) &&
				this.shortcut.CanTarget(owner, target);
		}

		public override bool ContainsAny(Combatant owner, List<Combatant> list)
		{
			if(list != null)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(this.targets.Contains(list[i]) &&
						this.shortcut.CanTarget(owner, list[i]))
					{
						return true;
					}
				}
			}
			return false;
		}

		public override bool ToggleTargetRange(Combatant owner)
		{
			if(this.shortcut is AbilityShortcut)
			{
				AbilityShortcut ability = (AbilityShortcut)this.shortcut;
				if(ability.ToggleTargetRange())
				{
					if(owner.Battle.BattleMenu != null &&
						owner.Battle.BattleMenu.Box != null)
					{
						owner.Battle.BattleMenu.Box.Audio.PlayAccept();
					}
					new AbilityBMItem(ability, null, this.blockBattleCamera).Accepted(owner);
					return true;
				}
			}
			else if(this.shortcut is ItemShortcut)
			{
				ItemShortcut item = (ItemShortcut)this.shortcut;
				if(item.ToggleTargetRange())
				{
					if(owner.Battle.BattleMenu != null &&
						owner.Battle.BattleMenu.Box != null)
					{
						owner.Battle.BattleMenu.Box.Audio.PlayAccept();
					}
					new ItemBMItem(item, null, this.blockBattleCamera).Accepted(owner);
					return true;
				}
			}
			return false;
		}
	}
}
