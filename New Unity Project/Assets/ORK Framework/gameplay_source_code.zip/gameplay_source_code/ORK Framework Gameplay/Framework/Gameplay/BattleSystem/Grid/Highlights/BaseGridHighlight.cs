﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BaseGridHighlight : BaseData
	{
		// prefab
		[ORKEditorHelp("Use Prefab", "Use a prefab to mark highlighted cells.", "")]
		[ORKEditorInfo(labelText="Highlight Prefab Settings")]
		public bool usePrefab = false;

		[ORKEditorHelp("Replace Cell Prefab", "A highlighted cell's prefab (defined by it's cell type) " +
			"will be replaced by the highlight prefab.\n" +
			"If disabled, the highlight prefab will be added additionally to the cell's prefab.", "")]
		[ORKEditorLayout("usePrefab", true)]
		public bool replaceCellPrefab = false;

		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public GridCellPrefab prefab;


		// blink
		[ORKEditorHelp("Use Blink", "The highlighted cell's prefab game object will blink.", "")]
		[ORKEditorInfo(separator=true, labelText="Highlight Blink Settings")]
		public bool useBlink = false;

		[ORKEditorHelp("Blink Children", "All child game objects of the prefab will blink.\n" +
			"If disabled, only the root object of the prefab will blink.", "")]
		[ORKEditorLayout("useBlink", true)]
		public bool blinkChildren = true;

		[ORKEditorHelp("Blink Highlight Prefab", "The highlight prefab will also blink.\n" +
			"If disabled, only the cell's prefab will blink.", "")]
		[ORKEditorLayout("usePrefab", true, endCheckGroup=true)]
		public bool blinkHighlightPrefab = false;

		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public FadeColorSettings blink;


		// line renderer
		[ORKEditorHelp("Use Line Renderer", "Use a prefab with a 'Line Renderer' to create an outline or a path line on the highlighted cells.", "")]
		[ORKEditorInfo(separator=true, labelText="Line Renderer Settings")]
		public bool useLineRenderer = false;

		[ORKEditorLayout("useLineRenderer", true, endCheckGroup=true, autoInit=true)]
		public LineGridHighlight line;


		// in-game
		private float linkedTime = 0;

		private bool linkedReverting = false;

		public BaseGridHighlight()
		{

		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public void Tick(float t)
		{
			// blink
			if(this.useBlink)
			{
				if(this.linkedTime >= this.blink.time)
				{
					this.linkedTime = 0;
					this.linkedReverting = !this.linkedReverting;
				}
				this.linkedTime += t;
			}
		}

		public void GetColorFade(ref float time, ref bool reverting)
		{
			time = this.linkedTime;
			reverting = this.linkedReverting;
		}


		public void Highlight(BattleGridCellComponent cell)
		{
			if(cell != null)
			{
				// prefab
				if(this.usePrefab &&
					this.prefab.prefab != null)
				{
					GameObject prefab = cell.HighlightPrefabInstance;
					if(ORK.Battle.Settings.gridHighlights.hideUnusedPrefabs)
					{
						if(this.replaceCellPrefab &&
							cell.PrefabInstance != null)
						{
							ComponentHelper.SetVisible(cell.PrefabInstance, false);
						}
						if(prefab == null)
						{
							prefab = this.prefab.CreatePrefabInstance(cell, true);
							cell.HighlightPrefabInstance = prefab;
						}
						else
						{
							ComponentHelper.SetVisible(prefab, true);
						}
					}
					else
					{
						if(this.replaceCellPrefab &&
							cell.PrefabInstance != null)
						{
							cell.PrefabInstance.SetActive(false);
						}
						if(prefab == null)
						{
							prefab = this.prefab.CreatePrefabInstance(cell, true);
							cell.HighlightPrefabInstance = prefab;
						}
						else
						{
							prefab.SetActive(true);
						}
					}
				}
				// blink
				if(this.useBlink && this.blink != null)
				{
					if(cell.PrefabInstance != null &&
						(!this.usePrefab || !this.replaceCellPrefab))
					{
						TargetBlinker blinker = cell.PrefabInstance.GetComponent<TargetBlinker>();
						if(blinker == null)
						{
							blinker = cell.PrefabInstance.AddComponent<TargetBlinker>();
							blinker.OneTimeInit();
						}
						blinker.LinkedTime = this.GetColorFade;
						blinker.Blink(this.blink, this.blinkChildren);
						if(!this.blink.fromCurrent)
						{
							blinker.StoreCurrentColors();
						}
					}
					if(this.blinkHighlightPrefab)
					{
						GameObject prefab = cell.HighlightPrefabInstance;
						if(prefab != null)
						{
							TargetBlinker blinker = prefab.GetComponent<TargetBlinker>();
							if(blinker == null)
							{
								blinker = prefab.AddComponent<TargetBlinker>();
								blinker.OneTimeInit();
							}
							blinker.LinkedTime = this.GetColorFade;
							blinker.Blink(this.blink, this.blinkChildren);
							if(!this.blink.fromCurrent)
							{
								blinker.StoreCurrentColors();
							}
						}
					}
				}
			}
		}

		public void StopHighlight(BattleGridCellComponent cell)
		{
			if(cell != null)
			{
				// prefab
				if(this.usePrefab &&
					this.prefab.prefab != null)
				{
					GameObject prefab = cell.HighlightPrefabInstance;
					if(ORK.Battle.Settings.gridHighlights.hideUnusedPrefabs)
					{
						if(this.replaceCellPrefab &&
							cell.PrefabInstance != null)
						{
							ComponentHelper.SetVisible(cell.PrefabInstance, true);
						}
						if(prefab != null)
						{
							ComponentHelper.SetVisible(prefab, false);
						}
					}
					else
					{
						if(this.replaceCellPrefab &&
							cell.PrefabInstance != null)
						{
							cell.PrefabInstance.SetActive(true);
						}
						if(prefab != null)
						{
							prefab.SetActive(false);
						}
					}
				}
				// blink
				if(this.useBlink && this.blink != null)
				{
					if(cell.PrefabInstance != null &&
						(!this.usePrefab || !this.replaceCellPrefab))
					{
						TargetBlinker blinker = cell.PrefabInstance.GetComponent<TargetBlinker>();
						if(blinker != null)
						{
							blinker.StopBlink();
							blinker.LinkedTime = null;
							blinker.RestoreCurrentColors();
						}
					}
					if(this.blinkHighlightPrefab)
					{
						GameObject prefab = cell.HighlightPrefabInstance;
						if(prefab != null)
						{
							TargetBlinker blinker = prefab.GetComponent<TargetBlinker>();
							if(blinker != null)
							{
								blinker.StopBlink();
								blinker.LinkedTime = null;
								blinker.RestoreCurrentColors();
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Line renderer functions
		============================================================================
		*/
		public void AddLineCell(BattleGridCellComponent cell, GridHighlightType type)
		{
			if(this.useLineRenderer &&
				this.line.prefab != null)
			{
				ORK.Battle.Grid.LineHighlight(type, this.line, cell);
			}
		}

		public void AddLineCells(List<BattleGridCellComponent> cells, GridHighlightType type)
		{
			if(this.useLineRenderer &&
				this.line.prefab != null)
			{
				ORK.Battle.Grid.LineHighlight(type, this.line, cells);
			}
		}

		public void RemoveLineCell(BattleGridCellComponent cell, GridHighlightType type)
		{
			if(this.useLineRenderer &&
				this.line.prefab != null)
			{
				ORK.Battle.Grid.StopLineHighlight(type, this.line, cell);
			}
		}

		public void RemoveLineCells(List<BattleGridCellComponent> cells, GridHighlightType type)
		{
			if(this.useLineRenderer &&
				this.line.prefab != null)
			{
				ORK.Battle.Grid.StopLineHighlight(type, this.line, cells);
			}
		}
	}
}
