﻿
using ORKFramework;
using ORKFramework.AI;
using ORKFramework.Behaviours;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI.Steps
{
	public static class AIStepHelper
	{
		public static Dictionary<System.Type, NodeInfo> GetSteps()
		{
			Dictionary<System.Type, NodeInfo> list = new Dictionary<System.Type, NodeInfo>();

			System.Reflection.Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
			for(int i = 0; i < assembly.Length; i++)
			{
				AIStepHelper.AddFromAssembly(assembly[i], ref list);
			}

			return list;
		}

		private static void AddFromAssembly(System.Reflection.Assembly assembly,
			ref Dictionary<System.Type, NodeInfo> list)
		{
			System.Type[] types = assembly.GetTypes();
			for(int i = 0; i < types.Length; i++)
			{
				if(types[i].Namespace == "ORKFramework.AI.Steps")
				{
					System.Object[] attr = types[i].GetCustomAttributes(typeof(ORKEditorHelpAttribute), true);
					if(attr.Length > 0)
					{
						string[] help = (attr[0] as ORKEditorHelpAttribute).text;

						string[] subMenu = new string[0];
						attr = types[i].GetCustomAttributes(typeof(ORKNodeInfoAttribute), true);
						if(attr.Length > 0)
						{
							subMenu = (attr[0] as ORKNodeInfoAttribute).subMenu;
						}
						list.Add(types[i], new NodeInfo(help, subMenu));
					}
				}
			}
		}
	}

	public abstract class BaseAIStep : CoreAIStep
	{
		[ORKEditorHelp("Enabled", "This step is enabled and will be executed.\n" +
			"If disabled, the step wont execute and the next step ('Next') will be executed.", "")]
		[ORKEditorInfo(hide=true)]
		public bool active = true;

		[ORKEditorInfo(hide=true)]
		public int next = -1;

		public abstract BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets);

		protected List<Combatant> GetTargetList(BattleAITargetType type,
			bool excludeSelf, bool excludeFoundTargets,
			Combatant user, List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			List<Combatant> list = new List<Combatant>();
			if(BattleAITargetType.Self == type)
			{
				list.Add(user);
			}
			else if(BattleAITargetType.Ally == type)
			{
				if(excludeSelf || excludeFoundTargets)
				{
					for(int i = 0; i < allies.Count; i++)
					{
						if((!excludeSelf || allies[i] != user) &&
							(!excludeFoundTargets || !foundTargets.Contains(allies[i])))
						{
							list.Add(allies[i]);
						}
					}
				}
				else
				{
					list.AddRange(allies);
				}
			}
			else if(BattleAITargetType.Enemy == type)
			{
				if(excludeFoundTargets)
				{
					for(int i = 0; i < enemies.Count; i++)
					{
						if(!foundTargets.Contains(enemies[i]))
						{
							list.Add(enemies[i]);
						}
					}
				}
				else
				{
					list.AddRange(enemies);
				}
			}
			else if(BattleAITargetType.All == type)
			{
				// allies
				if(excludeSelf || excludeFoundTargets)
				{
					for(int i = 0; i < allies.Count; i++)
					{
						if((!excludeSelf || allies[i] != user) &&
							(!excludeFoundTargets || !foundTargets.Contains(allies[i])))
						{
							list.Add(allies[i]);
						}
					}
				}
				else
				{
					list.AddRange(allies);
				}
				// enemies
				if(excludeFoundTargets)
				{
					for(int i = 0; i < enemies.Count; i++)
					{
						if(!foundTargets.Contains(enemies[i]))
						{
							list.Add(enemies[i]);
						}
					}
				}
				else
				{
					list.AddRange(enemies);
				}
			}
			return list;
		}

		protected List<Combatant> GetPreferredTargets(Combatant user, List<Combatant> foundTargets)
		{
			if(foundTargets.Count == 0)
			{
				List<Combatant> tmp = new List<Combatant>();
				if(user.Setting.attackLastTarget &&
					user.Battle.LastTargets.Count > 0)
				{
					tmp.AddRange(user.Battle.LastTargets);
				}
				return tmp;
			}
			else
			{
				return foundTargets;
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeName()
		{
			return "";
		}

		public override string GetNodeDetails()
		{
			return "";
		}

		public override string GetNextName(int index)
		{
			return "Next";
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 1;
		}

		public override int GetNext(int index)
		{
			return this.next;
		}

		public override void SetNext(int index, int next)
		{
			this.next = next;
		}


		/*
		============================================================================
		Enable functions
		============================================================================
		*/
		public override bool IsEnabled
		{
			get { return this.active; }
		}
	}

	public abstract class BaseAICheckStep : BaseAIStep
	{
		[ORKEditorInfo(hide=true)]
		public int nextFail = -1;


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Success";
			}
			else if(index == 1)
			{
				return "Failed";
			}
			return "";
		}

		public override int GetNextCount()
		{
			return 2;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index == 1)
			{
				return this.nextFail;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index == 1)
			{
				this.nextFail = next;
			}
		}
	}
}
