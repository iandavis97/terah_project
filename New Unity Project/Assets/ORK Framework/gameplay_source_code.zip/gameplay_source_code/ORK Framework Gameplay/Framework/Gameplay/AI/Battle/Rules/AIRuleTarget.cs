﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AIRuleTarget : BaseData
	{
		[ORKEditorHelp("Bind To Ruleset", "Only affect the targets of actions of this AI ruleset.\n" +
			"I.e. if an 'Action' or 'Battle AI' rule finds a usable action, it'll use this target rule.\n" +
			"If disabled, the targets of all AI actions will be affected by this rule.", "")]
		public bool bindToRuleset = false;

		[ORKEditorHelp("Target Type", "Select which group will be the target:\n" +
			"- Self: The user is the target.\n" +
			"- Ally: The target is in an allied group of the user.\n" +
			"- Enemy: The target is in an enemy group.\n" +
			"- All: All combatant's are possible targets.\n" +
			"- Member Target: The target of a group member.\n" +
			"- Targeting Member: Enemies targeting a group member.", "")]
		public AIRuleTargetType targetType = AIRuleTargetType.Enemy;


		// ally target/targeting
		[ORKEditorInfo("Member", "Select the group member that will be used.\n" +
			"When using 'Member Target', the selected member's current/last target will be used.\n" +
			"When using 'Targeting Member', enemies targeting the selected member will be used.", "",
			endFoldout=true)]
		[ORKEditorLayout(new string[] { "targetType", "targetType" },
			new System.Object[] { AIRuleTargetType.MemberTarget, AIRuleTargetType.TargetingMember },
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public GroupMemberSelection memberSelection;


		// target requirements
		[ORKEditorHelp("Use Requirements", "Use status requirements and game variable conditions.", "")]
		[ORKEditorInfo("Target Requirements", "Select targets based on status requirements and " +
			"game variable conditions.\n" +
			"The combatant using the AI ruleset is used for status checks and object game variables.", "")]
		public bool useTargetRequirements = false;

		[ORKEditorHelp("Is Use Requirement", "This rule is also a use requirement for 'Action' and 'Battle AI' rules of this ruleset.\n" +
			"I.e. the ruleset will only use actions if targets with the defined requirements are found.", "")]
		[ORKEditorLayout("useTargetRequirements", true)]
		public bool isUseRequirement = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public SimpleCombatantRequirement targetRequirement;

		public AIRuleTarget()
		{

		}

		public bool CheckRequirements(Combatant user, List<Combatant> allies, List<Combatant> enemies)
		{
			if(AIRuleTargetType.Self == this.targetType)
			{
				return this.CheckTargetRequirement(user);
			}
			else if(AIRuleTargetType.Ally == this.targetType)
			{
				for(int i = 0; i < allies.Count; i++)
				{
					if(this.CheckTargetRequirement(allies[i]))
					{
						return true;
					}
				}
			}
			else if(AIRuleTargetType.Enemy == this.targetType)
			{
				for(int i = 0; i < enemies.Count; i++)
				{
					if(this.CheckTargetRequirement(enemies[i]))
					{
						return true;
					}
				}
			}
			else if(AIRuleTargetType.All == this.targetType)
			{
				for(int i = 0; i < allies.Count; i++)
				{
					if(this.CheckTargetRequirement(allies[i]))
					{
						return true;
					}
				}
				for(int i = 0; i < enemies.Count; i++)
				{
					if(this.CheckTargetRequirement(enemies[i]))
					{
						return true;
					}
				}
			}
			else if(AIRuleTargetType.MemberTarget == this.targetType)
			{
				Combatant member = this.memberSelection.GetBattleGroupMember(user);

				if(member != null)
				{
					for(int i = 0; i < member.Battle.LastTargets.Count; i++)
					{
						if(member.Battle.LastTargets[i] != null &&
							this.CheckTargetRequirement(member.Battle.LastTargets[i]))
						{
							return true;
						}
					}
				}
			}
			else if(AIRuleTargetType.TargetingMember == this.targetType)
			{
				Combatant member = this.memberSelection.GetBattleGroupMember(user);

				if(member != null)
				{
					for(int i = 0; i < enemies.Count; i++)
					{
						if(enemies[i].Battle.LastTargets.Contains(member) &&
							this.CheckTargetRequirement(enemies[i]))
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		public bool CheckTargetRequirement(Combatant target)
		{
			return !this.useTargetRequirements ||
				this.targetRequirement.Check(target);
		}

		public bool SetActionTargets(BaseAction action, Combatant user, List<Combatant> allies, List<Combatant> enemies)
		{
			TargetSettings targetSettings = TargetSettings.Get(action);

			if(targetSettings != null)
			{
				List<Combatant> targets = new List<Combatant>();
				if(AIRuleTargetType.Self == this.targetType)
				{
					if(this.CheckTargetRequirement(user) &&
						targetSettings.CanTarget(user, user))
					{
						targets.Add(user);
					}
				}
				else if(AIRuleTargetType.Ally == this.targetType)
				{
					for(int i = 0; i < allies.Count; i++)
					{
						if(this.CheckTargetRequirement(allies[i]) &&
							targetSettings.CanTarget(user, allies[i]))
						{
							targets.Add(allies[i]);
						}
					}
				}
				else if(AIRuleTargetType.Enemy == this.targetType)
				{
					for(int i = 0; i < enemies.Count; i++)
					{
						if(this.CheckTargetRequirement(enemies[i]) &&
							targetSettings.CanTarget(user, enemies[i]))
						{
							targets.Add(enemies[i]);
						}
					}
				}
				else if(AIRuleTargetType.All == this.targetType)
				{
					for(int i = 0; i < allies.Count; i++)
					{
						if(this.CheckTargetRequirement(allies[i]) &&
							targetSettings.CanTarget(user, allies[i]))
						{
							targets.Add(allies[i]);
						}
					}
					for(int i = 0; i < enemies.Count; i++)
					{
						if(this.CheckTargetRequirement(enemies[i]) &&
							targetSettings.CanTarget(user, enemies[i]))
						{
							targets.Add(enemies[i]);
						}
					}
				}
				else if(AIRuleTargetType.MemberTarget == this.targetType)
				{
					Combatant member = this.memberSelection.GetBattleGroupMember(user);

					if(member != null)
					{
						for(int i = 0; i < member.Battle.LastTargets.Count; i++)
						{
							if(member.Battle.LastTargets[i] != null &&
								this.CheckTargetRequirement(member.Battle.LastTargets[i]) &&
								targetSettings.CanTarget(user, member.Battle.LastTargets[i]))
							{
								targets.Add(member.Battle.LastTargets[i]);
							}
						}
					}
				}
				else if(AIRuleTargetType.TargetingMember == this.targetType)
				{
					Combatant member = this.memberSelection.GetBattleGroupMember(user);

					if(member != null)
					{
						for(int i = 0; i < enemies.Count; i++)
						{
							if(enemies[i].Battle.LastTargets.Contains(member) &&
								this.CheckTargetRequirement(enemies[i]) &&
								targetSettings.CanTarget(user, enemies[i]))
							{
								targets.Add(enemies[i]);
							}
						}
					}
				}

				if(targets.Count > 0)
				{
					return targetSettings.SetTargets(action as TargetRangeAction, user, targets);
				}
			}
			return false;
		}
	}
}
