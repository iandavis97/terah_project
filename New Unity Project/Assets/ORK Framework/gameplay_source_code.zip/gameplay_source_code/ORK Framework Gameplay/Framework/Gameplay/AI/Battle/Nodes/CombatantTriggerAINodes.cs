﻿
using ORKFramework;
using ORKFramework.Behaviours;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI.Steps
{
	// TODO: test, event nodes, move AI detection checks
	[ORKEditorHelp("Has Combatant Trigger", "Checks if a combatant has combatant triggers.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Combatant", "Check")]
	public class HasCombatantTriggerStep : BaseAICheckStep
	{
		// combatant
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// tags
		[ORKEditorHelp("Needed", "Either all or only one tag must be on added to the combatant trigger component.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Tags")]
		public Needed needed = Needed.All;

		[ORKEditorInfo(hideName=true, separator=true)]
		[ORKEditorArray(false, "Add Tag", "Adds a tag that will be checked.", "",
			"Remove", "Removes this tag.", "", isHorizontal=true)]
		public string[] tags = new string[0];

		public HasCombatantTriggerStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			bool any = false;
			if(ORK.Battle.Grid != null)
			{
				if(FoundTargets.Clear == this.foundType)
				{
					foundTargets.Clear();
				}
				else if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(foundTargets);
					foundTargets.Clear();
					this.Check(ref any, tmp, foundTargets);
				}
				else if(FoundTargets.CheckKeep == this.foundType)
				{
					this.Check(ref any, foundTargets, foundTargets);
				}

				// check all possible targets
				this.Check(ref any,
					this.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						user, allies, enemies, foundTargets),
					foundTargets);
			}

			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}

			return null;
		}

		private void Check(ref bool any, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					list[i].Triggers.Count > 0 &&
					(this.tags.Length == 0 ||
						this.CheckTags(list[i].Triggers)))
				{
					any = true;
					if(!this.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}

		private bool CheckTags(List<CombatantTriggerComponent> list)
		{
			if(list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						list[i].IsActive &&
						list[i].CheckTags(this.tags, this.needed))
					{
						return true;
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found";
		}
	}

	[ORKEditorHelp("In Combatant Trigger", "Checks if a combatant is within one of the " +
		"user's combatant triggers (or the user in another combatant's trigger).\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Combatant", "Check")]
	public class InCombatantTriggerStep : BaseAICheckStep
	{
		// combatant
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// settings
		[ORKEditorHelp("In Target's Trigger", "Check if the user is in the target's trigger.\n" +
			"If disabled, checks if the target is in the user's trigger.", "")]
		[ORKEditorInfo(separator=true)]
		public bool inTargetTrigger = false;



		// tags
		[ORKEditorHelp("Needed", "Either all or only one tag must be on added to the combatant trigger component.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Tags")]
		public Needed needed = Needed.All;

		[ORKEditorInfo(hideName=true, separator=true)]
		[ORKEditorArray(false, "Add Tag", "Adds a tag that will be checked.", "",
			"Remove", "Removes this tag.", "", isHorizontal=true)]
		public string[] tags = new string[0];

		public InCombatantTriggerStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			bool any = false;
			if(ORK.Battle.Grid != null)
			{
				if(FoundTargets.Clear == this.foundType)
				{
					foundTargets.Clear();
				}
				else if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(foundTargets);
					foundTargets.Clear();
					this.Check(ref any, user, tmp, foundTargets);
				}
				else if(FoundTargets.CheckKeep == this.foundType)
				{
					this.Check(ref any, user, foundTargets, foundTargets);
				}

				// check all possible targets
				this.Check(ref any, user,
					this.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						user, allies, enemies, foundTargets),
					foundTargets);
			}

			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}

			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					(this.inTargetTrigger ?
						this.CheckTrigger(list[i], user) :
						this.CheckTrigger(user, list[i])))
				{
					any = true;
					if(!this.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}

		private bool CheckTrigger(Combatant user, Combatant combatant)
		{
			List<CombatantTriggerComponent> list = user.Triggers;
			if(list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						list[i].IsActive &&
						(this.tags.Length == 0 ||
							list[i].CheckTags(this.tags, this.needed)) &&
						list[i].Contains(combatant))
					{
						return true;
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType +
				(this.inTargetTrigger ?
					" found: In target's trigger" :
					" found: In user's trigger");
		}
	}

	[ORKEditorHelp("Combatant Trigger Time", "Checks if a combatant is within one of the " +
		"user's combatant triggers for a defined amount of time (or the user in another combatant's trigger).\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Combatant", "Check")]
	public class CombatantTriggerTimeStep : BaseAICheckStep
	{
		// combatant
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// settings
		[ORKEditorHelp("In Target's Trigger", "Check if the user is in the target's trigger.\n" +
			"If disabled, checks if the target is in the user's trigger.", "")]
		[ORKEditorInfo(separator=true)]
		public bool inTargetTrigger = false;

		[ORKEditorHelp("Check Type", "Checks if the time is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the time is between two defined values, including the values.\n" +
			"Range exclusive checks if the time is between two defined values, excluding the values.\n" +
			"Approximately checks if the time is similar to the defined value.", "")]
		public VariableValueCheck check = VariableValueCheck.IsEqual;

		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public AIFloat value = new AIFloat();

		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"},
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive},
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public AIFloat value2;



		// tags
		[ORKEditorHelp("Needed", "Either all or only one tag must be on added to the combatant trigger component.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Tags")]
		public Needed needed = Needed.All;

		[ORKEditorInfo(hideName=true, separator=true)]
		[ORKEditorArray(false, "Add Tag", "Adds a tag that will be checked.", "",
			"Remove", "Removes this tag.", "", isHorizontal=true)]
		public string[] tags = new string[0];

		public CombatantTriggerTimeStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			bool any = false;
			if(ORK.Battle.Grid != null)
			{
				if(FoundTargets.Clear == this.foundType)
				{
					foundTargets.Clear();
				}
				else if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(foundTargets);
					foundTargets.Clear();
					this.Check(ref any, user, tmp, foundTargets);
				}
				else if(FoundTargets.CheckKeep == this.foundType)
				{
					this.Check(ref any, user, foundTargets, foundTargets);
				}

				// check all possible targets
				this.Check(ref any, user,
					this.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						user, allies, enemies, foundTargets),
					foundTargets);
			}

			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}

			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					(this.inTargetTrigger ?
						this.CheckTrigger(list[i], user) :
						this.CheckTrigger(user, list[i])))
				{
					any = true;
					if(!this.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}

		private bool CheckTrigger(Combatant user, Combatant combatant)
		{
			List<CombatantTriggerComponent> list = user.Triggers;
			if(list.Count > 0)
			{
				float tmpValue = this.value.GetValue(user, combatant);
				float tmpValue2 = this.value2 != null ? this.value2.GetValue(user, combatant) : 0;
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						list[i].IsActive &&
						(this.tags.Length == 0 ||
							list[i].CheckTags(this.tags, this.needed)))
					{
						float time = list[i].GetTime(combatant);
						if(time >= 0 &&
							ValueHelper.CheckVariableValue(time, tmpValue, tmpValue2, this.check))
						{
							return true;
						}
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found: " +
				this.check.ToString() + " " + this.value.GetInfoText() +
				(this.value2 != null ? " ~ " + this.value2.GetInfoText() : "");
		}
	}
}
