
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantConditionalPrefab : BaseData
	{
		// prefab
		public CombatantPrefab prefab = new CombatantPrefab();

		[ORKEditorHelp("Use Spawned Scale", "Use the scale of the currently spawned prefab when changing prefabs.", "")]
		public bool useSpawnedScale = true;


		// status requirements
		[ORKEditorHelp("Needed", "Either all or only one requirement must be met.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Status Requirements")]
		public Needed needed = Needed.All;

		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.", "",
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be met to use this prefab.", ""
		})]
		public StatusRequirement[] req = new StatusRequirement[0];


		// variable conditions
		[ORKEditorHelp("Use Object Variable", "Use object variables of the combatant.\n" +
			"The combatant's game object must have an 'Object Variables' component attached, " +
			"else the check fails.", "")]
		[ORKEditorInfo(separator=true, labelText="Variable Conditions")]
		public bool useObjectVariable = false;

		public VariableCondition condition = new VariableCondition();

		public CombatantConditionalPrefab()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<float>("boxRadius"))
			{
				this.prefab.SetData(data);
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool Check(Combatant combatant)
		{
			return this.prefab.prefab.settings.Get() != null &&
				combatant != null &&
				StatusRequirement.Check(combatant, this.req, this.needed) &&
				this.CheckVariables(combatant);
		}

		public bool CheckVariables(Combatant combatant)
		{
			if(this.useObjectVariable)
			{
				if(combatant != null)
				{
					return this.condition.CheckVariables(combatant.Variables);
				}
			}
			else
			{
				return this.condition.CheckVariables(ORK.Game.Variables);
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public void RegisterStatusChanges(Combatant combatant, IStatusChanged notify)
		{
			for(int i = 0; i < this.req.Length; i++)
			{
				this.req[i].RegisterStatusChanges(combatant, notify);
			}
		}

		public void UnregisterStatusChanges(Combatant combatant, IStatusChanged notify)
		{
			for(int i = 0; i < this.req.Length; i++)
			{
				this.req[i].UnregisterStatusChanges(combatant, notify);
			}
		}
	}
}
