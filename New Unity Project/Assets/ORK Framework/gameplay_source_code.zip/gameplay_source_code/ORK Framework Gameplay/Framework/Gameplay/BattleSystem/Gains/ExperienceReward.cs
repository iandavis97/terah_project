
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ExperienceReward : BaseData
	{
		[ORKEditorHelp("Status Value", "Select the 'Experience' type status value.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue, "type", StatusValueType.Experience, true)]
		public int statusID = 0;
		
		[ORKEditorInfo(separator=true, labelText="Reward Value", 
			label=new string[] {
				"The combatant is used as user and target in formulas.", 
				"When splitting the reward, only the player will be used in formulas."
		})]
		public FloatValue rewardValue = new FloatValue();
		
		
		// chance
		[ORKEditorHelp("Use Chance", "A chance is used to determine if the reward is received.\n" +
			"If disabled, the reward is always received.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useChance = false;
		
		[ORKEditorInfo("Reward Chance (%)", "Define the reward received chance.\n" +
			"The reward will be received if the a random float number between two values " +
			"(default 0 and 100, you can change this in the game settings) " +
			 "is less or equal to this value", "", 
			endFoldout=true)]
		[ORKEditorLayout("useChance", true, endCheckGroup=true, autoInit=true)]
		public FloatValue chance;
		
		
		// group settings
		[ORKEditorHelp("Whole Group", "The whole player group will receive the experience reward.\n" +
			"If disabled, only the player combatant receives the experience reward.", "")]
		[ORKEditorInfo(separator=true, label=new string[] {
			"The following settings are ignored when used as a combatant's battle reward.", 
			"Use the settings in 'Battle System > Battle End' instead."
		})]
		public bool wholeGroup = false;
		
		[ORKEditorHelp("Only Battle Group", "Only the battle group will receive the experience reward.\n" +
			"If disabled, the whole player group receives the experience reward.", "")]
		[ORKEditorLayout("wholeGroup", true)]
		public bool onlyBattleGroup = false;
		
		[ORKEditorHelp("Split Experience", "The experience reward will be split through the group members, " +
			"i.e. every group member will only get a part of the experience.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool split = false;
		
		public ExperienceReward()
		{
			
		}
		
		public void AddExperience(Combatant combatant)
		{
			if((!this.useChance || ORK.GameSettings.CheckRandom(
					this.chance.GetValue(combatant, combatant))) && 
				combatant.Status[this.statusID].IsExperience())
			{
				if(this.wholeGroup)
				{
					List<Combatant> list = this.onlyBattleGroup ? 
						combatant.Group.GetBattle() : combatant.Group.GetGroup();
					
					if(split)
					{
						int exp = (int)(this.rewardValue.GetValue(combatant, combatant) / list.Count);
						for(int i=0; i<list.Count; i++)
						{
							list[i].Status[this.statusID].AddValue(exp, 
								false, false, true, false, true, true);
						}
					}
					else
					{
						for(int i=0; i<list.Count; i++)
						{
							list[i].Status[this.statusID].AddValue(
								(int)this.rewardValue.GetValue(list[i], list[i]), 
								false, false, true, false, true, true);
						}
					}
					
				}
				else
				{
					combatant.Status[this.statusID].AddValue(
						(int)this.rewardValue.GetValue(combatant, combatant), 
						false, false, true, false, true, true);
				}
			}
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			
			if(data.Contains<int>("reward"))
			{
				int tmp = 0;
				data.Get("reward", ref tmp);
				this.rewardValue.value = tmp;
			}
		}
	}
}
