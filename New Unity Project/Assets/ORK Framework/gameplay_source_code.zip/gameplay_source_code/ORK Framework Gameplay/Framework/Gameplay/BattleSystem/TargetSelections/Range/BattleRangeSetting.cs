﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public delegate bool InRangeCombatant(Combatant user, Combatant target);

	public delegate bool InRangeGridCell(Combatant user, BattleGridCellComponent target);

	public class BattleRangeSetting : BaseData
	{
		// only for AI controlled
		[ORKEditorHelp("Only AI Controlled", "The minimum/maximum range settings are only used for AI controlled combatants.\n" +
			"I.e. the player isn't bound to this range.\n" +
			"If disabled, all combatants use this range.", "")]
		[ORKEditorInfo("Range Settings", "Define the minimum and maximum range of this battle range.", "")]
		public bool onlyAIControlled = false;


		// range settings
		[ORKEditorHelp("Minimum Range", "A minimum range is used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useMin = false;

		[ORKEditorLayout("useMin", true, endCheckGroup=true, autoInit=true)]
		public Range minRange;

		[ORKEditorHelp("Maximum Range", "A maximum range is used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useMax = false;

		[ORKEditorLayout("useMax", true, endCheckGroup=true, autoInit=true)]
		public Range maxRange;


		// raycast LOS
		[ORKEditorInfo(separator=true, labelText="Raycast Line of Sight")]
		public RaycastLOS raycastLOS = new RaycastLOS();


		// move AI
		[ORKEditorHelp("Move Into Range", "Use the move AI to move into range if the target is out of range.\n" +
			"Only used when the move AI is allowed in battle and the combatant can move.", "")]
		[ORKEditorInfo(separator=true, labelText="Move AI Settings")]
		public bool moveAIMoveIntoRange = true;

		// check only for angle, defining angle threshold?
		[ORKEditorHelp("Use Stop Angle", "If the hunt or caution settings of the move AI use a stop angle, " +
			"the action can only be used from the angled position when moving into range.", "")]
		[ORKEditorLayout("moveAIMoveIntoRange", true, endCheckGroup=true)]
		public bool moveAIUseStopAngle = false;


		// height checks
		[ORKEditorHelp("Check Height Differences", "Check the height difference between user and target.\n" +
			"E.g. only use targets that are above the user.", "")]
		[ORKEditorInfo(separator=true, labelText="Check Height Differences")]
		public bool checkHeight = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("checkHeight", true, endCheckGroup=true, autoInit=true)]
		public HeightDifferenceCheck heightCheck;



		// grid range settings
		[ORKEditorInfo("Grid Shape", "Define the grid shape of this battle range.\n" +
			"The grid shape is only used in battles that use a 'Battle Grid'.", "",
			endFoldout=true)]
		public GridRangeSetting gridSettings = new GridRangeSetting();

		public BattleRangeSetting()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("gridRange"))
			{
				this.gridSettings.SetData(data);
			}
		}

		public Range GetMoveAIUseRange()
		{
			if(this.useMin)
			{
				return this.minRange.GetOutOfRange();
			}
			else if(this.useMax)
			{
				return this.maxRange.GetInRange();
			}
			return null;
		}


		/*
		============================================================================
		Range functions
		============================================================================
		*/
		public bool InRange(Combatant user, BattleGridCellComponent target)
		{
			if(ORK.Battle.Grid != null &&
				GridShapeType.None != this.gridSettings.gridShapeType &&
				user != null && user.Grid.Cell != null)
			{
				return this.gridSettings.InRange(user, -1, target);
			}
			return false;
		}

		public bool InRange(Combatant user, Combatant target)
		{
			if(ORK.Battle.Grid != null &&
				GridShapeType.None != this.gridSettings.gridShapeType &&
				user != null && user.Grid.Cell != null)
			{
				return this.gridSettings.InRange(user, -1, target);
			}
			else if(!this.onlyAIControlled ||
				(user != null && user.IsAIControlled()))
			{
				return (!this.useMin || this.minRange.OutOfRange(user, target)) &&
					(!this.useMax || this.maxRange.InRange(user, target)) &&
					(!this.checkHeight || this.heightCheck.Check(user, target)) &&
					this.raycastLOS.Check(user.GameObject, target.GameObject);
			}
			return true;
		}

		public bool InRange(Combatant user, Vector3 position)
		{
			if(!this.onlyAIControlled ||
				(user != null && user.IsAIControlled()))
			{
				return (!this.useMin || this.minRange.OutOfRange(position, user)) &&
					(!this.useMax || this.maxRange.InRange(position, user)) &&
					(!this.checkHeight || this.heightCheck.Check(user, position));
			}
			return true;
		}

		public List<Combatant> GetTargets(Combatant user, Consider isEnemy, Consider isDead, Consider inBattle)
		{
			List<Combatant> list = null;
			if(ORK.Battle.Grid != null &&
				GridShapeType.None != this.gridSettings.gridShapeType &&
				user != null && user.Grid.Cell != null)
			{
				list = new List<Combatant>();
				this.gridSettings.GetCellCombatants(user, -1, ref list, null);
			}
			else if(!this.onlyAIControlled ||
				(user != null && user.IsAIControlled()))
			{
				list = ORK.Game.Combatants.Get(user, true,
					this.useMax ? this.maxRange : null,
					isEnemy, isDead, inBattle, null);

				if(this.useMin)
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(!this.minRange.OutOfRange(user, list[i]))
						{
							list.RemoveAt(i--);
						}
					}
				}
				if(this.checkHeight)
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(!this.heightCheck.Check(user, list[i]))
						{
							list.RemoveAt(i--);
						}
					}
				}
				if(this.raycastLOS.useRaycast)
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(!this.raycastLOS.Check(user.GameObject, list[i].GameObject))
						{
							list.RemoveAt(i--);
						}
					}
				}
			}
			else
			{
				list = ORK.Game.Combatants.Get(user, true, null, isEnemy, isDead, inBattle, null);
			}
			return list;
		}
	}
}
