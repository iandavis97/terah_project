﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface IInventoryExchange
	{
		Combatant GetOwner();

		IContentSimple GetContent();

		void CheckDataChanged(bool checkItems, bool checkWeapons, bool checkArmors,
			bool checkAICollection, bool checkCraftingRecipes);

		bool IsEmpty
		{
			get;
		}

		event Notify Changed;


		/*
		============================================================================
		Item type functions
		============================================================================
		*/
		void GetItemTypes(int parentType, ref List<int> list, bool onlySellable,
			bool addMoney, bool addEmptyMoney, bool addItems, bool addWeapons, bool addArmor,
			bool addAIBehaviours, bool addAIRulesets, bool addCraftingRecipes);

		bool HasNewItemTypes(bool checkParent, List<int> types, bool onlySellable,
			bool addItems, bool addWeapons, bool addArmor,
			bool addAIBehaviours, bool addAIRulesets, bool addCraftingRecipes);

		bool HasItemType(bool checkParent, int typeID, bool onlySellable,
			bool addMoney, bool addEmptyMoney, bool addItems, bool addWeapons, bool addArmor,
			bool addAIBehaviours, bool addAIRulesets, bool addCraftingRecipes, bool checkNewContent);


		/*
		============================================================================
		Inventory functions
		============================================================================
		*/
		void GetAll(bool addMoney, bool addEmptyMoney, bool addItems, bool addWeapons, bool addArmor,
			bool addAIBehaviours, bool addAIRulesets, bool addCraftingRecipes,
			int typeID, bool checkParent, ref List<IInventoryShortcut> list);

		bool Add(IShortcut item, bool showNotification, bool showConsole, bool markNewContent);

		void Remove(IShortcut item, int quantity, bool showNotification, bool showConsole);

		void Drop(IShortcut item, int quantity, bool showNotification, bool showConsole);

		int GetAllowedQuantity(IShortcut shortcut, int quantity);

		int GetCount(IShortcut item);

		bool HasEnoughMoney(int id, int quantity);

		int GetMoney(int id);

		void AddMoney(int id, int quantity, bool showNotification, bool showConsole);

		void SubMoney(int id, int quantity, bool showNotification, bool showConsole);
	}
}
