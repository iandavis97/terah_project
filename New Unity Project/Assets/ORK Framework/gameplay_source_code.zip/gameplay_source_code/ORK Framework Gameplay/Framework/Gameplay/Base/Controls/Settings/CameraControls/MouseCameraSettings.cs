﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class MouseCameraSettings : BaseData
	{
		[ORKEditorHelp("Use Child Object", "The camera will be positioned using a child object of the player (e.g. body/head).\n" +
			"Leave empty if you don't want to use a child object and place the camera using the root of the player object.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string onChild = "";

		[ORKEditorHelp("Distance", "The distance of the camera to the player.", "")]
		[ORKEditorInfo(separator=true)]
		public float distance = 10.0f;

		// height
		[ORKEditorHelp("Height", "The height above the player.", "")]
		public float height = 15.0f;

		[ORKEditorHelp("Minimum Height", "The minimum height above the player.", "")]
		public float minHeight = 5.0f;

		[ORKEditorHelp("Maximum Height", "The maximum height above the player.", "")]
		public float maxHeight = 30.0f;

		[ORKEditorHelp("Height Damping", "Used for smoother height changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float heightDamping = 2.0f;

		[ORKEditorInfo("Mouse/Touch Control", "Input settings for mouse and touch control.", "",
			endFoldout=true, separatorForce=true)]
		public MouseTouchControl mouseTouch = new MouseTouchControl(false, 1, true, 2, 1, MouseTouch.Move);


		// rotation
		[ORKEditorHelp("Allow Rotation", "The rotation of the camera can be changed by mouse/touch controls.\n" +
			"The rotation can be changed by a horizontal mouse/touch drag.", "")]
		[ORKEditorInfo("Rotation Settings", "The camera can optionally be rotated.", "")]
		public bool allowRotation = true;

		[ORKEditorHelp("Remember Rotation", "The rotation will be remembered when changing between scenes.\n" +
			"The camera's rotation will be transfered over to the new scene.", "")]
		[ORKEditorLayout("allowRotation", true, endCheckGroup=true)]
		public bool rememberRotation = false;

		[ORKEditorHelp("Start Rotation", "The start rotation of the camera.\n" +
			"E.g. 90 will show the player from the south (world axis).", "")]
		public float rotation = 0;

		[ORKEditorHelp("Rotation Damping", "Used for smoother rotation changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float rotationDamping = 3.0f;

		[ORKEditorHelp("Reset On Target Change", "The rotation is reset when changing the camera control target.", "")]
		[ORKEditorLayout("allowRotation", true)]
		public bool cameraTargetChangeResetRotation = false;

		[ORKEditorHelp("Block On Target Change", "Rotation is blocked while changing the camera control target.", "")]
		public bool cameraTargetChangeBlockRotation = false;

		[ORKEditorHelp("Rotation Factor", "The actual touch/mouse move is multiplied with this number " +
			"to determine the rotation change.\n" +
			"Set to negative numbers to invert rotation.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public float rotationFactor = 1;


		// zoom
		[ORKEditorHelp("Allow Zoom", "The camera zoom (height) can be changed by mouse/touch controls.\n" +
			"The height can be changed by a vertical mouse/touch drag.", "")]
		[ORKEditorInfo("Zoom Settings", "The camera can optionally be zoomed in/out.", "")]
		public bool allowZoom = true;

		[ORKEditorHelp("Remember Zoom", "The camera zoom will be remembered when changing between scenes.\n" +
			"The camera's zoom will be transfered over to the new scene.", "")]
		[ORKEditorLayout("allowZoom", true)]
		public bool rememberZoom = false;

		[ORKEditorHelp("Reset On Target Change", "The zoom is reset when changing the camera control target.", "")]
		public bool cameraTargetChangeResetZoom = false;

		[ORKEditorHelp("Block On Target Change", "Zooming is blocked while changing the camera control target.", "")]
		public bool cameraTargetChangeBlockZoom = false;

		[ORKEditorHelp("Zoom Factor", "The actual touch/mouse move is multiplied with this number " +
			"to determine the zoom change.\n" +
			"Set to negative numbers to invert zoom.", "")]
		public float zoomFactor = 1;

		public AxisControl zoomAxis = new AxisControl();

		[ORKEditorHelp("Zoom Key Change", "The amount the zoom changes on key press.", "")]
		public float zoomKeyChange = 3;

		[ORKEditorHelp("Limit Change", "Changing the camera rotation/zoom is limited to one axis at a time.\n" +
			"The axis (horizontal for rotation, vertical for zoom) that received the larger change will be used.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("allowRotation", true, endCheckGroup=true, endGroups=2)]
		public bool limitChange = true;


		// in-game
		private bool hasStoredValues = false;

		private float storedRotation = 0;

		private float storedLastTargetRotation = 0;

		private float storedHeight = 0;

		private float storedLastTargetHeight = 0;

		public MouseCameraSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("zoomAxis"))
			{
				data.Get("zoomAxis", ref this.zoomAxis.useAxis);
				data.Get("zoomAxisKey", ref this.zoomAxis.axisKey);
				data.Get("zoomPlusKey", ref this.zoomAxis.plusKey);
				data.Get("zoomMinusKey", ref this.zoomAxis.minusKey);
			}
		}

		public void Setup(GameObject camera)
		{
			if(camera != null)
			{
				TouchCamera comp = camera.GetComponent<TouchCamera>();
				if(comp == null)
				{
					comp = camera.AddComponent<TouchCamera>();

					comp.onChild = this.onChild;
					comp.distance = this.distance;
					comp.height = this.height;
					comp.minHeight = this.minHeight;
					comp.maxHeight = this.maxHeight;
					comp.heightDamping = this.heightDamping;
					comp.allowRotation = this.allowRotation;
					comp.rememberRotation = this.rememberRotation;

					comp.allowZoom = this.allowZoom;
					comp.rememberZoom = this.rememberZoom;
					comp.rotation = this.rotation;
					comp.rotationDamping = this.rotationDamping;
					comp.rotationFactor = this.rotationFactor;
					comp.cameraTargetChangeResetRotation = this.cameraTargetChangeResetRotation;
					comp.cameraTargetChangeBlockRotation = this.cameraTargetChangeBlockRotation;

					comp.zoomFactor = this.zoomFactor;
					comp.zoomAxis = this.zoomAxis;
					comp.mouseTouch = this.mouseTouch;
					comp.zoomKeyChange = this.zoomKeyChange;
					comp.cameraTargetChangeResetZoom = this.cameraTargetChangeResetZoom;
					comp.cameraTargetChangeBlockZoom = this.cameraTargetChangeBlockZoom;
					comp.limitChange = this.limitChange;
				}
				if(comp != null)
				{
					ORK.Control.AddCameraControl(comp);
				}
			}
		}


		/*
		============================================================================
		Store functions
		============================================================================
		*/
		public void StoreRotation(float rotation, float lastTargetRotation)
		{
			this.hasStoredValues = true;
			this.storedRotation = rotation;
			this.storedLastTargetRotation = lastTargetRotation;
		}

		public void GetStoredRotation(ref float rotation, ref float lastTargetRotation)
		{
			if(this.hasStoredValues)
			{
				rotation = this.storedRotation;
				lastTargetRotation = this.storedLastTargetRotation;
			}
		}

		public void StoreZoom(float height, float lastTargetHeight)
		{
			this.hasStoredValues = true;
			this.storedHeight = height;
			this.storedLastTargetHeight = lastTargetHeight;
		}

		public void GetStoredZoom(ref float height, ref float lastTargetHeight)
		{
			if(this.hasStoredValues)
			{
				height = this.storedHeight;
				lastTargetHeight = this.storedLastTargetHeight;
			}
		}
	}
}
