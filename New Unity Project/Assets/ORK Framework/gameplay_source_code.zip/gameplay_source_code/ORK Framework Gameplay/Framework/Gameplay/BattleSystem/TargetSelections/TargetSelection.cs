
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TargetSelection : BaseData
	{
		// base settings
		[ORKEditorHelp("No Action Only", "The target can only be selected while the player " +
			"doesn't perform an action (i.e. when you can call the battle menu).", "")]
		public bool noActionOnly = false;

		[ORKEditorHelp("In Menus", "The target can be selected while displaying menus (e.g. the battle menu).", "")]
		public bool inMenus = false;

		[ORKEditorHelp("Auto Select", "The target is automatically selected.\n" +
			"If no target is set (e.g. the current target dies) the nearest one is selected.", "")]
		public bool autoSelect = false;


		// range
		[ORKEditorHelp("Only In Battle Range", "Only targets in battle range can be selected.", "")]
		[ORKEditorInfo(separator=true, labelText="Range Settings")]
		public bool onlyInBattleRange = true;

		[ORKEditorLayout("onlyInBattleRange", false, endCheckGroup=true, autoInit=true)]
		public Range range;


		// target settings
		[ORKEditorHelp("Select Enemies", "Select if enemies are selected:\n" +
			"- Yes: Only enemies of the player can be selected.\n" +
			"- No: Only allies of the player can be selected.\n" +
			"- Ignore: All combatants can be selected.", "")]
		[ORKEditorInfo(separator=true, labelText="Target Settings")]
		public Consider selectEnemies = Consider.Yes;

		[ORKEditorHelp("Select Dead", "Select if dead combatants are selected:\n" +
			"- Yes: Only dead combatants can be selected.\n" +
			"- No: Only alive combatants can be selected.\n" +
			"- Ignore: All combatants can be selected.", "")]
		public Consider selectDead = Consider.No;


		// system types
		[ORKEditorHelp("Field", "Available in the field (i.e. outside of battles).", "")]
		[ORKEditorInfo(separator=true, labelText="Useable In")]
		public bool field = false;

		public BattleSystemCheck battleSystemCheck = new BattleSystemCheck();


		// input keys
		[ORKEditorHelp("Next Target Key", "The key to select the next target.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, separator=true, labelText="Key Settings")]
		public int nextKey = 0;

		[ORKEditorHelp("Previous Target Key", "The key to select the previous target.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int previousKey = 0;

		[ORKEditorHelp("Nearest Target Key", "The key to select the nearest target.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int nearestKey = 0;

		[ORKEditorHelp("Remove Target Key", "The key to remove the target.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("autoSelect", false, endCheckGroup=true)]
		public int removeKey = 0;


		// mouse/touch
		[ORKEditorInfo("Mouse/Touch Control", "Input settings for mouse and touch control.", "",
			separatorForce=true)]
		public MouseTouchControl clickControl = new MouseTouchControl();

		[ORKEditorHelp("Allow Remove", "A click/touch that doesn't target a combatant will remove the target.", "")]
		[ORKEditorInfo(separator=true, endFoldout=true)]
		public bool allowClickRemove = false;


		// cursor
		[ORKEditorHelp("Use Cursor", "The target is marked with a cursor.", "")]
		[ORKEditorInfo(separator=true, labelText="Target Cursor")]
		public bool useTargetCursor = false;

		[ORKEditorHelp("Prefab", "Select the prefab used as cursor object.", "")]
		[ORKEditorLayout("useTargetCursor", true)]
		public GameObject cursorPrefab;

		[ORKEditorLayout(endCheckGroup=true)]
		public MountSettings cursorMount = new MountSettings();


		// auto attack
		[ORKEditorHelp("Auto Attack Target", "Auto attacks (if enabled) are performed on this target.", "")]
		[ORKEditorInfo(separator=true, labelText="Auto Attack Settings")]
		public bool autoAttackTarget = false;

		[ORKEditorHelp("Player Only", "Only the player performs auto attacks.", "")]
		[ORKEditorLayout("autoAttackTarget", true, endCheckGroup=true)]
		public bool aaPlayerOnly = false;


		// limit ability use
		[ORKEditorHelp("Limit Ability Use", "Limit using abilities on targets to defined abilities and ability types.\n" +
			"If disabled, all abilities will be used on the selected target (if possible).", "")]
		[ORKEditorInfo("Ability Use Settings", "Optionally limit using abilities on targets to defind abilities and ability types.", "")]
		public bool limitAbilityUse = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("limitAbilityUse", true, endCheckGroup=true, autoInit=true)]
		public LimitAbility limitAbility;


		// limit item use
		[ORKEditorHelp("Limit Item Use", "Limit using items on targets to defined items and item types.\n" +
			"If disabled, all items will be used on the selected target (if possible).", "")]
		[ORKEditorInfo("Item Use Settings", "Optionally limit using items on targets to defind items and item types.", "")]
		public bool limitItemUse = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("limitItemUse", true, endCheckGroup=true, autoInit=true)]
		public LimitItem limitItem;


		// target requirements
		[ORKEditorHelp("Use Requirements", "Use status requirements and game variable conditions.", "")]
		[ORKEditorInfo("Target Requirements", "A target can depend on status requirements and game variable conditions.\n" +
			"If the requirements aren't met, the combatant can't be targeted.", "")]
		public bool useTargetRequirements = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useTargetRequirements", true, endCheckGroup=true, autoInit=true)]
		public SimpleCombatantRequirement targetRequirement;


		// ingame
		private GameObject cursorInstance;

		public TargetSelection()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			if(data.Contains<bool>("turnBased"))
			{
				this.battleSystemCheck.SetData(data);
			}
			if(this.limitAbilityUse &&
				(data.ContainsArray<int>("useAbilityType") ||
					data.ContainsArray<int>("useAbility")))
			{
				this.limitAbility = new LimitAbility();
				this.limitAbility.UpdateData(data, "useAbilityType", "useAbility");
			}
			if(this.limitItemUse &&
				(data.ContainsArray<int>("useItemType") ||
					data.ContainsArray<int>("useItem")))
			{
				this.limitItem = new LimitItem();
				this.limitItem.UpdateData(data, "useItemType", "useItem");
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool CheckTarget(Combatant target)
		{
			return !this.useTargetRequirements ||
				this.targetRequirement.Check(target);
		}

		private bool CheckSystem(Combatant user)
		{
			return (!user.Battle.InBattle && this.field && !ORK.Control.Blocked) ||
				(user.Battle.InBattle && ORK.Control.InBattle &&
				ORK.Battle.IsBattleRunning() && this.battleSystemCheck.Check());
		}

		private Consider GetConsiderBattle()
		{
			if(this.field &&
				!this.battleSystemCheck.turnBased &&
				!this.battleSystemCheck.activeTime &&
				!this.battleSystemCheck.realTime &&
				!this.battleSystemCheck.phase)
			{
				return Consider.No;
			}
			else if(!this.field)
			{
				return Consider.Yes;
			}
			else
			{
				return Consider.Ignore;
			}
		}


		/*
		============================================================================
		Control functions
		============================================================================
		*/
		public void Tick(Combatant user, bool inMenu, int index, bool isGroupTarget)
		{
			if(user != null && this.CheckSystem(user) &&
				(!this.noActionOnly || user.Actions.CanChoose))
			{
				// check selected target
				if(isGroupTarget)
				{
					if(user.Group.SelectedTargets[index] != null &&
						(user.Group.SelectedTargets[index].GameObject == null ||
						!TargetHelper.CheckDeath(user.Group.SelectedTargets[index], this.selectDead)))
					{
						user.Group.SelectedTargets[index] = null;
					}
				}
				else
				{
					if(user.SelectedTargets[index] != null &&
						(user.SelectedTargets[index].GameObject == null ||
						!TargetHelper.CheckDeath(user.SelectedTargets[index], this.selectDead)))
					{
						user.SelectedTargets[index] = null;
					}
				}

				// click
				if(!inMenu || this.inMenus)
				{
					Vector3 point = Vector3.zero;
					if(this.clickControl.Interacted(ref point))
					{
						bool found = false;
						Ray ray = Camera.main.ScreenPointToRay(point);
						RaycastOutput hit;

						if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit))
						{
							Combatant target = ComponentHelper.GetCombatant(hit.transform.root.gameObject);
							if(target != null &&
								(Consider.Ignore == this.selectEnemies ||
								(Consider.Yes == this.selectEnemies) == user.IsEnemy(target)) &&
								this.CheckTarget(target))
							{
								if(isGroupTarget)
								{
									user.Group.SelectedTargets[index] = target;
								}
								else
								{
									user.SelectedTargets[index] = target;
								}
								found = true;
							}
						}

						if(!found && this.allowClickRemove)
						{
							if(isGroupTarget)
							{
								user.Group.SelectedTargets[index] = null;
							}
							else
							{
								user.SelectedTargets[index] = null;
							}
						}
					}
					// keys
					else
					{
						if(ORK.InputKeys.Get(this.nextKey).GetButton())
						{
							Combatant target = ORK.Game.Combatants.GetOffset(
								isGroupTarget ? user.Group.SelectedTargets[index] : user.SelectedTargets[index], 1,
								user, true, this.onlyInBattleRange ? Range.Battle : this.range,
								this.selectEnemies, this.selectDead, this.GetConsiderBattle(), this.CheckTarget);
							if(isGroupTarget)
							{
								user.Group.SelectedTargets[index] = target;
							}
							else
							{
								user.SelectedTargets[index] = target;
							}
						}
						else if(ORK.InputKeys.Get(this.previousKey).GetButton())
						{
							Combatant target = ORK.Game.Combatants.GetOffset(
								isGroupTarget ? user.Group.SelectedTargets[index] : user.SelectedTargets[index], -1,
								user, true, this.onlyInBattleRange ? Range.Battle : this.range,
								this.selectEnemies, this.selectDead, this.GetConsiderBattle(), this.CheckTarget);
							if(isGroupTarget)
							{
								user.Group.SelectedTargets[index] = target;
							}
							else
							{
								user.SelectedTargets[index] = target;
							}
						}
						else if(ORK.InputKeys.Get(this.nearestKey).GetButton())
						{
							Combatant target = ORK.Game.Combatants.GetNearest(user, true,
								this.onlyInBattleRange ? Range.Battle : this.range,
								this.selectEnemies, this.selectDead, this.GetConsiderBattle(), this.CheckTarget);
							if(isGroupTarget)
							{
								user.Group.SelectedTargets[index] = target;
							}
							else
							{
								user.SelectedTargets[index] = target;
							}
						}
						else if(!this.autoSelect &&
							ORK.InputKeys.Get(this.removeKey).GetButton())
						{
							if(isGroupTarget)
							{
								user.Group.SelectedTargets[index] = null;
							}
							else
							{
								user.SelectedTargets[index] = null;
							}
						}
					}
				}

				if(this.autoSelect &&
					!(isGroupTarget ?
						user.Group.SelectedTargets.HasTarget(index) :
						user.SelectedTargets.HasTarget(index)))
				{
					Combatant target = ORK.Game.Combatants.GetNearest(user, false,
						this.onlyInBattleRange ? Range.Battle : this.range,
						this.selectEnemies, this.selectDead, this.GetConsiderBattle(), this.CheckTarget);
					if(isGroupTarget)
					{
						user.Group.SelectedTargets[index] = target;
					}
					else
					{
						user.SelectedTargets[index] = target;
					}
				}
			}
		}

		public void AddCursor(Combatant target)
		{
			// destroy old cursor
			if(this.cursorInstance != null)
			{
				UnityWrapper.Destroy(this.cursorInstance);
			}
			// add cursor
			if(this.useTargetCursor && this.cursorPrefab != null &&
				target != null && target.GameObject != null)
			{
				this.cursorInstance = UnityWrapper.Instantiate(this.cursorPrefab);
				if(this.cursorInstance != null)
				{
					this.cursorMount.MountTo(target.GameObject.transform, this.cursorInstance.transform);
				}
			}
		}


		/*
		============================================================================
		Use functions
		============================================================================
		*/
		public bool UseAutoAttackTarget(Combatant user)
		{
			return this.CheckSystem(user) && this.autoAttackTarget &&
				(!this.aaPlayerOnly || user == ORK.Game.ActiveGroup.Leader);
		}

		public bool CanUseAbility(int abilityID, int typeID)
		{
			if(this.limitAbilityUse)
			{
				return this.limitAbility.Contains(abilityID, typeID);
			}
			return true;
		}

		public bool CanUseItem(int itemID, int typeID)
		{
			if(this.limitItemUse)
			{
				return this.limitItem.Contains(itemID, typeID);
			}
			return true;
		}
	}
}
