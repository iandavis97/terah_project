﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class AIDecisionTime : BaseData
	{
		[ORKEditorInfo("Min AI Decision Time", "The minimum time an AI controlled combatant needs to decide an action.", "",
			endFoldout=true)]
		public FloatValue minTime = new FloatValue(0);

		[ORKEditorInfo("Max AI Decision Time", "The maximum time an AI controlled combatant needs to decide an action.", "",
			endFoldout=true)]
		public FloatValue maxTime = new FloatValue(0);

		public AIDecisionTime()
		{

		}

		public float GetTime(Combatant combatant)
		{
			return UnityWrapper.Range(
				this.minTime.GetValue(combatant, combatant),
				this.maxTime.GetValue(combatant, combatant));
		}
	}
}
