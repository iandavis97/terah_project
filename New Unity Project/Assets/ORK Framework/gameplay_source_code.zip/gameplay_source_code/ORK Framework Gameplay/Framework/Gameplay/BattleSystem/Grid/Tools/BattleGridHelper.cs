﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public delegate bool GridCellCheck(BattleGridCellComponent cell);

	public delegate bool GridCellCheck2(BattleGridCellComponent origin, BattleGridCellComponent cell);

	public delegate bool GridCellOriginCheck(Combatant user, BattleGridCellComponent origin, BattleGridCellComponent cell);

	public static class BattleGridHelper
	{
		public static CubeCoord[] SquareDirectionsNonDiagonal = new CubeCoord[]
		{
			new CubeCoord(-1, 0, 0), new CubeCoord(0, 1, 0),
			new CubeCoord(1, 0, 0), new CubeCoord(0, -1, 0)
		};

		public static CubeCoord[] SquareDirectionsDiagonal = new CubeCoord[]
		{
			new CubeCoord(-1, 0, 0), new CubeCoord(-1, 1, 0),
			new CubeCoord(0, 1, 0), new CubeCoord(1, 1, 0),
			new CubeCoord(1, 0, 0), new CubeCoord(1, -1, 0),
			new CubeCoord(0, -1, 0), new CubeCoord(-1, -1, 0)
		};

		public static CubeCoord[] SquareDirections;

		public static CubeCoord[] HexagonalDirections = new CubeCoord[]
		{
			new CubeCoord(0, 1, -1), new CubeCoord(1, 0, -1), new CubeCoord(1, -1, 0),
			new CubeCoord(0, -1, 1), new CubeCoord(-1, 0, 1), new CubeCoord(-1, 1, 0)
		};

		private static IGridHelper helperInstance;

		public static void SetInstance(BattleSystemSettings settings)
		{
			if(BattleGridType.Square == settings.gridSettings.type)
			{
				helperInstance = new SquareGridHelper(settings);
			}
			else if(BattleGridType.Hexagonal == settings.gridSettings.type)
			{
				helperInstance = new HexagonalGridHelper(settings);
			}
			SquareDirections = settings.gridSettings.squareDiagonalDistanceOne ?
				BattleGridHelper.SquareDirectionsDiagonal :
				BattleGridHelper.SquareDirectionsNonDiagonal;
		}

		public static IGridHelper Helper
		{
			get { return helperInstance; }
		}


		/*
		============================================================================
		Direction functions
		============================================================================
		*/
		public static CubeCoord GetDirection(int direction)
		{
			return BattleGridHelper.Helper.GetDirection(direction);
		}

		public static CubeCoord GetDirectionNonDiagonal(int direction)
		{
			return BattleGridHelper.Helper.GetDirectionNonDiagonal(direction);
		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public static void Highlight(BattleGridCellComponent cell, GridHighlightType type)
		{
			if(cell != null)
			{
				GridHighlight setting = ORK.Battle.Settings.gridHighlights.GetHighlight(type);
				if(setting != null &&
					setting.enable)
				{
					setting.AddLineCell(cell, type);
					cell.Highlight(type);
				}
			}
		}

		public static void Highlight(List<BattleGridCellComponent> list, GridHighlightType type)
		{
			if(list != null)
			{
				GridHighlight setting = ORK.Battle.Settings.gridHighlights.GetHighlight(type);
				if(setting != null &&
					setting.enable)
				{
					setting.AddLineCells(list, type);
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							list[i].Highlight(type);
						}
					}
				}
			}
		}

		public static void StopHighlight(BattleGridCellComponent cell, GridHighlightType type)
		{
			if(cell != null)
			{
				GridHighlight setting = ORK.Battle.Settings.gridHighlights.GetHighlight(type);
				if(setting != null &&
					setting.enable)
				{
					setting.RemoveLineCell(cell, type);
					cell.StopHighlight(type);
				}
			}
		}

		public static void StopHighlight(List<BattleGridCellComponent> list, GridHighlightType type)
		{
			if(list != null)
			{
				GridHighlight setting = ORK.Battle.Settings.gridHighlights.GetHighlight(type);
				if(setting != null &&
					setting.enable)
				{
					setting.RemoveLineCells(list, type);
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							list[i].StopHighlight(type);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Cell check functions
		============================================================================
		*/
		public static bool IsUnblockedCell(BattleGridCellComponent cell)
		{
			return !cell.IsBlocked;
		}

		public static bool IsPassableCell(BattleGridCellComponent cell)
		{
			return cell.IsPassable;
		}

		public static bool IsEmptyCell(BattleGridCellComponent cell)
		{
			return cell.IsEmpty;
		}

		public static bool IsUnblockedEmptyCell(BattleGridCellComponent cell)
		{
			return !cell.IsBlocked && cell.IsEmpty;
		}


		/*
		============================================================================
		Filter cell functions
		============================================================================
		*/
		public static void FilterTargetCells(BattleGridCellComponent userCell, BattleGridCellComponent targetCell,
			ref List<BattleGridCellComponent> list, AIGridMoveTargetType type)
		{
			if(list != null && list.Count > 0 &&
				userCell != null && targetCell != null)
			{
				if(AIGridMoveTargetType.Nearest == type)
				{
					// do nothing
				}
				// global orientation
				else if(AIGridMoveTargetType.North == type ||
					AIGridMoveTargetType.East == type ||
					AIGridMoveTargetType.South == type ||
					AIGridMoveTargetType.West == type)
				{
					Orientation checkOrientation = Orientation.None;
					if(AIGridMoveTargetType.North == type)
					{
						checkOrientation = Orientation.Front;
					}
					else if(AIGridMoveTargetType.East == type)
					{
						checkOrientation = Orientation.Right;
					}
					else if(AIGridMoveTargetType.South == type)
					{
						checkOrientation = Orientation.Back;
					}
					else if(AIGridMoveTargetType.West == type)
					{
						checkOrientation = Orientation.Left;
					}

					for(int i = 0; i < list.Count; i++)
					{
						Orientation orientation = VectorHelper.GetOrientationGlobal(
							targetCell.transform, list[i].transform, HorizontalPlaneType.XZ);
						if(checkOrientation != orientation)
						{
							list.RemoveAt(i--);
						}
					}
				}
				// local orientation
				else if(AIGridMoveTargetType.Front == type ||
				   AIGridMoveTargetType.Back == type ||
				   AIGridMoveTargetType.Left == type ||
				   AIGridMoveTargetType.Right == type)
				{
					Transform origin = targetCell.Combatant != null && targetCell.Combatant.GameObject != null ?
						targetCell.Combatant.GameObject.transform :
						targetCell.transform;
					Orientation checkOrientation = Orientation.None;
					if(AIGridMoveTargetType.Front == type)
					{
						checkOrientation = Orientation.Front;
					}
					else if(AIGridMoveTargetType.Right == type)
					{
						checkOrientation = Orientation.Right;
					}
					else if(AIGridMoveTargetType.Back == type)
					{
						checkOrientation = Orientation.Back;
					}
					else if(AIGridMoveTargetType.Left == type)
					{
						checkOrientation = Orientation.Left;
					}

					for(int i = 0; i < list.Count; i++)
					{
						Orientation orientation = VectorHelper.GetOrientation(
							origin, list[i].transform, HorizontalPlaneType.XZ);
						if(checkOrientation != orientation)
						{
							list.RemoveAt(i--);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Get cell functions
		============================================================================
		*/
		public static BattleGridCellComponent GetCell(GameObject gameObject)
		{
			BattleGridCellComponent cell = null;
			if(gameObject != null)
			{
				cell = gameObject.GetComponentInChildren<BattleGridCellComponent>();
				if(cell == null)
				{
					CombatantComponent cc = gameObject.GetComponentInChildren<CombatantComponent>();
					if(cc != null)
					{
						cell = cc.combatant.Grid.Cell;
					}
				}
			}
			return cell;
		}

		public static BattleGridCellComponent GetCell(List<GameObject> list)
		{
			if(list != null)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						BattleGridCellComponent cell = BattleGridHelper.GetCell(list[i]);
						if(cell != null)
						{
							return cell;
						}
					}
				}
			}
			return null;
		}

		public static List<BattleGridCellComponent> GetCells(List<GameObject> list)
		{
			List<BattleGridCellComponent> cells = new List<BattleGridCellComponent>();
			if(list != null)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						BattleGridCellComponent cell = BattleGridHelper.GetCell(list[i]);
						if(cell != null)
						{
							cells.Add(cell);
						}
					}
				}
			}
			return cells;
		}

		public static void GetRoughArea(BattleGridComponent grid, Vector3 position,
			ref int row, ref int column, ref int rowMax, ref int columnMax)
		{
			rowMax = 3;
			if(grid.cellRow.Length >= 100)
			{
				rowMax = 10;
			}
			else if(grid.cellRow.Length >= 40)
			{
				rowMax = grid.cellRow.Length / 10;
			}

			columnMax = 3;
			if(grid.cellRow[0].cell.Length >= 100)
			{
				columnMax = 10;
			}
			else if(grid.cellRow[0].cell.Length >= 40)
			{
				columnMax = grid.cellRow[0].cell.Length / 10;
			}

			float distance = Mathf.Infinity;

			for(int i = 0; i < grid.cellRow.Length; i += rowMax)
			{
				for(int j = 0; j < grid.cellRow[i].cell.Length; j += columnMax)
				{
					if(grid.cellRow[i].cell[j] != null &&
						grid.cellRow[i].cell[j].enabled &&
						grid.cellRow[i].cell[j].gameObject.activeInHierarchy)
					{
						float tmp = Vector3.Distance(position,
								grid.cellRow[i].cell[j].transform.position);
						if(tmp < distance)
						{
							row = i;
							column = j;
							distance = tmp;
						}
					}
				}
			}
		}

		public static bool IsCellType(BattleGridCellComponent cell, int[] cellTypes)
		{
			if(cell != null &&
				cellTypes.Length > 0)
			{
				for(int i = 0; i < cellTypes.Length; i++)
				{
					if(cell.CellType.RealID == cellTypes[i])
					{
						return true;
					}
				}
			}
			return false;
		}

		public static List<BattleGridCellComponent> GetCellsOfType(
			BattleGridComponent grid, int[] cellTypes, GridCellCheck check)
		{
			List<BattleGridCellComponent> list = new List<BattleGridCellComponent>();

			if(grid != null &&
				cellTypes.Length > 0)
			{
				for(int i = 0; i < grid.cellRow.Length; i++)
				{
					for(int j = 0; j < grid.cellRow[i].cell.Length; j++)
					{
						if(grid.cellRow[i].cell[j] != null &&
							grid.cellRow[i].cell[j].enabled &&
							grid.cellRow[i].cell[j].gameObject.activeInHierarchy &&
							(check == null || check(grid.cellRow[i].cell[j])))
						{
							for(int k = 0; k < cellTypes.Length; k++)
							{
								if(grid.cellRow[i].cell[j].CellType.RealID == cellTypes[k])
								{
									list.Add(grid.cellRow[i].cell[j]);
									break;
								}
							}
						}
					}
				}
			}

			return list;
		}

		public static List<BattleGridCellComponent> GetCellsOfType(
			BattleGridCellComponent origin, int[] cellTypes, int minDistance, int maxDistance,
			bool addOrigin, bool addBlocked, bool addNotPassable, bool allowSquareDiagonal, GridCellCheck check)
		{
			List<BattleGridCellComponent> list = new List<BattleGridCellComponent>();
			List<BattleGridCellComponent> cells = new List<BattleGridCellComponent>();
			HashSet<BattleGridCellComponent> contains = new HashSet<BattleGridCellComponent>();

			BattleGridHelper.GetRange(origin, minDistance, maxDistance, ref cells, ref contains,
				addOrigin, addBlocked, addNotPassable, allowSquareDiagonal, check);

			for(int i = 0; i < cells.Count; i++)
			{
				for(int k = 0; k < cellTypes.Length; k++)
				{
					if(cells[i].CellType.RealID == cellTypes[k])
					{
						list.Add(cells[i]);
						break;
					}
				}
			}

			return list;
		}


		/*
		============================================================================
		Rotation functions
		============================================================================
		*/
		public static int GetCombatantDirection(Combatant combatant, bool allowSquareDiagonal)
		{
			if(combatant != null &&
				combatant.Grid.Cell != null &&
				combatant.GameObject != null)
			{
				return BattleGridHelper.AngleToDirection(
					combatant.GameObject.transform.eulerAngles.y, allowSquareDiagonal);
			}
			return 0;
		}

		public static int GetCellDirection(BattleGridCellComponent origin, BattleGridCellComponent target, bool allowSquareDiagonal)
		{
			if(origin != null &&
				target != null)
			{
				return BattleGridHelper.AngleToDirection(
					VectorHelper.HorizontalAngle(origin.transform,
						target.transform.position, HorizontalPlaneType.XZ), allowSquareDiagonal);
			}
			return 0;
		}

		public static int AngleToDirection(float angle, bool allowSquareDiagonal)
		{
			return BattleGridHelper.Helper.AngleToDirection(angle, allowSquareDiagonal);
		}

		public static float DirectionToAngle(int direction, bool allowSquareDiagonal)
		{
			return BattleGridHelper.Helper.DirectionToAngle(direction, allowSquareDiagonal);
		}

		public static float GetDirectionRotation(GameObject gameObject, GridDirectionRotationType type, bool allowSquareDiagonal)
		{
			if(gameObject != null)
			{
				int direction = BattleGridHelper.AngleToDirection(gameObject.transform.eulerAngles.y, allowSquareDiagonal);
				if(GridDirectionRotationType.Nearest == type)
				{
					return BattleGridHelper.DirectionToAngle(direction, allowSquareDiagonal);
				}
				else if(GridDirectionRotationType.Left == type)
				{
					return BattleGridHelper.DirectionToAngle(direction - 1, allowSquareDiagonal);
				}
				else if(GridDirectionRotationType.Right == type)
				{
					return BattleGridHelper.DirectionToAngle(direction + 1, allowSquareDiagonal);
				}
			}
			return 0;
		}

		public static float GetPositionRotation(Combatant combatant, Vector3 position, bool allowSquareDiagonal)
		{
			if(combatant != null &&
				combatant.GameObject != null &&
				combatant.Grid.Cell != null)
			{
				Vector3 rotation = combatant.GameObject.transform.eulerAngles;
				rotation.y = VectorHelper.HorizontalAngle(combatant.Grid.Cell.transform,
					position, HorizontalPlaneType.XZ);
				int direction = BattleGridHelper.AngleToDirection(rotation.y, allowSquareDiagonal);
				return BattleGridHelper.DirectionToAngle(direction, allowSquareDiagonal);
			}
			return 0;
		}

		public static void RotateToPosition(Combatant combatant, Vector3 position, bool allowSquareDiagonal)
		{
			if(combatant != null &&
				combatant.GameObject != null &&
				combatant.Grid.Cell != null)
			{
				Vector3 rotation = combatant.GameObject.transform.eulerAngles;
				rotation.y = VectorHelper.HorizontalAngle(combatant.Grid.Cell.transform,
					position, HorizontalPlaneType.XZ);
				int direction = BattleGridHelper.AngleToDirection(rotation.y, allowSquareDiagonal);

				if(combatant.Grid.CanRotateTo(direction))
				{
					rotation.y = BattleGridHelper.DirectionToAngle(direction, allowSquareDiagonal);
					combatant.GameObject.transform.eulerAngles = rotation;
					combatant.Grid.UpdateSizeCells();
				}
			}
		}

		public static void RotateToDirection(Combatant combatant, int direction, bool allowSquareDiagonal)
		{
			if(combatant != null &&
				combatant.GameObject != null &&
				combatant.Grid.Cell != null &&
				combatant.Grid.CanRotateTo(direction))
			{
				Vector3 rotation = combatant.GameObject.transform.eulerAngles;
				rotation.y = BattleGridHelper.DirectionToAngle(direction, allowSquareDiagonal);
				combatant.GameObject.transform.eulerAngles = rotation;
				combatant.Grid.UpdateSizeCells();
			}
		}


		/*
		============================================================================
		Neighbour functions
		============================================================================
		*/
		public static float GetNeighbourAngle()
		{
			return BattleGridHelper.Helper.GetNeighbourAngle();
		}

		public static float GetNeighbourAngleOffset()
		{
			return BattleGridHelper.Helper.GetNeighbourAngleOffset();
		}

		public static BattleGridCellComponent GetNeighbourCell(BattleGridCellComponent cell, int index)
		{
			return BattleGridHelper.Helper.GetNeighbourCell(cell, index);
		}

		public static bool IsNeighbourCell(BattleGridCellComponent origin,
			BattleGridCellComponent cell, bool allowSquareDiagonal, GridCellCheck check)
		{
			return BattleGridHelper.helperInstance.IsNeighbourCell(origin, cell, allowSquareDiagonal, check);
		}

		public static void UsePathNeighbourCells(BattleGridCellComponent origin, UsePathCell useCell,
			bool allowSquareDiagonal, GridCellCheck check, GridCellCheck checkDiagonal)
		{
			BattleGridHelper.Helper.UsePathNeighbourCells(origin, useCell,
				allowSquareDiagonal, check, checkDiagonal);
		}

		public static void UsePathNeighbourCells(BattleGridCellComponent origin,
			UsePathCell useCell, ref List<BattleGridCellComponent> blockedList,
			bool allowSquareDiagonal, bool blockedOccupied,
			GridCellCheck check, GridCellCheck checkDiagonal)
		{
			BattleGridHelper.Helper.UsePathNeighbourCells(origin, useCell,
				ref blockedList, allowSquareDiagonal, blockedOccupied, check, checkDiagonal);
		}


		/*
		============================================================================
		Range functions
		============================================================================
		*/
		public static void GetRange(BattleGridCellComponent origin, int minDistance, int maxDistance,
			ref List<BattleGridCellComponent> list, ref HashSet<BattleGridCellComponent> contains,
			bool addOrigin, bool addBlocked, bool addNotPassable, bool allowSquareDiagonal, GridCellCheck check)
		{
			BattleGridHelper.Helper.GetRange(origin, minDistance, maxDistance, ref list, ref contains,
				addOrigin, addBlocked, addNotPassable, allowSquareDiagonal, check);
		}

		public static void GetRange(Combatant user, int minDistance, int maxDistance,
			ref List<BattleGridCellComponent> list, ref HashSet<BattleGridCellComponent> contains,
			bool allowSquareDiagonal, GridCellOriginCheck check)
		{
			BattleGridHelper.Helper.GetRange(user, minDistance, maxDistance,
				ref list, ref contains, allowSquareDiagonal, check);
		}

		public static void GetRangeCombatants(BattleGridCellComponent origin, int minDistance, int maxDistance,
		   ref List<Combatant> list, bool addOrigin, bool addBlocked, bool addNotPassable,
		   bool allowSquareDiagonal, GridCellCheck check)
		{
			BattleGridHelper.Helper.GetRangeCombatants(origin, minDistance, maxDistance, ref list,
				addOrigin, addBlocked, addNotPassable, allowSquareDiagonal, check);
		}

		public static void GetRangeCombatants(Combatant user, int minDistance, int maxDistance,
		   ref List<Combatant> list, bool allowSquareDiagonal, GridCellOriginCheck check)
		{
			BattleGridHelper.Helper.GetRangeCombatants(user, minDistance, maxDistance,
				ref list, allowSquareDiagonal, check);
		}

		public static bool CheckRange(BattleGridCellComponent origin, int minDistance, int maxDistance,
			bool addOrigin, bool addBlocked, bool addNotPassable, bool allowSquareDiagonal, GridCellCheck check)
		{
			return BattleGridHelper.Helper.CheckRange(origin, minDistance, maxDistance,
				addOrigin, addBlocked, addNotPassable, allowSquareDiagonal, check);
		}


		/*
		============================================================================
		Ring functions
		============================================================================
		*/
		public static BattleGridCellComponent GetNearestFreeCell(BattleGridCellComponent origin,
			BattleGridCellComponent nearestToCell, bool allowSquareDiagonal, GridCellCheck check)
		{
			if(origin != null &&
				nearestToCell != null)
			{
				List<BattleGridCellComponent> list = new List<BattleGridCellComponent>();
				HashSet<BattleGridCellComponent> contains = new HashSet<BattleGridCellComponent>();
				int maxCount = origin.CubeCoord.Distance(nearestToCell.CubeCoord);

				for(int i = 1; i < maxCount; i++)
				{
					if(list.Count > 0)
					{
						list.Clear();
					}
					if(contains.Count > 0)
					{
						contains.Clear();
					}
					BattleGridHelper.GetRing(origin, i, ref list, ref contains, false, false, false,
						allowSquareDiagonal, BattleGridHelper.IsEmptyCell);

					if(list.Count > 0)
					{
						int distance = int.MaxValue;
						int index = -1;
						for(int j = 0; j < list.Count; j++)
						{
							int tmp = nearestToCell.CubeCoord.Distance(list[j].CubeCoord);
							if(tmp < distance &&
								(check == null || check(list[j])))
							{
								distance = tmp;
								index = j;
							}
						}
						if(index >= 0)
						{
							return list[index];
						}
					}
				}
			}
			return null;
		}

		public static void GetRing(BattleGridCellComponent center, int radius,
			ref List<BattleGridCellComponent> list, ref HashSet<BattleGridCellComponent> contains,
			bool addOrigin, bool addBlocked, bool addNotPassable,
			bool allowSquareDiagonal, GridCellCheck check)
		{
			if(center != null)
			{
				if(radius <= 0)
				{
					list.Add(center);
				}
				else
				{
					BattleGridHelper.Helper.GetRing(center, radius, ref list, ref contains,
						addOrigin, addBlocked, addNotPassable, allowSquareDiagonal, check);
				}
			}
		}

		public static void GetRingCombatants(BattleGridCellComponent center, int radius,
			ref List<Combatant> list, bool addOrigin, bool addBlocked, bool addNotPassable,
			bool allowSquareDiagonal, GridCellCheck check)
		{
			if(center != null)
			{
				if(radius <= 0)
				{
					center.GetCombatants(ref list, null);
				}
				else
				{
					BattleGridHelper.Helper.GetRingCombatants(center, radius, ref list,
						addOrigin, addBlocked, addNotPassable, allowSquareDiagonal, check);
				}
			}
		}

		public static bool CheckRing(BattleGridCellComponent center, int radius,
			bool addOrigin, bool addBlocked, bool addNotPassable,
			bool allowSquareDiagonal, GridCellCheck check)
		{
			if(center != null)
			{
				if(radius <= 0)
				{
					return true;
				}
				else
				{
					return BattleGridHelper.Helper.CheckRing(center, radius,
						addOrigin, addBlocked, addNotPassable, allowSquareDiagonal, check);
				}
			}
			return false;
		}


		/*
		============================================================================
		Line functions
		============================================================================
		*/
		public static void GetLine(BattleGridCellComponent origin, BattleGridCellComponent target,
			ref List<BattleGridCellComponent> list, ref HashSet<BattleGridCellComponent> contains,
			bool ignoreBlocked)
		{
			BattleGridHelper.Helper.GetLine(origin, target, ref list, ref contains, ignoreBlocked);
		}


		/*
		============================================================================
		Line of sight functions
		============================================================================
		*/
		public static bool CheckLineOfSight(Combatant user, BattleGridCellComponent origin, BattleGridCellComponent target,
			GridCellOriginCheck blockLOS, float cellArea)
		{
			return BattleGridHelper.Helper.CheckLineOfSight(user, origin, target, blockLOS, cellArea);
		}


		/*
		============================================================================
		CubeCoord functions
		============================================================================
		*/
		public static CubeCoord Rotate(CubeCoord origin, int turns)
		{
			return BattleGridHelper.Helper.Rotate(origin, turns);
		}

		public static int Distance(CubeCoord origin, CubeCoord target)
		{
			return BattleGridHelper.Helper.Distance(origin, target);
		}

		public static int Distance(CubeCoord origin, CubeCoord target, bool blockDiagonalDistance1)
		{
			return BattleGridHelper.Helper.Distance(origin, target, blockDiagonalDistance1);
		}


		/*
		============================================================================
		Editor tool functions
		============================================================================
		*/
		public static BattleGridCellComponent GetPreviousCell(BattleGridCellComponent cell)
		{
			if(cell != null && cell.parentGrid != null)
			{
				int row = cell.row;
				int column = cell.column;
				column--;
				if(column < 0)
				{
					row--;
					if(row < 0)
					{
						row = cell.parentGrid.cellRow.Length - 1;
					}
					column = cell.parentGrid.cellRow[row].cell.Length - 1;
				}
				return cell.parentGrid.GetCell(row, column);
			}
			return null;
		}

		public static BattleGridCellComponent GetNextCell(BattleGridCellComponent cell)
		{
			if(cell != null && cell.parentGrid != null)
			{
				int row = cell.row;
				int column = cell.column;
				column++;
				if(column >= cell.parentGrid.cellRow[row].cell.Length)
				{
					row++;
					if(row >= cell.parentGrid.cellRow.Length)
					{
						row = 0;
					}
					column = 0;
				}
				return cell.parentGrid.GetCell(row, column);
			}
			return null;
		}
	}
}
