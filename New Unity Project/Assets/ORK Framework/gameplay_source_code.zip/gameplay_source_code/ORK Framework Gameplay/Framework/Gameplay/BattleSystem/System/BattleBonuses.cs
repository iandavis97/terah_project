
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleBonuses : BaseData
	{
		// start bonus
		[ORKEditorInfo("Bonus Settings", "'Consumable' type status values can be changed every turn or " +
			"at start and end of the battle.\n" +
			"Additionally dead combatants can be revived at the end of the battle.", "",
			"Start Battle Bonus", "Bonuses that will be given at the start of a battle.", "")]
		[ORKEditorArray(false, "Add Status Value Bonus", "Adds a status value bonus to the list.\n" +
			"The bonus is added at the start of a battle.", "",
			"Remove", "Removes this status value bonus.", "", isMove=true, isCopy=true,
			removeType=ORKDataType.StatusValue, removeCheckField="statusID",
			foldout=true, foldoutText=new string[] {"Status Value Bonus",
				"This bonus will be added at the start of a battle.", ""})]
		public StatusValueSetter[] startSetter = new StatusValueSetter[0];

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Status Effect", "Add a status effect cast.\n" +
			"The status effect is added/removed at the start of a battle.", "",
			"Remove", "Remove this status effect cast.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Status Effect", "Define the status effect that will be added/removed at the start of a battle.", ""
		})]
		public StatusEffectCast[] startEffect = new StatusEffectCast[0];


		// turn bonus
		[ORKEditorInfo("Turn Bonuses", "Bonuses that will be given when a combatant starts a new turn.", "")]
		[ORKEditorArray(false, "Add Status Value Bonus", "Adds a status value bonus to the list.\n" +
			"The bonus is added whenever a combatant starts a new turn (i.e. selects a battle action).", "",
			"Remove", "Removes this status value bonus.", "", isMove=true, isCopy=true,
			removeType=ORKDataType.StatusValue, removeCheckField="statusID",
			foldout=true, foldoutText=new string[] {"Status Value Bonus",
				"This bonus will be added when a combatant starts a new turn.", ""})]
		public StatusValueSetter[] turnSetter = new StatusValueSetter[0];

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Status Effect", "Add a status effect cast.\n" +
			"The status effect is added/removed when a combatant starts a new turn.", "",
			"Remove", "Remove this status effect cast.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Status Effect", "Define the status effect that will be added/removed when a combatant starts a new turn.", ""
		})]
		public StatusEffectCast[] turnEffect = new StatusEffectCast[0];


		// end bonus
		[ORKEditorInfo("End Battle Bonus", "Bonuses that will be given at the end of a battle.", "")]
		[ORKEditorArray(false, "Add Status Value Bonus", "Adds a status value bonus to the list.\n" +
			"The bonus is added at the end of a battle.", "",
			"Remove", "Removes this end bonus.", "", isMove=true, isCopy=true,
			removeType=ORKDataType.StatusValue, removeCheckField="statusID",
			foldout=true, foldoutText=new string[] {"Status Value Bonus",
				"This bonus will be added at the end of a battle.", ""})]
		public StatusValueSetter[] endSetter = new StatusValueSetter[0];

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Status Effect", "Add a status effect cast.\n" +
			"The status effect is added/removed at the end of a battle.", "",
			"Remove", "Remove this status effect cast.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Status Effect", "Define the status effect that will be added/removed at the end of a battle.", ""
		})]
		public StatusEffectCast[] endEffect = new StatusEffectCast[0];


		// revive after battle
		[ORKEditorHelp("Revive After Battle", "Dead members of the player group will be revived after battle.", "")]
		[ORKEditorInfo("Revive After Battle", "Dead members of the player group can " +
			"optionally be revived after battle and receive bonuses.", "")]
		public bool reviveAfterBattle = false;

		[ORKEditorArray(false, "Add Status Value Bonus", "Adds a status value bonus to the list.\n" +
			"The bonus is added when a combatant is revived after battle.", "",
			"Remove", "Removes this status value bonus.", "", isMove=true, isCopy=true,
			removeType=ORKDataType.StatusValue, removeCheckField="statusID",
			foldout=true, foldoutText=new string[] {"Status Value Bonus",
				"This bonus will be added when a combatant is revived after the battle.", ""})]
		[ORKEditorLayout("reviveAfterBattle", true)]
		public StatusValueSetter[] reviveSetter = new StatusValueSetter[0];

		[ORKEditorInfo(endFoldout=true, endFolds=2)]
		[ORKEditorArray(false, "Add Status Effect", "Add a status effect cast.\n" +
			"The status effect is added/removed when a combatant is revived after battle.", "",
			"Remove", "Remove this status effect cast.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Status Effect", "Define the status effect that will be added/removed when a combatant is revived after battle.", ""
		})]
		[ORKEditorLayout(endCheckGroup=true)]
		public StatusEffectCast[] reviveEffect = new StatusEffectCast[0];

		public BattleBonuses()
		{

		}


		/*
		============================================================================
		Status bonus functions
		============================================================================
		*/
		private void AddBonus(Combatant c, StatusValueSetter[] bonus, StatusEffectCast[] effect)
		{
			if(!c.Dead)
			{
				for(int i = 0; i < bonus.Length; i++)
				{
					bonus[i].Change(c);
				}
				for(int i = 0; i < effect.Length; i++)
				{
					effect[i].ChangeEffect(c, c, false, null);
				}
				c.MarkStatusBoundsCheck();
			}
		}

		public void StartBonus(Combatant c)
		{
			this.AddBonus(c, this.startSetter, this.startEffect);
		}

		public void TurnBonus(Combatant c)
		{
			this.AddBonus(c, this.turnSetter, this.turnEffect);
		}

		public void EndBonus(Combatant c)
		{
			this.AddBonus(c, this.endSetter, this.endEffect);
		}

		public void ReviveBonus(Combatant c)
		{
			if(this.reviveAfterBattle &&
				c.Dead &&
				c.Group.IsPlayerControlled())
			{
				c.DeathState = CombatantDeathState.Alive;
				this.AddBonus(c, this.reviveSetter, this.reviveEffect);
			}
		}
	}
}
