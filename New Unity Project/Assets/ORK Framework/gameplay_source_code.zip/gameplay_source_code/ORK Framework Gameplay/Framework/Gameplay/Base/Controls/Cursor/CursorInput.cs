﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CursorInput : BaseData
	{
		[ORKEditorHelp("Vertical Axis", "The input key used to move the cursor vertically.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int verticalAxisID = 0;

		[ORKEditorHelp("Horizontal Axis", "The input key used to move the cursor horizontally.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int horizontalAxisID = 0;

		[ORKEditorHelp("Axis Minimum", "Define the minimum value an axis must have to trigger a cursor change.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float axisMinimum = 0.3f;

		[ORKEditorHelp("Use Camera Direction", "The axis keys will change the cursor based on the camera view (main camera).", "")]
		public bool useCameraDirection = false;

		[ORKEditorHelp("Camera Direction Offset", "Define the angle in degrees that will be added to the camera direction.\n" +
			"E.g. use 45 to shift the cursor change 45 degrees to the camera view.", "")]
		[ORKEditorLayout("useCameraDirection", true, endCheckGroup=true)]
		public float cameraDirectionOffset = 0;

		public CursorInput()
		{

		}

		public Vector3 GetInput(HorizontalPlaneType horizontalPlane)
		{
			float h = ORK.InputKeys.Get(this.horizontalAxisID).GetAxis();
			float v = ORK.InputKeys.Get(this.verticalAxisID).GetAxis();

			if(h <= -this.axisMinimum || h >= this.axisMinimum ||
				v <= -this.axisMinimum || v >= this.axisMinimum)
			{
				if(this.useCameraDirection && Camera.main != null)
				{
					return InputHelper.GetDirectionJoystick(h, v,
						Camera.main.transform, horizontalPlane, this.cameraDirectionOffset);
				}
				else
				{
					if(HorizontalPlaneType.XZ == horizontalPlane)
					{
						new Vector3(h, 0, v);
					}
					else if(HorizontalPlaneType.XY == horizontalPlane)
					{
						new Vector3(h, v, 0);
					}
				}
			}

			return Vector3.zero;
		}
	}
}
