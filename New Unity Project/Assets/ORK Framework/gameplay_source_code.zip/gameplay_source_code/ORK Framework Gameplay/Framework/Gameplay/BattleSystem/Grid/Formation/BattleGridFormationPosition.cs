﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public enum BattleGridFormationRotation { None, Leader, Select };

	public class BattleGridFormationPosition : BaseData
	{
		[ORKEditorHelp("Priority", "The priority of this position.\n" +
			"Positions will be filled based on their priority, the higher the priority number, the sooner they'll be filled.\n" +
			 "E.g. priority 1 positions will be filled before priority 0 positions.", "")]
		[ORKEditorLimit(0, false)]
		[ORKEditorInfo(instanceCallback="editor:GridFormationChange")]
		public int priority = 0;

		[ORKEditorHelp("From Positions", "Use a combatant from another position if no other combatant is available.\n" +
			"Uses combatants from positions with lower priority.", "")]
		public bool fromPositions = false;

		[ORKEditorHelp("Free On Death", "The position is freed when the combatant dies.\n" +
			"The position is freed in any case if the combatant leaves the battle or group.", "")]
		public bool freeOnDeath = false;


		// rotation
		[ORKEditorHelp("Set Rotation", "Select if the combatant's rotation will be changed when reaching the cell:\n" +
			"- None: Doesn't change the rotation.\n" +
			"- Leader: Uses the same rotation as the leader.\n" +
			"- Select: Define the rotation (within the formation's rotation).", "")]
		[ORKEditorInfo(separator=true)]
		public BattleGridFormationRotation setRotation = BattleGridFormationRotation.None;

		[ORKEditorHelp("Rotation", "Define the rotation the combatant will use.\n" +
			"0 is front/north.", "")]
		[ORKEditorLimit(-180.0f, 180.0f)]
		[ORKEditorLayout("setRotation", BattleGridFormationRotation.Select, endCheckGroup=true)]
		public float rotation = 0;


		// requirement
		[ORKEditorHelp("Use Requirements", "Use status requirements and variable conditions to " +
			"determine if a combatant can use this position.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useRequirements = false;

		[ORKEditorHelp("Ignore Requirements", "Ignore the requirements if no combatant is found.\n" +
			"If disabled, the position will not be filled if no combatant is found.", "")]
		[ORKEditorLayout("useRequirements", true)]
		public bool ignoreRequirements = true;

		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public SimpleCombatantRequirement requirement;


		// position relative to leader
		[ORKEditorInfo(hide=true)]
		public CubeCoord coord;

		public BattleGridFormationPosition()
		{

		}

		public BattleGridFormationPosition(CubeCoord coord)
		{
			this.coord = coord;
		}

		public bool CheckRequirements(Combatant combatant)
		{
			return !this.useRequirements || this.requirement.Check(combatant);
		}

		public bool CheckRotation(Combatant combatant, GroupGridFormation formation)
		{
			if(combatant != null &&
				combatant.GameObject != null &&
				formation != null &&
				formation.Formation != null)
			{
				if(BattleGridFormationRotation.None == this.setRotation)
				{
					return true;
				}
				else if(BattleGridFormationRotation.Leader == this.setRotation)
				{
					if(formation.Leader != null &&
						formation.Leader.GameObject != null)
					{
						return Mathf.Approximately(
							combatant.GameObject.transform.eulerAngles.y,
							formation.Leader.GameObject.transform.eulerAngles.y);
					}
				}
				else if(BattleGridFormationRotation.Select == this.setRotation)
				{
					if(formation.Formation.leader.isLocalSpace &&
						formation.Leader != null &&
						formation.Leader.GameObject != null)
					{
						return Mathf.Approximately(
							combatant.GameObject.transform.eulerAngles.y,
							formation.Leader.GameObject.transform.eulerAngles.y + this.rotation);
					}
					else
					{
						return Mathf.Approximately(
							combatant.GameObject.transform.eulerAngles.y,
							this.rotation);
					}
				}
			}
			return false;
		}

		public void UseRotation(Combatant combatant, GroupGridFormation formation)
		{
			if(combatant != null &&
				combatant.GameObject != null &&
				formation != null &&
				formation.Formation != null)
			{
				if(BattleGridFormationRotation.Leader == this.setRotation)
				{
					if(formation.Leader != null &&
						formation.Leader.GameObject != null)
					{
						Vector3 rotation = combatant.GameObject.transform.eulerAngles;
						rotation.y = formation.Leader.GameObject.transform.eulerAngles.y;
						combatant.GameObject.transform.eulerAngles = rotation;
					}
				}
				else if(BattleGridFormationRotation.Select == this.setRotation)
				{
					Vector3 rotation = combatant.GameObject.transform.eulerAngles;
					if(formation.Formation.leader.isLocalSpace &&
						formation.Leader != null &&
						formation.Leader.GameObject != null)
					{
						rotation.y = formation.Leader.GameObject.transform.eulerAngles.y + this.rotation;
					}
					else
					{
						rotation.y = this.rotation;
					}
					combatant.GameObject.transform.eulerAngles = rotation;
				}
			}
		}
	}
}
