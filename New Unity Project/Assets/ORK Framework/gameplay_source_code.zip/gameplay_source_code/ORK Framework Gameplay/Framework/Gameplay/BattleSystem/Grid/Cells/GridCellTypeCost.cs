﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridCellTypeCost : BaseData
	{
		[ORKEditorHelp("Grid Cell Type", "Select the grid cell type that will be used.", "")]
		[ORKEditorInfo(ORKDataType.BattleGridCellType, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Grid Cell Type", "Adds a grid cell type that will be used.", "",
			"Remove", "Removes the grid cell type.", "", isHorizontal=true, noRemoveCount=1)]
		public int[] cellTypeID = new int[1];

		[ORKEditorHelp("Block Movement", "Movement from the defined grid cell types to this type is blocked, " +
			"i.e. a combatant can't move from the defined cell types to this cell type.", "")]
		[ORKEditorInfo(separator=true)]
		public bool blockMovement = false;

		[ORKEditorInfo("Move Cost", "Defines how much moving on/over this cell will reduce a combatant's move points " +
			"when coming from one of the defined grid cell types.", "",
			endFoldout=true)]
		[ORKEditorLayout("blockMovement", false)]
		public FloatValue moveCost = new FloatValue(1);

		[ORKEditorInfo("Action Cost", "Defines how much moving on/over this cell will reduce a combatant's actions per turn " +
			"when coming from one of the defined grid cell types.\n" +
			"This is only used in turn based and phase battles.", "",
			endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public FloatValue actionCost = new FloatValue(0);

		public GridCellTypeCost()
		{

		}

		public bool IsCellType(BattleGridCellComponent cell)
		{
			return BattleGridHelper.IsCellType(cell, this.cellTypeID);
		}
	}
}
