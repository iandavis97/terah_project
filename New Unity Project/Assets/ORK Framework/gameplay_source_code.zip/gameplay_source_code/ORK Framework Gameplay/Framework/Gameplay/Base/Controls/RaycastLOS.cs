﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class RaycastLOS : BaseData
	{
		[ORKEditorHelp("Use Raycast", "Use a raycast to check if any other objects are between user and target.", "")]
		public bool useRaycast = false;

		[ORKEditorHelp("Layer Mask", "The layer mask used for the raycast.", "")]
		[ORKEditorLayout("useRaycast", true)]
		public LayerMask layerMask = -1;

		[ORKEditorHelp("Use Child (User)", "The position of the defined child of the user's game object will be used for the raycast.\n" +
			"If the child can't be found, the user's game object itself will be used.\n" +
			"Define the child as Path/To/Child, use / to separate game objects in the hierarchy.\n" +
			"Leave empty if no child object should be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string childNameUser = "";

		[ORKEditorHelp("Use Child (Target)", "The position of the defined child of the target's game object will be used for the raycast.\n" +
			"If the child can't be found, the target's game object itself will be used.\n" +
			"Define the child as Path/To/Child, use / to separate game objects in the hierarchy.\n" +
			"Leave empty if no child object should be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string childNameTarget = "";

		public RaycastLOS()
		{

		}

		public bool Check(GameObject user, GameObject target)
		{
			if(this.useRaycast)
			{
				if(user == null ||
					target == null)
				{
					return false;
				}

				Vector3 origin = TransformHelper.GetChild(this.childNameUser, user.transform).position;
				Vector3 destination = TransformHelper.GetChild(this.childNameTarget, target.transform).position;

				List<RaycastOutput> hit = RaycastHelper.RaycastAll(origin,
					VectorHelper.GetDirection(origin, destination),
					Vector3.Distance(origin, destination), this.layerMask);

				for(int i = 0; i < hit.Count; i++)
				{
					if(hit[i].transform.root != user.transform.root &&
						hit[i].transform.root != target.transform.root)
					{
						return false;
					}
				}
			}
			return true;
		}
	}
}
