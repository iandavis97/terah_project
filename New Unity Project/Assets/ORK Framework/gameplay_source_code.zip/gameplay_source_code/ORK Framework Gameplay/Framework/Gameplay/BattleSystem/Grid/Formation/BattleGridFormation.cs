﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleGridFormation : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of this grid formation.", "")]
		[ORKEditorInfo("Base Settings", "Set the name and base settings of this grid formation.\n" +
			"Grid formations can be used by AI controlled combatants to move them into a formation in grid battles.", "",
			expandWidth=true)]
		public string name = "";

		[ORKEditorHelp("Allow Rearranging", "Combatants can change their formation positions " +
			"when the formation is moved or rotated.\n" +
			"This is used when combatants are on the cells of other formation positions " +
			"after the formation changed.", "")]
		public bool allowRearranging = false;

		[ORKEditorHelp("Use Required", "Combatants already placed on positions using " +
			"requirements will also be available for rearranging.\n" +
			"If disabled, combatants from positions using requirements will not be rearranged.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("allowRearranging", true, endCheckGroup=true)]
		public bool rearrangeUseRequired = false;

		[ORKEditorHelp("Rows", "The number of rows of the formation.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLimit(3, false)]
		public int rows = 3;

		[ORKEditorHelp("Columns", "The number of columns of the formation.", "")]
		[ORKEditorInfo(endFoldout=true, callbackAfter="editor:GridFormation")]
		[ORKEditorLimit(3, false)]
		public int columns = 3;


		// formation leader
		[ORKEditorInfo("Formation Leader", "Define the settings for the formation's leader.", "",
			endFoldout=true)]
		public BattleGridFormationLeader leader = new BattleGridFormationLeader();


		// formation positions
		[ORKEditorArray(isMove=true, foldout=true, foldoutText=new string[] {
			"Formation Position", "Define the settings for this formation position.", ""
		})]
		public BattleGridFormationPosition[] position = new BattleGridFormationPosition[0];


		// status effects
		// call effects
		[ORKEditorInfo("Status Effects", "Status effect changes can automatically be used upon certain formation conditions, "+
			"e.g. when calling the formation or finishing it (i.e. all combatants reaching their formation positions).", "",
			"Call Formation", "These status effect changes will be used " +
			"on all formation members when calling the formation.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Status Effect", "Add a status effect cast to the list.", "",
			"Remove", "Remove this status effect cast from the list.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Status Effect", "Select the status effect and how it will be changed.", ""
		})]
		public StatusEffectCast[] callEffect = new StatusEffectCast[0];


		// break effects
		[ORKEditorInfo("Break Formation", "These status effect changes will be used " +
			"on all formation members when breaking the formation.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Status Effect", "Add a status effect cast to the list.", "",
			"Remove", "Remove this status effect cast from the list.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Status Effect", "Select the status effect and how it will be changed.", ""
		})]
		public StatusEffectCast[] breakEffect = new StatusEffectCast[0];


		// finished effects
		[ORKEditorHelp("Only Filled Positions", "Only positions that have a combatant assigned will be checked.\n" +
			"If disabled, an empty position will result in failure.", "")]
		[ORKEditorInfo("Finished Formation", "These status effect changes will be used " +
			"on all formation members when finishing the formation, " +
			"i.e. when all combatants reached their positions.", "")]
		public bool finishedEffectOnlyFilled = true;

		[ORKEditorHelp("Check Rotation", "Checks if the combatant's rotation matches the rotation defined by the position " +
			"(e.g. matching the leader's rotatin).\n" +
			"If disabled, rotations are ignored.", "")]
		public bool finishedEffectCheckRotation = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Status Effect", "Add a status effect cast to the list.", "",
			"Remove", "Remove this status effect cast from the list.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Status Effect", "Select the status effect and how it will be changed.", ""
		})]
		public StatusEffectCast[] finishedEffect = new StatusEffectCast[0];


		// end finished effects
		[ORKEditorInfo("End Finished Formation", "These status effect changes will be used " +
			"on all formation members when an already finished formation is unfinished, " +
			"e.g. a combatant moving from its position.\n" +
			"Used when the 'Finished Formation' check fails and the formation was previously finished.", "",
			endFoldout=true, endFolds=2)]
		[ORKEditorArray(false, "Add Status Effect", "Add a status effect cast to the list.", "",
			"Remove", "Remove this status effect cast from the list.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Status Effect", "Select the status effect and how it will be changed.", ""
		})]
		public StatusEffectCast[] endFinishedEffect = new StatusEffectCast[0];

		public BattleGridFormation()
		{

		}

		public BattleGridFormation(string name)
		{
			this.name = name;
		}

		public bool IsFormationPossible(Combatant combatant)
		{
			if(combatant != null)
			{
				if(this.leader.isGroupLeader)
				{
					combatant = combatant.Group.BattleLeader;
				}

				if(combatant != null &&
					combatant.Grid.Cell != null &&
					ORK.Battle.Grid != null)
				{

					if(this.leader.isLocalSpace)
					{
						int turns = BattleGridHelper.GetCombatantDirection(combatant, false);
						for(int i = 0; i < this.position.Length; i++)
						{
							BattleGridCellComponent cell = ORK.Battle.Grid.GetCell(
							combatant.Grid.Cell.CubeCoord + this.position[i].coord.Rotate(turns));

							if(cell == null ||
								cell.IsBlocked)
							{
								return false;
							}
						}
					}
					else
					{
						for(int i = 0; i < this.position.Length; i++)
						{
							BattleGridCellComponent cell = ORK.Battle.Grid.GetCell(
							combatant.Grid.Cell.CubeCoord + this.position[i].coord);

							if(cell == null ||
								cell.IsBlocked)
							{
								return false;
							}
						}
					}
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Status effect functions
		============================================================================
		*/
		public void UseCallStatusEffects(Combatant combatant, object source)
		{
			for(int i = 0; i < this.callEffect.Length; i++)
			{
				this.callEffect[i].ChangeEffect(combatant, combatant, false, source);
			}
		}

		public void UseBreakStatusEffects(Combatant combatant, object source)
		{
			for(int i = 0; i < this.breakEffect.Length; i++)
			{
				this.breakEffect[i].ChangeEffect(combatant, combatant, false, source);
			}
		}

		public bool CheckFinishStatusEffects(GroupGridFormation formation)
		{
			return this.finishedEffect.Length > 0 &&
				formation.PositionsFilled(this.finishedEffectOnlyFilled,
					this.finishedEffectCheckRotation, -1);
		}

		public void UseFinishedStatusEffects(Combatant combatant, object source)
		{
			for(int i = 0; i < this.finishedEffect.Length; i++)
			{
				this.finishedEffect[i].ChangeEffect(combatant, combatant, false, source);
			}
		}

		public void UseEndFinishedStatusEffects(Combatant combatant, object source)
		{
			for(int i = 0; i < this.endFinishedEffect.Length; i++)
			{
				this.endFinishedEffect[i].ChangeEffect(combatant, combatant, false, source);
			}
		}
	}
}
