﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CastTimeSettings : BaseData
	{
		[ORKEditorHelp("Use Cast Time", "This action will be casted before using.", "")]
		public bool useCastTime = false;

		[ORKEditorInfo(separator=true, labelText="Cast Time")]
		[ORKEditorLayout("useCastTime", true, autoInit=true)]
		public FloatValue castTimeValue;

		[ORKEditorHelp("Cancelable", "The action can be canceled while casting.\n" +
			"The action will only be canceled when the caster is attacked by an attack with cancel action option selected.", "")]
		[ORKEditorInfo(separator=true)]
		public bool cancelable = false;

		[ORKEditorHelp("Move While Casting", "The combatant can move while casting this action.\n" +
			"If disabled, the combatant can't move (like a status effect with 'Stop Movement').", "")]
		public bool castMove = false;

		[ORKEditorHelp("Play Sound", "A sound will be played on the user when starting to cast this action.", "")]
		[ORKEditorInfo(separator=true)]
		public bool castPlaySound = false;

		[ORKEditorLayout("castPlaySound", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public PlayAudioCombatant castAudioSettings;

		public CastTimeSettings()
		{

		}
	}
}
