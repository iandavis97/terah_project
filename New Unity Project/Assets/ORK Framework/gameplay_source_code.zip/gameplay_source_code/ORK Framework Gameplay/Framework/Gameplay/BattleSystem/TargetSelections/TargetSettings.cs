
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TargetSettings : BaseData
	{
		[ORKEditorHelp("Target Type", "Select which group will be the target:\n" +
			"- Self: The user is the target.\n" +
			"- Ally: The target is in an allied group of the user.\n" +
			"- Enemy: The target is in an enemy group.\n" +
			"- All: All combatant's are possible targets.", "")]
		[ORKEditorInfo("Target Settings", "Set the target range of this ability/item.", "",
			isEnumToolbar=true, toolbarWidth=75)]
		public TargetType targetType = TargetType.Enemy;

		[ORKEditorHelp("Target Range", "Sets if a single or multiple combatants are targeted:\n" +
			"- None: No target required. Use this setting for 'area of effect' spells, etc.\n" +
			"- Single: Only one combatant is the target.\n" +
			"- Group: The whole group of combatants are the target.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("targetType", TargetType.Self, elseCheckGroup=true)]
		public TargetRange targetRange = TargetRange.Single;

		[ORKEditorHelp("Not On Self", "The user can't be the target.", "")]
		[ORKEditorLayout("targetType", TargetType.Enemy, elseCheckGroup=true, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool notSelf = false;


		// none target
		[ORKEditorHelp("Select Target Cell", "Select a cell as target for the ability in grid battles.", "")]
		[ORKEditorLayout("targetRange", TargetRange.None)]
		public bool noneSelectGridCell = false;

		[ORKEditorInfo("Raycast Settings", "You can optionally use a raycast for setting a target (position).\n" +
			"Use this for area of effect type of abilities.", "", endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public TargetRaycast targetRaycast;


		// can target dead
		[ORKEditorHelp("Is Dead", "Select if the target must be dead:\n" +
			"- Yes: The target must be dead to be a valid target.\n" +
			"- No: The target mustn't be dead to be a valid target.\n" +
			"- Ignore: The target's death status is ignored.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=50)]
		[ORKEditorLayout(endCheckGroup=true, setDefault=true, defaultValue=Consider.No)]
		public Consider isDead = Consider.No;


		// use range
		[ORKEditorHelp("Own Use Range", "Override the default use range (found in 'Battle Settings').", "")]
		[ORKEditorInfo("Use Range Setting", "An ability/item can override the default use range.\n" +
			"The use range determines the maximum distance between user and target to allow using an ability or item. " +
			"The range can be defined for each battle system type.", "")]
		[ORKEditorLayout("targetType", TargetType.Self, elseCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool ownUseRange = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("ownUseRange", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public UseRangeSettings useRange;


		// single target affect range
		[ORKEditorHelp("Affect Range", "Select if affect range is used and when affected targets will be selected:\n" +
			"- None: No affect range is used.\n" +
			"- Calculation: Each time the outcome is calculated (targets not available in battle events).\n" +
			"- Execution: When the action is started (targets available in battle events).", "")]
		[ORKEditorInfo("Affect Range Setting", "An ability/item can affect all combatants of the same group " +
			"as the target if they are within a defined range to the target.\n" +
			"The range can be defined for each battle system type.", "")]
		public AffectRangeType affectRangeType = AffectRangeType.None;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("affectRangeType", AffectRangeType.None,
			elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public UseRangeSettings rangeAffect;


		// requirements
		[ORKEditorHelp("Use Requirements", "Use status requirements and game variable conditions.", "")]
		[ORKEditorInfo("Target Requirements", "A target can depend on status requirements and game variable conditions.\n" +
			"If the requirements aren't met, the combatant can't be targeted.", "")]
		public bool useRequirements = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useRequirements", true, endCheckGroup=true, autoInit=true)]
		public SimpleCombatantRequirement requirement;


		// orientation
		[ORKEditorHelp("Check User Orientation", "Check the orientation from user to target.", "")]
		[ORKEditorInfo("Orientation Requirements", "A target can depend on the orientation between user and target.\n" +
			"E.g. only allow using an ability/item when being behind a target.", "",
			labelText="User Orientation")]
		public bool checkUserOrientation = false;

		[ORKEditorHelp("Horizontal Plane", "Select the horizontal plane (i.e. which axes are used for horizontal movement):\n" +
			"- XZ: The game objects are moving on the XZ plane horizontally, i.e. default 3D behaviour.\n" +
			"- XY: The game objects are moving on the XY plane horizontally, i.e. default 2D behaviour.", "")]
		[ORKEditorLayout("checkUserOrientation", true)]
		public HorizontalPlaneType horizontalPlane = HorizontalPlaneType.XZ;

		[ORKEditorHelp("Target In Front", "The target has to be in front of the user.", "")]
		public bool userFront = false;

		[ORKEditorHelp("Target In Back", "The target has to be in the back of the user.", "")]
		public bool userBack = false;

		[ORKEditorHelp("Target Left", "The target has to be left of the user.", "")]
		public bool userLeft = false;

		[ORKEditorHelp("Target Right", "The target has to be right of the user.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool userRight = false;

		[ORKEditorHelp("Check Target Orientation", "Check the orientation from target to user.", "")]
		[ORKEditorInfo(separator=true, labelText="Target Orientation")]
		public bool checkTargetOrientation = false;

		[ORKEditorHelp("User In Front", "The user has to be in front of the target.", "")]
		[ORKEditorLayout("checkTargetOrientation", true)]
		public bool targetFront = false;

		[ORKEditorHelp("User In Back", "The user has to be in the back of the target.", "")]
		public bool targetBack = false;

		[ORKEditorHelp("User Left", "The user has to be left of the target.", "")]
		public bool targetLeft = false;

		[ORKEditorHelp("User Right", "The user has to be right of the target.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool targetRight = false;


		// auto target
		[ORKEditorHelp("Use Auto Target", "Use status requirements and game variable conditions.", "")]
		[ORKEditorInfo("Auto Targets", "A target can automatically be selected depending on status requirements and " +
			"game variable conditions.\n" +
			"This can be used by battle menus to automatically select the first combatant fitting the requirements " +
			"(this still requires the player to accept the selection) and by control maps and " +
			"'Combatant' type HUDs ('Shortcut' elements) to use automatically select and use a target.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetRange", "targetRange"},
			new System.Object[] {TargetType.Self, TargetRange.None, TargetRange.Group},
			needed=Needed.One, elseCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool useAutoTarget = false;

		[ORKEditorInfo(separator=true, endFoldout=true, endFolds=2)]
		[ORKEditorLayout("useAutoTarget", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public SimpleCombatantRequirement autoTarget;

		public TargetSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useAffectRange"))
			{
				bool tmp = false;
				data.Get("useAffectRange", ref tmp);

				if(tmp)
				{
					this.affectRangeType = AffectRangeType.Calculation;

					if(data.Contains<DataObject>("affectRange"))
					{
						this.rangeAffect = new UseRangeSettings();
						DataObject tmpData = data.GetFile("affectRange");
						if(tmpData != null)
						{
							this.rangeAffect.rangeDefault.type = BattleRangeType.Custom;
							this.rangeAffect.rangeDefault.custom = new BattleRangeSetting();
							this.rangeAffect.rangeDefault.custom.useMax = true;
							this.rangeAffect.rangeDefault.custom.maxRange = new Range();
							this.rangeAffect.rangeDefault.custom.maxRange.SetData(tmpData);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Target type functions
		============================================================================
		*/
		public bool TargetSelf()
		{
			return TargetType.Self == this.targetType;
		}

		public bool TargetAlly()
		{
			return TargetType.Ally == this.targetType;
		}

		public bool TargetEnemy()
		{
			return TargetType.Enemy == this.targetType;
		}

		public bool TargetAll()
		{
			return TargetType.All == this.targetType;
		}


		/*
		============================================================================
		Target range functions
		============================================================================
		*/
		public bool NoneTarget()
		{
			return TargetRange.None == this.targetRange;
		}

		public bool SingleTarget()
		{
			return TargetRange.Single == this.targetRange;
		}

		public bool GroupTarget()
		{
			return TargetRange.Group == this.targetRange;
		}


		/*
		============================================================================
		Move AI functions
		============================================================================
		*/
		public bool CanMoveIntoRange(Combatant user)
		{
			if(ORK.Battle.CanUseMoveAI(user))
			{
				if(this.ownUseRange)
				{
					return this.useRange.CanMoveIntoRange(user);
				}
				else
				{
					return ORK.BattleSettings.useRange.CanMoveIntoRange(user);
				}
			}
			return false;
		}

		public void MoveIntoRange(Combatant user, ref bool moveIntoRange, ref bool useStopAngle)
		{
			if(this.ownUseRange)
			{
				this.useRange.MoveIntoRange(user, ref moveIntoRange, ref useStopAngle);
			}
			else
			{
				ORK.BattleSettings.useRange.MoveIntoRange(user, ref moveIntoRange, ref useStopAngle);
			}
		}

		public Range GetMoveAIUseRange(Combatant user)
		{
			if(this.ownUseRange)
			{
				return this.useRange.GetMoveAIUseRange(user);
			}
			else
			{
				return ORK.BattleSettings.useRange.GetMoveAIUseRange(user);
			}
		}


		/*
		============================================================================
		Use range functions
		============================================================================
		*/
		public bool InRange(Combatant user, Combatant target)
		{
			if(TargetType.Self == this.targetType)
			{
				return true;
			}
			else if(this.ownUseRange)
			{
				return this.useRange.InRange(user, target);
			}
			else
			{
				return ORK.BattleSettings.useRange.InRange(user, target);
			}
		}

		public bool InRange(Combatant user, Vector3 position)
		{
			if(TargetType.Self == this.targetType)
			{
				return true;
			}
			else if(this.ownUseRange)
			{
				return this.useRange.InRange(user, position);
			}
			else
			{
				return ORK.BattleSettings.useRange.InRange(user, position);
			}
		}

		public bool InRange(Combatant user, BattleGridCellComponent target)
		{
			if(TargetType.Self == this.targetType)
			{
				return true;
			}
			else if(this.ownUseRange)
			{
				return this.useRange.InRange(user, target);
			}
			else
			{
				return ORK.BattleSettings.useRange.InRange(user, target);
			}
		}

		public List<BattleGridCellComponent> GetUseRangeCells(Combatant user, GridCellCheck check)
		{
			if(TargetType.Self == this.targetType)
			{
				return null;
			}
			else if(this.ownUseRange)
			{
				return this.useRange.GetCells(user, user.Grid.Cell, check);
			}
			else
			{
				return ORK.BattleSettings.useRange.GetCells(user, user.Grid.Cell, check);
			}
		}

		public void GetUseRangeCells(Combatant user, ref List<BattleGridCellComponent> list, GridCellCheck check)
		{
			if(this.ownUseRange)
			{
				this.useRange.GetCells(user, user.Grid.Cell, ref list, check);
			}
			else
			{
				ORK.BattleSettings.useRange.GetCells(user, user.Grid.Cell, ref list, check);
			}
		}

		public List<Combatant> GetUseRange(Combatant user)
		{
			if(this.ownUseRange)
			{
				return this.useRange.GetTargets(
					user, this.ConsiderTargetType, this.isDead,
					user.Battle.InBattle ? Consider.Yes : Consider.Ignore);
			}
			else
			{
				return ORK.BattleSettings.useRange.GetTargets(
					user, this.ConsiderTargetType, this.isDead,
					user.Battle.InBattle ? Consider.Yes : Consider.Ignore);
			}
		}

		private Consider ConsiderTargetType
		{
			get
			{
				if(TargetType.Enemy == this.targetType)
				{
					return Consider.Yes;
				}
				else if(TargetType.All == this.targetType)
				{
					return Consider.Ignore;
				}
				return Consider.No;
			}
		}


		/*
		============================================================================
		Affect range functions
		============================================================================
		*/
		public List<BattleGridCellComponent> GetAffectRangeCells(Combatant user, BattleGridCellComponent originCell, GridCellCheck check)
		{
			if(AffectRangeType.None != this.affectRangeType &&
				this.rangeAffect != null)
			{
				return this.rangeAffect.GetCells(user, originCell, check);
			}
			return null;
		}

		public void GetAffectRangeCells(Combatant user, BattleGridCellComponent originCell,
			ref List<BattleGridCellComponent> list, GridCellCheck check)
		{
			if(AffectRangeType.None != this.affectRangeType &&
				this.rangeAffect != null)
			{
				this.rangeAffect.GetCells(user, originCell, ref list, check);
			}
		}

		public List<Combatant> GetAffectRange(Combatant user, List<Combatant> targets)
		{
			if(AffectRangeType.None != this.affectRangeType &&
				this.rangeAffect != null)
			{
				List<Combatant> newTargets = new List<Combatant>(targets);

				for(int i = 0; i < targets.Count; i++)
				{
					List<Combatant> tmp = this.rangeAffect.GetTargets(
						targets[i], Consider.No, this.isDead,
						user.Battle.InBattle ? Consider.Yes : Consider.Ignore);
					for(int j = 0; j < tmp.Count; j++)
					{
						if(!newTargets.Contains(tmp[j]) &&
							this.CanTarget(user, tmp[j]))
						{
							newTargets.Add(tmp[j]);
						}
					}
				}

				return newTargets;
			}
			else
			{
				return targets;
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool CanTargetAny(Combatant user, List<Combatant> targets)
		{
			for(int i = 0; i < targets.Count; i++)
			{
				if(targets[i] != null &&
					this.CanTarget(user, targets[i]))
				{
					return true;
				}
			}
			return false;
		}

		public bool CanTarget(Combatant user, Combatant target)
		{
			return TargetHelper.CheckDeath(target, this.isDead) &&
				((this.TargetSelf() && user == target) ||
				(this.TargetAll() && (!this.notSelf || user != target)) ||
				(this.TargetAlly() && !user.IsEnemy(target) && (!this.notSelf || user != target)) ||
				(this.TargetEnemy() && (user.Status.AttackAllies || user.IsEnemy(target)))) &&
				(!this.useRequirements || this.requirement.Check(target)) &&
				this.CheckOrientation(user, target);
		}

		private bool CheckOrientation(Combatant user, Combatant target)
		{
			if(user.GameObject != null && target.GameObject != null)
			{
				if(this.checkUserOrientation)
				{
					Orientation orientation = VectorHelper.GetOrientation(
						user.GameObject.transform, target.GameObject.transform, this.horizontalPlane);

					if((Orientation.Front == orientation && !this.userFront) ||
						(Orientation.Back == orientation && !this.userBack) ||
						(Orientation.Left == orientation && !this.userLeft) ||
						(Orientation.Right == orientation && !this.userRight))
					{
						return false;
					}
				}
				if(this.checkTargetOrientation)
				{
					Orientation orientation = VectorHelper.GetOrientation(
						target.GameObject.transform, user.GameObject.transform, this.horizontalPlane);

					if((Orientation.Front == orientation && !this.targetFront) ||
						(Orientation.Back == orientation && !this.targetBack) ||
						(Orientation.Left == orientation && !this.targetLeft) ||
						(Orientation.Right == orientation && !this.targetRight))
					{
						return false;
					}
				}
			}
			return true;
		}

		public void CheckTargets(Combatant user, ref List<Combatant> targets)
		{
			for(int i = 0; i < targets.Count; i++)
			{
				if(!this.CanTarget(user, targets[i]) ||
					!this.InRange(user, targets[i]))
				{
					targets.RemoveAt(i--);
				}
			}
		}

		private void CheckTargets(Combatant user, ref List<Combatant> targets, ref List<Combatant> outOfRange)
		{
			for(int i = 0; i < targets.Count; i++)
			{
				if(this.CanTarget(user, targets[i]))
				{
					if(!this.InRange(user, targets[i]))
					{
						if(!outOfRange.Contains(targets[i]))
						{
							outOfRange.Add(targets[i]);
						}
						targets.RemoveAt(i--);
					}
				}
				else
				{
					targets.RemoveAt(i--);
				}
			}
		}


		/*
		============================================================================
		Possible target functions
		============================================================================
		*/
		public List<Combatant> GetPossibleTargets(Combatant user, List<Combatant> available)
		{
			List<Combatant> list = new List<Combatant>();
			this.GetPossibleTargets(ref list, user, available);
			return list;
		}

		public void GetPossibleTargets(ref List<Combatant> list, Combatant user, List<Combatant> available)
		{
			if(available == null)
			{
				available = this.GetUseRange(user);
			}

			if(this.TargetSelf())
			{
				if(this.CanTarget(user, user))
				{
					list.Add(user);
				}
			}
			else if(this.TargetAlly())
			{
				for(int i = 0; i < available.Count; i++)
				{
					if(this.CanTarget(user, available[i]))
					{
						list.Add(available[i]);
					}
				}
			}
			else if(this.TargetEnemy())
			{
				for(int i = 0; i < available.Count; i++)
				{
					if(this.CanTarget(user, available[i]))
					{
						list.Add(available[i]);
					}
				}
			}
			else if(this.TargetAll())
			{
				for(int i = 0; i < available.Count; i++)
				{
					if(this.CanTarget(user, available[i]))
					{
						list.Add(available[i]);
					}
				}
			}
		}

		public bool HasPossibleTargets(Combatant user, List<Combatant> available)
		{
			if(this.TargetSelf())
			{
				if(this.CanTarget(user, user))
				{
					return true;
				}
			}
			else if(this.NoneTarget())
			{
				return true;
			}
			else
			{
				if(available == null)
				{
					available = this.GetUseRange(user);
				}

				if(this.TargetAlly())
				{
					for(int i = 0; i < available.Count; i++)
					{
						if(this.CanTarget(user, available[i]))
						{
							return true;
						}
					}
				}
				else if(this.TargetEnemy())
				{
					for(int i = 0; i < available.Count; i++)
					{
						if(this.CanTarget(user, available[i]))
						{
							return true;
						}
					}
				}
				else if(this.TargetAll())
				{
					for(int i = 0; i < available.Count; i++)
					{
						if(this.CanTarget(user, available[i]))
						{
							return true;
						}
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Set target functions
		============================================================================
		*/
		public bool SetTargets(BaseAction action, Combatant user, List<Combatant> targets)
		{
			bool targetsFound = false;
			ArrayHelper.GetBlank(ref action.target);

			if(this.TargetSelf() &&
				targets.Contains(user) &&
				TargetHelper.CheckDeath(user, this.isDead))
			{
				targetsFound = true;
				action.target.Add(user);
			}
			else
			{
				if(this.NoneTarget())
				{
					targetsFound = true;
					if(ORK.Battle.Grid != null &&
						this.noneSelectGridCell)
					{
						Combatant target = null;
						if(action.User.Setting.aiNearestTarget)
						{
							target = TargetHelper.GetNearestTarget(action.User, targets, this.isDead);
						}
						else
						{
							target = TargetHelper.GetRandomTarget(targets, this.isDead);
						}
						if(target.Grid.Cell != null)
						{
							action.rayTargetSet = true;
							action.rayPoint = target.Grid.Cell.transform.position;
							action.rayObject = target.Grid.Cell.gameObject;
						}
					}
					else if(this.targetRaycast.active)
					{
						GameObject targetObj = null;
						if(action.User.Setting.aiNearestTarget)
						{
							targetObj = TargetHelper.GetNearestTargetObject(action.User, targets, this.isDead);
						}
						else
						{
							targetObj = TargetHelper.GetRandomTargetObject(targets, this.isDead);
						}

						this.targetRaycast.GetAIPoint(action.User, targetObj, action);
					}
				}
				else if(this.SingleTarget())
				{
					action.outOfRange = new List<Combatant>();
					this.CheckTargets(action.User, ref targets, ref action.outOfRange);

					if(action.User.Setting.aiAutoTarget && this.useAutoTarget)
					{
						Combatant combatant = TargetHelper.GetAutoTarget(targets, this.autoTarget, this.isDead);
						if(combatant != null &&
							!action.target.Contains(combatant))
						{
							action.target.Add(combatant);
							targetsFound = true;
						}
					}
					if(!targetsFound)
					{
						if(action.User.Setting.aiNearestTarget)
						{
							Combatant combatant = TargetHelper.GetNearestTarget(action.User, targets, this.isDead);
							if(combatant != null &&
								!action.target.Contains(combatant))
							{
								action.target.Add(combatant);
								targetsFound = true;
							}
						}
						else
						{
							Combatant combatant = TargetHelper.GetRandomTarget(targets, this.isDead);
							if(combatant != null &&
								!action.target.Contains(combatant))
							{
								action.target.Add(combatant);
								targetsFound = true;
							}
						}
					}
				}
				else if(this.GroupTarget())
				{
					action.outOfRange = new List<Combatant>();
					this.CheckTargets(action.User, ref targets, ref action.outOfRange);

					if(targets.Count > 0)
					{
						action.target.AddRange(targets);
						targetsFound = true;
					}
				}
			}
			return targetsFound;
		}

		public bool SetAutoTargets(BaseAction action, List<Combatant> preferredTargets, List<Combatant> allies, List<Combatant> enemies)
		{
			ArrayHelper.GetBlank(ref action.target);

			if(this.TargetSelf() && TargetHelper.CheckDeath(action.User, this.isDead))
			{
				action.target.Add(action.User);
				return true;
			}
			else if(this.TargetAlly())
			{
				return this.GetRangeAutoTargets(action, preferredTargets, allies);
			}
			else if(this.TargetEnemy())
			{
				return this.GetRangeAutoTargets(action, preferredTargets, enemies);
			}
			else if(this.TargetAll())
			{
				List<Combatant> tmp = new List<Combatant>();
				tmp.AddRange(allies);
				tmp.AddRange(enemies);
				return this.GetRangeAutoTargets(action, preferredTargets, tmp);
			}
			return false;
		}

		private bool GetRangeAutoTargets(BaseAction action, List<Combatant> preferredTargets, List<Combatant> targets)
		{
			bool targetsFound = false;
			if(this.NoneTarget())
			{
				targetsFound = true;
				if(ORK.Battle.Grid != null &&
					this.noneSelectGridCell)
				{
					Combatant target = null;
					if(action.User.Setting.aiNearestTarget)
					{
						target = TargetHelper.GetNearestTarget(action.User, targets, this.isDead);
					}
					else
					{
						target = TargetHelper.GetRandomTarget(targets, this.isDead);
					}
					if(target.Grid.Cell != null)
					{
						action.rayTargetSet = true;
						action.rayPoint = target.Grid.Cell.transform.position;
						action.rayObject = target.Grid.Cell.gameObject;
					}
				}
				else if(this.targetRaycast.active)
				{
					GameObject targetObj = null;
					if(action.User.Setting.aiNearestTarget)
					{
						targetObj = TargetHelper.GetNearestTargetObject(action.User, targets, this.isDead);
					}
					else
					{
						targetObj = TargetHelper.GetRandomTargetObject(targets, this.isDead);
					}

					this.targetRaycast.GetAIPoint(action.User, targetObj, action);
				}
			}
			else if(this.SingleTarget())
			{
				action.outOfRange = new List<Combatant>();
				this.CheckTargets(action.User, ref targets, ref action.outOfRange);

				if(preferredTargets == null && action.User.Setting.attackLastTarget)
				{
					preferredTargets = action.User.Battle.LastTargets;
				}
				if(preferredTargets != null && preferredTargets.Count > 0)
				{
					this.CheckTargets(action.User, ref preferredTargets, ref action.outOfRange);
				}

				if(action.User.Setting.aiAutoTarget && this.useAutoTarget)
				{
					Combatant combatant = TargetHelper.GetAutoTarget(
						(preferredTargets == null || preferredTargets.Count == 0) ? targets : preferredTargets,
						this.autoTarget, this.isDead);
					if(combatant != null &&
						!action.target.Contains(combatant))
					{
						action.target.Add(combatant);
						targetsFound = true;
					}
				}
				if(!targetsFound)
				{
					if(action.User.Setting.aiNearestTarget)
					{
						Combatant combatant = TargetHelper.GetNearestTarget(action.User,
							(preferredTargets == null || preferredTargets.Count == 0) ? targets : preferredTargets, this.isDead);
						if(combatant != null &&
							!action.target.Contains(combatant))
						{
							action.target.Add(combatant);
							targetsFound = true;
						}
					}
					else
					{
						Combatant combatant = TargetHelper.GetRandomTarget(
							(preferredTargets == null || preferredTargets.Count == 0) ? targets : preferredTargets, this.isDead);
						if(combatant != null &&
							!action.target.Contains(combatant))
						{
							action.target.Add(combatant);
							targetsFound = true;
						}
					}
				}
				if(!targetsFound &&
					action.outOfRange.Count > 0 &&
					this.CanMoveIntoRange(action.User))
				{
					targetsFound = true;
				}
			}
			else if(this.GroupTarget())
			{
				action.outOfRange = new List<Combatant>();
				this.CheckTargets(action.User, ref targets, ref action.outOfRange);

				if(targets.Count > 0)
				{
					action.target.AddRange(targets);
					targetsFound = true;
				}
				if(!targetsFound &&
					action.outOfRange.Count > 0 &&
					this.CanMoveIntoRange(action.User))
				{
					targetsFound = true;
				}
			}
			return targetsFound;
		}


		/*
		============================================================================
		Static tool functions
		============================================================================
		*/
		public static TargetSettings Get(IShortcut shortcut)
		{
			// ability
			if(shortcut is AbilityShortcut)
			{
				ActiveAbility activeLevel = ((AbilityShortcut)shortcut).GetActiveLevel();
				if(activeLevel != null)
				{
					return activeLevel.targetSettings;
				}
			}
			// item
			else if(shortcut is ItemShortcut)
			{
				return ((ItemShortcut)shortcut).Setting.targetSettings;
			}
			return null;
		}

		public static TargetSettings Get(BaseAction action)
		{
			// ability
			if(action is AbilityAction)
			{
				return ((AbilityAction)action).Ability.GetActiveLevel().targetSettings;
			}
			// item
			else if(action is ItemAction)
			{
				return ((ItemAction)action).Item.Setting.targetSettings;
			}
			return null;
		}
	}
}
