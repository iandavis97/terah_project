
using System.Collections.Generic;
using UnityEngine;
using ORKFramework.Behaviours;

namespace ORKFramework
{
	public class AbilityAction : TargetRangeAction
	{
		protected AbilityShortcut ability;

		protected bool experienceGained = false;

		public AbilityAction(Combatant user, AbilityShortcut ability)
		{
			this.user = user;
			this.ability = ability;
			this.SetTargetRange(this.ability);

			ActiveAbility activeLevel = this.ability.GetActiveLevel();
			if(activeLevel != null)
			{
				this.targetDead = activeLevel.targetSettings.isDead;
				this.targetRaycast = activeLevel.targetSettings.targetRaycast;

				if(AbilityActionType.CounterAttack == this.ability.Type)
				{
					this.consumeTime = false;
				}
				else
				{
					this.actionCost = activeLevel.GetActionCost(
						this.user, this.Variables, this.SelectedData);
				}
			}

			this.CheckActionAffiliation();
		}

		public override bool IsType(ActionType t)
		{
			return (ActionType.Attack == t && AbilityActionType.BaseAttack == this.ability.Type) ||
				(ActionType.CounterAttack == t && AbilityActionType.CounterAttack == this.ability.Type) ||
				(ActionType.Ability == t && AbilityActionType.Ability == this.ability.Type);
		}

		public override IShortcut Shortcut
		{
			get { return this.ability; }
		}

		public AbilityShortcut Ability
		{
			get { return this.ability; }
		}

		public override object GetSelectedData()
		{
			return this.ability;
		}

		public override void SetTarget(Combatant t)
		{
			this.target = new List<Combatant>();
			this.target.Add(t);
		}

		public override void SetTargets(List<Combatant> t)
		{
			this.target = t;
		}

		public override bool AutoTarget(List<Combatant> preferredTargets, List<Combatant> allies, List<Combatant> enemies)
		{
			if(this.user.Status.Effects.AttackAllies)
			{
				enemies = allies;
			}
			return this.ability.GetActiveLevel().targetSettings.SetAutoTargets(this, preferredTargets, allies, enemies);
		}

		public override bool ForceFoundTargets(List<Combatant> preferredTargets, List<Combatant> allies, List<Combatant> enemies)
		{
			ActiveAbility level = this.ability.GetActiveLevel();
			if(level != null)
			{
				if(level.targetSettings.TargetSelf())
				{
					return this.AutoTarget(preferredTargets, allies, enemies);
				}
				else if(level.targetSettings.TargetEnemy())
				{
					return this.AutoTarget(preferredTargets, allies, preferredTargets);
				}
				else if(level.targetSettings.TargetAlly())
				{
					return this.AutoTarget(preferredTargets, preferredTargets, enemies);
				}
				else if(level.targetSettings.TargetAll())
				{
					return this.AutoTarget(preferredTargets, preferredTargets, preferredTargets);
				}
			}
			return false;
		}

		public override bool SetGroupTarget()
		{
			Combatant tmpTarget = this.user.Group.SelectedTargets.GetAbilityTarget(this.user, this.ability);
			if(tmpTarget != null)
			{
				this.SetTarget(tmpTarget);
				return true;
			}
			return false;
		}

		public override bool SetIndividualTarget()
		{
			Combatant tmpTarget = this.user.SelectedTargets.GetAbilityTarget(this.user, this.ability);
			if(tmpTarget != null)
			{
				this.SetTarget(tmpTarget);
				return true;
			}
			return false;
		}

		protected override void CreateStatusChangeInfos()
		{
			if(this.target != null &&
				this.target.Count > 0)
			{
				if(this.statusChangesTarget == null)
				{
					this.statusChangesTarget = new Dictionary<Combatant, StatusChangeInformation>();
				}

				for(int i = 0; i < this.target.Count; i++)
				{
					if(!this.statusChangesTarget.ContainsKey(this.target[i]))
					{
						this.statusChangesTarget.Add(this.target[i],
							new StatusChangeInformation(this.ability, this.user, this.target[i]));
					}
				}
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool CanTarget(Combatant c)
		{
			return (this.user.Status.Effects.AttackAllies ||
				this.ability.CanTarget(this.user, c));
		}


		/*
		============================================================================
		Damage dealer functions
		============================================================================
		*/
		public override void AutoActivateUserDamageDealers(bool activate)
		{
			if(this.user != null && this.user.GameObject != null)
			{
				DamageDealer[] damage = this.user.GameObject.GetComponentsInChildren<DamageDealer>();
				for(int i = 0; i < damage.Length; i++)
				{
					if((!this.user.Battle.InBattle && damage[i].autoField) ||
						(this.user.Battle.InBattle &&
							((ORK.Battle.IsTurnBased() && damage[i].autoTurnBased) ||
							(ORK.Battle.IsActiveTime() && damage[i].autoActiveTime) ||
							(ORK.Battle.IsRealTime() && damage[i].autoRealTime) ||
							(ORK.Battle.IsPhase() && damage[i].autoPhase)) &&
						(Consider.Ignore == damage[i].autoGridBattles ||
							(Consider.Yes == damage[i].autoGridBattles && ORK.Battle.Grid != null) ||
							(Consider.No == damage[i].autoGridBattles && ORK.Battle.Grid == null))))
					{
						damage[i].SetAction(activate ? this : null);

						ActiveAbility activeLevel = this.ability.GetActiveLevel();
						if(activeLevel != null)
						{
							damage[i].SetDamageActive(activate, activeLevel.activationTags);
							activeLevel.ddActivation.Add(damage[i], this.user);
						}
					}
				}
			}
		}

		public override bool CheckDamageDealer(DamageDealer dealer)
		{
			if(AbilityActionType.Ability == this.ability.Type)
			{
				for(int i = 0; i < dealer.abilityID.Length; i++)
				{
					if(dealer.abilityID[i] == this.ability.ID)
					{
						return true;
					}
				}
			}
			else if(AbilityActionType.BaseAttack == this.ability.Type)
			{
				return dealer.baseAttack;
			}
			else if(AbilityActionType.CounterAttack == this.ability.Type)
			{
				return dealer.counterAttack;
			}
			return false;
		}

		public override string[] GetActivationTags()
		{
			return this.ability.GetActiveLevel().activationTags;
		}

		public override DamageDealerActivation GetDamageDealerActivation()
		{
			return this.ability.GetActiveLevel().ddActivation;
		}


		/*
		============================================================================
		Target selection functions
		============================================================================
		*/
		public override void SetRandomTarget()
		{
			if(this.forceFoundTargets)
			{
				List<Combatant> list = new List<Combatant>();
				if(this.target != null)
				{
					list.AddRange(this.target);
					this.target = null;
				}
				if(this.outOfRange != null)
				{
					list.AddRange(this.outOfRange);
					this.outOfRange = null;
				}

				ActiveAbility level = this.ability.GetActiveLevel();
				if(level != null)
				{
					if(level.targetSettings.TargetSelf())
					{
						this.AutoTarget(list,
							ORK.Game.Combatants.Get(this.user, true, Range.Battle,
								Consider.No, Consider.Ignore, Consider.Ignore, null),
							ORK.Game.Combatants.Get(this.user, true, Range.Battle,
								Consider.Yes, Consider.Ignore, Consider.Ignore, null));
					}
					else if(level.targetSettings.TargetEnemy())
					{
						this.AutoTarget(list,
							ORK.Game.Combatants.Get(this.user, true, Range.Battle,
								Consider.No, Consider.Ignore, Consider.Ignore, null),
							list);
					}
					else if(level.targetSettings.TargetAlly())
					{
						this.AutoTarget(list, list,
							ORK.Game.Combatants.Get(this.user, true, Range.Battle,
								Consider.Yes, Consider.Ignore, Consider.Ignore, null));
					}
					else if(level.targetSettings.TargetAll())
					{
						this.AutoTarget(list, list, list);
					}
				}
			}
			else
			{
				this.AutoTarget(null,
					ORK.Game.Combatants.Get(this.user, true, Range.Battle,
						Consider.No, Consider.Ignore, Consider.Ignore, null),
					ORK.Game.Combatants.Get(this.user, true, Range.Battle,
						Consider.Yes, Consider.Ignore, Consider.Ignore, null));
			}
		}

		public override bool TargetNone()
		{
			return this.ability.IsNoneTarget();
		}


		/*
		============================================================================
		Range functions
		============================================================================
		*/
		public override bool InRange(Combatant t)
		{
			if(this.user != null && t != null &&
				!this.ability.InRange(this.user, t))
			{
				return false;
			}
			return true;
		}

		public override bool InRange(Vector3 position)
		{
			if(this.user != null)
			{
				return this.ability.GetActiveLevel().targetSettings.InUseRange(this.user, position);
			}
			return true;
		}


		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		public override bool CanUse()
		{
			return this.user != null && !this.user.Status.IsDead &&
				this.ability.CanUse(this.user, false, this.userConsumeDone) &&
				(this.ability.IsNoneTarget() || this.target.Count > 0);
		}

		public override void ActionAdded()
		{
			if(ORK.ConsoleSettings.displayActions)
			{
				this.CreateStatusChangeInfos();

				if(this.ability.Setting.ownConsoleAddAction)
				{
					this.ability.Setting.consoleAddAction.Print(this.user, this.target,
						this.statusChangesTarget, this.ability);
				}
				else
				{
					ORK.ConsoleSettings.actionAddAbility.Print(this.user, this.target,
						this.statusChangesTarget, this.ability);
				}
			}
		}

		protected override void ActionStartSetup()
		{
			if(ORK.BattleTexts.showInfo)
			{
				if(this.ability.Setting.ownBattleInfoText)
				{
					this.ability.Setting.battleInfoText.Show(this.user, this.ability.GetName());
				}
				else if(AbilityActionType.Ability == this.ability.Type)
				{
					ORK.BattleTexts.abilityInfo.Show(this.user, this.ability.GetName());
				}
				else if(AbilityActionType.BaseAttack == this.ability.Type)
				{
					ORK.BattleTexts.attackInfo.Show(this.user, this.ability.GetName());
				}
				else if(AbilityActionType.CounterAttack == this.ability.Type)
				{
					ORK.BattleTexts.counterInfo.Show(this.user, this.ability.GetName());
				}
			}

			if(ORK.ConsoleSettings.displayActions)
			{
				this.CreateStatusChangeInfos();

				if(this.ability.Setting.ownConsoleAction)
				{
					this.ability.Setting.consoleAction.Print(this.user, this.target,
						this.statusChangesTarget, this.ability);
				}
				else
				{
					ORK.ConsoleSettings.actionAbility.Print(this.user, this.target,
						this.statusChangesTarget, this.ability);
				}
			}

			ActiveAbility activeLevel = this.ability.GetActiveLevel();

			// get affected range targets
			this.target = this.GetTargetsWithAffectRange(AffectRangeType.Execution,
				activeLevel.targetSettings, this.target);

			if(UseCostAutoConsumeType.Always == activeLevel.autoConsumeType ||
				(UseCostAutoConsumeType.WithoutTargets == activeLevel.autoConsumeType &&
				(this.target == null || this.target.Count == 0)))
			{
				this.ConsumeCosts();
			}
			if(!user.GetAbilityAnimation(this.ability.ID, this.ability.UseLevel, ref this.events))
			{
				activeLevel.battleAnimation.GetBattleAnimation(this.user, ref this.events);
			}
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate)
		{
			this.results = new ActionResults();

			// get affected range targets
			ts = this.GetTargetsWithAffectRange(AffectRangeType.Calculation,
				this.ability.GetActiveLevel().targetSettings, ts);

			if(!this.blockBattleCamera &&
				!ORK.BattleSettings.camera.IsNone &&
				!ORK.BattleSettings.camera.latestDamageActionBlock.IsBlocked(this))
			{
				if(ts.Count == 1 &&
					ts[0] != null &&
					ts[0].GameObject != null)
				{
					ORK.BattleSettings.camera.SetLatestDamage(
						this.user.GameObject != null ? this.user.GameObject.transform : null,
						ts[0].GameObject.transform);
				}
				else if(ts.Count > 1)
				{
					ORK.BattleSettings.camera.SetLatestDamage(
						this.user.GameObject != null ? this.user.GameObject.transform : null,
						ORK.Battle.GetGroupCenter(ts).transform);
				}
			}

			if(this.user != null &&
				(!this.user.Status.IsDead ||
					this.ability.Setting.allowDeadUser) &&
				ts.Count > 0 &&
				ts[0] != null)
			{
				this.CheckBestiary(ts);

				this.ability.Setting.Use(this.user, ts, animate, this, this.ability.Type,
					AbilityActionType.CounterAttack != this.ability.Type,
					!this.userConsumeDone, this.ability.GetLevel(), damageFactor, this.damageMultiplier,
					this.Variables, this.SelectedData);

				// use level up only once
				if(!this.experienceGained)
				{
					// ability
					if(this.user.Abilities.CanGetUseExperience(this.ability))
					{
						this.ability.UsesExperience(this.user, 1);
					}
					// weapons
					if(AbilityActionType.BaseAttack == this.ability.Type ||
						AbilityActionType.CounterAttack == this.ability.Type)
					{
						for(int i = 0; i < ORK.EquipmentParts.Count; i++)
						{
							if(this.user.Equipment[i].Equipped)
							{
								this.user.Equipment[i].Equipment.UsesExperience(this.user, 1);
							}
						}
					}
					this.experienceGained = true;
				}
				this.userConsumeDone = true;
			}
		}

		public override void ConsumeCosts()
		{
			if(this.ability != null && this.user != null)
			{
				ActiveAbility activeLevel = this.ability.GetActiveLevel();
				if(activeLevel != null)
				{
					activeLevel.UseCosts(this.user, this.Variables, this.SelectedData);
				}
			}
			this.userConsumeDone = true;
		}

		protected override void ActionEndSetup()
		{
			// set last ability
			this.user.Abilities.LastAbilityID = this.ability.ID;

			// update base attack index
			if(AbilityActionType.BaseAttack == this.ability.Type)
			{
				this.user.Abilities.NextBaseAttack();
			}

			// set reuse and delay
			ActiveAbility lvl = this.ability.GetActiveLevel();
			if(lvl != null)
			{
				lvl.SetReuseAfter(this.user, this.ability.ID, this.SelectedData);
			}
		}
	}
}
