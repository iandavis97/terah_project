
using ORKFramework;
using ORKFramework.AI;
using ORKFramework.Behaviours;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI.Steps
{
	[ORKEditorHelp("Change Object Variables", "Changes a combatant's object variables " +
		"(requires an 'Object Variables' component attached to the combatant's game object).", "")]
	[ORKNodeInfo("Variable")]
	public class ChangeObjectVariablesStep : BaseAIStep
	{
		[ORKEditorHelp("Use Found Targets", "Change the object variables on the targets found by previous steps.\n" +
			"If disabled, you need to define the target that will be changed.", "")]
		public bool onFound = false;

		[ORKEditorHelp("Target", "Select which combatant's or combatant group's object variables will be changed:\n" +
			"- Self: The combatant itself.\n" +
			"- Ally: The combatant's allies.\n" +
			"- Enemy: The combatant's enemies.\n" +
			"- All: All combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("onFound", false, endCheckGroup=true)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// variables
		[ORKEditorInfo(separator=true)]
		public VariableSetter change = new VariableSetter();

		public ChangeObjectVariablesStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			this.Change(this.onFound ?
				foundTargets :
				this.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					user, allies, enemies, foundTargets));
			currentStep = this.next;
			return null;
		}

		private void Change(List<Combatant> list)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null && list[i].GameObject != null)
				{
					ObjectVariablesComponent comp = ComponentHelper.GetInChildren<ObjectVariablesComponent>(list[i].GameObject);
					if(comp != null)
					{
						this.change.SetVariables(comp.GetHandler());
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.onFound ? "Found Targets" : this.targetType.ToString();
		}
	}

	[ORKEditorHelp("Check Object Variables", "Checks a combatant's object variables " +
		"(requires an 'Object Variables' component attached to the combatant's game object).\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Variable", "Check")]
	public class CheckObjectVariablesStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// variables
		[ORKEditorInfo(separator=true)]
		public VariableCondition condition = new VariableCondition();

		public CheckObjectVariablesStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(ref any, tmp, foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, foundTargets, foundTargets);
			}

			// check all possible targets
			this.Check(ref any,
				this.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					user, allies, enemies, foundTargets),
				foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check object variables of all possible targets, add to found targets
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null && list[i].GameObject != null)
				{
					ObjectVariablesComponent comp = ComponentHelper.GetInChildren<ObjectVariablesComponent>(list[i].GameObject);
					if(comp != null && this.condition.CheckVariables(comp.GetHandler()))
					{
						any = true;
						if(!this.dontAddTargets &&
							!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found";
		}
	}

	[ORKEditorHelp("Check Game Variables", "Checks game variable conditions.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Doesn't influence the target list.", "")]
	[ORKNodeInfo("Variable", "Check")]
	public class CheckGameVariablesStep : BaseAICheckStep
	{
		// variables
		public VariableCondition condition = new VariableCondition();

		public CheckGameVariablesStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			if(this.condition.CheckVariables())
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}
	}

	[ORKEditorHelp("Game Variable Fork", "Checks a single game variable for certain values.\n" +
		"If a variable condition is valid, it's next step will be executed.\n" +
		"If no variable condition is valid, 'Failed' will be executed.", "")]
	[ORKNodeInfo("Check", "Variable")]
	public class GameVariableForkStep : BaseAIStep
	{
		// variable
		[ORKEditorInfo(labelText="Variable Key")]
		public StringValue key = new StringValue();

		[ORKEditorArray(false, "Add Condition", "Adds a new game variable condition.", "",
			"Remove", "Removes the game variable condition.", "", isMove=true, isCopy=true,
			noRemoveCount=1, foldout=true, foldoutText=new string[] {
				"Variable Condition", "Define the game variable condition that must be valid.", ""
		})]
		public CheckVariableAINextNode[] condition = new CheckVariableAINextNode[] {new CheckVariableAINextNode()};

		public GameVariableForkStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			currentStep = this.next;

			string varKey = this.key.GetValue();

			for(int i = 0; i < this.condition.Length; i++)
			{
				if(this.condition[i].Check(varKey, ORK.Game.Variables))
				{
					currentStep = this.condition[i].next;
					break;
				}
			}

			return null;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.key.GetInfoText();
		}

		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return "Condition " + (index - 1) + ": " + this.condition[index - 1].GetInfoText();
			}
			return "";
		}

		public override int GetNextCount()
		{
			return this.condition.Length + 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.condition[index - 1].next;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.condition[index - 1].next = next;
			}
		}
	}

	[ORKEditorHelp("Get Object Variable", "The combatant with the highest or lowest " +
		"float object variable will be added to the target list.\n" +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Variable")]
	public class GetObjectVariableStep : BaseAIStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// status
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public StringValue key = new StringValue();

		[ORKEditorHelp("Highest/Lowest", "If enabled, the combatant with the highest value of the " +
			"defined float object variable will be added to the target list.\n" +
			"If disabled, the combatant with the lowest value of the " +
			"defined float object variable will be added to the target list.", "")]
		public bool getHighest = false;

		[ORKEditorHelp("Variable Must Exist", "The float object variable must exist on the combatant. " +
			"If the variable doesn't exist, the combatant wont be added to the list.\n" +
			"If disabled, the default value (0) will be used.", "")]
		public bool variableMustExist = false;

		public GetObjectVariableStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			if(FoundTargets.Clear == this.foundType)
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(user, tmp, foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(user, foundTargets, foundTargets);
			}

			// check all possible targets
			this.Check(user,
				this.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					user, allies, enemies, foundTargets),
				foundTargets);

			currentStep = this.next;
			return null;
		}

		private void Check(Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			int found = -1;
			float tmpVal = this.getHighest ? float.MinValue : float.MaxValue;
			string tmpKey = this.key.GetValue();

			// check for highest/lowest status value
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null && list[i].GameObject != null)
				{
					ObjectVariablesComponent comp = ComponentHelper.
						GetInChildren<ObjectVariablesComponent>(list[i].GameObject);
					if(comp != null &&
						(!this.variableMustExist ||
						comp.GetHandler().GetFloatKeys().Contains(tmpKey)))
					{
						float objValue = comp.GetHandler().GetFloat(tmpKey);
						if((this.getHighest && tmpVal < objValue) ||
							(!this.getHighest && tmpVal > objValue))
						{
							tmpVal = objValue;
							found = i;
						}
					}
				}
			}

			if(found >= 0 && !foundTargets.Contains(list[found]))
			{
				foundTargets.Add(list[found]);
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.getHighest ? "Highest " : "Lowest ") +
				this.key.GetInfoText();
		}
	}
}
