﻿
using UnityEngine;
using ORKFramework.AI;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class AIBehaviourSlotBMItem : BMItem
	{
		private int slotIndex = -1;

		private BattleMenuItem parent;

		public AIBehaviourSlotBMItem(ChoiceContent content, int slotIndex, BattleMenuItem parent)
		{
			this.content = content;
			this.slotIndex = slotIndex;
			this.parent = parent;
		}

		public override bool Accepted(Combatant owner)
		{
			if(owner.BattleMenu != null)
			{
				AIBehaviourBattleMenuItem settings = (AIBehaviourBattleMenuItem)this.parent.settings;
				BattleMenuMode mode = BattleMenuMode.List;

				List<BMItem> list = new List<BMItem>();

				// list AI behaviour slots
				if(this.slotIndex == -1)
				{
					mode = BattleMenuMode.AIBehaviourSlot;

					for(int i = 0; i < owner.AI.AIBehaviourSlot.Length; i++)
					{
						list.Add(new AIBehaviourSlotBMItem(
							settings.GetChoiceContent(owner, i),
							i, this.parent));
					}
				}
				// list AI types
				else if(settings.showTypes)
				{
					mode = BattleMenuMode.AIType;

					List<int> types = owner.Inventory.AICollection.GetAIBehaviourTypes(
						settings.limitAIType ? settings.typeID : -1);
					settings.typeSorter.Sort(ref types, ORKDataType.AbilityType);

					for(int i = 0; i < types.Count; i++)
					{
						AIType aiType = ORK.AITypes.Get(types[i]);
						TypeBMItem tmp = new TypeBMItem(
							owner.BattleMenu.Settings.contentLayout.GetChoiceContent(aiType),
							types[i], this.parent, false);
						tmp.slotIndex = this.slotIndex;
						tmp.hasSubTypes = aiType.HasSubTypes();
						list.Add(tmp);
					}
				}
				// list AI behaviours
				else
				{
					mode = BattleMenuMode.AIBehaviour;

					List<AIBehaviourShortcut> behaviours = owner.Inventory.AICollection.GetAIBehavioursByType(-1, true);

					for(int i = 0; i < behaviours.Count; i++)
					{
						list.Add(new AIBehaviourBMItem(this.slotIndex, behaviours[i],
							owner.BattleMenu.Settings.contentLayout.GetChoiceContent(behaviours[i])));
					}

					if(settings.unequipButton.UnequipFirst)
					{
						list.Insert(0, new AIBehaviourBMItem(this.slotIndex, null,
							settings.unequipButton.GetButton(owner.BattleMenu.Settings.contentLayout)));
					}
					else if(settings.unequipButton.UnequipLast)
					{
						list.Add(new AIBehaviourBMItem(this.slotIndex, null,
							settings.unequipButton.GetButton(owner.BattleMenu.Settings.contentLayout)));
					}
				}

				owner.BattleMenu.Settings.AddBack(list);

				owner.BattleMenu.Show(list, 0, mode);
				return true;
			}
			return false;
		}
	}
}
