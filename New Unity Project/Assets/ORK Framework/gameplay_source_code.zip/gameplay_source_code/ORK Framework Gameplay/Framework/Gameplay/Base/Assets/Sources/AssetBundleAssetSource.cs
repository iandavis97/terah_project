﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface IAssetBundleAssetSource
	{
		string AssetName
		{
			get;
			set;
		}

		AssetBundleSettings AssetBundle
		{
			get;
			set;
		}
	}

	[ORKEditorSettingInfo("Asset Bundle", "Uses an asset stored in an asset bundle.\n" +
		"Define the name of the asset, asset bundle and path the asset bundle is stored in.", "")]
	public class AssetBundleAssetSource<T> : BaseAssetSource<T>, IAssetBundleAssetSource where T : UnityEngine.Object
	{
		[ORKEditorHelp("Asset", "Select the asset that will be used.\n" +
			"The asset has to be assigned to an asset bundle, ORK will fill the 'Asset Name' and " +
			"'Asset Bundle Name' fields with the according information.\n" +
			"The asset isn't saved, but you can use this to find the asset bundle it is part of.", "")]
		[ORKEditorInfo(hide=true, hideName=true, setWidth=true, fieldWidth=150)]
		public T asset;

		[ORKEditorHelp("Asset Name", "Define the name of the asset in the asset bundle.", "")]
		[ORKEditorInfo(indent=true, expandWidth=true)]
		public string assetName = "";

		[ORKEditorInfo(indent=true)]
		public AssetBundleSettings assetBundle = new AssetBundleSettings();

		public AssetBundleAssetSource()
		{

		}

		public override DataObject GetData()
		{
			DataObject data = new DataObject();
			data.Set("assetName", this.assetName);
			data.Set("assetBundle", this.assetBundle.GetData());
			data.Set(DataSerializer.TYPE, this.GetTypeNamespace() + this.GetType().Name);
			return data;
		}

		public override T Get()
		{
			return AssetSourceCache.Instance.GetFromAssetBundle<T>(
				this.assetBundle.GetBundlePath(),
				this.assetName);
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public override void EditorAfter(bool assetChanged, string assetPath)
		{
			if(assetChanged)
			{
				if(this.asset == null ||
					string.IsNullOrEmpty(assetPath))
				{
					this.asset = null;
					this.assetName = "";
					this.assetBundle.assetBundleName = "";
				}
				else
				{
					this.assetName = this.asset.name;
					this.assetBundle.assetBundleName = assetPath;
				}
			}
		}

		public override bool EditorHasAssetField
		{
			get { return true; }
		}

		public override Object EditorAsset
		{
			get { return this.asset; }
			set { this.asset = value as T; }
		}

		public string AssetName
		{
			get { return this.assetName; }
			set { this.assetName = value; }
		}

		public AssetBundleSettings AssetBundle
		{
			get { return this.assetBundle; }
			set { this.assetBundle = value; }
		}

		public override string GetInfoText()
		{
			return this.assetName + " (" + this.AssetBundle.Name + ")";
		}
	}
}
