﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridCombatantPlacementInfo : BaseData
	{
		// show settings
		[ORKEditorHelp("Is Accept Dialogue", "This combatant info box is used as accept dialogue to accept a selected combatant.\n" +
			"When the dialogue is accepted, the combatant will be used for placement.\n" +
			"Please note that only the first combatant info box with 'Is Accept Dialogue' enabled will be used as accept dialogue, " +
			"the other boxes will only show information.", "")]
		public bool isAcceptDialogue = false;

		[ORKEditorHelp("During Selection", "Show this combatant info box while selecting a combatant.", "")]
		public bool showDuringSelection = false;

		[ORKEditorHelp("During Placement", "Show this combatant info box while selecting a combatant's cell for placement.", "")]
		public bool showDuringPlacement = false;

		[ORKEditorHelp("During Orientation", "Show this combatant info box while selecting a combatant's orientation.", "")]
		public bool showDuringOrientation = false;


		// info box
		[ORKEditorInfo(separator=true)]
		public BestiaryChoice info = new BestiaryChoice();

		public GridCombatantPlacementInfo()
		{

		}

		public void Show(Combatant combatant)
		{
			if(combatant != null)
			{
				this.info.Show(combatant, false, false, null, null);
			}
			else
			{
				this.Close();
			}
		}

		public void ShowAccept(Combatant combatant, bool canCancel, NotifyBool callback)
		{
			if(combatant != null)
			{
				this.info.Show(combatant, true, canCancel, callback, null);
			}
			else
			{
				this.Close();
			}
		}

		public void Close()
		{
			this.info.Close();
		}
	}
}
