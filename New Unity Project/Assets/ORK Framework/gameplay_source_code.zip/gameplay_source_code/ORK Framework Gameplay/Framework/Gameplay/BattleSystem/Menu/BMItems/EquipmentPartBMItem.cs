
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class EquipmentPartBMItem : BMItem
	{
		private int partID = -1;

		private BattleMenuItem parent;

		public EquipmentPartBMItem(ChoiceContent content, int partID, BattleMenuItem parent)
		{
			this.content = content;
			this.partID = partID;
			this.parent = parent;
		}

		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			// sub menu
			if(this.partID == -1)
			{
				this.content.Active = !owner.Status.BlockEquipmentChange;
			}
			else
			{
				this.content.Active = !owner.Status.BlockEquipmentChange &&
					owner.Equipment[this.partID].Available &&
					!owner.Equipment[this.partID].Locked &&
					owner.Inventory.GetEquipmentByPart(this.partID, true, true).Count > 0;
			}
			return tmp != this.content.Active;
		}

		public override bool Accepted(Combatant owner)
		{
			if(owner.BattleMenu != null)
			{
				EquipmentBattleMenuItem settings = (EquipmentBattleMenuItem)this.parent.settings;
				BattleMenuMode mode = BattleMenuMode.List;

				List<BMItem> list = new List<BMItem>();

				// list equipment parts
				if(this.partID == -1)
				{
					mode = BattleMenuMode.EquipmentPart;

					List<int> parts = owner.Equipment.GetAvailableParts();
					for(int i = 0; i < parts.Count; i++)
					{
						if(!ORK.EquipmentParts.Get(parts[i]).hidden)
						{
							list.Add(new EquipmentPartBMItem(
								settings.GetChoiceContent(owner, parts[i]),
								parts[i], this.parent));
						}
					}
				}
				// list equipment
				else
				{
					mode = BattleMenuMode.Equipment;

					List<EquipShortcut> equips = owner.Inventory.GetEquipmentByPart(this.partID, true, true);

					for(int i = 0; i < equips.Count; i++)
					{
						list.Add(new EquipmentBMItem(this.partID, equips[i],
							owner.BattleMenu.Settings.contentLayout.GetChoiceContent(equips[i])));
					}
				}
				
				owner.BattleMenu.Settings.AddBack(list);

				owner.BattleMenu.Show(list, 0, mode);
				return true;
			}
			return false;
		}
	}
}
