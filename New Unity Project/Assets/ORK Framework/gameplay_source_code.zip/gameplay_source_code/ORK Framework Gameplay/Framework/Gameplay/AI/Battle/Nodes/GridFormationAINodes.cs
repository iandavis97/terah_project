﻿
using ORKFramework;
using ORKFramework.AI;
using ORKFramework.Behaviours;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI.Steps
{
	[ORKEditorHelp("Use Grid Formation", "Initiates a defined grid formation for the user's group or the found targets.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Grid Formation")]
	public class UseGridFormationStep : BaseAIStep
	{
		[ORKEditorHelp("Grid Formation", "Select the grid formation that will be used.", "")]
		[ORKEditorInfo(ORKDataType.BattleGridFormation)]
		public int formationID = 0;

		[ORKEditorHelp("Use On Target", "Use the grid formation on the found target(s).\n" +
			"Uses the target as the leader.", "")]
		public bool useOnTarget = false;

		public UseGridFormationStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(ORK.Battle.Grid != null)
			{
				if(this.useOnTarget)
				{
					for(int i = 0; i < call.foundTargets.Count; i++)
					{
						if(call.foundTargets[i] != null)
						{
							call.foundTargets[i].Group.GridFormation.InitFormation(this.formationID, call.foundTargets[i]);
						}
					}
				}
				else
				{
					call.user.Group.GridFormation.InitFormation(this.formationID, call.user);
				}
			}
			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.BattleGridFormations.GetName(this.formationID) +
				(this.useOnTarget ? " on targets" : " on user");
		}
	}

	[ORKEditorHelp("Break Grid Formation", "Ends the current or only a defined grid formation of the user's group.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Grid Formation")]
	public class BreakGridFormationStep : BaseAIStep
	{
		[ORKEditorHelp("Any Formation", "Ends the current grid formation of the user's group.", "")]
		public bool any = true;

		[ORKEditorHelp("Grid Formation", "Select the grid formation that will be used.", "")]
		[ORKEditorInfo(ORKDataType.BattleGridFormation)]
		[ORKEditorLayout("any", false, endCheckGroup=true)]
		public int formationID = 0;

		public BreakGridFormationStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(ORK.Battle.Grid != null &&
				call.user.Group.InFormation)
			{
				call.user.Group.GridFormation.EndFormation(this.any ? -1 : this.formationID);
			}
			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.any ? "Any" : ORK.BattleGridFormations.GetName(this.formationID);
		}
	}

	[ORKEditorHelp("Update Grid Formation", "Updates the user group's grid formation (formation positions, filling empty positions).\n" +
		"Please note that this also happens automatically - the formation positions are updated when the leader's cell changes and " +
		"empty positions are filled when a combatant is removed from the formation (e.g. upon death or leaving group).\n" +
		"Only used in grid battles and when the user's group is using a grid formation.", "")]
	[ORKNodeInfo("Grid Formation")]
	public class UpdateGridFormationStep : BaseAIStep
	{
		[ORKEditorHelp("Update Positions", "Update the cell positions of the individual grid formation positions.", "")]
		public bool updatePositions = true;

		[ORKEditorHelp("Fill Positions", "Find combatants for empty grid formation positions.", "")]
		public bool fillPositions = false;

		public UpdateGridFormationStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(ORK.Battle.Grid != null &&
				call.user.Group.InFormation)
			{
				if(this.updatePositions)
				{
					call.user.Group.GridFormation.UpdatePositionCoords();
				}
				if(this.fillPositions)
				{
					call.user.Group.GridFormation.FindPositionCombatants();
				}
				call.user.Group.GridFormation.UpdateHighlight();
			}
			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.updatePositions && this.fillPositions ? "Update and fill positions" :
				((this.updatePositions ? "Update positions" : "") +
				(this.fillPositions ? "Fill positions" : ""));
		}
	}

	[ORKEditorHelp("Use Grid Formation Rotation", "Uses the rotations on the grid formation positions (e.g. using leader's rotation).\n" +
		"Changes the rotation of the user or all combatants of the formation that are on their formation position cells.\n" +
		"Only used in grid battles and when the user's group is using a grid formation.", "")]
	[ORKNodeInfo("Grid Formation")]
	public class UseGridFormationRotationStep : BaseAIStep
	{
		[ORKEditorHelp("Whole Formation", "All combatants that are part of the formation " +
			"(and on their formation position cells) will use the rotation.\n" +
			"If disabled, only the user will rotate.", "")]
		public bool wholeFormation = true;

		public UseGridFormationRotationStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(ORK.Battle.Grid != null &&
				call.user.Group.InFormation)
			{
				if(this.wholeFormation)
				{
					call.user.Group.GridFormation.UsePositionRotations();
				}
				else
				{
					call.user.Group.GridFormation.UsePositionRotations(call.user);
				}
			}
			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.wholeFormation ? "Whole Formation" : "User";
		}
	}

	[ORKEditorHelp("In Grid Formation", "Checks if the user's group currently is in any or a defined grid formation, " +
		"or checks if a combatant is part of a formation.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Grid Formation", "Check")]
	public class InGridFormationStep : BaseAICheckStep
	{
		[ORKEditorHelp("Check Combatant", "Checks if a combatant is part of a formation.", "")]
		public bool checkCombatant = false;


		// combatant
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("checkCombatant", true)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// formation
		[ORKEditorHelp("Any Formation", "Checks if the user's group is in any grid formation.", "")]
		[ORKEditorLayout(elseCheckGroup=true)]
		public bool anyFormation = true;

		[ORKEditorHelp("Grid Formation", "Select the grid formation that will be used.", "")]
		[ORKEditorInfo(ORKDataType.BattleGridFormation)]
		[ORKEditorLayout("anyFormation", false, endCheckGroup=true, endGroups=2)]
		public int formationID = 0;

		public InGridFormationStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;

			if(ORK.Battle.Grid != null)
			{
				if(this.checkCombatant)
				{
					if(FoundTargets.Clear == this.foundType)
					{
						call.foundTargets.Clear();
					}
					else if(FoundTargets.Check == this.foundType)
					{
						List<Combatant> tmp = new List<Combatant>(call.foundTargets);
						call.foundTargets.Clear();
						this.Check(ref any, tmp, call.foundTargets);
					}
					else if(FoundTargets.CheckKeep == this.foundType)
					{
						this.Check(ref any, call.foundTargets, call.foundTargets);
					}

					// check all possible targets
					this.Check(ref any,
						BattleAI.GetTargetList(this.targetType,
							this.targetExcludeSelf, this.targetExcludeFoundTargets,
							call),
						call.foundTargets);
				}
				else if(call.user.Group.InFormation &&
					(this.anyFormation || call.user.Group.GridFormation.IsFormation(this.formationID)))
				{
					any = true;
				}
			}

			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}

			return null;
		}

		private void Check(ref bool any, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					list[i].Group.InFormation &&
					list[i].Group.GridFormation.IsInFormation(list[i]))
				{
					any = true;
					if(!this.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.checkCombatant ?
				(this.targetType + ", " + this.foundType + " found") :
				(this.anyFormation ? "Any" : ORK.BattleGridFormations.GetName(this.formationID));
		}
	}

	[ORKEditorHelp("Is Grid Formation Leader", "Checks if a combatant is the leader of a grid formation.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Grid Formation", "Check")]
	public class IsGridFormationLeaderStep : BaseAICheckStep
	{
		// combatant
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		public IsGridFormationLeaderStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;
			if(ORK.Battle.Grid != null)
			{
				if(FoundTargets.Clear == this.foundType)
				{
					call.foundTargets.Clear();
				}
				else if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(call.foundTargets);
					call.foundTargets.Clear();
					this.Check(ref any, tmp, call.foundTargets);
				}
				else if(FoundTargets.CheckKeep == this.foundType)
				{
					this.Check(ref any, call.foundTargets, call.foundTargets);
				}

				// check all possible targets
				this.Check(ref any,
					BattleAI.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						call),
					call.foundTargets);
			}

			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}

			return null;
		}

		private void Check(ref bool any, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					list[i].Group.InFormation &&
					list[i].Group.GridFormation.Leader == list[i])
				{
					any = true;
					if(!this.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found";
		}
	}

	[ORKEditorHelp("In Grid Formation Position", "Checks if a combatant is on the assigned grid formation position cell.\n" +
		"The formation leader is always in formation position.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Grid Formation", "Check")]
	public class InGridFormationPositionStep : BaseAICheckStep
	{
		// combatant
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		public InGridFormationPositionStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;
			if(ORK.Battle.Grid != null)
			{
				if(FoundTargets.Clear == this.foundType)
				{
					call.foundTargets.Clear();
				}
				else if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(call.foundTargets);
					call.foundTargets.Clear();
					this.Check(ref any, tmp, call.foundTargets);
				}
				else if(FoundTargets.CheckKeep == this.foundType)
				{
					this.Check(ref any, call.foundTargets, call.foundTargets);
				}

				// check all possible targets
				this.Check(ref any,
					BattleAI.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						call),
					call.foundTargets);
			}

			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}

			return null;
		}

		private void Check(ref bool any, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					list[i].Group.InFormation &&
					list[i].Group.GridFormation.IsInPosition(list[i]))
				{
					any = true;
					if(!this.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found";
		}
	}

	[ORKEditorHelp("Grid Formation Finished", "Checks if all combatants reached their grid formation position.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Grid Formation", "Check")]
	public class GridFormationFinishedStep : BaseAICheckStep
	{
		// combatant
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// settings
		[ORKEditorHelp("Only Filled Positions", "Only positions that have a combatant assigned will be checked.\n" +
			"If disabled, an empty position will result in failure.", "")]
		public bool onlyFilled = true;

		[ORKEditorHelp("Check Rotation", "Checks if the combatant's rotation matches the rotation defined by the position " +
			"(e.g. matching the leader's rotatin).\n" +
			"If disabled, rotations are ignored.", "")]
		public bool checkRotation = false;

		[ORKEditorHelp("Check Grid Distance", "Only positions where the combatant is " +
			"a defined grid distance away from the cell will be checked.\n" +
			"If the combatant is farther away, the position will be ignored.", "")]
		public bool checkGridDistance = false;

		[ORKEditorInfo(separator=true, labelText="Distance")]
		[ORKEditorLayout("checkGridDistance", true, endCheckGroup=true, autoInit=true)]
		public AIFloat distance;

		public GridFormationFinishedStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;
			if(ORK.Battle.Grid != null)
			{
				if(FoundTargets.Clear == this.foundType)
				{
					call.foundTargets.Clear();
				}
				else if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(call.foundTargets);
					call.foundTargets.Clear();
					this.Check(ref any, call, tmp, call.foundTargets);
				}
				else if(FoundTargets.CheckKeep == this.foundType)
				{
					this.Check(ref any, call, call.foundTargets, call.foundTargets);
				}

				// check all possible targets
				this.Check(ref any, call,
					BattleAI.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						call),
					call.foundTargets);
			}

			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}

			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					list[i].Group.InFormation &&
					list[i].Group.GridFormation.PositionsFilled(this.onlyFilled, this.checkRotation,
						(int)(this.checkGridDistance ? this.distance.GetValue(call, list[i], list[i]) : -1)))
				{
					any = true;
					if(!this.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found";
		}
	}

	[ORKEditorHelp("Grid Formation Possible", "Checks if a combatant group's formation is possible " +
		"or a defined grid formation is possible at a combatant's cell.\n" +
		"A formation isn't possible if one of the position cells is blocked or invalid (outside the grid)." +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Grid Formation", "Check")]
	public class GridFormationPossibleStep : BaseAICheckStep
	{
		// combatant
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// settings
		[ORKEditorHelp("Use Current Formation", "Uses the combatant group's current formation for the check.\n" +
			"The check fails if the combatant's group isn't in formation.\n"+
			"If disabled, a defined grid formation is used.", "")]
		public bool useCurrentFormation = true;

		[ORKEditorHelp("Grid Formation", "Select the grid formation that will be used.", "")]
		[ORKEditorInfo(ORKDataType.BattleGridFormation)]
		[ORKEditorLayout("useCurrentFormation", false, endCheckGroup=true)]
		public int formationID = 0;

		public GridFormationPossibleStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			bool any = false;
			if(ORK.Battle.Grid != null)
			{
				if(FoundTargets.Clear == this.foundType)
				{
					call.foundTargets.Clear();
				}
				else if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(call.foundTargets);
					call.foundTargets.Clear();
					this.Check(ref any, tmp, call.foundTargets);
				}
				else if(FoundTargets.CheckKeep == this.foundType)
				{
					this.Check(ref any, call.foundTargets, call.foundTargets);
				}

				// check all possible targets
				this.Check(ref any,
					BattleAI.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						call),
					call.foundTargets);
			}

			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}

			return null;
		}

		private void Check(ref bool any, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.useCurrentFormation)
					{
						if(list[i].Group.InFormation &&
							list[i].Group.GridFormation.IsFormationPossible())
						{
							any = true;
							if(!this.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
					else if(ORK.BattleGridFormations.Get(this.formationID).IsFormationPossible(list[i]))
					{
						any = true;
						if(!this.dontAddTargets &&
							!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found: " +
				(this.useCurrentFormation ? "Current" :
					ORK.BattleGridFormations.GetName(this.formationID));
		}
	}

	[ORKEditorHelp("Reassign Formation Position", "Reassigns the user's grid formation position with a new combatant.\n" +
		"The user will be assigned to a new formation position afterwards (if possible).\n" +
		"Only used in grid battles and when the user's group is using a grid formation.", "")]
	[ORKNodeInfo("Grid Formation")]
	public class ReassignGridFormationPositionStep : BaseAIStep
	{
		public ReassignGridFormationPositionStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(ORK.Battle.Grid != null &&
				call.user.Group.InFormation)
			{
				call.user.Group.GridFormation.ReassignPosition(call.user);
				call.user.Group.GridFormation.AssignToFreePosition(call.user);
			}
			currentStep = this.next;
			return null;
		}
	}
}
