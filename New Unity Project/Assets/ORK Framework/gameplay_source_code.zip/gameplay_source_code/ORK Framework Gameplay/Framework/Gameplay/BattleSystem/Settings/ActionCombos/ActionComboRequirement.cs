﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ActionComboRequirement : BaseData
	{
		[ORKEditorHelp("Action Type", "Select the action type the combatant performed:\n" +
			"- Attack: A base attack.\n" +
			"- Counter Attack: A counter attack..\n" +
			"- Ability: An ability.\n" +
			"- Item: An item.\n" +
			"- Defend: The defend command.\n" +
			"- Escape: The escape command.\n" +
			"- Death: Died.\n" +
			"- None: Did nothing.\n" +
			"- Change Member: Was exchanged for another group member.\n" +
			"- Class Ability: The combatant's class ability.\n" +
			"- Shortcut: A shortcut slot of the combatant.", "")]
		public ActionSelectType type = ActionSelectType.Attack;


		// attack
		[ORKEditorHelp("Any Attack", "Checks for any base attack of the combatant.\n" +
			"If disabled, you need to define which attack index will be checked for.", "")]
		[ORKEditorLayout("type", ActionSelectType.Attack)]
		public bool anyAttack = true;

		[ORKEditorHelp("Attack Index", "Set the index of the base attack that will be checked for, e.g.:\n" +
			"- 0: Index of the first base attack.\n" +
			"- 1: Index of the second base attack.", "")]
		[ORKEditorLimit(0, false)]
		[ORKEditorLayout("anyAttack", false, endCheckGroup=true, endGroups=2)]
		public int attackIndex = 0;



		// ability
		[ORKEditorHelp("Ability", "Select the ability that will be checked for.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		[ORKEditorLayout("type", ActionSelectType.Ability)]
		public int abilityID = 0;

		[ORKEditorHelp("Any Level", "Checks for any level of the ability.", "")]
		public bool abilityAnyLevel = true;

		[ORKEditorHelp("Ability Level", "Define the ability level that will be checked for.", "")]
		[ORKEditorLayout("abilityAnyLevel", false, endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(1, false)]
		public int abilityLevel = 1;


		// item
		[ORKEditorHelp("Item", "Select the item the combatant will be checked for.", "")]
		[ORKEditorInfo(ORKDataType.Item)]
		[ORKEditorLayout("type", ActionSelectType.Item, endCheckGroup=true)]
		public int itemID = 0;


		// shortcut
		[ORKEditorLayout("type", ActionSelectType.Shortcut, endCheckGroup=true, autoInit=true)]
		public ShortcutSlot slot;

		public ActionComboRequirement()
		{

		}

		public bool CheckAction(BaseAction action)
		{
			if(ActionSelectType.Attack == this.type)
			{
				if(action.IsType(ActionType.Attack))
				{
					if(this.anyAttack)
					{
						return true;
					}
					else
					{
						return action.User.Abilities.GetBaseAttack(this.attackIndex) == action.Shortcut;
					}
				}
			}
			// counter
			else if(ActionSelectType.CounterAttack == this.type)
			{
				return action.IsType(ActionType.CounterAttack);
			}
			// ability
			else if(ActionSelectType.Ability == this.type)
			{
				if(action.IsType(ActionType.Ability))
				{
					AbilityShortcut ability = (AbilityShortcut)action.Shortcut;
					return ability != null &&
						ability.ID == this.abilityID &&
						(this.abilityAnyLevel || this.abilityLevel == ability.GetLevel() + 1);
				}
			}
			// class ability
			else if(ActionSelectType.ClassAbility == this.type)
			{
				return action.IsType(ActionType.Ability) &&
					action.Shortcut == action.User.Abilities.GetClassAbility();
			}
			// item
			else if(ActionSelectType.Item == this.type)
			{
				return action.IsType(ActionType.Item) &&
					action.Shortcut != null &&
					action.Shortcut.ID == this.itemID;
			}
			// defend
			else if(ActionSelectType.Defend == this.type)
			{
				return action.IsType(ActionType.Defend);
			}
			// escape
			else if(ActionSelectType.Escape == this.type)
			{
				return action.IsType(ActionType.Escape);
			}
			// death
			else if(ActionSelectType.Death == this.type)
			{
				return action.IsType(ActionType.Death);
			}
			// none
			else if(ActionSelectType.None == this.type)
			{
				return action.IsType(ActionType.None);
			}
			// change member
			else if(ActionSelectType.ChangeMember == this.type)
			{
				return action.IsType(ActionType.ChangeMember);
			}
			// shortcut
			else if(ActionSelectType.Shortcut == this.type)
			{
				return action.Shortcut != null &&
					this.slot.IsShortcut(action.User, action.Shortcut);
			}
			return false;
		}
	}
}
