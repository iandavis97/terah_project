﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class GridCellEvent : BaseData
	{
		[ORKEditorHelp("Event Type", "Select what will be performed by this cell event:\n" +
			"- Ability: Uses an ability with the combatant as a target.\n" +
			"- Status Effect: Changes status effects on the combatant.\n" +
			"- Game Event: Starts a game event with the combatant as starting object.", "")]
		public GridCellEventType type = GridCellEventType.Ability;

		[ORKEditorHelp("Start Type", "Select when this cell event will be started:\n" +
			"- None: Can only be started through the event system.\n" +
			"- Any: Starts with any other type.\n" +
			"- Move To: Starts when a combatant moves to this cell (i.e. target of a move command).\n" +
			"- Move Over: Starts when a combatant moves over this cell (i.e. path of a move command).\n" +
			"- Start Turn: Starts when a combatant's turn starts on this cell.\n" +
			"- End Turn: Starts when a combatant's turn ends on this cell.", "")]
		public GridCellEventStartType startType = GridCellEventStartType.None;


		// ability
		[ORKEditorInfo(separator=true, labelText="Ability Settings")]
		[ORKEditorLayout("type", GridCellEventType.Ability)]
		public AbilitySelection ability = new AbilitySelection();

		[ORKEditorHelp("Animate Ability", "Using the ability will be animated.\n" +
			"If disabled, the ability will only calculate the outcome.", "")]
		public bool animateAbility = true;

		// combatant
		[ORKEditorHelp("Faction", "Select the faction of the combatant that will use the ability.", "")]
		[ORKEditorInfo(ORKDataType.Faction, separator=true, labelText="Combatant Settings")]
		public int factionID = 0;

		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public CombatantInit combatantSetting;


		// status effect
		[ORKEditorLayout("type", GridCellEventType.StatusEffect, endCheckGroup=true, autoInit=true)]
		public StatusEffectCast statusEffect;


		// game event
		[ORKEditorHelp("Game Event", "Select the game event asset that will be used.\n" +
			"The combatant will be used as starting object.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", GridCellEventType.GameEvent, endCheckGroup=true, autoInit=true)]
		public AssetSource<ORKGameEvent> gameEvent;

		public GridCellEvent()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("abilityID"))
			{
				this.ability.SetData(data);
			}
			if(GridCellEventType.GameEvent == this.type &&
				data.Contains<ORKGameEvent>("gameEvent"))
			{
				this.gameEvent = new AssetSource<ORKGameEvent>();
				this.gameEvent.Upgrade(data, "gameEvent");
			}
		}

		public void StartEvent(BattleGridCellComponent cell, List<Combatant> targets, Notify finishedCallback)
		{
			bool done = false;

			if(GridCellEventType.Ability == this.type)
			{
				Combatant user = this.combatantSetting.Create(new Group(this.factionID));
				this.ability.Learn(user, false, false, false);
				user.Object.SetGameObjectSimple(cell.gameObject);
				user.Battle.StartBattle();

				AbilityShortcut ability = this.ability.GetAbilityAtUseLevel(user);
				if(ability != null)
				{
					ActiveAbility activeLevel = ability.GetActiveLevel();

					if(activeLevel.targetSettings.CanTargetAny(user, targets))
					{
						if(this.animateAbility)
						{
							done = true;
							AbilityAction action = new AbilityAction(user, ability);

							if(ability.IsNoneTarget() &&
								activeLevel.targetSettings.noneSelectGridCell)
							{
								action.rayTargetSet = true;
								action.rayPoint = cell.transform.position;
								action.rayObject = cell.gameObject;
								action.target = targets;
							}
							else
							{
								activeLevel.targetSettings.SetTargets(action, user, targets);
							}

							action.finishedCallback = delegate (BaseAction finishedAction)
							{
								if(finishedCallback != null)
								{
									finishedCallback();
								}
							};
							action.PerformAction();
						}
						else if(activeLevel != null)
						{
							activeLevel.targetSettings.CheckTargets(user, ref targets);
							activeLevel.Use(user, targets, ability.Setting, true, ability.Type, null,
								SelectedDataHelper.CreateSelectedData(SelectedDataHelper.Action, ability));
						}
					}
				}
			}
			else if(GridCellEventType.StatusEffect == this.type)
			{
				for(int i = 0; i < targets.Count; i++)
				{
					if(targets[i] != null)
					{
						this.statusEffect.ChangeEffect(targets[i], targets[i], false, null);
					}
				}
			}
			else if(GridCellEventType.GameEvent == this.type)
			{
				ORKGameEvent eventAsset = this.gameEvent;
				if(eventAsset != null)
				{
					done = true;
					ORK.Core.GameObject.AddComponent<GameEventTicker>().StartEvent(
						eventAsset, targets, null, false, finishedCallback);
				}
			}

			if(!done && finishedCallback != null)
			{
				finishedCallback();
			}
		}
	}
}
