
using UnityEngine;
using ORKFramework.Events;
using System.Collections.Generic;
using System.Collections;

namespace ORKFramework
{
	public class PhaseBattle : BaseBattle, IEventStarter
	{
		// battle mode
		[ORKEditorHelp("Use Active Command", "Battle actions are executed right after selecting them, resulting in " +
			"each combatant selecting his action after the previous combatant finished it's action.\n" +
			"If disabled, the battle actions are selected at the beginning of each phase and executed " +
			"after all faction members chose their actions.", "")]
		[ORKEditorInfo("Phase Settings", "Settings for the phase battle system.\n" +
			"Each participating faction will perform their actions in a phase.\n" +
			"The order of the faction's combatants is free.\n" +
			"Phase battles don't support auto attacks.", "",
			labelText="Battle Mode")]
		public bool activeCommand = false;

		[ORKEditorHelp("Use Dynamic Combat", "Multiple actions are allowed at the same time.\n" +
			"Combatants will attack as soon as they can, the strict battle order isn't followed.\n" +
			"In any case, the next faction's phase will begin after all actions of the current phase have ended.\n" +
			"Please note that only camera changes from the latest battle action (battle animations) will be performed.", "")]
		public bool dynamicCombat = false;

		[ORKEditorHelp("Time Between Actions (s)", "The minimum time in seconds between two battle actions.", "")]
		[ORKEditorLayout("dynamicCombat", true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float minTimeBetween = 0;

		[ORKEditorHelp("Auto Start Turn", "Select when combatants of a phase will start their turn:\n" +
			"- None: A combatant's turn starts when selecting the first action, " +
			"combatants that don't select any actions will not progress their turn.\n" +
			"- Phase Start: All combatant turns are started after the phase start event.\n" +
			"- Phase End: A combatant's turn starts when selecting the first action, " +
			"combatants that don't select any actions will progress their turn before the phase end event.", "")]
		public PhaseTurnStartType autoStartTurn = PhaseTurnStartType.PhaseEnd;


		// phase calculation
		[ORKEditorHelp("Calculate Phase Order", "The order in which factions will " +
			"get their phase will be calculated by a formula.\n" +
			"If disabled, the order is based on sorting the factions.", "")]
		[ORKEditorInfo(separator=true, labelText="Phase Calculation")]
		public bool calculatePhase = false;

		[ORKEditorHelp("Phase Calculation", "Select the formula used to calculate " +
			"a value for every participating faction.\n" +
			"The formula is calculated for every member of a faction that isn't dead." +
			"The faction with the highest value performs the first phase, " +
			"followed by the faction with the next (lower) value.", "")]
		[ORKEditorInfo(ORKDataType.Formula)]
		[ORKEditorLayout("calculatePhase", true)]
		public int phaseFormulaID = 0;

		[ORKEditorHelp("Initial Value (Phase)", "The initial value passed to the phase formula.\n" +
			"The formula will use the initial value as it's base and start the calculation with that value.", "")]
		public float initialValuePhase = 0;

		[ORKEditorHelp("Sum Values", "The value of a faction is the sum of all faction member's formula results.\n" +
			"If disabled, the value of a faction is the highest formula result of all faction members.", "")]
		public bool sumValues = false;

		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public TypeSorter sorter = new TypeSorter();


		// combatant order
		[ORKEditorHelp("Calculate Order", "The order in which combatants of a factions will " +
			"get their turns will be calculated by a formula.\n" +
			"If disabled, the order is based on sorting the combatants.", "")]
		[ORKEditorInfo(separator=true, labelText="Combatant Order")]
		public bool calculateCombatantOrder = false;

		[ORKEditorHelp("Order Calculation", "Select the formula used to calculate " +
			"a value for each combatant of a faction.\n" +
			"The combatant with the highest value will be the first, " +
			"followed by the combatant with the next (lower) value.", "")]
		[ORKEditorInfo(ORKDataType.Formula)]
		[ORKEditorLayout("calculateCombatantOrder", true)]
		public int combatantOrderFormulaID = 0;

		[ORKEditorHelp("Initial Value (Order)", "The initial value passed to the combatant order formula.\n" +
			"The formula will use the initial value as it's base and start the calculation with that value.", "")]
		public float initialValueCombatantOrder = 0;

		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public TypeSorter combatantSorter = new TypeSorter(TypeSorting.None);

		[ORKEditorHelp("Group Leaders First", "Group leaders will be prioritized, " +
			"even if their calculated/sorted order wouldn't place them first.", "")]
		public bool groupLeadersFirst = false;


		// battle menu settings
		[ORKEditorHelp("Auto Call Menu", "Automatically call the battle menu when a player controlled combatant's turn starts.\n" +
			"If disabled, the battle menu can be called through an input key during the combatant's turn, " +
			"or rely on other methods to select battle actions (e.g. control maps or shortcut HUDs).", "")]
		[ORKEditorInfo(separator=true, labelText="Battle Menu Settings")]
		public bool autoCallBattleMenu = true;

		[ORKEditorHelp("Battle Menu Key", "Key to call the battle menu.\n" +
			"The key is only used in 'Real Time' type battles.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("autoCallBattleMenu", false)]
		public int battleMenuKey = 0;

		[ORKEditorHelp("Cancel Closes", "Using the cancel key will close the battle menu.", "")]
		public bool battleMenuCancelCloses = false;

		[ORKEditorHelp("2nd Press Closes", "A second press on the battle menu key closes the battle menu.", "")]
		public bool battleMenuKeyCloses = false;

		[ORKEditorHelp("Close Back to Selection", "Closing the battle menu with the 2nd key press will return to the combatant selection.", "")]
		[ORKEditorLayout("battleMenuKeyCloses", true, endCheckGroup=true, endGroups=2)]
		public bool battleMenuKeyBack = false;


		// options
		[ORKEditorHelp("Can Counter", "Combatants can counter attack in 'Phase' battles.\n" +
			"If disabled, combatants can't counter attack.", "")]
		[ORKEditorInfo(separator=true, labelText="Options")]
		public bool canCounter = true;

		[ORKEditorHelp("Defeat on Player Death", "The player is defeated if the player combatant is dead.\n" +
			"If disabled, the whole player battle group has to be dead.", "")]
		public bool defeatPlayerDead = false;

		[ORKEditorHelp("Death Immediately", "A combatant's death action will be performed immediately when dying.\n" +
			"If disabled, the death action will be performed after the current action ends.", "")]
		public bool deathImmediately = false;

		[ORKEditorHelp("End Immediately", "The battle will end immediately, stopping the actions that are still performing.\n" +
			"If disabled, the battle will wait for all active actions to end.", "")]
		public bool endImmediately = false;

		[ORKEditorHelp("Defend First", "The defend command will perform before other actions.\n" +
			"Doesn't take already performing actions into account.", "")]
		public bool defendFirst = false;

		[ORKEditorHelp("Selecting Control Map", "The control map of the currently selecting player group member is used (and only while selecting).\n" +
			"If disabled, the control map of the player is used at all times.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool selectingControlMap = false;


		// actions settings
		[ORKEditorInfo("Actions Settings", "Define how many actions a combatant can perform each turn and the default action costs.", "",
			endFoldout=true)]
		public ActionsPerTurnSettings actionsPerTurn = new ActionsPerTurnSettings();


		// action time settings
		[ORKEditorInfo("Action Time Settings", "Optionally use action time, " +
			"allowing a combatant to select actions only for a defined amount of time.", "",
			endFoldout=true)]
		public ActionTimeSettings actionTime = new ActionTimeSettings();


		// player combatant choice
		[ORKEditorInfo("Player Combatant Selection", "Define how the player can choose the " +
			"next combatant to perform an action.", "", endFoldout=true)]
		public PhaseCombatantChoice combatantChoice = new PhaseCombatantChoice();


		// ingame
		protected List<KeyValuePair<int, List<Combatant>>> phaseOrder;

		protected List<Combatant> currentFaction;

		protected List<Combatant> performedOrder = new List<Combatant>();

		protected bool performingActions = false;

		protected bool inPlayerSelection = false;


		// phase events
		protected PhaseChangeEvent phaseEvent;

		protected int phaseEventFlag = 0;


		// player controlled list > for click feedback
		protected List<Combatant> playerControlled = new List<Combatant>();

		protected Combatant selectingCombatant;

		protected int selectingCombatantIndex = -1;


		// advantage
		protected int firstPhaseRounds = 1;

		public PhaseBattle()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			// action costs
			if(data.Contains<bool>("addActionsPerTurn"))
			{
				this.actionsPerTurn.SetData(data);
			}
			else if(data.Contains<DataObject>("defaultActionCost"))
			{
				this.actionsPerTurn.defaultActionCostSetting.cost.SetData(data.GetFile("defaultActionCost"));
				if(this.actionsPerTurn.ownAbilityCost)
				{
					this.actionsPerTurn.defaultAbilityCostSetting = new ActionCost();
					this.actionsPerTurn.defaultAbilityCostSetting.cost.SetData(data.GetFile("defaultAbilityCost"));
				}
				if(this.actionsPerTurn.ownItemCost)
				{
					this.actionsPerTurn.defaultItemCostSetting = new ActionCost();
					this.actionsPerTurn.defaultItemCostSetting.cost.SetData(data.GetFile("defaultItemCost"));
				}
				if(this.actionsPerTurn.ownDefendCost)
				{
					this.actionsPerTurn.defendCostSetting = new ActionCost();
					this.actionsPerTurn.defendCostSetting.cost.SetData(data.GetFile("defendCost"));
				}
				if(this.actionsPerTurn.ownEscapeCost)
				{
					this.actionsPerTurn.escapeCostSetting = new ActionCost();
					this.actionsPerTurn.escapeCostSetting.cost.SetData(data.GetFile("escapeCost"));
				}
				if(this.actionsPerTurn.ownNoneCost)
				{
					this.actionsPerTurn.noneCostSetting = new ActionCost();
					this.actionsPerTurn.noneCostSetting.cost.SetData(data.GetFile("noneCost"));
				}
				if(this.actionsPerTurn.ownChangeMemberCost)
				{
					this.actionsPerTurn.changeMemberCostSetting = new ActionCost();
					this.actionsPerTurn.changeMemberCostSetting.cost.SetData(data.GetFile("changeMemberCost"));
				}
				if(this.actionsPerTurn.ownGridMoveCost)
				{
					this.actionsPerTurn.gridMoveCostSetting = new ActionCost();
					this.actionsPerTurn.gridMoveCostSetting.cost.SetData(data.GetFile("gridMoveCost"));
				}
			}

			if(data.Contains<bool>("autoUseTurns"))
			{
				bool tmp = true;
				data.Get("autoUseTurns", ref tmp);
				this.autoStartTurn = tmp ? PhaseTurnStartType.PhaseEnd : PhaseTurnStartType.None;
			}
		}

		public override bool CanCounter
		{
			get { return this.canCounter; }
		}

		public override bool DeathImmediately
		{
			get { return this.deathImmediately; }
		}

		public override bool EndImmediately
		{
			get { return this.endImmediately; }
		}

		public override bool DefeatOnPlayerDeath
		{
			get { return this.defeatPlayerDead; }
		}

		public override bool DefendFirst
		{
			get { return this.defendFirst; }
		}

		public override Combatant SelectingCombatant
		{
			get { return this.selectingCombatant; }
			set { this.selectingCombatant = value; }
		}

		public int CurrentFactionID
		{
			get
			{
				if(this.phaseOrder != null &&
					this.phaseOrder.Count > 0)
				{
					return this.phaseOrder[0].Key;
				}
				return -1;
			}
		}

		public bool PhaseEventRunning
		{
			get { return this.phaseEvent != null; }
		}

		public override void Tick()
		{
			// battle menu key
			if(!this.autoCallBattleMenu &&
				this.selectingCombatant != null)
			{
				if(ORK.InputKeys.Get(this.battleMenuKey).GetButton())
				{
					if(!this.selectingCombatant.Dead &&
						this.selectingCombatant.Actions.IsChoosing &&
						this.selectingCombatant.IsPlayerControlled() &&
						!this.selectingCombatant.IsAIControlled())
					{
						if(!this.selectingCombatant.BattleMenu.IsOpen)
						{
							this.selectingCombatant.Actions.Choose(false, true);
						}
						else if(this.battleMenuKeyCloses)
						{
							this.selectingCombatant.EndBattleMenu(this.battleMenuKeyBack);
						}
					}
				}
				else if(this.battleMenuCancelCloses &&
					ORK.InputKeys.Get(ORK.GameControls.menuControls.cancelKeyID).GetButton())
				{
					if(!this.selectingCombatant.Dead &&
						this.selectingCombatant.Actions.IsChoosing &&
						this.selectingCombatant.IsPlayerControlled() &&
						!this.selectingCombatant.IsAIControlled() &&
						this.selectingCombatant.BattleMenu.IsOpen &&
						this.selectingCombatant.BattleMenu.Mode == BattleMenuMode.List)
					{
						this.selectingCombatant.EndBattleMenu(this.battleMenuKeyBack);
					}
				}
			}

			// selection input
			if(this.combatantChoice.useCombatantChoice &&
				this.combatantChoice.useKeys &&
				this.inPlayerSelection &&
				this.currentFaction != null &&
				((this.selectingCombatant != null &&
						this.selectingCombatant.IsPlayerControlled()) ||
					this.playerControlled.Count > 0))
			{
				if(ORK.InputKeys.Get(this.combatantChoice.endPhaseKeyID).GetButton())
				{
					this.combatantChoice.PlayEndPhaseClip();
					this.CombatantSelected(null);
				}
				else if(ORK.InputKeys.Get(this.combatantChoice.nextCombatantKeyID).GetButton() &&
					this.currentFaction.Count > 0)
				{
					this.combatantChoice.PlayChangeCombatantClip();
					if(this.selectingCombatantIndex >= 0 &&
						this.selectingCombatantIndex < this.currentFaction.Count)
					{
						this.CombatantSelected(this.currentFaction[this.selectingCombatantIndex]);
					}
					else
					{
						this.CombatantSelected(this.currentFaction[0]);
					}
				}
				else if(ORK.InputKeys.Get(this.combatantChoice.previousCombatantKeyID).GetButton() &&
					this.currentFaction.Count > 0)
				{
					this.combatantChoice.PlayChangeCombatantClip();
					if(this.selectingCombatantIndex - 1 >= 0 &&
						this.selectingCombatantIndex - 1 < this.currentFaction.Count)
					{
						this.CombatantSelected(this.currentFaction[this.selectingCombatantIndex - 1]);
					}
					else
					{
						this.CombatantSelected(this.currentFaction[this.currentFaction.Count - 1]);
					}
				}
			}

			if(this.phaseEvent != null && this.phaseEvent.Executing)
			{
				this.phaseEvent.Tick(ORK.Game.DeltaTime);
			}
		}


		/*
		============================================================================
		Battle menu functions
		============================================================================
		*/
		public override bool IsMenuBackAllowed
		{
			get
			{
				return this.combatantChoice.useCombatantChoice &&
					!this.combatantChoice.autoSelect &&
					(!this.combatantChoice.autoSelectOne ||
						this.combatantChoice.addEndPhase ||
						this.currentFaction.Count > 0);
			}
		}

		public override void BattleMenuCanceled(Combatant user)
		{
			// canceled battle menu > add to the list of possible combatants again
			this.inPlayerSelection = false;
			this.CombatantCanceled(user, true);
			this.GetNextAction();
		}

		public void CombatantCanceled(Combatant user, bool unsetLatestTurn)
		{
			user.Battle.ActionTimeRunning = false;
			if(this.currentFaction != null)
			{
				if(this.selectingCombatantIndex >= 0)
				{
					this.currentFaction.Insert(this.selectingCombatantIndex, user);
				}
				else
				{
					this.currentFaction.Add(user);
				}
			}
			if(this.selectingCombatant == user)
			{
				if(this.performedOrder.Contains(this.selectingCombatant))
				{
					this.performedOrder.Remove(this.selectingCombatant);
				}
				this.selectingCombatant = null;
				if(unsetLatestTurn)
				{
					ORK.Battle.FireLatestTurn(null);
				}
			}
		}

		public override bool CombatantClicked(Combatant combatant)
		{
			if(this.inPlayerSelection &&
				this.combatantChoice.useCombatantChoice &&
				this.combatantChoice.allowClicking &&
				combatant != null &&
				combatant.Actions.CanChoose &&
				this.currentFaction.Contains(combatant) &&
				(this.playerControlled.Contains(combatant) ||
					(this.combatantChoice.allowClickingWhileSelected &&
						this.selectingCombatant != null &&
						this.selectingCombatant != combatant &&
						this.selectingCombatant.IsPlayerControlled() &&
						this.selectingCombatant.BattleMenu != null &&
						BattleMenuMode.Target != this.selectingCombatant.BattleMenu.Mode &&
						BattleMenuMode.Command != this.selectingCombatant.BattleMenu.Mode)))
			{
				this.CombatantSelected(combatant);
				return true;
			}
			return false;
		}

		public override bool UseControlMap()
		{
			if(this.selectingControlMap)
			{
				if(this.selectingCombatant != null &&
					this.selectingCombatant.IsPlayerControlled() &&
					!this.selectingCombatant.IsAIControlled())
				{
					this.selectingCombatant.ControlMapTick();
				}
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool IsDynamicCombat()
		{
			return this.dynamicCombat;
		}

		public override bool CanChoose(Combatant combatant)
		{
			return combatant.Battle.UsedActionBar < combatant.Battle.ActionBar &&
				(!this.actionTime.useActionTime || combatant.Battle.ActionTime > 0);
		}

		public override bool CanDecreaseActionTime(Combatant combatant)
		{
			return this.actionTime.CanDecrease(combatant);
		}


		/*
		============================================================================
		Action cost functions
		============================================================================
		*/
		public override float GetDefendActionCost(Combatant user)
		{
			if(this.actionsPerTurn.ownDefendCost)
			{
				return this.actionsPerTurn.defendCostSetting.GetCost(user);
			}
			else
			{
				return this.actionsPerTurn.defaultActionCostSetting.GetCost(user);
			}
		}

		public override float GetEscapeActionCost(Combatant user)
		{
			if(this.actionsPerTurn.ownEscapeCost)
			{
				return this.actionsPerTurn.escapeCostSetting.GetCost(user);
			}
			else
			{
				return this.actionsPerTurn.defaultActionCostSetting.GetCost(user);
			}
		}

		public override float GetNoneActionCost(Combatant user)
		{
			if(this.actionsPerTurn.ownNoneCost)
			{
				return this.actionsPerTurn.noneCostSetting.GetCost(user);
			}
			else
			{
				return this.actionsPerTurn.defaultActionCostSetting.GetCost(user);
			}
		}

		public override float GetChangeMemberActionCost(Combatant user)
		{
			if(this.actionsPerTurn.ownChangeMemberCost)
			{
				return this.actionsPerTurn.changeMemberCostSetting.GetCost(user);
			}
			else
			{
				return this.actionsPerTurn.defaultActionCostSetting.GetCost(user);
			}
		}

		public override float GetGridMoveActionCost(Combatant user)
		{
			if(this.actionsPerTurn.ownGridMoveCost)
			{
				return this.actionsPerTurn.gridMoveCostSetting.GetCost(user);
			}
			else
			{
				return this.actionsPerTurn.defaultActionCostSetting.GetCost(user);
			}
		}


		/*
		============================================================================
		Start functions
		============================================================================
		*/
		public override void StartBattle(bool changed)
		{
			base.StartBattle(changed);
			this.selectingCombatant = null;

			if(!changed)
			{
				this.firstPhaseRounds = 0;
				if(GroupAdvantageType.Player == ORK.Battle.Advantage)
				{
					if(ORK.BattleSettings.playerAdvantage.playerGroupCondition.firstPhase)
					{
						this.firstPhaseRounds = ORK.BattleSettings.playerAdvantage.playerGroupCondition.firstPhaseRounds;
					}
					else if(ORK.BattleSettings.playerAdvantage.enemyGroupCondition.firstPhase)
					{
						this.firstPhaseRounds = ORK.BattleSettings.playerAdvantage.enemyGroupCondition.firstPhaseRounds;
					}
				}
				else if(GroupAdvantageType.Enemy == ORK.Battle.Advantage)
				{
					if(ORK.BattleSettings.enemyAdvantage.playerGroupCondition.firstPhase)
					{
						this.firstPhaseRounds = ORK.BattleSettings.enemyAdvantage.playerGroupCondition.firstPhaseRounds;
					}
					else if(ORK.BattleSettings.enemyAdvantage.enemyGroupCondition.firstPhase)
					{
						this.firstPhaseRounds = ORK.BattleSettings.enemyAdvantage.enemyGroupCondition.firstPhaseRounds;
					}
				}
			}

			this.StartTurn();
		}

		protected void StartTurn()
		{
			ORK.Battle.CheckBattleEnd();
			if(!ORK.Battle.BattleEnd && !ORK.Battle.WaitForLastAction)
			{
				ORK.Battle.Turn++;
				this.phaseOrder = null;
				this.currentFaction = null;
				this.performingActions = false;

				if(!this.dynamicCombat)
				{
					ORK.Battle.Actions.ClearStack();
				}

				// get participating factions and their members
				Dictionary<int, List<Combatant>> factions = ORK.Game.Combatants.GetByFaction(
					ORK.Game.ActiveGroup.Leader, true, Range.Infinity, Consider.No, Consider.Yes, null);

				// get the faction order
				List<int> factionIDs = new List<int>();

				if(this.calculatePhase)
				{
					List<KeyValuePair<int, float>> factionValues = new List<KeyValuePair<int, float>>();
					foreach(KeyValuePair<int, List<Combatant>> pair in factions)
					{
						factionValues.Add(new KeyValuePair<int, float>(pair.Key, this.GetFactionValue(pair.Value)));
					}
					factionValues.Sort(new PhaseSorter());

					for(int i = 0; i < factionValues.Count; i++)
					{
						factionIDs.Add(factionValues[i].Key);
					}
				}
				else
				{
					factionIDs.AddRange(factions.Keys);
					this.sorter.Sort(ref factionIDs, ORKDataType.Faction);
				}

				// create phase order
				this.phaseOrder = new List<KeyValuePair<int, List<Combatant>>>();
				for(int i = 0; i < factionIDs.Count; i++)
				{
					// unset phase performed
					for(int j = 0; j < factions[factionIDs[i]].Count; j++)
					{
						if(factions[factionIDs[i]][j] != null)
						{
							factions[factionIDs[i]][j].Battle.TurnState = CombatantTurnState.BeforeTurn;
							if(factions[factionIDs[i]][j].Battle.ReceiveActionsPerTurn)
							{
								this.actionTime.SetActionTime(factions[factionIDs[i]][j]);
								this.actionsPerTurn.SetActionsPerTurn(factions[factionIDs[i]][j]);
							}
						}
					}
					KeyValuePair<int, List<Combatant>> tmp = new KeyValuePair<int, List<Combatant>>(factionIDs[i], factions[factionIDs[i]]);

					// player advantage first phase
					if(GroupAdvantageType.Player == ORK.Battle.Advantage &&
						this.firstPhaseRounds > 0 &&
						ORK.Game.ActiveGroup.FactionID == tmp.Key)
					{
						this.phaseOrder.Insert(0, tmp);
					}
					// enemy advantage first phase
					else if(GroupAdvantageType.Enemy == ORK.Battle.Advantage &&
						this.firstPhaseRounds > 0 &&
						ORK.Game.ActiveGroup.IsEnemy(tmp.Key))
					{
						this.phaseOrder.Insert(0, tmp);
					}
					// no first phase
					else
					{
						this.phaseOrder.Add(tmp);
					}
				}

				if(this.firstPhaseRounds > 0)
				{
					this.firstPhaseRounds--;
				}

				// start first phase
				this.NextPhase();
			}
		}

		protected float GetFactionValue(List<Combatant> list)
		{
			float value = 0;
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null && !list[i].Dead)
				{
					float newValue = ORK.Formulas.Get(this.phaseFormulaID).Calculate(
						new FormulaCall(this.initialValuePhase, list[i], list[i]));
					if(this.sumValues)
					{
						value += newValue;
					}
					else if(value < newValue)
					{
						value = newValue;
					}
				}
			}
			return value;
		}


		/*
		============================================================================
		Phase handling functions
		============================================================================
		*/
		protected IEnumerator NextPhaseWait()
		{
			yield return null;
			this.NextPhase();
		}

		protected void NextPhase()
		{
			this.ClearPlayerChoice(true);

			if(!ORK.Battle.BattleEnd)
			{
				if(this.currentFaction != null)
				{
					for(int i = 0; i < this.currentFaction.Count; i++)
					{
						if(this.currentFaction[i] != null)
						{
							// unused combatants
							if(CombatantTurnState.BeforeTurn == this.currentFaction[i].Battle.TurnState)
							{
								if(PhaseTurnStartType.PhaseEnd == this.autoStartTurn)
								{
									this.performedOrder.Add(this.currentFaction[i]);
								}
							}
							// combatants without ended turns
							else if(CombatantTurnState.InTurn == this.currentFaction[i].Battle.TurnState)
							{
								this.currentFaction[i].Actions.FinishedChoosing = true;
								this.currentFaction[i].Actions.IsWaiting = false;
								this.currentFaction[i].Battle.ReceiveActionsPerTurn = true;
								this.performedOrder.Add(this.currentFaction[i]);
							}
						}
					}
					this.currentFaction.Clear();
				}
				// still actions left?
				if(ORK.Battle.Actions.Has())
				{
					this.PerformNextAction();
				}
				// start next phase
				else if(this.selectingCombatant == null &&
					!ORK.Battle.Actions.HasCasting() &&
					!ORK.Battle.Actions.HasActive())
				{
					this.performingActions = false;

					// set phase end flag
					this.phaseEventFlag = 2;

					// not first phase in this turn
					if(this.currentFaction != null)
					{
						this.TurnEnd();
					}
					// first phase > play only start event
					else
					{
						this.EventEnded();
					}
				}
				// continue checking next phase until all actions finished
				else
				{
					ORK.StartCoroutine(this.NextPhaseWait());
				}
			}
		}

		private void TurnStart()
		{
			if(this.performedOrder.Count > 0)
			{
				Combatant combatant = this.performedOrder[0];
				this.performedOrder.RemoveAt(0);
				combatant.Battle.StartTurn(true, this.TurnStart);
			}
			else
			{
				this.GetNextAction();
			}
		}

		private void TurnEnd()
		{
			if(this.performedOrder.Count > 0)
			{
				Combatant combatant = this.performedOrder[0];
				this.performedOrder.RemoveAt(0);
				if(CombatantTurnState.BeforeTurn == combatant.Battle.TurnState)
				{
					combatant.Battle.StartEndTurn(this.TurnEnd);
				}
				else if(combatant.Battle.CanEndTurn)
				{
					combatant.Battle.EndTurn(this.TurnEnd);
				}
				else
				{
					this.TurnEnd();
				}
			}
			else
			{
				this.PhaseEndEvent();
			}
		}

		private void PhaseEndEvent()
		{
			FactionSetting faction = ORK.Factions.Get(this.phaseOrder[0].Key);
			if(faction.phaseEndAsset != null)
			{
				this.phaseEvent = new PhaseChangeEvent();
				this.phaseEvent.SetData(faction.phaseEndAsset.GetData().ToDataObject());
				this.phaseEvent.SetMembers(this.phaseOrder[0].Value);
				this.phaseOrder.RemoveAt(0);
				this.phaseEvent.StartEvent(this, null);
			}
			else
			{
				this.phaseOrder.RemoveAt(0);
				this.EventEnded();
			}
		}

		protected void CheckPhaseCombatants()
		{
			for(int i = 0; i < this.currentFaction.Count; i++)
			{
				if(this.currentFaction[i] == null ||
					this.currentFaction[i].Dead)
				{
					this.currentFaction.RemoveAt(i--);
				}
			}

			if(this.calculateCombatantOrder)
			{
				for(int i = 0; i < this.currentFaction.Count; i++)
				{
					this.currentFaction[i].Battle.TurnValue = ORK.Formulas.Get(this.combatantOrderFormulaID).Calculate(
						new FormulaCall(this.initialValueCombatantOrder, this.currentFaction[i], this.currentFaction[i]));
				}
				this.currentFaction.Sort(new TurnSorter(false, this.groupLeadersFirst));
			}
			else
			{
				this.combatantSorter.Sort(ref this.currentFaction);
				if(this.groupLeadersFirst)
				{
					this.currentFaction.Sort(new GroupLeaderSorter(false));
				}
			}
		}

		public void CombatantSelected(Combatant combatant)
		{
			if(this.selectingCombatant != null)
			{
				if(this.selectingCombatant.BattleMenu != null)
				{
					this.selectingCombatant.BattleMenu.CloseSilent();
					this.selectingCombatant.BattleMenu.IsOpen = false;
				}
				this.selectingCombatant.Actions.IsWaiting = false;
				this.selectingCombatant.Actions.IsChoosing = false;
				this.CombatantCanceled(this.selectingCombatant, combatant == null);
			}
			this.ClearPlayerChoice(!this.combatantChoice.keepOpen || combatant == null);

			// null combatant selected > next phase
			if(combatant == null)
			{
				this.selectingCombatant = null;
				this.NextPhase();
			}
			// check for combatant and get it's action
			else
			{
				if(this.currentFaction.Contains(combatant))
				{
					this.selectingCombatant = combatant;
					this.selectingCombatantIndex = this.currentFaction.IndexOf(combatant);
					this.currentFaction.Remove(combatant);
					this.SelectAction(combatant);
				}
				else
				{
					ORK.Battle.Actions.Add(null);
				}
			}
		}

		protected void SelectAction(Combatant combatant)
		{
			if(combatant != null && combatant.Actions.CanChoose)
			{
				if(!this.performedOrder.Contains(combatant))
				{
					this.performedOrder.Add(combatant);
				}
				if(this.IsGroupAuto(combatant))
				{
					combatant.Actions.ChooseAuto(CombatantTurnState.InTurn != combatant.Battle.TurnState);
				}
				else
				{
					combatant.Actions.Choose(CombatantTurnState.InTurn != combatant.Battle.TurnState,
						this.autoCallBattleMenu);
				}
			}
			else
			{
				ORK.Battle.Actions.Add(null);
			}
		}

		public void ClearPlayerChoice(bool close)
		{
			if(this.playerControlled.Count > 0)
			{
				this.playerControlled.Clear();
			}
			if(close)
			{
				this.combatantChoice.Close();
			}
			this.selectingCombatantIndex = -1;
		}

		public void ClearCurrentFaction()
		{
			if(this.currentFaction != null)
			{
				this.currentFaction.Clear();
			}
		}

		public override void CombatantChanged(Combatant oldCombatant, Combatant newCombatant)
		{
			if(this.selectingCombatant == oldCombatant)
			{
				this.selectingCombatant = newCombatant;
				if(this.performedOrder.Contains(oldCombatant))
				{
					this.performedOrder[this.performedOrder.IndexOf(oldCombatant)] = newCombatant;
				}
			}
			if(this.playerControlled.Contains(oldCombatant))
			{
				if(newCombatant.IsPlayerControlled())
				{
					this.playerControlled[this.playerControlled.IndexOf(oldCombatant)] = newCombatant;
				}
				else
				{
					this.playerControlled.Remove(oldCombatant);
				}
			}
			if(this.currentFaction != null &&
				this.currentFaction.Contains(oldCombatant))
			{
				this.currentFaction[this.currentFaction.IndexOf(oldCombatant)] = newCombatant;
			}
			if(this.phaseOrder != null)
			{
				foreach(KeyValuePair<int, List<Combatant>> pair in this.phaseOrder)
				{
					if(pair.Value != null &&
						pair.Value.Contains(oldCombatant))
					{
						pair.Value[pair.Value.IndexOf(oldCombatant)] = newCombatant;
					}
				}
			}
		}


		/*
		============================================================================
		Action handling functions
		============================================================================
		*/
		protected void GetNextAction()
		{
			ORK.StartCoroutine(this.GetNextAction2());
		}

		protected IEnumerator GetNextAction2()
		{
			yield return null;

			if(ORK.Battle.IsBattleRunning() &&
				!ORK.Battle.BattleEnd &&
				!ORK.Battle.WaitForLastAction)
			{
				this.CheckPhaseCombatants();

				// select next combatant/action to perform
				if(this.phaseOrder.Count > 0)
				{
					// still has actions per turn
					if(this.selectingCombatant != null &&
						this.selectingCombatant.Actions.CanChoose)
					{
						if(this.selectingCombatant.IsPlayerControlled())
						{
							this.inPlayerSelection = true;
						}
						this.SelectAction(this.selectingCombatant);
					}
					// still someone left?
					else if(this.currentFaction.Count > 0)
					{
						this.selectingCombatant = null;
						int canChoose = 0;
						if(this.playerControlled.Count > 0)
						{
							this.playerControlled.Clear();
						}
						int aiPlayerControlled = -1;
						for(int i = 0; i < this.currentFaction.Count; i++)
						{
							if(this.currentFaction[i].Actions.CanChoose)
							{
								canChoose++;
							}
							if(this.currentFaction[i].IsPlayerControlled())
							{
								this.playerControlled.Add(this.currentFaction[i]);

								// AI player
								if(this.combatantChoice.useCombatantChoice &&
									this.combatantChoice.forceAICombatants &&
									aiPlayerControlled == -1 &&
									this.currentFaction[i].IsAIControlled())
								{
									aiPlayerControlled = i;
								}
							}
						}

						if(canChoose > 0)
						{
							// AI controlled player combatant
							if(aiPlayerControlled != -1)
							{
								this.selectingCombatant = this.currentFaction[aiPlayerControlled];
								this.currentFaction.RemoveAt(aiPlayerControlled);
								this.SelectAction(this.selectingCombatant);
							}
							// player controlled combatants > wait for player to select next combatant
							else if(this.playerControlled.Count > 0 &&
								(this.groupAuto == null || this.groupAuto.Count == 0) &&
								this.combatantChoice.useCombatantChoice)
							{
								this.inPlayerSelection = true;
								this.combatantChoice.Show(this.playerControlled);
							}
							else
							{
								this.selectingCombatant = this.currentFaction[0];
								this.currentFaction.RemoveAt(0);
								this.SelectAction(this.selectingCombatant);
							}
						}
						else
						{
							this.NextPhase();
						}
					}
					// phase finished > next phase
					else
					{
						this.selectingCombatant = null;
						this.NextPhase();
					}
				}
				else
				{
					this.StartTurn();
				}
			}
		}

		public override void ActionAdded(BaseAction action)
		{
			if(action != null)
			{
				if(this.currentFaction != null &&
					this.currentFaction.Contains(action.User))
				{
					this.currentFaction.Remove(action.User);
				}
			}
			this.inPlayerSelection = false;

			if(this.activeCommand ||
				(!this.performingActions &&
					// all combatants chose their actions in the current phase?
					this.currentFaction != null && this.currentFaction.Count == 0 &&
					(this.selectingCombatant == null ||
						(!this.selectingCombatant.Actions.IsChoosing &&
						!this.selectingCombatant.Actions.CanChoose))))
			{
				this.ClearPlayerChoice(true);
				this.performingActions = true;
				this.PerformNextAction();
			}
			else
			{
				this.GetNextAction();
			}
		}

		protected override void PerformNextAction3()
		{
			if(!ORK.Battle.BattleEnd)
			{
				if(ORK.Battle.Actions.Has())
				{
					BaseAction action = ORK.Battle.Actions.NextPerformable();
					if(action != null)
					{
						if(!action.IsCastingAbility())
						{
							this.PerformAction(action);
						}
						else if(this.dynamicCombat)
						{
							this.PerformingAction(action);
						}
					}
					else
					{
						this.ActionFinished(null);
					}
				}
				else if(this.activeCommand)
				{
					this.GetNextAction();
				}
			}
		}

		public override void PerformingAction(BaseAction action)
		{
			if(this.dynamicCombat &&
				(action == null || !action.isPerforming))
			{
				if(action != null)
				{
					action.isPerforming = true;
				}
				if(this.minTimeBetween > 0)
				{
					ORK.StartCoroutine(this.ActionFinished2(action));
				}
				else
				{
					this.ActionFinished(action);
				}
			}
		}

		public IEnumerator ActionFinished2(BaseAction action)
		{
			yield return new WaitForSeconds(this.minTimeBetween);
			this.ActionFinished(action);
		}

		public override void ActionFinished(BaseAction action)
		{
			if(!ORK.Battle.BattleEnd)
			{
				if(action == null || !action.notifiedFinished ||
					ORK.Battle.WaitForLastAction)
				{
					if(ORK.Battle.Actions.Has())
					{
						if(action != null)
						{
							action.notifiedFinished = true;
						}
						this.PerformNextAction();
					}
					else if(this.activeCommand ||
						this.phaseOrder.Count > 0)
					{
						if(action != null)
						{
							action.notifiedFinished = true;
						}

						if(this.activeCommand &&
							this.selectingCombatant != null &&
							this.selectingCombatant.Battle.CanEndTurn)
						{
							this.performedOrder.Remove(this.selectingCombatant);
							this.selectingCombatant.Battle.EndTurn(this.GetNextAction);
						}
						else
						{
							this.GetNextAction();
						}
					}
					else if(!this.dynamicCombat ||
						(!ORK.Battle.Actions.HasCasting() &&
							!ORK.Battle.Actions.HasActive()))
					{
						if(action != null)
						{
							action.notifiedFinished = true;
						}
						if(this.selectingCombatant != null &&
							this.selectingCombatant.Battle.CanEndTurn)
						{
							this.performedOrder.Remove(this.selectingCombatant);
							this.selectingCombatant.Battle.EndTurn(this.StartTurn);
						}
						else
						{
							this.StartTurn();
						}
					}
				}
				else if(this.activeCommand &&
					this.dynamicCombat &&
					ORK.Battle.Actions.Has())
				{
					if(action != null)
					{
						action.notifiedFinished = true;
					}
					// perform next action without notify
					action = ORK.Battle.Actions.NextPerformable();
					if(action != null)
					{
						action.notifiedFinished = true;
						if(!action.IsCastingAbility())
						{
							this.PerformAction(action);
						}
						else if(this.dynamicCombat)
						{
							this.PerformingAction(action);
						}
					}
					else
					{
						this.ActionFinished(null);
					}
				}
			}
		}


		/*
		============================================================================
		Battle end functions
		============================================================================
		*/
		public override void EndBattle()
		{
			this.combatantChoice.Close();
		}


		/*
		============================================================================
		Phase event functions
		============================================================================
		*/
		public void EventEnded()
		{
			this.phaseEvent = null;

			// phase start ended
			if(this.phaseEventFlag == 1)
			{
				this.phaseEventFlag = 0;

				if(PhaseTurnStartType.PhaseStart == this.autoStartTurn)
				{
					this.performedOrder.AddRange(this.currentFaction);
					this.TurnStart();
				}
				else
				{
					this.GetNextAction();
				}
			}
			// phase end ended
			if(this.phaseEventFlag == 2)
			{
				this.performedOrder.Clear();

				// still phases left
				if(this.phaseOrder.Count > 0)
				{
					this.phaseEventFlag = 1;

					this.currentFaction = new List<Combatant>(this.phaseOrder[0].Value);

					this.CheckPhaseCombatants();

					// perform phase start event of current faction
					FactionSetting faction = ORK.Factions.Get(this.phaseOrder[0].Key);
					if(faction.phaseStartAsset != null)
					{
						this.phaseEvent = new PhaseChangeEvent();
						this.phaseEvent.SetData(faction.phaseStartAsset.GetData().ToDataObject());
						this.phaseEvent.SetMembers(this.phaseOrder[0].Value);
						this.phaseEvent.StartEvent(this, null);
					}
					else
					{
						this.EventEnded();
					}
				}
				// new turn
				else
				{
					this.phaseEventFlag = 0;

					this.StartTurn();
				}
			}
		}

		public void DontDestroy()
		{
			if(ORK.Battle.BattleArena != null)
			{
				ORK.Battle.BattleArena.DontDestroy();
			}
		}

		public void OnSceneLoaded()
		{
			if(ORK.Battle.BattleArena != null)
			{
				ORK.Battle.BattleArena.OnSceneLoaded();
			}
		}

		public GameObject GameObject
		{
			get
			{
				if(ORK.Battle.BattleArena != null)
				{
					return ORK.Battle.BattleArena.GameObject;
				}
				return null;
			}
		}
	}
}
