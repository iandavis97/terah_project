﻿
using UnityEngine;
using ORKFramework.Events;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridMoveCommandSettings : BaseData
	{
		// settings
		[ORKEditorHelp("Use Only Once", "A combatant can use the move command only once per turn.\n" +
			"If disabled, the combatant can move multiple times (if the move range allows it).", "")]
		public bool useOnlyOnce = false;

		[ORKEditorHelp("Player", "Members of the player can only move once per turn.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("useOnlyOnce", true)]
		public bool useOnlyOncePlayer = true;

		[ORKEditorHelp("Ally", "Allies of the player can only move once per turn.", "")]
		[ORKEditorInfo(indent=true)]
		public bool useOnlyOnceAlly = true;

		[ORKEditorHelp("Enemy", "Enemies of the player can only move once per turn.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool useOnlyOnceEnemy = true;

		[ORKEditorHelp("Mark Target Cell", "The selected target cell will be marked for the user.\n" +
			"Other combatants can't move on the marked cell.\n" +
			"If disabled, the cell will remain free until the combatant actually moved there.", "")]
		public bool markTargetCell = true;

		[ORKEditorHelp("Allow Cancel", "The target cell selection can be canceled using the 'Cancel' key defined in the game controls.", "")]
		public bool allowCancel = false;

		[ORKEditorHelp("Block Action Use", "Using actions is blocked for the combatant during the grid cell selection.", "")]
		public bool blockActionUse = false;

		[ORKEditorHelp("Start From User", "The target cell selection will always start from the user's cell.\n" +
			"If disabled, a previously selected cell (also from other cell selections) will be used.", "")]
		public bool startFromUser = true;

		[ORKEditorHelp("Rotate To Cell", "Rotate the user to the selected cell.\n" +
			"If disabled, a previously selected cell (also from other cell selections) will be used.", "")]
		public bool rotateToCell = false;

		[ORKEditorHelp("Grid Rotation", "Limit the rotation to the nearest grid rotation during grid battles.", "")]
		[ORKEditorLayout("rotateToCell", true, endCheckGroup=true)]
		public bool gridRotation = false;

		[ORKEditorHelp("Examine Cell", "Display the cell info text for the selected cell ('Examine Grid' settings).", "")]
		public bool examineCell = false;

		[ORKEditorHelp("Examine Cell Combatant", "Display the combatant info dialogue for the selected cell's combatant ('Examine Grid' settings).\n" +
			"Please note that this only shows the information dialogue and " +
			"doesn't show cell highlights (e.g. move range of a combatant).", "")]
		public bool examineCellCombatant = false;


		// pathfinding
		[ORKEditorHelp("Use Shortest Path", "Use the shortest path to a cell if multiple paths with the same move costs are available.\n" +
			"If disabled, the first path that was found will be used.", "")]
		[ORKEditorInfo(separator=true, labelText="Pathfinding Settings")]
		public bool useShortestPath = false;

		[ORKEditorHelp("Move To Own Cells", "A combatant can move on cells it currently occupies itself.\n" +
			"E.g. a combatant using grid cell size can move its own size cells.\n" +
			"The combatant's origin cell (the actual cell the combatant is placed on) can't be moved on in any case.", "")]
		public bool moveToOwnCells = false;

		[ORKEditorHelp("Move Over Allies", "A combatant can move over cells that are currently occupied by allied combatants.", "")]
		public bool moveOverAllies = false;

		[ORKEditorHelp("Move Over Enemies", "A combatant can move over cells that are currently occupied by enemy combatants.", "")]
		public bool moveOverEnemies = false;

		[ORKEditorHelp("Diagonal Move", "Diagonal movement is allowed in 'Square' type grids.", "")]
		[ORKEditorLayout("battlegrid:square", setDefault=true, defaultValue=false)]
		public bool squareDiagonalMove = false;

		[ORKEditorHelp("Blocking Combatants", "Combatants blocking the path will prevent diagonal movement around them.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("squareDiagonalMove", true, endCheckGroup=true, endGroups=2)]
		public bool squareDiagonalMoveBlockingCombatants = true;


		// camera control target
		[ORKEditorHelp("Camera Control Target", "Changes the camera control target to the selected cell.\n" +
			"The camera control must descent from the 'BaseCameraControl' class (like all built-in camera controls).", "")]
		[ORKEditorInfo("Camera Control Target", "Optionally change the camera control target to the selected cell.\n" +
			"The camera control must descent from the 'BaseCameraControl' class (like all built-in camera controls).", "")]
		public bool cameraControlTarget = false;

		[ORKEditorHelp("Own Transition", "Use a custom camera control transition when changing the camera control target.\n" +
			"If disabled, the default transition defined in 'Base/Control > Game Controls' will be used.", "")]
		[ORKEditorLayout("cameraControlTarget", true)]
		public bool ownControlTargetTransition = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownControlTargetTransition", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public CameraControlTargetTransition controlTargetTransition;


		// default move range
		[ORKEditorInfo("Default Move Range", "Define the default base grid move range for all combatants.\n" +
			"The grid move range defines how far a combatant can move when using the move command in grid battles.\n" +
			"The base move range can be changed through grid move range bonuses applied from status bonuses.\n" +
			"Can be overridden by each individual combatant.", "",
			endFoldout=true)]
		public FloatValue moveRange = new FloatValue();


		// default battle animation
		[ORKEditorInfo("Default Battle Animation", "Define the default battle events used to animate the grid move command.\n" + 
			"Combatants can individually override the battle animation.", "",
			endFoldout=true)]
		public BattleAnimationSetting battleAnimation = new BattleAnimationSetting();


		// info text
		[ORKEditorHelp("Show Info Text", "An info text will be displayed while selecting a target cell for the move command.", "")]
		[ORKEditorInfo("Info Text", "Optionally display an info text box while the player selects a target cell for the move command.", "")]
		public bool showInfo = false;

		[ORKEditorInfo(separator=true, endFoldout=true, label=new string[] {
			"%un = user name, %ud = user description, %ui = user icon",
			"%cn = cell name, %cd = cell description, %ci = cell icon",
			"% = move cost (0), %1 = move cost (0.0), %2 = move cost (0.00)",
			"%r = move range (0), %r1 = move range (0.0), %r2 = move range (0.00)",
			"%m = max range (0), %m1 = max range (0.0), %m2 = max range (0.00)",
			"%new = range after move (0), %new1 = range after move (0.0), %new2 = range after move (0.00)",
			"%a = action cost (0), %a1 = action cost (0.0), %a2 = action cost (0.00)"
		})]
		[ORKEditorLayout("showInfo", true, endCheckGroup=true, autoInit=true)]
		public InfoBoxChoice info;


		// accept dialogue
		[ORKEditorHelp("Show Accept Question", "A question dialogue will be displayed when a cell was accepted.\n" +
			"If the player accepts the question, the cell will be used, otherwise the cell selection will be resumed.", "")]
		[ORKEditorInfo("Accept Question Dialogue", "Optionally display an accept question dialogue to ask " +
			"if the player wants to use the accepted cell.", "")]
		public bool showAcceptQuestion = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("showAcceptQuestion", true, endCheckGroup=true, autoInit=true)]
		public QuestionChoice acceptQuestion;


		// own cell selection
		[ORKEditorHelp("Own Cell Selection", "The move target selection uses a different cell selection setup.\n" +
			"If disabled, the cell selection will be used.", "")]
		[ORKEditorInfo("Cell Selection", "The move target selection can optionally override the cell selection settings.", "")]
		public bool ownCellSelection = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownCellSelection", true, endCheckGroup=true, autoInit=true)]
		public GridCellSelectionSettings selection;


		// in-game
		private GridMoveShortcut gridMoveShortcut;

		private GridPathFinder path;

		private GameObject previousCameraControlTarget;

		private NotifyBool notify;

		private bool enclosingMoveRange = false;


		// selection
		private bool canSelect = true;

		private bool isSelecting = false;

		private List<BattleGridCellComponent> selectedPath;

		private SelectGridCellBool selectCellFunction;

		private SelectGridCell acceptCellFunction;

		private GridCellCheck acceptCheckFunction;


		public GridMoveCommandSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("animate"))
			{
				this.battleAnimation.UpgradeSetting(data, "animate", "battleEvent");
			}
		}

		public void Clear()
		{
			this.CloseInfoBox();
			this.StopHighlights();

			if(this.isSelecting)
			{
				if(this.blockActionUse &&
					ORK.Battle.Settings.gridSettings.SelectingCombatant != null)
				{
					ORK.Battle.Settings.gridSettings.SelectingCombatant.Actions.BlockActionUse = false;
				}
				ORK.Battle.Grid.GridChanged -= this.GridChanged;
				this.isSelecting = false;
			}

			this.canSelect = true;
			this.gridMoveShortcut = null;
			this.previousCameraControlTarget = null;
		}

		public void GridChanged()
		{
			BattleGridCellComponent tmpCell = ORK.Battle.Settings.gridSettings.SelectedCell;
			this.StopHighlights();
			ORK.Battle.Settings.gridSettings.SelectedCell = null;
			if(this.selectedPath != null &&
				this.selectedPath.Count > 0)
			{
				this.selectedPath.Clear();
			}

			if(this.path != null)
			{
				this.path.CreateMoveRange(ORK.Battle.Settings.gridSettings.SelectingCombatant, MoveRangeType.Current, null, null);
				this.HighlightMoveRange(true);
			}
			this.SelectCell(tmpCell, true);
		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		private void HighlightMoveRange(bool start)
		{
			if(start)
			{
				if(ORK.Battle.Settings.gridHighlights.moveRangeHighlight.enable)
				{
					if(this.enclosingMoveRange)
					{
						List<BattleGridCellComponent> tmp = new List<BattleGridCellComponent>();
						tmp.AddRange(this.path.availableTargets);
						tmp.AddRange(this.path.blockedCells);
						tmp.AddRange(this.path.passableCells);
						ORK.Battle.Settings.gridHighlights.moveRangeHighlight.AddLineCells(tmp, GridHighlightType.MoveRange);
					}
					BattleGridHelper.Highlight(this.path.availableTargets, GridHighlightType.MoveRange);
				}
				if(ORK.Battle.Settings.gridHighlights.moveRangeBlockedHighlight.enable)
				{
					BattleGridHelper.Highlight(this.path.blockedCells, GridHighlightType.MoveRangeBlocked);
				}
				BattleGridHelper.Highlight(this.path.passableCells, GridHighlightType.MoveRangePassable);
			}
			else
			{
				if(ORK.Battle.Settings.gridHighlights.moveRangeHighlight.enable)
				{
					if(this.enclosingMoveRange)
					{
						List<BattleGridCellComponent> tmp = new List<BattleGridCellComponent>();
						tmp.AddRange(this.path.availableTargets);
						tmp.AddRange(this.path.blockedCells);
						tmp.AddRange(this.path.passableCells);
						ORK.Battle.Settings.gridHighlights.moveRangeHighlight.RemoveLineCells(tmp, GridHighlightType.MoveRange);
					}
					BattleGridHelper.StopHighlight(this.path.availableTargets, GridHighlightType.MoveRange);
				}
				if(ORK.Battle.Settings.gridHighlights.moveRangeBlockedHighlight.enable)
				{
					BattleGridHelper.StopHighlight(this.path.blockedCells, GridHighlightType.MoveRangeBlocked);
				}
				if(ORK.Battle.Settings.gridHighlights.moveRangePassableHighlight.enable)
				{
					BattleGridHelper.StopHighlight(this.path.passableCells, GridHighlightType.MoveRangePassable);
				}
			}
		}


		/*
		============================================================================
		GUI box functions
		============================================================================
		*/
		private string InfoReplace(string text, float moveCost, float newRange, float actionCost)
		{
			return text.
				Replace("%un", ORK.Battle.Settings.gridSettings.SelectingCombatant.GetName()).
				Replace("%ud", ORK.Battle.Settings.gridSettings.SelectingCombatant.GetDescription()).
				Replace("%ui", ORK.Battle.Settings.gridSettings.SelectingCombatant.GetIconTextCode()).
				Replace("%cn", ORK.Battle.Settings.gridSettings.SelectedCell.CellType.GetName()).
				Replace("%cd", ORK.Battle.Settings.gridSettings.SelectedCell.CellType.GetDescription()).
				Replace("%ci", ORK.Battle.Settings.gridSettings.SelectedCell.CellType.GetIconTextCode()).
				Replace("%new2", newRange.ToString("0.00")).
				Replace("%new1", newRange.ToString("0.0")).
				Replace("%new", newRange.ToString("0")).
				Replace("%m2", ORK.Battle.Settings.gridSettings.SelectingCombatant.Battle.GridMoveRangeMax.ToString("0.00")).
				Replace("%m1", ORK.Battle.Settings.gridSettings.SelectingCombatant.Battle.GridMoveRangeMax.ToString("0.0")).
				Replace("%m", ORK.Battle.Settings.gridSettings.SelectingCombatant.Battle.GridMoveRangeMax.ToString("0")).
				Replace("%r2", ORK.Battle.Settings.gridSettings.SelectingCombatant.Battle.GridMoveRange.ToString("0.00")).
				Replace("%r1", ORK.Battle.Settings.gridSettings.SelectingCombatant.Battle.GridMoveRange.ToString("0.0")).
				Replace("%r", ORK.Battle.Settings.gridSettings.SelectingCombatant.Battle.GridMoveRange.ToString("0")).
				Replace("%a2", actionCost.ToString("0.00")).
				Replace("%a1", actionCost.ToString("0.0")).
				Replace("%a", actionCost.ToString("0")).
				Replace("%2", moveCost.ToString("0.00")).
				Replace("%1", moveCost.ToString("0.0")).
				Replace("%", moveCost.ToString("0"));
		}

		private void ShowInfoBox(float moveCost, float actionCost)
		{
			if(ORK.MenuSettings.preview.gridMoveMoveCost ||
				ORK.MenuSettings.preview.gridMoveActionCost)
			{
				PreviewValues preview = new PreviewValues();
				if(ORK.MenuSettings.preview.gridMoveMoveCost)
				{
					preview.gridMoveRangeChange -= moveCost;
				}
				if(ORK.MenuSettings.preview.gridMoveActionCost)
				{
					preview.usedActionBarChange += actionCost;
				}
				ORK.GUI.ForcedPreviewShortcut = new PreviewSelection(ORK.Battle.Settings.gridSettings.SelectingCombatant, preview);
			}
			if(this.showInfo)
			{
				float newRange = ORK.Battle.Settings.gridSettings.SelectingCombatant.Battle.GridMoveRange - moveCost;
				string tmpTitle = this.info.useTitle ?
					this.InfoReplace(this.info.title[ORK.Game.Language], moveCost, newRange, actionCost) : "";
				string tmpText = this.InfoReplace(this.info.infoText[ORK.Game.Language], moveCost, newRange, actionCost);

				this.info.Show(tmpTitle, tmpText, null);
			}
		}

		private void CloseInfoBox()
		{
			if(this.showInfo)
			{
				this.info.Close();
			}
		}


		/*
		============================================================================
		Move selection functions
		============================================================================
		*/
		public void Start(Combatant combatant, GridMoveShortcut gridMoveShortcut, NotifyBool notify)
		{
			if(this.path == null)
			{
				this.enclosingMoveRange = ORK.Battle.Settings.gridHighlights.moveRangeHighlight.HighlightSetting.useLineRenderer &&
					  ORK.Battle.Settings.gridHighlights.moveRangeHighlight.HighlightSetting.line.prefab != null &&
					  ORK.Battle.Settings.gridHighlights.moveRangeHighlight.HighlightSetting.line.enclosedCells;
				this.path = new GridPathFinder(
					this.enclosingMoveRange ?
						true :
						(ORK.Battle.Settings.gridHighlights.moveRangeBlockedHighlight.enable ||
							ORK.Battle.Settings.gridHighlights.moveRangePassableHighlight.enable));
			}

			ORK.Battle.Settings.gridSettings.InitSelection(GridSelectionType.Move, combatant);
			this.previousCameraControlTarget = ORK.Control.CameraControlTarget;

			this.notify = notify == null && combatant.BattleMenu.IsOpen ?
				combatant.BattleMenu.EndGridMoveSelectionClose : notify;
			ORK.Battle.Settings.gridSettings.SelectingCombatant.BattleMenu.CloseSilent();


			this.gridMoveShortcut = gridMoveShortcut;
			if(this.gridMoveShortcut == null)
			{
				this.gridMoveShortcut = ORK.Battle.Settings.gridSettings.SelectingCombatant.Shortcuts.GridMoveShortcut;
			}
			else
			{
				ORK.Battle.Settings.gridSettings.SelectingCombatant.Shortcuts.GridMoveShortcut = this.gridMoveShortcut;
			}
			ORK.Battle.Settings.gridSettings.SelectingCombatant.Shortcuts.Active = this.gridMoveShortcut;

			if(this.selectCellFunction == null)
			{
				this.selectCellFunction = this.SelectCell;
				this.acceptCellFunction = this.AcceptCell;
				this.acceptCheckFunction = this.CheckAcceptCell;
			}

			if(this.blockActionUse)
			{
				ORK.Battle.Settings.gridSettings.SelectingCombatant.Actions.BlockActionUse = true;
			}

			this.path.CreateMoveRange(ORK.Battle.Settings.gridSettings.SelectingCombatant, MoveRangeType.Current, null, null);
			this.HighlightMoveRange(true);

			BattleGridCellComponent tmpCell = ORK.Battle.Settings.gridSettings.SelectedCell;
			ORK.Battle.Settings.gridSettings.SelectedCell = null;
			this.SelectCell(this.startFromUser || tmpCell == null ?
				this.path.startCell : tmpCell, true);

			this.isSelecting = true;
			ORK.Battle.Grid.GridChanged += this.GridChanged;
		}

		public void Restart(Combatant combatant)
		{
			if(ORK.Battle.Settings.gridSettings.SelectingCombatant == combatant)
			{
				BattleGridCellComponent tmpCell = ORK.Battle.Settings.gridSettings.SelectedCell;
				ORK.Battle.Settings.gridSettings.SelectedCell = null;
				this.SelectCell(tmpCell, true);
			}
		}

		public void Close(bool accepted)
		{
			this.StopHighlights();
			ORK.InputKeys.ResetInputAxes(true);
			if(this.blockActionUse)
			{
				ORK.Battle.Settings.gridSettings.SelectingCombatant.Actions.BlockActionUse = false;
			}

			ORK.Battle.Grid.GridChanged -= this.GridChanged;
			this.ResetCameraControlTarget();
			this.isSelecting = false;
			if(ORK.Battle.Settings.gridSettings.SelectingCombatant.Shortcuts.Active is GridMoveShortcut)
			{
				ORK.Battle.Settings.gridSettings.SelectingCombatant.Shortcuts.Active = null;
			}
			ORK.Battle.Settings.gridSettings.ClearCellSelection();

			this.Clear();
			if(this.notify != null)
			{
				this.notify(accepted);
			}
		}

		private void StopHighlights()
		{
			this.StopSelectedCellHighlight();
			if(this.selectedPath != null &&
				this.selectedPath.Count > 0)
			{
				BattleGridHelper.StopHighlight(this.selectedPath, GridHighlightType.MovePath);
				this.selectedPath.Clear();
			}
			if(this.path != null)
			{
				this.HighlightMoveRange(false);
				this.path.Clear();
			}
		}

		private void StopSelectedCellHighlight()
		{
			if(ORK.Battle.Settings.gridSettings.SelectedCell != null)
			{
				ORK.Battle.Settings.gridSettings.SelectingCombatant.Grid.StopHighlightCells(
					ORK.Battle.Settings.gridSettings.SelectedCell,
					this.path.GetPathDirection(ORK.Battle.Settings.gridSettings.SelectedCell),
					ORK.Battle.Settings.gridHighlights.GetSelectionHighlight(
						GridHighlightType.MoveSelection, ORK.Battle.Settings.gridSettings.SelectedCell));

				BattleGridHelper.StopHighlight(ORK.Battle.Settings.gridSettings.SelectedCell, GridHighlightType.NoMoveSelection);
			}
		}

		private void UseSelectedCell()
		{
			ORK.Battle.Grid.GridChanged -= this.GridChanged;
			GridMoveAction action = this.path.GetMoveAction(
				ORK.Battle.Settings.gridSettings.SelectedCell,
				this.gridMoveShortcut, null);
			this.Close(true);
			action.User.BattleMenu.AddAction(action);
		}

		private void ResetCameraControlTarget()
		{
			if(this.cameraControlTarget &&
				this.previousCameraControlTarget != null &&
				(ORK.Battle.Settings.gridSettings.SelectedCell == null ||
				ORK.Control.CameraControlTarget == ORK.Battle.Settings.gridSettings.SelectedCell.gameObject))
			{
				ORK.Control.SetCameraControlTarget(this.previousCameraControlTarget,
					this.ownControlTargetTransition ? this.controlTargetTransition : null);
			}
			this.previousCameraControlTarget = null;
		}


		/*
		============================================================================
		Cell selection functions
		============================================================================
		*/
		public void Tick()
		{
			if(this.canSelect &&
				this.isSelecting &&
				ORK.Battle.Settings.gridSettings.SelectingCombatant != null)
			{
				if(this.allowCancel &&
					ORK.InputKeys.Get(ORK.GameControls.menuControls.cancelKeyID).GetButton())
				{
					if(this.ownCellSelection)
					{
						this.selection.PlayCancelAudio();
					}
					else
					{
						ORK.Battle.Settings.gridSettings.cellSelection.PlayCancelAudio();
					}

					this.Close(false);
				}
				else
				{
					if(ORK.Battle.Settings.gridSettings.SelectedCell == null)
					{
						this.SelectCell(this.path.startCell, true);
					}
					if(this.ownCellSelection)
					{
						this.selection.SelectCell(
							this.path.startCell, ORK.Battle.Settings.gridSettings.SelectedCell,
							this.selectCellFunction, this.acceptCellFunction,
							this.acceptCheckFunction, null, false, false);
					}
					else
					{
						ORK.Battle.Settings.gridSettings.cellSelection.SelectCell(
							this.path.startCell, ORK.Battle.Settings.gridSettings.SelectedCell,
							this.selectCellFunction, this.acceptCellFunction,
							this.acceptCheckFunction, null, false, false);
					}
				}
			}
		}

		public void SelectCell(BattleGridCellComponent cell, bool isHover)
		{
			if(ORK.Battle.Settings.gridSettings.SelectedCell != cell)
			{
				// stop path highlight
				if(ORK.Battle.Settings.gridHighlights.movePathHighlight.enable &&
					this.selectedPath != null)
				{
					BattleGridHelper.StopHighlight(this.selectedPath, GridHighlightType.MovePath);
					this.selectedPath.Clear();
				}
				// stop selection highlight
				this.StopSelectedCellHighlight();

				ORK.Battle.Settings.gridSettings.SelectedCell = cell;

				// new highlights
				if(ORK.Battle.Settings.gridSettings.SelectedCell != null)
				{
					if(this.cameraControlTarget && !isHover)
					{
						ORK.Control.SetCameraControlTarget(ORK.Battle.Settings.gridSettings.SelectedCell.gameObject,
							this.ownControlTargetTransition ? this.controlTargetTransition : null);
					}

					// rotation
					if(this.rotateToCell)
					{
						ORK.Battle.Settings.gridSettings.RotateToSelectedCell(this.gridRotation);
					}

					if(this.path.availableTargets.Contains(ORK.Battle.Settings.gridSettings.SelectedCell) &&
						this.path.CheckCosts(ORK.Battle.Settings.gridSettings.SelectedCell))
					{
						if(ORK.Battle.Settings.gridHighlights.movePathHighlight.enable)
						{
							if(this.selectedPath == null)
							{
								this.selectedPath = new List<BattleGridCellComponent>();
							}
							this.path.GetPath(ORK.Battle.Settings.gridSettings.SelectedCell, ref this.selectedPath);
							this.selectedPath.Insert(0, ORK.Battle.Settings.gridSettings.SelectingCombatant.Grid.Cell);
							BattleGridHelper.Highlight(this.selectedPath, GridHighlightType.MovePath);
						}
						if(ORK.Battle.Settings.gridHighlights.moveSelectionHighlight.enable)
						{
							/*BattleGridHelper.Highlight(ORK.Battle.Settings.gridSettings.SelectedCell,
								ORK.Battle.Settings.gridHighlights.GetSelectionHighlight(
									GridHighlightType.MoveSelection, ORK.Battle.Settings.gridSettings.SelectedCell));*/
							ORK.Battle.Settings.gridSettings.SelectingCombatant.Grid.HighlightCells(
								ORK.Battle.Settings.gridSettings.SelectedCell,
								this.path.GetPathDirection(ORK.Battle.Settings.gridSettings.SelectedCell),
								ORK.Battle.Settings.gridHighlights.GetSelectionHighlight(
									GridHighlightType.MoveSelection, ORK.Battle.Settings.gridSettings.SelectedCell));
						}
					}
					else if(ORK.Battle.Settings.gridHighlights.noMoveSelectionHighlight.enable)
					{
						BattleGridHelper.Highlight(ORK.Battle.Settings.gridSettings.SelectedCell,
							ORK.Battle.Settings.gridHighlights.GetSelectionHighlight(
								GridHighlightType.NoMoveSelection, ORK.Battle.Settings.gridSettings.SelectedCell));
					}
				}
				else
				{
					this.ResetCameraControlTarget();
				}
				this.ShowInfoBox(this.path.GetMoveCost(ORK.Battle.Settings.gridSettings.SelectedCell),
					this.path.GetActionCost(ORK.Battle.Settings.gridSettings.SelectedCell));

				if(this.examineCell ||
					this.examineCellCombatant)
				{
					ORK.Battle.Settings.gridSettings.examine.ExternalExamine(
						ORK.Battle.Settings.gridSettings.SelectedCell,
						this.examineCell, this.examineCellCombatant);
				}
			}
		}

		public void AcceptCell(BattleGridCellComponent cell)
		{
			if(this.CheckAcceptCell(cell))
			{
				this.canSelect = false;
				this.CloseInfoBox();

				if(ORK.Battle.Settings.gridSettings.SelectedCell != cell)
				{
					this.SelectCell(cell, true);
				}
				if(this.showAcceptQuestion)
				{
					this.acceptQuestion.Show(
						ORK.Battle.Settings.gridSettings.SelectingCombatant.GetName(),
						this.AcceptQuestionClosed);
				}
				else
				{
					this.UseSelectedCell();
				}
			}
			else
			{
				this.SelectCell(cell, true);
			}
		}

		public void AcceptQuestionClosed(bool accepted)
		{
			if(accepted)
			{
				this.UseSelectedCell();
			}
			else
			{
				this.ShowInfoBox(this.path.GetMoveCost(ORK.Battle.Settings.gridSettings.SelectedCell),
					this.path.GetActionCost(ORK.Battle.Settings.gridSettings.SelectedCell));
				this.canSelect = true;
			}
		}

		public bool CheckAcceptCell(BattleGridCellComponent cell)
		{
			return cell != null &&
				this.path.availableTargets.Contains(cell) &&
				this.path.CheckCosts(cell);
		}
	}
}
