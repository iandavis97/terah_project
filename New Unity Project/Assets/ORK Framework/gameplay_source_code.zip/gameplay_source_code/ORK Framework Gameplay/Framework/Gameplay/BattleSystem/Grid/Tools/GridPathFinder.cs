﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;
using System.Collections;

namespace ORKFramework
{
	public enum MoveRangeType { Current, Max, All };

	public delegate void UsePathCell(BattleGridCellComponent cell, int direction);

	public class GridPathFinder
	{
		private Combatant user;

		private bool checkMarkedForAI = false;


		// flags
		private bool blockTargetDiagonalDistance1 = false;

		private bool keepBlockedCells = false;

		private bool ignoreBlockingCombatants = false;

		private bool ignoreFormationCombatants = false;

		private bool noMoveOver = false;

		private bool useActionCost = false;

		private bool moveRangeCreated = false;

		private bool considerGridFormation = false;

		private ConsiderFormationCombatants considerGridFormationCombatants = ConsiderFormationCombatants.None;

		private bool considerGridFormationReachable = false;

		private bool considerGridFormationCellType = false;


		// cells
		public BattleGridCellComponent startCell;

		public List<BattleGridCellComponent> availableTargets;

		public List<BattleGridCellComponent> blockedCells;

		public List<BattleGridCellComponent> passableCells;

		private Dictionary<BattleGridCellComponent, PathCell> cameFrom;


		// path calculation
		private bool inLocalSpace = false;

		private bool canMoveTo = false;

		private int currentPathLength = 0;

		private float currentMoveRange = 0;

		private float currentActionRange = 0;

		private Queue<BattleGridCellComponent> frontier;

		private BattleGridCellComponent current;

		private BattleGridCellComponent toCell;

		private PathCell currentCell;


		// checks
		private CombatantCheck occupantCheck;

		private GridCellCheck cellCheck;

		private UsePathCell cellUse;

		private GridCellCheck cellUseCheck;

		private GridCellCheck2 heightDistanceCheck;

		public GridPathFinder()
		{
			this.occupantCheck = this.CheckCellOccupant;
			this.cellCheck = this.CheckCell;
			this.cellUse = this.UsePathCell;
			this.cellUseCheck = this.CheckCellUse;
			this.useActionCost = ORK.Battle.IsTurnBased() || ORK.Battle.IsPhase();
		}

		public GridPathFinder(bool keepBlockedCells)
		{
			this.keepBlockedCells = keepBlockedCells;

			this.occupantCheck = this.CheckCellOccupant;
			this.cellCheck = this.CheckCell;
			this.cellUse = this.UsePathCell;
			this.cellUseCheck = this.CheckCellUse;
			this.useActionCost = ORK.Battle.IsTurnBased() || ORK.Battle.IsPhase();
		}

		public GridPathFinder(bool keepBlockedCells, bool blockTargetDiagonalDistance1)
		{
			this.keepBlockedCells = keepBlockedCells;
			this.blockTargetDiagonalDistance1 = blockTargetDiagonalDistance1;

			this.occupantCheck = this.CheckCellOccupant;
			this.cellCheck = this.CheckCell;
			this.cellUse = this.UsePathCell;
			this.cellUseCheck = this.CheckCellUse;
			this.useActionCost = ORK.Battle.IsTurnBased() || ORK.Battle.IsPhase();
		}

		public void Clear()
		{
			this.user = null;
			this.startCell = null;
			if(this.availableTargets != null)
			{
				this.availableTargets.Clear();
			}
			if(this.blockedCells != null)
			{
				this.blockedCells.Clear();
			}
			if(this.passableCells != null)
			{
				this.passableCells.Clear();
			}
			if(this.cameFrom != null)
			{
				this.cameFrom.Clear();
			}
			this.moveRangeCreated = false;
		}

		public bool MoveRangeCreated
		{
			get { return this.moveRangeCreated; }
		}

		public bool IgnoreBlockingCombatants
		{
			get { return this.ignoreBlockingCombatants; }
			set { this.ignoreBlockingCombatants = value; }
		}

		public bool IgnoreFormationCombatants
		{
			get { return this.ignoreFormationCombatants; }
			set { this.ignoreFormationCombatants = value; }
		}

		public bool NoMoveOver
		{
			get { return this.noMoveOver; }
			set { this.noMoveOver = value; }
		}

		public void SetConsiderGridFormation(bool consider,
			ConsiderFormationCombatants checkCombatants, bool checkReachable, bool sameCellType)
		{
			this.considerGridFormation = consider;
			this.considerGridFormationCombatants = checkCombatants;
			this.considerGridFormationReachable = checkReachable;
			this.considerGridFormationCellType = sameCellType;
		}


		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		public List<Combatant> GetCombatantsOnPath(BattleGridCellComponent toCell)
		{
			List<Combatant> list = new List<Combatant>();
			this.GetCombatantsOnPath(toCell, ref list);
			return list;
		}

		public void GetCombatantsOnPath(BattleGridCellComponent toCell, ref List<Combatant> list)
		{
			if(list.Count > 0)
			{
				list.Clear();
			}
			if(toCell != null && this.cameFrom != null &&
				this.cameFrom.ContainsKey(toCell))
			{
				BattleGridCellComponent current = toCell;
				current.GetCombatants(ref list, null);
				while(current != this.startCell)
				{
					current = this.cameFrom[current].cell;
					if(current != this.startCell)
					{
						current.GetCombatants(ref list, null);
					}
				}
				list.Reverse();
			}
		}

		public bool IsMarkedForAI(BattleGridCellComponent cell)
		{
			return this.checkMarkedForAI &&
				cell.MarkedForAI != null &&
				cell.MarkedForAI != this.user;
		}


		/*
		============================================================================
		Path functions
		============================================================================
		*/
		public bool CheckCosts(BattleGridCellComponent toCell)
		{
			return this.cameFrom.ContainsKey(toCell) ?
				(this.cameFrom[toCell].moveCost <= this.user.Battle.GridMoveRange &&
				(!this.useActionCost ||
					this.user.Battle.UsedActionBar + this.cameFrom[toCell].actionCost <= this.user.Battle.ActionBar)) :
				false;
		}

		public float GetMoveCost(BattleGridCellComponent toCell)
		{
			return this.cameFrom.ContainsKey(toCell) ? this.cameFrom[toCell].moveCost : 0;
		}

		public float GetActionCost(BattleGridCellComponent toCell)
		{
			return this.useActionCost ?
				(this.cameFrom.ContainsKey(toCell) ? this.cameFrom[toCell].actionCost : 0) : 0;
		}

		public List<BattleGridCellComponent> GetPath(BattleGridCellComponent toCell)
		{
			List<BattleGridCellComponent> path = new List<BattleGridCellComponent>();
			this.GetPath(toCell, ref path);
			return path;
		}

		public void GetPath(BattleGridCellComponent toCell, ref List<BattleGridCellComponent> path)
		{
			if(path.Count > 0)
			{
				path.Clear();
			}
			if(toCell != null &&
				this.cameFrom != null &&
				this.cameFrom.ContainsKey(toCell))
			{
				BattleGridCellComponent current = toCell;
				path.Add(current);
				while(current != this.startCell)
				{
					current = this.cameFrom[current].cell;
					if(current != this.startCell)
					{
						path.Add(current);
					}
				}
				path.Reverse();
			}
		}

		public int GetPathDirection(BattleGridCellComponent toCell)
		{
			if(toCell != null &&
				this.cameFrom != null)
			{
				PathCell fromCell;
				if(this.cameFrom.TryGetValue(toCell, out fromCell) &&
					fromCell.cell != null)
				{
					return fromCell.direction;
				}
			}
			return -1;
		}

		public BattleGridCellComponent GetLastReachablePathCell(BattleGridCellComponent toCell,
			bool directMoveOnly, ref bool canReach, BattleGridCellComponent targetCell,
			List<BattleGridCellComponent> ignoreCells, List<BattleGridCellComponent> allowCells,
			GridCellCheck check)
		{
			BattleGridCellComponent current = null;
			if(toCell != null &&
				this.cameFrom != null &&
				this.cameFrom.ContainsKey(toCell))
			{
				if(this.user.Grid.CanMoveTo(toCell, false, -1) &&
					!this.IsMarkedForAI(toCell) &&
					!toCell.IsBlocked)
				{
					current = toCell;
				}
				if(this.ignoreBlockingCombatants &&
					current == null)
				{
					current = toCell;
				}
				if(current != null)
				{
					canReach = true;

					if(directMoveOnly &&
						current != toCell)
					{
						return null;
					}

					// blocking combatant
					if(this.ignoreBlockingCombatants)
					{
						BattleGridCellComponent tmpCell = current;
						current = null;
						while(tmpCell != this.startCell)
						{
							if(!tmpCell.IsPassable ||
								!this.CheckCellOccupant(tmpCell.Combatant) ||
								(this.checkMarkedForAI &&
									!this.CheckCellOccupant(tmpCell.MarkedForAI)))
							{
								current = null;
							}
							if(current == null &&
								this.user.Grid.CanMoveTo(tmpCell, false, -1) &&
								!this.IsMarkedForAI(tmpCell) &&
								!tmpCell.IsBlocked)
							{
								current = tmpCell;
							}
							tmpCell = this.cameFrom[tmpCell].cell;
						}

						if(directMoveOnly &&
							current != toCell)
						{
							return null;
						}
					}
					if(current != null)
					{
						// last reachable
						while(current != this.startCell &&
							(this.cameFrom[current].moveCost > this.user.Battle.GridMoveRange ||
							(this.useActionCost &&
								this.user.Battle.UsedActionBar + this.cameFrom[current].actionCost > this.user.Battle.ActionBar) ||
							(check != null && !check(current))))
						{
							current = this.cameFrom[current].cell;


							if(directMoveOnly &&
								current != toCell)
							{
								return null;
							}

							while(current != this.startCell &&
								(current.IsBlocked ||
									!this.user.Grid.CanMoveTo(current, false, -1) ||
									this.IsMarkedForAI(current)))
							{
								current = this.cameFrom[current].cell;

								if(directMoveOnly &&
									current != toCell)
								{
									return null;
								}
							}
						}
						// grid formation
						if(this.considerGridFormation)
						{
							while(current != this.startCell &&
								!this.user.Group.GridFormation.CheckFormationPossible(
									current, this.considerGridFormationCombatants,
									targetCell != null ?
										BattleGridHelper.GetCellDirection(current, targetCell, false) :
										this.cameFrom[current].direction,
									this.considerGridFormationReachable, this.keepBlockedCells,
									this.considerGridFormationCellType, ignoreCells, allowCells))
							{
								current = this.cameFrom[current].cell;

								if(directMoveOnly &&
									current != toCell)
								{
									return null;
								}

								while(current != this.startCell &&
									(current.IsBlocked ||
										!this.user.Grid.CanMoveTo(current, false, -1) ||
										this.IsMarkedForAI(current)))
								{
									current = this.cameFrom[current].cell;

									if(directMoveOnly &&
										current != toCell)
									{
										return null;
									}
								}
							}
						}
						// final check
						if(current == this.startCell ||
							(current != null &&
								(current.IsBlocked ||
									!this.user.Grid.CanMoveTo(current, false, -1) ||
									this.IsMarkedForAI(current)) ||
									(check != null && !check(current))))
						{
							current = null;
						}
					}
				}
			}
			return current;
		}

		public BattleGridCellComponent GetMostDistantCell(BattleGridCellComponent fromCell, GridCellCheck check)
		{
			BattleGridCellComponent current = null;
			if(fromCell != null)
			{
				float maxDistance = Mathf.Infinity;
				for(int i = 0; i < this.availableTargets.Count; i++)
				{
					if(this.availableTargets[i] != null)
					{
						float tmpDistance = fromCell.CubeCoord.Distance(this.availableTargets[i].CubeCoord);
						if(tmpDistance < maxDistance &&
							(check == null || check(this.availableTargets[i])))
						{
							tmpDistance = maxDistance;
							current = this.availableTargets[i];
						}
					}
				}
			}
			return current;
		}


		/*
		============================================================================
		Move range functions
		============================================================================
		*/
		public GridMoveAction GetMoveAction(BattleGridCellComponent toCell, GridMoveShortcut gridMoveShortcut, Combatant target)
		{
			return new GridMoveAction(this.user, target, this.GetPath(toCell), this.GetMoveCost(toCell),
				this.useActionCost ? this.GetActionCost(toCell) : 0, gridMoveShortcut);
		}

		public bool CheckCell(BattleGridCellComponent cell)
		{
			return cell != null &&
				cell.CheckOccupants(this.occupantCheck) &&
				(!this.checkMarkedForAI || this.occupantCheck(cell.MarkedForAI));
		}

		public bool CheckCellOccupant(Combatant combatant)
		{
			return combatant == null ||
				combatant == this.user ||
				(!this.noMoveOver &&
					((ORK.Battle.Settings.gridSettings.moveCommand.moveOverAllies &&
						!this.user.IsEnemy(combatant)) ||
					(ORK.Battle.Settings.gridSettings.moveCommand.moveOverEnemies &&
						this.user.IsEnemy(combatant)) ||
					(this.ignoreFormationCombatants &&
						this.user.Group.InFormation &&
						this.user.Group.GridFormation.IsInFormation(combatant))));
		}

		public bool CheckCellUse(BattleGridCellComponent cell)
		{
			if(cell != null)
			{
				if(this.user.Grid.PlaceOnCheck(cell))
				{
					return true;
				}
				else
				{
					this.canMoveTo = false;
					return cell.CheckOccupants(this.occupantCheck) &&
						(!this.checkMarkedForAI || this.occupantCheck(cell.MarkedForAI));
				}
			}
			return false;
		}

		private void SetHeightLimitCheck()
		{
			GridMoveHeightLimit heightLimit = this.user.Setting.ownGridMoveHeightLimit ?
				this.user.Setting.gridMoveHeightLimit :
				ORK.Battle.Settings.gridSettings.moveCommand.heightLimit;
			if(heightLimit.limitUpwardMove ||
				heightLimit.limitDownwardMove)
			{
				this.heightDistanceCheck = heightLimit.Check;
			}
			else
			{
				this.heightDistanceCheck = null;
			}
		}

		public void CreateMoveRange(Combatant user, MoveRangeType moveRangeType,
			List<BattleGridCellComponent> ignoreCells, List<BattleGridCellComponent> allowCells)
		{
			if(user != null && user.Grid.Cell != null)
			{
				this.user = user;
				this.startCell = this.user.Grid.Cell;
				this.checkMarkedForAI = this.user.IsAIControlled();
				this.inLocalSpace = this.user.Grid.InLocalSpace;
				this.SetHeightLimitCheck();

				if(this.keepBlockedCells)
				{
					ArrayHelper.GetBlank(ref this.blockedCells);
					ArrayHelper.GetBlank(ref this.passableCells);
				}

				this.frontier = new Queue<BattleGridCellComponent>();
				this.frontier.Enqueue(this.startCell);

				ArrayHelper.GetBlank(ref this.cameFrom);
				this.cameFrom.Add(this.startCell, new PathCell(null, 0,
					this.useActionCost ? ORK.Battle.GetGridMoveActionCost(this.user) : 0, 0, false, -1));

				HashSet<BattleGridCellComponent> used = new HashSet<BattleGridCellComponent>();

				if(ignoreCells != null)
				{
					for(int i = 0; i < ignoreCells.Count; i++)
					{
						if(ignoreCells[i] != this.startCell &&
							(allowCells == null ||
								!allowCells.Contains(ignoreCells[i])))
						{
							used.Add(ignoreCells[i]);
						}
					}
				}

				this.currentMoveRange = 0;
				this.currentActionRange = 0;
				if(MoveRangeType.Current == moveRangeType)
				{
					this.currentMoveRange = this.user.Battle.GridMoveRange;
					if(this.useActionCost)
					{
						this.currentActionRange = this.user.Battle.ActionBar - this.user.Battle.UsedActionBar;
					}
				}
				else if(MoveRangeType.Max == moveRangeType)
				{
					this.currentMoveRange = this.user.Battle.GridMoveRangeMax;
					if(this.useActionCost)
					{
						this.currentActionRange = this.user.Battle.ActionBar;
					}
				}
				else if(MoveRangeType.All == moveRangeType)
				{
					this.currentMoveRange = Mathf.Infinity;
					if(this.useActionCost)
					{
						this.currentActionRange = Mathf.Infinity;
					}
				}

				bool blockedOccupied = ORK.Battle.Settings.gridHighlights.moveRangeBlockedHighlightOccupied;

				while(this.frontier.Count > 0)
				{
					this.current = this.frontier.Dequeue();
					this.currentCell = this.cameFrom[this.current];
					bool costLimit = this.currentCell.moveCost >= this.currentMoveRange ||
						this.currentCell.actionCost >= this.currentActionRange;
					this.currentPathLength = this.currentCell.pathLength + 1;

					if(!used.Contains(this.current))
					{
						used.Add(this.current);

						// neighbours
						if(this.keepBlockedCells &&
							!costLimit)
						{
							BattleGridHelper.UsePathNeighbourCells(this.current, this.cellUse, ref this.blockedCells,
								ORK.Battle.Settings.gridSettings.moveCommand.squareDiagonalMove, blockedOccupied,
								this.ignoreBlockingCombatants ? null : this.cellCheck,
								ORK.Battle.Settings.gridSettings.moveCommand.squareDiagonalMoveBlockingCombatants ? this.cellCheck : null);
						}
						else
						{
							BattleGridHelper.UsePathNeighbourCells(this.current, this.cellUse,
								ORK.Battle.Settings.gridSettings.moveCommand.squareDiagonalMove,
								this.ignoreBlockingCombatants ? null : this.cellCheck,
								ORK.Battle.Settings.gridSettings.moveCommand.squareDiagonalMoveBlockingCombatants ? this.cellCheck : null);
						}
					}
				}

				// generate available target cells
				ArrayHelper.GetBlank(ref this.availableTargets);
				foreach(BattleGridCellComponent cell in this.cameFrom.Keys)
				{
					if(cell != null &&
						!cell.IsBlocked &&
						this.cameFrom[cell].canMoveTo &&
						(!this.checkMarkedForAI ||
							cell.MarkedForAI == null ||
							cell.MarkedForAI == user ||
							(this.ignoreFormationCombatants &&
								user.Group.InFormation &&
								user.Group.GridFormation.IsInFormation(cell.MarkedForAI))))
					{
						this.availableTargets.Add(cell);
					}
					else if(this.keepBlockedCells &&
						(blockedOccupied || cell.IsEmpty))
					{
						this.passableCells.Add(cell);
					}
				}
				this.moveRangeCreated = true;
			}
		}

		public void UsePathCell(BattleGridCellComponent cell, int direction)
		{
			this.canMoveTo = true;
			if(cell.Settings.CanMoveFrom(this.current) &&
				(this.heightDistanceCheck == null ||
					this.heightDistanceCheck(this.current, cell)) &&
				this.user.Grid.CheckCells(cell, 
					this.inLocalSpace ? direction : -1,
					this.cellUseCheck))
			{
				// check cost
				float newMoveCost = this.currentCell.moveCost +
					cell.Settings.GetMoveCost(this.user, this.current);
				float newActionCost = this.useActionCost ?
					(this.currentCell.actionCost +
						cell.Settings.GetActionCost(this.user, this.current)) :
					0;

				if(newMoveCost <= this.currentMoveRange &&
					(!this.useActionCost ||
						newActionCost <= this.currentActionRange))
				{
					PathCell cameFromCell;
					// check replace old cell
					if(this.cameFrom.TryGetValue(cell, out cameFromCell))
					{
						if((newMoveCost < cameFromCell.moveCost &&
								newActionCost == cameFromCell.actionCost) ||
							(this.useActionCost &&
								newMoveCost == cameFromCell.moveCost &&
								newActionCost < cameFromCell.actionCost) ||
							(newMoveCost == cameFromCell.moveCost &&
								(!this.useActionCost ||
									newActionCost == cameFromCell.actionCost) &&
								// not diagonal
								((ORK.Battle.Settings.gridSettings.moveCommand.squareDiagonalMove &&
									ORK.Battle.Settings.gridSettings.IsSquare &&
									!CubeCoord.IsSquareDiagonal(this.current.CubeCoord, cell.CubeCoord)) ||
								// shorter path
								(ORK.Battle.Settings.gridSettings.moveCommand.useShortestPath &&
									this.currentPathLength < cameFromCell.pathLength))))
						{
							this.frontier.Enqueue(cell);
							this.cameFrom[cell].Set(
								this.current, newMoveCost, newActionCost,
								this.currentPathLength, this.canMoveTo, direction);
						}
					}
					// new cell
					else
					{
						this.frontier.Enqueue(cell);
						this.cameFrom.Add(cell, new PathCell(
							this.current, newMoveCost, newActionCost,
							this.currentPathLength, this.canMoveTo, direction));
					}
				}
			}
		}

		public void CreatePathTo(Combatant user, BattleGridCellComponent toCell)
		{
			if(user != null && user.Grid.Cell != null)
			{
				this.user = user;
				this.startCell = this.user.Grid.Cell;
				this.toCell = toCell;
				this.checkMarkedForAI = this.user.IsAIControlled();
				this.SetHeightLimitCheck();

				this.frontier = new Queue<BattleGridCellComponent>();
				this.frontier.Enqueue(this.startCell);

				ArrayHelper.GetBlank(ref this.cameFrom);
				this.cameFrom.Add(this.startCell, new PathCell(null, 0,
					this.useActionCost ? ORK.Battle.GetGridMoveActionCost(this.user) : 0, 0, false, -1));

				HashSet<BattleGridCellComponent> used = new HashSet<BattleGridCellComponent>();
				used.Add(this.toCell);

				while(this.frontier.Count > 0)
				{
					// sort frontier
					this.current = this.frontier.Dequeue();
					this.currentPathLength = this.cameFrom[current].pathLength + 1;

					if(!used.Contains(current))
					{
						used.Add(current);

						BattleGridHelper.UsePathNeighbourCells(current, this.UseCreatePathCell,
							ORK.Battle.Settings.gridSettings.moveCommand.squareDiagonalMove, null,
							ORK.Battle.Settings.gridSettings.moveCommand.squareDiagonalMoveBlockingCombatants ? this.cellCheck : null);

					}
				}
			}
		}

		public void UseCreatePathCell(BattleGridCellComponent cell, int direction)
		{
			this.canMoveTo = true;
			// check cell combatant
			if(cell.Settings.CanMoveFrom(this.current) &&
				(this.heightDistanceCheck == null ||
					this.heightDistanceCheck(this.current, cell)) &&
				(cell == this.toCell ||
					this.user.Grid.CheckCells(cell, 
						this.inLocalSpace ? direction : -1,
						this.cellUseCheck)))
			{
				float newMoveCost = this.cameFrom[this.current].moveCost +
					cell.Settings.GetMoveCost(this.user, this.current);
				float newActionCost = this.useActionCost ?
					(this.cameFrom[this.current].actionCost +
						cell.Settings.GetActionCost(this.user, this.current)) :
					0;

				PathCell cameFromCell;
				// check replace old cell
				if(this.cameFrom.TryGetValue(cell, out cameFromCell))
				{
					if((newMoveCost < cameFromCell.moveCost &&
							newActionCost == cameFromCell.actionCost) ||
						(this.useActionCost && newMoveCost == cameFromCell.moveCost &&
							newActionCost < cameFromCell.actionCost) ||
						(newMoveCost == cameFromCell.moveCost &&
							(!this.useActionCost || newActionCost == cameFromCell.actionCost) &&
							// not diagonal
							((ORK.Battle.Settings.gridSettings.moveCommand.squareDiagonalMove &&
								ORK.Battle.Settings.gridSettings.IsSquare &&
								!CubeCoord.IsSquareDiagonal(this.current.CubeCoord, cell.CubeCoord)) ||
							// shorter path
							(ORK.Battle.Settings.gridSettings.moveCommand.useShortestPath &&
								this.currentPathLength < cameFromCell.pathLength))) ||
						// use free cell
						(cell == this.toCell &&
							this.user.Grid.CanMoveTo(this.current, false, -1) &&
							(!ORK.Battle.Settings.gridSettings.squareDiagonalDistanceOne ||
								this.current.CubeCoord.Distance(this.toCell.CubeCoord, this.blockTargetDiagonalDistance1) == 1) &&
							!this.user.Grid.CanMoveTo(cameFromCell.cell, false, -1)))
					{
						this.frontier.Enqueue(cell);
						this.cameFrom[cell].Set(this.current, newMoveCost, newActionCost,
							this.currentPathLength, this.canMoveTo, direction);
					}
				}
				// new cell
				else
				{
					this.frontier.Enqueue(cell);
					this.cameFrom.Add(cell, new PathCell(this.current, newMoveCost, newActionCost,
						this.currentPathLength, this.canMoveTo, direction));
				}
			}
		}

		public static bool CanReach(Combatant combatant, BattleGridCellComponent cell,
			bool keepBlockedCells, bool ignoreFormationCombatants, MoveRangeType moveRangeType,
			List<BattleGridCellComponent> ignoreCells, List<BattleGridCellComponent> allowCells)
		{
			if(combatant != null &&
				combatant.Grid.Cell != null &&
				ORK.Battle.Grid != null)
			{
				GridPathFinder path = new GridPathFinder(keepBlockedCells);
				path.ignoreFormationCombatants = ignoreFormationCombatants;
				path.CreateMoveRange(combatant, moveRangeType, ignoreCells, allowCells);
				return path.availableTargets.Contains(cell);
			}
			return false;
		}

		private struct PathCell
		{
			public BattleGridCellComponent cell;

			public float moveCost;

			public float actionCost;

			public int pathLength;

			public bool canMoveTo;

			public int direction;

			public PathCell(BattleGridCellComponent cell, float moveCost, float actionCost,
				int pathLength, bool canMoveTo, int direction)
			{
				this.cell = cell;
				this.moveCost = moveCost;
				this.actionCost = actionCost;
				this.pathLength = pathLength;
				this.canMoveTo = canMoveTo;
				this.direction = direction;
			}

			public void Set(BattleGridCellComponent cell, float moveCost, float actionCost,
				int pathLength, bool canMoveTo, int direction)
			{
				this.cell = cell;
				this.moveCost = moveCost;
				this.actionCost = actionCost;
				this.pathLength = pathLength;
				this.canMoveTo = canMoveTo;
				this.direction = direction;
			}
		}
	}
}
