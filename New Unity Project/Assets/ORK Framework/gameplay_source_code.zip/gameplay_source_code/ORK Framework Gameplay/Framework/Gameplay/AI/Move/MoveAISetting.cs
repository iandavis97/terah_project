
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class MoveAISetting : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of the AI movement.", "")]
		[ORKEditorInfo("Base Settings", "Set the name and base settings of the battle AI.", "", expandWidth=true)]
		public string name = "";

		[ORKEditorHelp("Use Mode", "Select the use mode of this move AI:\n" +
			"- Auto: Automatically uses the different behaviours (e.g. hunting, fleeing).\n" +
			"- Idle: Forces idle mode, only following waypoints (if used).\n" +
			"- Hunt: Forces hunting.\n" +
			"- Flee: Forces fleeing.\n" +
			"- Caution: Forces caution.", "")]
		public MoveAIUseMode useMode = MoveAIUseMode.Auto;

		[ORKEditorHelp("Horizontal Plane", "Select the horizontal plane (i.e. which axes are used for horizontal movement):\n" +
			"- XZ: The game objects are moving on the XZ plane horizontally, i.e. default 3D behaviour.\n" +
			"- XY: The game objects are moving on the XY plane horizontally, i.e. default 2D behaviour.", "")]
		public HorizontalPlaneType horizontalPlane = HorizontalPlaneType.XZ;

		// move range
		[ORKEditorHelp("Use Move Range", "The combatant will only move within a range of its start position " +
			"(i.e. the position it has been spawned at).\n" +
			"When leaving the move range, the combatant will return to its start position." +
			"If disabled, there is no limit to the move range.\n" +
			"The move range overrules other ranges (e.g. the hunting range).", "")]
		[ORKEditorInfo(separator=true, labelText="Move Range")]
		public bool useMoveRange = false;

		[ORKEditorLayout("useMoveRange", true, endCheckGroup=true, autoInit=true)]
		public Range moveRange;

		// auto stop
		[ORKEditorHelp("Use Auto Stop", "The combatant will automatcially stop when " +
			"being close to the target for a defined amount of time.\n" +
			"Use this when the combatant seems to move in circles at the target location.", "")]
		[ORKEditorInfo(separator=true, labelText="Auto Stop Settings")]
		public bool autoStop = true;

		[ORKEditorHelp("Stop Distance", "The distance in world units the combatant must be to auto stop.", "")]
		[ORKEditorLayout("autoStop", true)]
		public float stopDistance = 0.5f;

		[ORKEditorHelp("Stop Time (s)", "The time in seconds the combatant ", "")]
		public float stopTime = 0.5f;

		[ORKEditorHelp("Clear Target", "Clear the target the combatant was following or hunting when auto stopping.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool stopClear = false;

		// move position/speed component calls
		[ORKEditorHelp("Component Type", "Select the component used to move the combatant:\n" +
			"- Default: A simple movement component that will move directly to the target.\n" +
			"- Nav Mesh Agent: Unity's built in NavMesh is used.\n" +
			"- Custom: A custom component is used.", "")]
		[ORKEditorInfo(separator=true, labelText="Move Component Settings", callbackAfter="button:movecomopnent")]
		public MoveComponentType compType = MoveComponentType.Default;

		[ORKEditorHelp("Add Component", "The component will be added to the combatant's game object, if it isn't added already.\n" +
			"If disabled, the component must already be attached to the combatant's game object (i.e. its prefab).", "")]
		public bool compAdd = false;

		[ORKEditorHelp("Component Name", "The name of the custom component used to move the combatant.\n" +
			"If the component is in a namespace, you must define the full path (e.g. MyNamespace.Script.ComponentName).", "")]
		[ORKEditorLayout("compType", MoveComponentType.Custom)]
		[ORKEditorInfo(expandWidth=true)]
		public string compName = "";

		[ORKEditorHelp("Speed Method Name", "The name of the method used to set the move speed.\n" +
			"Requires a method that takes a float value as parameter.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string compSpeedMethod = "";

		[ORKEditorHelp("Position Method Name", "The name of the method used to set the move position.\n" +
			"Requires a method that takes a Vector3 value as parameter.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string compPositionMethod = "";

		[ORKEditorHelp("Stop Method Name", "The name of the method used to stop the movement.\n" +
			"Requires a method that takes no parameters.", "")]
		[ORKEditorInfo(endFoldout=true, expandWidth=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string compStopMethod = "";


		// speed settings
		[ORKEditorInfo("Speed Settings", "Define the move speed for the different modes of the move AI (i.e. following, hunting, fleeing).", "",
			labelText="Follow Speed")]
		public MoveSpeed followSpeed = new MoveSpeed(MoveSpeedType.Run, 5);

		[ORKEditorInfo(separator=true, labelText="Give Way Speed")]
		public MoveSpeed giveWaySpeed = new MoveSpeed(MoveSpeedType.Walk, 5);

		[ORKEditorInfo(separator=true, labelText="Hunting Speed")]
		public MoveSpeed huntingSpeed = new MoveSpeed(MoveSpeedType.Run, 5);

		[ORKEditorInfo(separator=true, labelText="Flee Speed")]
		public MoveSpeed fleeSpeed = new MoveSpeed(MoveSpeedType.Run, 5);

		[ORKEditorInfo(separator=true, labelText="Waypoint Speed", endFoldout=true)]
		public MoveSpeed waypointSpeed = new MoveSpeed(MoveSpeedType.Run, 5);


		// waypoint settings
		[ORKEditorHelp("Stop Distance", "The distance in world units the combatant will stop before reaching a waypoint.", "")]
		[ORKEditorInfo("Waypoint Settings", "The combatant can follow defined waypoints or randomly patrol in the scene.\n" +
			"To follow waypoints, you have to add the waypoints to the combatant's settings in the scene (inspector).\n" +
			"Uses the 'Waypoint Speed' to move.\n" +
			"Randomly patroling or following defined waypoints is only done if the combatant isn't " +
			"following someone (e.g. the leader or an enemy).", "")]
		[ORKEditorLimit(0.0f, false)]
		public float waypointStopDistance = 0.1f;

		[ORKEditorHelp("No Combatant Radius", "The combatant radius setting of the combatants will " +
			"be ignored when calculating the distance to a waypoint.", "")]
		public bool waypointIgnoreRadius = false;

		[ORKEditorHelp("Reset Time (s)", "The time in seconds before the combatant switches to the " +
			"next waypoint when not reaching the current one.\n" +
			"The combatant needs to stand still for the time to start.", "")]
		public float waypointResetTime = 1;

		[ORKEditorHelp("Enable Random Patrol", "The combatant will randomly patrol in the scene.\n" +
			"The random patrol can be overridden by waypoints added to a spawned combatant (e.g. in their inspector in the scene).", "")]
		[ORKEditorInfo(separator=true)]
		public bool randomPatrol = false;

		[ORKEditorHelp("Patrol Radius", "The radius around the original spawn point used to patrol.\n" +
			"If in a group, the group leader will be the center of the area.", "")]
		[ORKEditorLayout("randomPatrol", true)]
		public float patrolRadius = 20.0f;

		[ORKEditorHelp("From Current Position", "The patrol radius is used from the current position of the combatant.\n" +
			"If disabled, the patrol radius is used from the original start position of the combatant.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool patrolFromCurrent = false;


		// idle behaviour
		[ORKEditorHelp("Enable Idle", "Use move events as idle behaviours.\n" +
			"If disabled, the combatant wont use idle behaviours and wont stop between waypoints.", "")]
		[ORKEditorInfo("Idle Settings", "Define how the combatant acts while standing still, e.g. while waiting at a waypoint.", "")]
		public bool useIdle = false;

		[ORKEditorHelp("Random", "A random idle behaviour will be used.\n" +
			"If disabled, the idle behaviours will be used in sequence.", "")]
		[ORKEditorLayout("useIdle", true)]
		public bool idleRandom = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Idle Behaviour", "Adds an idle behaviour setting.", "",
			"Remove", "Removes this idle behaviour setting.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {"Idle Behaviour", "Idle behaviours use move events to define how a combatant acts while standing still.\n" +
				"If the chance fails, no other move event will be selected instead.", ""})]
		[ORKEditorLayout(autoInit=true, endCheckGroup=true)]
		public IdleBehaviour[] idleBehaviour;


		// follow leader
		[ORKEditorHelp("Follow Leader", "The combatant will follow its group leader if outside a defined range to the leader.", "")]
		[ORKEditorInfo("Group Settings", "Define if the combatant will follow its group leader.", "")]
		public bool followLeader = false;

		[ORKEditorHelp("Stop Hunting", "The combatant wont hunt if following its group leader.\n" +
			"Only the leader of a group will hunt (if all group members have this option enabled).\n" +
			"If disabled, the combatant will still hunt, even while following its leader.", "")]
		[ORKEditorLayout("followLeader", true)]
		public bool leaderStopHunt = true;

		[ORKEditorHelp("No Waypoints", "The combatant wont follow waypoints or randomly patrol if following its group leader.\n" +
			"Only the leader of a group will follow waypoints (if all group members have this option enabled).\n" +
			"If disabled, the combatant will still follow waypoints, even while following its leader " +
			"(when not outside the follow range).", "")]
		public bool leaderNoWaypoint = true;

		[ORKEditorInfo(separator=true, labelText="Follow Range", label=new string[] {
			"The combatant will follow his leader when being outside this range."
		})]
		public Range followLeaderRange = new Range(5, true, false, 0.5f);

		// give way
		[ORKEditorHelp("Give Way", "The combatant will move out of the way of its leader if inside a defined range to the leader.", "")]
		[ORKEditorInfo(separator=true, labelText="Give Way")]
		public bool giveWay = false;

		[ORKEditorLayout("giveWay", true, endCheckGroup=true)]
		public Range giveWayRange = new Range(1, true, false, 0.5f);

		// auto respawn
		[ORKEditorHelp("Auto Respawn", "The combatant will automatically respawn near its leader if outside a defined range to the leader.", "")]
		[ORKEditorInfo(separator=true, labelText="Auto Respawn")]
		public bool autoRespawn = false;

		[ORKEditorLayout("autoRespawn", true, endCheckGroup=true, endGroups=2)]
		public Range autoRespawnRange = new Range(50);

		// leader priority
		[ORKEditorHelp("Prioritise Leader", "Following the leader takes priority over " +
			"other movement when outside a defined range.\n" +
			"If disabled, the combatant will continue movement toward his current target ignoring the leader.", "")]
		[ORKEditorInfo(separator=true, labelText="Prioritise Leader")]
		public bool leaderPriority = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("leaderPriority", true, endCheckGroup=true)]
		public Range leaderPriorityRange = new Range(10, true, false, 0.5f);


		// enemy detection
		// base range
		[ORKEditorHelp("Use Detection", "Use enemy detection - this is needed for hunting and fleeing.\n" +
			"If disabled, the combatant can't hunt or flee from enemy combatants.", "")]
		[ORKEditorInfo("Enemy Detection", "Define how enemies are detected.\n" +
			"Only detected enemy combatants can be hunted or fled from.", "")]
		public bool useDetection = false;

		[ORKEditorHelp("Detect Only Leader", "Only enemy group leaders will be detected.\n" +
			"If disabled, all ememy group members can be detected.", "")]
		[ORKEditorLayout("useDetection", true)]
		public bool detectOnlyLeader = false;

		[ORKEditorHelp("Detect On Damage", "Detect combatants that damage the combatant.", "")]
		public bool detectOnDamage = false;

		[ORKEditorHelp("Use Attack Allies", "Allies will also be detected as targets when a status value " +
			"with 'Attack Allies' enabled is applied to the combatant.", "")]
		public bool detectAttackAllies = false;

		[ORKEditorHelp("Timeout (s)", "The time in seconds between two detection checks.\n" +
			"Set to 0 to check every Update call.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float detectionTimeout = 1;

		[ORKEditorInfo(separator=true, labelText="Base Detection Range")]
		public Range detectionRange = new Range(20, true, false, 0.5f);

		[ORKEditorHelp("Needed", "Select if all or just one move detection must detect the target.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Move Detections")]
		public Needed detectionNeeded = Needed.One;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Detection", "Adds a move detection setting.\n" +
			"You can use multiple move detections to detect enemy movement.", "",
			"Remove", "Removes this move detection setting.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {"Move Detection", "Move detections determine how an enemy combatant will be detected.", ""})]
		[ORKEditorLayout(autoInit=true, endCheckGroup=true)]
		public MoveDetection[] detection;


		// target check intervalls
		[ORKEditorInfo("Target Position Check", "If the move AI has a target (e.g. hunting another combatant, following its leader), " +
			"the position of the target will be checked frequently and forwarded to the component handling the movement.\n" +
			"You can define several intervals based on different distances, " +
			"the combatant will move to the position of the last check.\n" +
			"The interval between two checks should decrease as the combatant gets nearer to the target.", "",
			endFoldout=true)]
		public MoveAITargetPositionCheck targetPositionCheck = new MoveAITargetPositionCheck();


		// hunting settings
		[ORKEditorInfo("Hunting Settings", "This settings determine if and how a combatant reacts to enemy combatants.", "",
			endFoldout=true)]
		[ORKEditorLayout("useDetection", true)]
		public MoveAIHunting hunting = new MoveAIHunting();


		// flee settings
		[ORKEditorInfo("Flee Settings", "The combatant can optionally flee from enemy combatants if a defined level difference occurs.", "",
			endFoldout=true)]
		public MoveAIFlee flee = new MoveAIFlee();


		// cautious settings
		[ORKEditorInfo("Caution Settings", "The combatant can be cautious, staying within a defined range to the target " +
			"and fleeing when getting too close.", "",
			endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public MoveAICaution caution = new MoveAICaution();

		public MoveAISetting()
		{

		}

		public MoveAISetting(string name)
		{
			this.name = name;
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useHunting"))
			{
				data.Get("randomPatrolHorizontalPlane", ref this.horizontalPlane);
				this.hunting.SetData(data);
				this.flee.SetData(data);
				this.targetPositionCheck.SetData(data);
			}
		}


		/*
		============================================================================
		Idle functions
		============================================================================
		*/
		public ORKMoveEvent GetIdleEvent(ref int lastIndex)
		{
			if(this.useIdle && this.idleBehaviour != null && this.idleBehaviour.Length > 0)
			{
				if(this.idleRandom)
				{
					return this.idleBehaviour[UnityWrapper.Range(0, this.idleBehaviour.Length)].GetEvent();
				}
				else
				{
					lastIndex++;
					if(lastIndex < 0 || lastIndex >= this.idleBehaviour.Length)
					{
						lastIndex = 0;
					}
					return this.idleBehaviour[lastIndex].GetEvent();
				}
			}
			return null;
		}


		/*
		============================================================================
		Detection functions
		============================================================================
		*/
		public bool IsDetectionEnabled()
		{
			return this.useDetection && this.detection != null && this.detection.Length > 0 &&
				(this.hunting.enabled || this.flee.enabled || this.caution.enabled);
		}

		public void DetectTargets(Combatant combatant, ref List<Combatant> targets)
		{
			if(this.useDetection)
			{
				List<Combatant> list = ORK.Game.Combatants.Get(combatant, true, this.detectionRange,
					this.detectAttackAllies && combatant.Status.Effects.AttackAllies ?
						Consider.Ignore : Consider.Yes,
					Consider.No, Consider.Ignore, null);

				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						!list[i].Status.IsDead &&
						!targets.Contains(list[i]) &&
						(!this.detectOnlyLeader || list[i].IsLeader) &&
						this.Detect(combatant, list[i]))
					{
						targets.Add(list[i]);
					}
				}
			}
		}

		public bool Detect(Combatant combatant, Combatant target)
		{
			if(this.detection != null)
			{
				for(int i = 0; i < this.detection.Length; i++)
				{
					if(this.detection[i].Detected(combatant, target))
					{
						if(Needed.One == this.detectionNeeded)
						{
							return true;
						}
					}
					else if(Needed.All == this.detectionNeeded)
					{
						return false;
					}
				}
				if(Needed.All == this.detectionNeeded)
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Component functions
		============================================================================
		*/
		public MoveAIComponent AddAIMover(Combatant combatant)
		{
			MoveAIComponent comp = combatant.GameObject.GetComponent<MoveAIComponent>();
			if(comp == null)
			{
				comp = combatant.GameObject.AddComponent<MoveAIComponent>();
				comp.combatant = combatant;
				comp.settings = this;
				comp.originalMoveID = this.realID;
				comp.useMode = this.useMode;
			}
			else
			{
				comp.settings = this;
				comp.combatant = combatant;
			}
			return comp;
		}
	}
}
