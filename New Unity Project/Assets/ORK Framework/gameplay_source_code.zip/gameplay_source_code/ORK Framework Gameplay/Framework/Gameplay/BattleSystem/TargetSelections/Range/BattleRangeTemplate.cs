﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleRangeTemplate : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of this battle range template.", "")]
		[ORKEditorInfo("Base Settings", "Set the name and base settings of this battle range template.", "",
			expandWidth=true, endFoldout=true)]
		public string name = "";

		public BattleRangeSetting range = new BattleRangeSetting();

		public BattleRangeTemplate()
		{

		}

		public BattleRangeTemplate(string name)
		{
			this.name = name;
		}

		public BattleRangeTemplate(string name, float range)
		{
			this.name = name;
			this.range.useMax = true;
			this.range.maxRange = new Range(range);
			this.range.gridSettings.gridShapeType = GridShapeType.Range;
			this.range.gridSettings.gridRange = (int)range;
		}
	}
}
