﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridPath
	{
		private Combatant user;

		private List<BattleGridCellComponent> path;

		private BattleGridCellComponent targetCell;

		private float moveCost;

		private bool ended = false;

		public GridPath(Combatant user, List<BattleGridCellComponent> path, float moveCost)
		{
			this.user = user;
			this.path = path;
			this.moveCost = moveCost;

			if(this.path != null)
			{
				while(this.path.Count > 0 &&
					(this.path[this.path.Count - 1].IsBlocked ||
						!this.user.Grid.CanMoveTo(this.path[this.path.Count - 1], false, -1)))
				{
					this.path.RemoveAt(this.path.Count - 1);
				}
				if(this.path.Count > 0)
				{
					this.targetCell = this.path[this.path.Count - 1];
					if(ORK.Battle.Settings.gridSettings.moveCommand.markTargetCell)
					{
						this.targetCell.MarkedForCombatant = this.user;
					}
				}
			}
		}

		public void Clear()
		{
			this.path = null;
			if(this.targetCell != null)
			{
				if(ORK.Battle.Settings.gridSettings.moveCommand.markTargetCell)
				{
					this.targetCell.MarkedForCombatant = null;
				}
				this.targetCell = null;
			}
		}

		public void ConsumeMoveCost()
		{
			this.user.Battle.GridMoveRange -= this.moveCost;
			this.moveCost = 0;
		}

		public void End()
		{
			if(!this.ended)
			{
				this.ended = true;
				if(this.targetCell != null)
				{
					this.user.Grid.Cell = this.targetCell;
				}
				this.ConsumeMoveCost();

				if(this.user.Grid.Cell != null &&
					this.user.GameObject != null)
				{
					this.user.GameObject.transform.position = this.user.Grid.Cell.transform.position;
				}
			}
		}


		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		public Combatant User
		{
			get { return this.user; }
		}

		public bool IsNotUser(Combatant combatant)
		{
			return this.user != combatant;
		}

		public List<Combatant> GetNextPathCellCombatants(bool ignoreUser, bool removeCell)
		{
			if(this.path != null && this.path.Count > 0)
			{
				BattleGridCellComponent cell = this.path[0];
				if(removeCell)
				{
					this.path.RemoveAt(0);
				}
				if(cell != null)
				{
					List<Combatant> list = new List<Combatant>();
					cell.GetCombatants(ref list,
						ignoreUser ? this.IsNotUser : (CombatantCheck)null);
					return list;
				}
			}
			return null;
		}

		public List<Combatant> GetLastPathCellCombatants(bool ignoreUser, bool removeCell)
		{
			if(this.path != null && this.path.Count > 0)
			{
				int index = this.path.Count - 1;
				BattleGridCellComponent cell = this.path[index];
				if(removeCell)
				{
					this.path.RemoveAt(index);
				}
				if(cell != null)
				{
					List<Combatant> list = new List<Combatant>();
					cell.GetCombatants(ref list,
						ignoreUser ? this.IsNotUser : (CombatantCheck)null);
					return list;
				}
			}
			return null;
		}

		public List<Combatant> GetRemainingPathCombatants(bool ignoreUser, bool removeCell)
		{
			List<Combatant> list = new List<Combatant>();
			for(int i = 0; i < this.path.Count; i++)
			{
				if(this.path[i] != null)
				{
					this.path[i].GetCombatants(ref list,
						ignoreUser ? this.IsNotUser : (CombatantCheck)null);
				}
			}
			if(removeCell)
			{
				this.path = null;
			}
			return list;
		}


		/*
		============================================================================
		Path functions
		============================================================================
		*/
		public int GetRemainingPathLength()
		{
			return this.path != null ? this.path.Count : 0;
		}

		public BattleGridCellComponent GetNextPathCell(bool removeCell)
		{
			if(this.path != null && this.path.Count > 0)
			{
				BattleGridCellComponent cell = this.path[0];
				if(removeCell)
				{
					this.path.RemoveAt(0);
				}
				return cell;
			}
			return null;
		}

		public BattleGridCellComponent GetLastPathCell(bool removeCell)
		{
			if(this.path != null && this.path.Count > 0)
			{
				int index = this.path.Count - 1;
				BattleGridCellComponent cell = this.path[index];
				if(removeCell)
				{
					this.path.RemoveAt(index);
				}
				return cell;
			}
			return null;
		}

		public List<BattleGridCellComponent> GetRemainingPath(bool removeCell)
		{
			List<BattleGridCellComponent> list = this.path;
			if(removeCell)
			{
				this.path = null;
			}
			return list;
		}

		public void RemoveCell(GridPathCellSelection selection)
		{
			if(GridPathCellSelection.Next == selection)
			{
				if(this.path != null && this.path.Count > 0)
				{
					this.path.RemoveAt(0);
				}
			}
			else if(GridPathCellSelection.Last == selection)
			{
				if(this.path != null && this.path.Count > 0)
				{
					this.path.RemoveAt(this.path.Count - 1);
				}
			}
			else if(GridPathCellSelection.All == selection)
			{
				this.path = null;
			}
		}

		public bool CheckValidStart()
		{
			bool found = false;
			if(this.path != null &&
				this.path.Count > 0)
			{

				for(int i = 0; i < this.path.Count; i++)
				{
					if(BattleGridHelper.IsNeighbourCell(this.user.Grid.Cell, this.path[i],
						ORK.Battle.Settings.gridSettings.moveCommand.squareDiagonalMove, null))
					{
						found = true;
						break;
					}
					else
					{
						this.path.RemoveAt(i--);
					}
				}
			}

			if(!found)
			{
				this.Clear();
			}

			return found;
		}
	}
}
