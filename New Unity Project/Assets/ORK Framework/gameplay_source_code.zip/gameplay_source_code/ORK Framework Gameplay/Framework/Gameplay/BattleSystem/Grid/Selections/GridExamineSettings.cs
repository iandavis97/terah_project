﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridExamineSettings : BaseData
	{
		// settings
		[ORKEditorHelp("Allow Cancel", "The grid cell selection can be canceled using the 'Cancel' key defined in the game controls.\n" +
			"If disabled, the cell of the selecting combatant must be selected and accepted to stop the grid examination.", "")]
		public bool allowCancel = false;

		[ORKEditorHelp("Block Action Use", "Using actions is blocked for the combatant during the grid cell selection.\n" +
			"This isn't used during 'Always Active' selection phases.", "")]
		public bool blockActionUse = false;


		// always active
		[ORKEditorHelp("Always Active", "Grid examine is always active during grid battles.\n" +
			"Please note that grid examine isn't active during other cell selections (e.g. move command or target cell selections), " +
			"but you can enable showing the cell info and combatant info dialogues for the selected cell in the individual settings.\n" +
			"'Block Action Use' is not used during 'Always Active' selection phases.", "")]
		[ORKEditorInfo(separator=true, labelText="Always Active Examine")]
		public bool alwaysActive = false;

		[ORKEditorHelp("During Target Selection", "Grid examine is also active during target selections.\n" +
			"If disabled, 'Always Active' isn't used when a target for an action is being selected.", "")]
		[ORKEditorLayout("alwaysActive", true)]
		public bool alwaysActiveDuringTargetSelection = false;

		[ORKEditorHelp("During Actions", "Grid examine is also active during actions.\n" +
			"If disabled, 'Always Active' is only used while no action is being performed.", "")]
		public bool alwaysActiveDuringActions = false;

		[ORKEditorHelp("Only Player Phase", "In 'Phase' battles, always active is only used during the player's phase.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool alwaysActiveOnlyPlayerPhase = false;

		// external
		[ORKEditorHelp("Examine Cell", "Display the cell info text for the selected combatant's cell during target selections.\n" +
			"This isn't used for target cell selections, see the separate setting in the 'Target Cell Selection' settings.", "")]
		[ORKEditorLayout(new string[] { "alwaysActive", "alwaysActiveDuringTargetSelection" },
			new System.Object[] { false, false },
			needed=Needed.One)]
		[ORKEditorInfo(separator=true, labelText="Target Selection Examine")]
		public bool targetExamineCell = false;

		[ORKEditorHelp("Examine Cell Combatant", "Display the combatant info dialogue for the selected combatant ('Examine Grid' settings).\n" +
			"Please note that this only shows the information dialogue and " +
			"doesn't show cell highlights (e.g. move range of a combatant).\n" +
			"This isn't used for target cell selections, see the separate setting in the 'Target Cell Selection' settings", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool targetExamineCellCombatant = false;


		// camera control target
		[ORKEditorHelp("Camera Control Target", "Changes the camera control target to the selected cell.\n" +
			"The camera control must descent from the 'BaseCameraControl' class (like all built-in camera controls).", "")]
		[ORKEditorInfo("Camera Control Target", "Optionally change the camera control target to the selected cell.\n" +
			"The camera control must descent from the 'BaseCameraControl' class (like all built-in camera controls).", "")]
		public bool cameraControlTarget = false;

		[ORKEditorHelp("Own Transition", "Use a custom camera control transition when changing the camera control target.\n" +
			"If disabled, the default transition defined in 'Base/Control > Game Controls' will be used.", "")]
		[ORKEditorLayout("cameraControlTarget", true)]
		public bool ownControlTargetTransition = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownControlTargetTransition", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public CameraControlTargetTransition controlTargetTransition;


		// info text
		[ORKEditorHelp("Show Info Text", "An info text will be displayed while selecting a target cell.", "")]
		[ORKEditorInfo("Info Text", "Optionally display an info text box while the player selects a target cell.", "")]
		public bool showInfo = false;

		[ORKEditorInfo(separator=true, endFoldout=true, label=new string[] {
			"%un = user name, %ud = user description, %ui = user icon",
			"%n = cell name, %d = cell description, %i = cell icon",
			"%cn = cell combatant name, %cd = cell combatant description, %ci = cell combatant icon",
			"% = move cost (0), %1 = move cost (0.0), %2 = move cost (0.00)",
			"%mcn = marked combatant name, %mcd = marked combatant description, %mci = marked combatant icon",
			"The marked combatant of a cell is e.g. set when the cell is the target of a combatant's move command."
		})]
		[ORKEditorLayout("showInfo", true, endCheckGroup=true, autoInit=true)]
		public InfoBoxChoice info;


		// own cell selection
		[ORKEditorHelp("Own Cell Selection", "The grid examination uses a different cell selection setup.\n" +
			"If disabled, the cell selection will be used.", "")]
		[ORKEditorInfo("Cell Selection", "The grid examination can optionally override the cell selection settings.", "")]
		public bool ownCellSelection = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownCellSelection", true, endCheckGroup=true, autoInit=true)]
		public GridCellSelectionSettings selection;


		// cell info text
		[ORKEditorInfo(separator=true)]
		[ORKEditorArray(false, "Add Cell Info", "Adds a cell info text box.\n" +
			"Cell info text boxes display informations about the selected cell.", "",
			"Remove", "Removes this cell info box.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Cell Info Text", "Displays a cell info text box for the selected cell.", ""
		})]
		public GridCellInfoChoice[] cellInfo = new GridCellInfoChoice[0];


		// combatant information
		// move range display
		[ORKEditorHelp("Show Move Range", "Highlight the move range of the examined combatant.", "")]
		[ORKEditorInfo("Combatant Info Dialogue", "Define how the combatant information dialogue " +
			"(displaying bestiary information) will look like.", "",
			labelText="Move Range Display")]
		public bool showMoveRange = false;

		[ORKEditorHelp("Max Move Range (Enemy)", "Show the maximum move range of enemy combatants.\n" +
			"If disabled, the current move range will be shown.", "")]
		[ORKEditorLayout("showMoveRange", true)]
		public bool moveRangeMaxEnemy = true;

		[ORKEditorHelp("Max Move Range (Ally)", "Show the maximum move range of ally combatants.\n" +
			"If disabled, the current move range will be shown.", "")]
		public bool moveRangeMaxAlly = true;

		[ORKEditorHelp("Auto Show Move Range", "The move range is automatically shown when a cell with a combatant is selected.", "")]
		public bool moveRangeAuto = false;

		[ORKEditorHelp("Move Range Input Key", "Select the input key used to show/hide the move range of a cell's combatant.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("moveRangeAuto", false)]
		public int moveRangeKeyID = 0;

		[ORKEditorHelp("Move Range Audio", "Played when the move range is shown/hidden.", "")]
		[ORKEditorLayout(autoInit=true)]
		public AssetSource<AudioClip> moveRangeAudio;

		[ORKEditorHelp("Move Range Volume", "The volume (0-1) used to play the move range clip.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float moveRangeVolume = 1.0f;


		// attack range display
		[ORKEditorHelp("Show Attack Range", "Highlight the attack range of the examined combatant.\n" +
			"The attack range is the use range of the combatant's base attack.", "")]
		[ORKEditorInfo(separator=true, labelText="Attack Range Display")]
		public bool showAttackRange = false;

		[ORKEditorHelp("Use Counter Attack", "Use the use range of the combatant's counter attack instead of the current base attack.", "")]
		[ORKEditorLayout("showAttackRange", true)]
		public bool useCounterRange = false;

		[ORKEditorHelp("Auto Show Attack Range", "The attack range is automatically shown when a cell with a combatant is selected.", "")]
		public bool attackRangeAuto = false;

		[ORKEditorHelp("Attack Range Input Key", "Select the input key used to show/hide the attack range of a cell's combatant.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("attackRangeAuto", false)]
		public int attackRangeKeyID = 0;

		[ORKEditorHelp("Attack Range Audio", "Played when the attack range is shown/hidden.", "")]
		[ORKEditorLayout(autoInit=true)]
		public AssetSource<AudioClip> attackRangeAudio;

		[ORKEditorHelp("Attack Range Volume", "The volume (0-1) used to play the attack range clip.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float attackRangeVolume = 1.0f;


		// combatant info box
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorArray(false, "Add Combatant Info Box", "Adds a combatant info box.\n" +
			"Combatant info boxes display informations about the selected cell's combatant.", "",
			"Remove", "Removes this combatant info box.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Combatant Info Box", "Displays a combatant info box for the selected cell.", ""
		})]
		public GridExamineBestiaryChoice[] combatantInfoDisplay = new GridExamineBestiaryChoice[0];


		// in-game
		private GameObject previousCameraControlTarget;

		private Notify notify;

		private bool enclosingMoveRange = false;


		// selection
		private bool isAlwaysActive = false;

		private bool isExternalCall = false;

		private bool externalCallShowCombatant = false;

		private bool isSelecting = false;

		private bool isCombatantInfoCalled = true;

		private GridPathFinder path;

		private List<BattleGridCellComponent> useRangeCells;

		private SelectGridCellBool selectCellFunction;

		private SelectGridCell acceptCellFunction;

		private GridCellCheck acceptCheckFunction;

		public GridExamineSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			// cell/combatant info > multiple boxes
			if(data.Contains<bool>("showCellInfo"))
			{
				bool tmp = false;
				data.Get("showCellInfo", ref tmp);
				if(tmp)
				{
					this.cellInfo = new GridCellInfoChoice[1];
					this.cellInfo[0] = new GridCellInfoChoice();
					this.cellInfo[0].SetData(data.GetFile("cellInfo"));
				}

				this.combatantInfoDisplay = new GridExamineBestiaryChoice[1];
				this.combatantInfoDisplay[0] = new GridExamineBestiaryChoice();
				this.combatantInfoDisplay[0].SetData(data.GetFile("combatantInfoDisplay"));
			}
			if(data.Contains<bool>("combatantAutoShow"))
			{
				bool tmp = false;
				data.Get("combatantAutoShow", ref tmp);
				if(tmp)
				{
					for(int i = 0; i < this.combatantInfoDisplay.Length; i++)
					{
						this.combatantInfoDisplay[i].autoShow = true;
					}
				}
			}
			if(this.showMoveRange &&
				!this.moveRangeAuto &&
				data.Contains<AudioClip>("moveRangeAudio"))
			{
				this.moveRangeAudio = new AssetSource<AudioClip>();
				this.moveRangeAudio.Upgrade(data, "moveRangeAudio");
			}
			if(this.showAttackRange &&
				!this.attackRangeAuto &&
				data.Contains<AudioClip>("attackRangeAudio"))
			{
				this.attackRangeAudio = new AssetSource<AudioClip>();
				this.attackRangeAudio.Upgrade(data, "attackRangeAudio");
			}
		}

		public void Clear()
		{
			this.CloseInfoBox();
			this.CloseCellInfoBox();
			this.StopHighlights();
			this.CloseCombatantInfoBox();
			ORK.Control.Cursor.RemoveGridExamineSelections();

			if(this.isSelecting)
			{
				if(!this.isAlwaysActive &&
					this.blockActionUse &&
					ORK.Battle.SystemSettings.gridSettings.SelectingCombatant != null)
				{
					ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Actions.BlockActionUse = false;
				}
				this.isSelecting = false;
			}

			this.isAlwaysActive = false;
			this.isExternalCall = false;
			this.notify = null;
			this.previousCameraControlTarget = null;

			if(this.path != null)
			{
				this.path.Clear();
			}
			if(this.useRangeCells != null)
			{
				this.useRangeCells.Clear();
			}
		}

		public bool IsExternalCall
		{
			get { return this.isExternalCall; }
		}

		public bool IsAlwaysActiveOn
		{
			get { return this.isAlwaysActive && this.isSelecting; }
		}

		public bool CheckAlwaysActive()
		{
			return this.alwaysActive &&
				ORK.Battle.IsBattleRunning() &&
				(this.alwaysActiveDuringActions ||
					!ORK.Battle.Actions.HasActive()) &&
				(!this.alwaysActiveOnlyPlayerPhase ||
					!ORK.Battle.IsPhase() ||
					ORK.Battle.SystemSettings.phase.CurrentFactionID == ORK.Game.ActiveGroup.FactionID);
		}

		public bool ExamineTarget
		{
			get
			{
				return (!this.alwaysActive || !this.alwaysActiveDuringTargetSelection) &&
					(this.targetExamineCell || this.targetExamineCellCombatant);
			}
		}


		/*
		============================================================================
		GUI box functions
		============================================================================
		*/
		private string InfoReplace(string text)
		{
			float cost = ORK.Battle.SystemSettings.gridSettings.SelectedCell.Settings.GetMoveCost(
				ORK.Battle.SystemSettings.gridSettings.SelectingCombatant);
			return text.
				Replace("%un", ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.GetName()).
				Replace("%ud", ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.GetDescription()).
				Replace("%ui", ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.GetIconTextCode()).
				Replace("%n", ORK.Battle.SystemSettings.gridSettings.SelectedCell.CellType.GetName(
					ORK.Battle.SystemSettings.gridSettings.SelectingCombatant)).
				Replace("%d", ORK.Battle.SystemSettings.gridSettings.SelectedCell.CellType.GetDescription(
					ORK.Battle.SystemSettings.gridSettings.SelectingCombatant)).
				Replace("%i", ORK.Battle.SystemSettings.gridSettings.SelectedCell.CellType.GetIconTextCode()).
				Replace("%2", cost.ToString("0.00")).
				Replace("%1", cost.ToString("0.0")).
				Replace("%", cost.ToString("0"));
		}

		private void ShowInfoBox()
		{
			if(this.showInfo)
			{
				this.info.Show(this.info.useTitle ?
					GridCellInfoChoice.CellInfoReplace(this.info.title[ORK.Game.Language],
						ORK.Battle.SystemSettings.gridSettings.SelectedCell,
						ORK.Battle.SystemSettings.gridSettings.SelectingCombatant) : "",
					GridCellInfoChoice.CellInfoReplace(this.info.infoText[ORK.Game.Language],
						ORK.Battle.SystemSettings.gridSettings.SelectedCell,
						ORK.Battle.SystemSettings.gridSettings.SelectingCombatant),
					null);
			}
		}

		private void CloseInfoBox()
		{
			if(this.showInfo)
			{
				this.info.Close();
			}
		}

		private void ShowCellInfoBox()
		{
			for(int i = 0; i < this.cellInfo.Length; i++)
			{
				this.cellInfo[i].Show(
					ORK.Battle.SystemSettings.gridSettings.SelectingCombatant,
					ORK.Battle.SystemSettings.gridSettings.SelectedCell);
			}
		}

		private void CloseCellInfoBox()
		{
			for(int i = 0; i < this.cellInfo.Length; i++)
			{
				this.cellInfo[i].Close();
			}
		}

		private void CheckCombatantInfoCall()
		{
			bool called = false;
			for(int i = 0; i < this.combatantInfoDisplay.Length; i++)
			{
				if(this.combatantInfoDisplay[i].CheckCall())
				{
					called = true;
					Combatant combatant = null;
					if(this.combatantInfoDisplay[i].callCursorOver)
					{
						if(ORK.Battle.CursorOverCombatant != null)
						{
							combatant = ORK.Battle.CursorOverCombatant;
							if(!this.isExternalCall)
							{
								this.SelectCell(ORK.Battle.CursorOverCombatant.Grid.Cell, true);
							}
						}
					}
					else if(ORK.Battle.SystemSettings.gridSettings.SelectedCell != null &&
						ORK.Battle.SystemSettings.gridSettings.SelectedCell.Combatant != null)
					{
						combatant = ORK.Battle.SystemSettings.gridSettings.SelectedCell.Combatant;
					}

					if(combatant != null &&
						!this.combatantInfoDisplay[i].CheckCloseCall(combatant))
					{
						Combatant user = !this.IsAlwaysActiveOn &&
							ORK.Battle.SystemSettings.gridSettings.SelectingCombatant != null ?
								ORK.Battle.SystemSettings.gridSettings.SelectingCombatant :
								(ORK.Battle.SelectingCombatant != null &&
									ORK.Battle.SelectingCombatant.IsPlayerControlled() ?
										ORK.Battle.SelectingCombatant :
										null);
						if(this.combatantInfoDisplay[i].CheckShow(user, combatant))
						{
							this.combatantInfoDisplay[i].Show(
								this.combatantInfoDisplay[i].useUser ?
									(user != null ? user : ORK.Game.ActiveGroup.BattleLeader) :
									combatant,
								false, true, this.CombatantInfoClosed, this.CombatantInfoTick);
						}
						else
						{
							this.combatantInfoDisplay[i].Close();
						}
					}
					else
					{
						this.combatantInfoDisplay[i].Close();
					}
				}
			}
			if(called)
			{
				this.CheckOpenCombatantInfos();
			}
		}

		private void ShowCombatantInfoBox(bool autoShow, Combatant combatant, NotifyBool callback)
		{
			Combatant user = !this.IsAlwaysActiveOn &&
				ORK.Battle.SystemSettings.gridSettings.SelectingCombatant != null ?
					ORK.Battle.SystemSettings.gridSettings.SelectingCombatant :
					(ORK.Battle.SelectingCombatant != null &&
						ORK.Battle.SelectingCombatant.IsPlayerControlled() ?
							ORK.Battle.SelectingCombatant :
							null);

			for(int i = 0; i < this.combatantInfoDisplay.Length; i++)
			{
				if(this.combatantInfoDisplay[i].autoShow == autoShow &&
					!this.combatantInfoDisplay[i].useCallKey)
				{
					if(this.combatantInfoDisplay[i].CheckShow(user, combatant))
					{
						this.combatantInfoDisplay[i].Show(
							this.combatantInfoDisplay[i].useUser ?
								(user != null ? user : ORK.Game.ActiveGroup.BattleLeader) :
								combatant,
							false, !autoShow, callback, this.CombatantInfoTick);
					}
					else
					{
						this.combatantInfoDisplay[i].Close();
					}
				}
			}
			this.CheckOpenCombatantInfos();
			if(!autoShow &&
				this.isCombatantInfoCalled)
			{
				this.CloseInfoBox();
				this.CloseCellInfoBox();
			}
		}

		public void CloseCombatantInfoBox()
		{
			for(int i = 0; i < this.combatantInfoDisplay.Length; i++)
			{
				this.combatantInfoDisplay[i].Close();
			}
			this.CheckOpenCombatantInfos();
		}

		public void CloseCombatantInfoBox(bool autoShow)
		{
			for(int i = 0; i < this.combatantInfoDisplay.Length; i++)
			{
				if(this.combatantInfoDisplay[i].autoShow == autoShow)
				{
					this.combatantInfoDisplay[i].Close();
				}
			}
			this.CheckOpenCombatantInfos();
		}

		public void CombatantInfoClosed(bool accepted)
		{
			this.CheckOpenCombatantInfos();
			if(!this.isCombatantInfoCalled)
			{
				this.ShowInfoBox();
			}
		}

		private void CheckOpenCombatantInfos()
		{
			this.isCombatantInfoCalled = false;
			for(int i = 0; i < this.combatantInfoDisplay.Length; i++)
			{
				if(!this.combatantInfoDisplay[i].autoShow &&
					this.combatantInfoDisplay[i].IsOpen)
				{
					this.isCombatantInfoCalled = true;
					break;
				}
			}
		}


		/*
		============================================================================
		Audio functions
		============================================================================
		*/
		public void PlayMoveRange()
		{
			ORK.PlaySound(this.moveRangeAudio, this.moveRangeVolume);
		}

		public void PlayAttackRange()
		{
			ORK.PlaySound(this.attackRangeAudio, this.attackRangeVolume);
		}


		/*
		============================================================================
		Grid examination functions
		============================================================================
		*/
		public void Start(Combatant combatant, BattleGridCellComponent selectedCell, Notify notify)
		{
			if(this.path == null)
			{
				this.enclosingMoveRange = ORK.Battle.SystemSettings.gridHighlights.moveRangeHighlight.HighlightSetting.useLineRenderer &&
					ORK.Battle.SystemSettings.gridHighlights.moveRangeHighlight.HighlightSetting.line.prefab.settings.Get() != null &&
					ORK.Battle.SystemSettings.gridHighlights.moveRangeHighlight.HighlightSetting.line.enclosedCells;

				this.path = new GridPathFinder(
					this.enclosingMoveRange ?
						true :
						(ORK.Battle.SystemSettings.gridHighlights.moveRangeBlockedHighlight.enable ||
							ORK.Battle.SystemSettings.gridHighlights.moveRangePassableHighlight.enable));
			}

			ORK.Battle.SystemSettings.gridSettings.InitSelection(GridSelectionType.Examine, combatant);
			this.previousCameraControlTarget = ORK.Control.CameraControlTarget;

			this.isAlwaysActive = false;
			this.notify = notify == null && combatant.Battle.BattleMenu.IsOpen ?
				combatant.Battle.BattleMenu.EndGridExamineClose : notify;
			ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Battle.BattleMenu.CloseSilent();

			ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Shortcuts.Active =
				ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Shortcuts.GridExamineShortcut;
			if(this.blockActionUse)
			{
				ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Actions.BlockActionUse = true;
			}

			if(this.selectCellFunction == null)
			{
				this.selectCellFunction = this.SelectCell;
				this.acceptCellFunction = this.AcceptCell;
				this.acceptCheckFunction = this.CheckAcceptCell;
			}

			this.ShowInfoBox();

			this.isSelecting = true;
			ORK.Battle.SystemSettings.gridSettings.SelectedCell = null;
			this.SelectCell(selectedCell, true);
		}

		public void StartAlwaysActive(Combatant combatant, BattleGridCellComponent selectedCell)
		{
			ORK.Battle.SystemSettings.gridSettings.InitSelection(GridSelectionType.Examine, combatant);
			this.previousCameraControlTarget = ORK.Control.CameraControlTarget;

			this.isAlwaysActive = true;
			this.notify = null;

			if(this.selectCellFunction == null)
			{
				this.selectCellFunction = this.SelectCell;
				this.acceptCellFunction = this.AcceptCell;
				this.acceptCheckFunction = this.CheckAcceptCell;
			}

			this.ShowInfoBox();

			this.isSelecting = true;
			ORK.Battle.SystemSettings.gridSettings.SelectedCell = null;
			this.SelectCell(selectedCell, true);
		}

		public void Restart(Combatant combatant)
		{
			if(ORK.Battle.SystemSettings.gridSettings.SelectingCombatant == combatant)
			{
				BattleGridCellComponent tmpCell = ORK.Battle.SystemSettings.gridSettings.SelectedCell;
				ORK.Battle.SystemSettings.gridSettings.SelectedCell = null;
				this.SelectCell(tmpCell, true);
			}
		}

		private void StopHighlights()
		{
			this.StopSelectedCellHighlight();
			if(this.path != null)
			{
				this.HighlightMoveRange(false);
				this.path.Clear();
			}
			if(this.useRangeCells != null)
			{
				BattleGridHelper.StopHighlight(this.useRangeCells, GridHighlightType.ExamineUseRange);
				this.useRangeCells.Clear();
			}
		}

		private void StopSelectedCellHighlight()
		{
			if(ORK.Battle.SystemSettings.gridSettings.SelectedCell != null)
			{
				BattleGridHelper.StopHighlight(ORK.Battle.SystemSettings.gridSettings.SelectedCell, GridHighlightType.ExamineSelection);
				BattleGridHelper.StopHighlight(ORK.Battle.SystemSettings.gridSettings.SelectedCell, GridHighlightType.ExamineSelectionBlocked);
				BattleGridHelper.StopHighlight(ORK.Battle.SystemSettings.gridSettings.SelectedCell, GridHighlightType.ExamineSelectionPlayer);
				BattleGridHelper.StopHighlight(ORK.Battle.SystemSettings.gridSettings.SelectedCell, GridHighlightType.ExamineSelectionAlly);
				BattleGridHelper.StopHighlight(ORK.Battle.SystemSettings.gridSettings.SelectedCell, GridHighlightType.ExamineSelectionEnemy);
			}
		}

		private void HighlightMoveRange(bool start)
		{
			if(this.path != null &&
				this.path.availableTargets != null &&
				this.path.availableTargets.Count > 0)
			{
				if(start)
				{
					if(ORK.Battle.SystemSettings.gridHighlights.moveRangeHighlight.enable)
					{
						if(this.enclosingMoveRange)
						{
							List<BattleGridCellComponent> tmp = this.path.availableTargets;
							if(this.path.blockedCells != null ||
								this.path.passableCells != null)
							{
								tmp = new List<BattleGridCellComponent>();
								tmp.AddRange(this.path.availableTargets);
								if(this.path.blockedCells != null)
								{
									tmp.AddRange(this.path.blockedCells);
								}
								if(this.path.passableCells != null)
								{
									tmp.AddRange(this.path.passableCells);
								}
							}
							ORK.Battle.SystemSettings.gridHighlights.moveRangeHighlight.AddLineCells(tmp, GridHighlightType.ExamineMoveRange);
						}
						BattleGridHelper.Highlight(this.path.availableTargets, GridHighlightType.ExamineMoveRange);
					}
					if(ORK.Battle.SystemSettings.gridHighlights.moveRangeBlockedHighlight.enable)
					{
						BattleGridHelper.Highlight(this.path.blockedCells, GridHighlightType.ExamineMoveRangeBlocked);
					}
					BattleGridHelper.Highlight(this.path.passableCells, GridHighlightType.ExamineMoveRangePassable);
				}
				else
				{
					if(ORK.Battle.SystemSettings.gridHighlights.moveRangeHighlight.enable)
					{
						if(this.enclosingMoveRange)
						{
							List<BattleGridCellComponent> tmp = this.path.availableTargets;
							if(this.path.blockedCells != null ||
								this.path.passableCells != null)
							{
								tmp = new List<BattleGridCellComponent>();
								tmp.AddRange(this.path.availableTargets);
								if(this.path.blockedCells != null)
								{
									tmp.AddRange(this.path.blockedCells);
								}
								if(this.path.passableCells != null)
								{
									tmp.AddRange(this.path.passableCells);
								}
							}
							ORK.Battle.SystemSettings.gridHighlights.moveRangeHighlight.RemoveLineCells(tmp, GridHighlightType.ExamineMoveRange);
						}
						BattleGridHelper.StopHighlight(this.path.availableTargets, GridHighlightType.ExamineMoveRange);
					}
					if(ORK.Battle.SystemSettings.gridHighlights.moveRangeBlockedHighlight.enable)
					{
						BattleGridHelper.StopHighlight(this.path.blockedCells, GridHighlightType.ExamineMoveRangeBlocked);
					}
					if(ORK.Battle.SystemSettings.gridHighlights.moveRangePassableHighlight.enable)
					{
						BattleGridHelper.StopHighlight(this.path.passableCells, GridHighlightType.ExamineMoveRangePassable);
					}
				}
			}
		}

		private void ToggleMoveRange()
		{
			if(this.path != null &&
				ORK.Battle.SystemSettings.gridSettings.SelectedCell != null &&
				ORK.Battle.SystemSettings.gridSettings.SelectedCell.Combatant != null &&
				(ORK.Battle.SystemSettings.gridHighlights.moveRangeHighlight.enable ||
					ORK.Battle.SystemSettings.gridHighlights.moveRangeBlockedHighlight.enable ||
					ORK.Battle.SystemSettings.gridHighlights.moveRangePassableHighlight.enable))
			{
				// hide move range
				if((this.path.availableTargets != null &&
						this.path.availableTargets.Count > 0) ||
					(this.path.blockedCells != null &&
						this.path.blockedCells.Count > 0))
				{
					this.HighlightMoveRange(false);
					this.path.Clear();
				}
				// show move range
				else
				{
					MoveRangeType moveRangeType = MoveRangeType.Current;
					if(ORK.Battle.SystemSettings.gridSettings.SelectingCombatant == null ||
						(ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.IsEnemy(
								ORK.Battle.SystemSettings.gridSettings.SelectedCell.Combatant) ?
							this.moveRangeMaxEnemy : this.moveRangeMaxAlly))
					{
						moveRangeType = MoveRangeType.Max;
					}
					this.path.CreateMoveRange(ORK.Battle.SystemSettings.gridSettings.SelectedCell.Combatant, moveRangeType, null, null);
					this.path.availableTargets.Remove(ORK.Battle.SystemSettings.gridSettings.SelectedCell);
					this.HighlightMoveRange(true);
				}
			}
		}

		private void ToggleAttackRange()
		{
			if(ORK.Battle.SystemSettings.gridSettings.SelectedCell != null &&
				ORK.Battle.SystemSettings.gridSettings.SelectedCell.Combatant != null &&
				ORK.Battle.SystemSettings.gridHighlights.useRangeHighlight.enable)
			{
				// hide use range
				if(this.useRangeCells != null &&
					this.useRangeCells.Count > 0)
				{
					BattleGridHelper.StopHighlight(this.useRangeCells, GridHighlightType.ExamineUseRange);
					this.useRangeCells.Clear();
				}
				// show use range
				else
				{
					ArrayHelper.GetBlank<BattleGridCellComponent>(ref this.useRangeCells);
					AbilityShortcut ability = this.useCounterRange ?
						ORK.Battle.SystemSettings.gridSettings.SelectedCell.
							Combatant.Abilities.GetCounterAttack() :
						ORK.Battle.SystemSettings.gridSettings.SelectedCell.
							Combatant.Abilities.GetCurrentBaseAttack();
					if(ability != null)
					{
						ActiveAbility activeAbility = ability.GetActiveLevel();
						if(activeAbility != null)
						{
							activeAbility.targetSettings.useRange.GetCells(
							   ORK.Battle.SystemSettings.gridSettings.SelectedCell.Combatant,
							   ref this.useRangeCells, null);
						}
					}
					this.useRangeCells.Remove(ORK.Battle.SystemSettings.gridSettings.SelectedCell);
					BattleGridHelper.Highlight(this.useRangeCells, GridHighlightType.ExamineUseRange);
				}
			}
		}

		private void ResetCameraControlTarget()
		{
			if(this.cameraControlTarget &&
				this.previousCameraControlTarget != null &&
				(ORK.Battle.SystemSettings.gridSettings.SelectedCell == null ||
				ORK.Control.CameraControlTarget == ORK.Battle.SystemSettings.gridSettings.SelectedCell.gameObject))
			{
				ORK.Control.SetCameraControlTarget(this.previousCameraControlTarget,
					this.ownControlTargetTransition ? this.controlTargetTransition : null);
			}
			this.previousCameraControlTarget = null;
		}


		/*
		============================================================================
		Cell selection functions
		============================================================================
		*/
		public void Tick()
		{
			if(this.isSelecting &&
				ORK.Battle.SystemSettings.gridSettings.SelectingCombatant != null)
			{
				if(!this.CheckCancel())
				{
					if(ORK.Battle.SystemSettings.gridSettings.SelectedCell == null)
					{
						this.SelectCell(ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Grid.Cell, true);
					}
					if(this.ownCellSelection)
					{
						this.selection.SelectCell(
							ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Grid.Cell,
							ORK.Battle.SystemSettings.gridSettings.SelectedCell,
							this.selectCellFunction, this.acceptCellFunction,
							this.acceptCheckFunction, null, false, false);
					}
					else
					{
						ORK.Battle.SystemSettings.gridSettings.cellSelection.SelectCell(
							ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Grid.Cell,
							ORK.Battle.SystemSettings.gridSettings.SelectedCell,
							this.selectCellFunction, this.acceptCellFunction,
							this.acceptCheckFunction, null, false, false);
					}

					// combatant info call key
					this.CheckCombatantInfoCall();

					if(ORK.Battle.SystemSettings.gridSettings.SelectedCell != null &&
						ORK.Battle.SystemSettings.gridSettings.SelectedCell.Combatant != null)
					{
						// move range display
						if(this.showMoveRange &&
							!this.moveRangeAuto &&
							ORK.InputKeys.Get(this.moveRangeKeyID).GetButton())
						{
							ORK.InputKeys.ResetInputAxes(true);
							this.PlayMoveRange();
							this.ToggleMoveRange();
						}
						// use range display
						if(this.showAttackRange &&
							!this.attackRangeAuto &&
							ORK.InputKeys.Get(this.attackRangeKeyID).GetButton())
						{
							ORK.InputKeys.ResetInputAxes(true);
							this.PlayAttackRange();
							this.ToggleAttackRange();
						}
					}
				}
			}
			else
			{
				this.CheckCombatantInfoCall();
			}
		}

		public void TickExternalCall()
		{
			// combatant info call key
			if(this.externalCallShowCombatant)
			{
				this.CheckCombatantInfoCall();
			}
		}

		public void TickToggles()
		{
			for(int i = 0; i < this.cellInfo.Length; i++)
			{
				this.cellInfo[i].TickToggle();
			}
		}

		private bool CombatantInfoTick()
		{
			if(!this.isExternalCall)
			{
				// cancel
				if(this.CheckCancel())
				{
					this.CloseCombatantInfoBox(false);
					return true;
				}
				// move range display
				else if(this.showMoveRange &&
					!this.moveRangeAuto &&
					ORK.Battle.SystemSettings.gridSettings.SelectedCell != null &&
					ORK.Battle.SystemSettings.gridSettings.SelectedCell.Combatant != null &&
					ORK.InputKeys.Get(this.moveRangeKeyID).GetButton())
				{
					ORK.InputKeys.ResetInputAxes(true);
					this.PlayMoveRange();
					this.ToggleMoveRange();
					return true;
				}
				// use range display
				else if(this.showAttackRange &&
					!this.attackRangeAuto &&
					ORK.Battle.SystemSettings.gridSettings.SelectedCell != null &&
					ORK.Battle.SystemSettings.gridSettings.SelectedCell.Combatant != null &&
					ORK.InputKeys.Get(this.attackRangeKeyID).GetButton())
				{
					ORK.InputKeys.ResetInputAxes(true);
					this.PlayAttackRange();
					this.ToggleAttackRange();
				}
			}
			return false;
		}

		private bool CheckCancel()
		{
			if(this.allowCancel &&
				!this.isExternalCall &&
				!this.isAlwaysActive &&
				ORK.GameControls.menuControls.CancelKey.GetButton())
			{
				ORK.InputKeys.ResetInputAxes(true);
				if(this.ownCellSelection)
				{
					this.selection.PlayCancelAudio();
				}
				else
				{
					ORK.Battle.SystemSettings.gridSettings.cellSelection.PlayCancelAudio();
				}
				this.Close();
				return true;
			}
			return false;
		}

		public void Close()
		{
			this.isSelecting = false;
			if(!this.isAlwaysActive &&
				this.blockActionUse)
			{
				ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Actions.BlockActionUse = false;
			}
			this.ResetCameraControlTarget();

			this.StopHighlights();
			ORK.InputKeys.ResetInputAxes(true);
			this.CloseInfoBox();
			this.CloseCellInfoBox();
			this.CloseCombatantInfoBox();
			if(ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Shortcuts.Active is GridExamineShortcut)
			{
				ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Shortcuts.Active = null;
			}
			ORK.Battle.SystemSettings.gridSettings.ClearCellSelection();

			if(this.notify != null)
			{
				this.notify();
			}
			this.Clear();
		}

		public void SelectCell(BattleGridCellComponent cell, bool isHover)
		{
			if(ORK.Battle.SystemSettings.gridSettings.SelectedCell != cell)
			{
				// stop move range highlight
				if(this.path != null)
				{
					this.HighlightMoveRange(false);
					this.path.Clear();
				}
				// stop use range highlight
				if(ORK.Battle.SystemSettings.gridHighlights.useRangeHighlight.enable &&
					this.useRangeCells != null)
				{
					BattleGridHelper.StopHighlight(this.useRangeCells, GridHighlightType.ExamineUseRange);
					this.useRangeCells.Clear();
				}
				// stop selection highlight
				this.StopSelectedCellHighlight();

				ORK.Battle.SystemSettings.gridSettings.SelectedCell = cell;

				// new highlights
				if(ORK.Battle.SystemSettings.gridSettings.SelectedCell != null)
				{
					if(this.cameraControlTarget && !isHover)
					{
						ORK.Control.SetCameraControlTarget(ORK.Battle.SystemSettings.gridSettings.SelectedCell.gameObject,
							this.ownControlTargetTransition ? this.controlTargetTransition : null);
					}
					if(ORK.Battle.SystemSettings.gridSettings.SelectedCell.Combatant != null)
					{
						this.ShowCombatantInfoBox(true, ORK.Battle.SystemSettings.gridSettings.SelectedCell.Combatant, null);
						if(this.showMoveRange &&
							this.moveRangeAuto)
						{
							this.ToggleMoveRange();
						}
						if(this.showAttackRange &&
							this.attackRangeAuto)
						{
							this.ToggleAttackRange();
						}
					}
					else
					{
						this.CloseCombatantInfoBox(true);
					}
					if(ORK.Battle.SystemSettings.gridSettings.SelectedCell.IsBlocked ||
						(ORK.Battle.SystemSettings.gridHighlights.examineCombatantIsBlocked &&
							!ORK.Battle.SystemSettings.gridSettings.SelectedCell.IsEmpty))
					{
						if(!this.isAlwaysActive &&
							!this.isExternalCall)
						{
							ORK.Control.Cursor.ShowGridExamineSelectionBlocked();
						}

						if(ORK.Battle.SystemSettings.gridHighlights.examineBlockedHighlight.enable)
						{
							BattleGridHelper.Highlight(ORK.Battle.SystemSettings.gridSettings.SelectedCell,
								ORK.Battle.SystemSettings.gridHighlights.GetSelectionHighlight(
									GridHighlightType.ExamineSelectionBlocked, ORK.Battle.SystemSettings.gridSettings.SelectedCell));
						}
					}
					else
					{
						if(!this.isAlwaysActive &&
							!this.isExternalCall)
						{
							ORK.Control.Cursor.ShowGridExamineSelection();
						}

						if(ORK.Battle.SystemSettings.gridHighlights.examineHighlight.enable)
						{
							BattleGridHelper.Highlight(ORK.Battle.SystemSettings.gridSettings.SelectedCell,
								ORK.Battle.SystemSettings.gridHighlights.GetSelectionHighlight(
									GridHighlightType.ExamineSelection, ORK.Battle.SystemSettings.gridSettings.SelectedCell));
						}
					}
					this.ShowCellInfoBox();
				}
				else
				{
					this.ResetCameraControlTarget();
					this.CloseCombatantInfoBox(true);
					this.CloseCellInfoBox();
				}
				this.ShowInfoBox();
			}
		}

		public void ExternalExamine(BattleGridCellComponent cell, bool showCellInfo, bool showCombatantInfo)
		{
			if(this.isAlwaysActive)
			{
				this.isAlwaysActive = false;
				this.Close();
			}
			if(cell != null)
			{
				this.isExternalCall = true;
				this.externalCallShowCombatant = showCombatantInfo;
				if(cell.Combatant != null &&
					showCombatantInfo)
				{
					this.ShowCombatantInfoBox(true, cell.Combatant, null);
				}
				else
				{
					this.CloseCombatantInfoBox(true);
				}
				if(showCellInfo)
				{
					this.ShowCellInfoBox();
				}
				else
				{
					this.CloseCellInfoBox();
				}
			}
			else
			{
				this.isExternalCall = false;
				this.CloseCombatantInfoBox(true);
				this.CloseCellInfoBox();
			}
		}

		public void AcceptCell(BattleGridCellComponent cell)
		{
			if(this.CheckAcceptCell(cell))
			{
				if(ORK.Battle.SystemSettings.gridSettings.SelectedCell != cell)
				{
					this.SelectCell(cell, true);
				}

				if(!this.isAlwaysActive &&
					ORK.Battle.SystemSettings.gridSettings.SelectedCell.Combatant ==
					ORK.Battle.SystemSettings.gridSettings.SelectingCombatant)
				{
					this.Close();
				}
				else if(ORK.Battle.SystemSettings.gridSettings.SelectedCell.Combatant != null)
				{
					this.ShowCombatantInfoBox(false,
						ORK.Battle.SystemSettings.gridSettings.SelectedCell.Combatant,
						this.CombatantInfoClosed);
				}
			}
			else
			{
				this.SelectCell(cell, true);
			}
		}

		public bool CheckAcceptCell(BattleGridCellComponent cell)
		{
			return cell != null && cell.Combatant != null;
		}
	}
}
