
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class EquipmentBMItem : BMItem
	{
		private int partID = -1;

		private EquipShortcut equip;

		public EquipmentBMItem(int partID, EquipShortcut equip, ChoiceContent content)
		{
			this.partID = partID;
			this.equip = equip;
			this.content = content;
		}

		public override void CreateDrag(Combatant owner)
		{
			// portrait
			if(this.content.portrait == null &&
				owner.BattleMenu.Settings.showEquipPortraits)
			{
				this.content.portrait = this.equip.GetPortrait(owner.BattleMenu.Settings.equipPortraitTypeID);
			}
		}

		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			this.content.Active = this.equip.CanEquip(owner);
			return tmp != this.content.Active;
		}

		public override bool Accepted(Combatant owner)
		{
			if(owner.BattleMenu != null)
			{
				owner.Equipment.Equip(this.partID, this.equip, owner.Inventory, owner.Inventory, true);

				if(owner.BattleMenu.CommandedBy != null)
				{
					owner.EndBattleMenu(true);
				}
				else
				{
					owner.BattleMenu.Show(true);
				}
				return true;
			}
			return false;
		}
	}
}
