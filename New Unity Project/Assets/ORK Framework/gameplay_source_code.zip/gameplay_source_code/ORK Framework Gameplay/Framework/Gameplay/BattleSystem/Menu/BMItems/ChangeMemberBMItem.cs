
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class ChangeMemberBMItem : BMItem
	{
		private Combatant combatant;

		public ChangeMemberBMItem(ChoiceContent content, Combatant combatant)
		{
			this.content = content;
			this.combatant = combatant;
		}

		public override void CreateDrag(Combatant owner)
		{
			// portrait
			if(this.content.portrait == null && this.combatant != null &&
				owner.Battle.BattleMenu.Settings.showChangePortraits)
			{
				this.content.portrait = this.combatant.UI.GetPortrait(
					owner.Battle.BattleMenu.Settings.changePortraitTypeID);
			}
		}

		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			// sub menu call
			if(this.combatant == null)
			{
				this.content.Active = owner.Group.NonBattleSize > 0 &&
					owner.Battle.CanUse(ORK.Battle.GetChangeMemberActionCost(owner));
			}
			else
			{
				this.content.Active = !this.combatant.Status.IsDead;
			}
			return tmp != this.content.Active;
		}

		public override void Selected(Combatant owner)
		{
			owner.Battle.BattleMenu.TargetHighlight.SelectTarget(this.combatant, null);

			if(ORK.GUI.Settings.preview.changeMemberActionCost)
			{
				PreviewValues preview = new PreviewValues();
				preview.usedActionBarChange += ORK.Battle.GetChangeMemberActionCost(owner);
				ORK.GUI.Tooltip.ForcedPreview = new PreviewSelection(owner, preview);
			}
			else
			{
				ORK.GUI.Tooltip.ForcedPreview = null;
			}
		}

		public override bool Accepted(Combatant owner)
		{
			if(owner.Battle.BattleMenu != null)
			{
				// list non-battle combatants
				if(this.combatant == null)
				{
					List<BMItem> list = new List<BMItem>();

					List<Combatant> members = owner.Group.GetNonBattle();
					for(int i = 0; i < members.Count; i++)
					{
						if(members[i] != owner)
						{
							list.Add(new ChangeMemberBMItem(
								owner.Battle.BattleMenu.GetCombatantChoice(members[i]),
								members[i]));
						}
					}

					owner.Battle.BattleMenu.Settings.AddBack(list);

					owner.Battle.BattleMenu.Show(list, 0, BattleMenuMode.ChangeMember);
				}
				// fire change action
				else
				{
					owner.Battle.BattleMenu.AddAction(new ChangeMemberAction(owner, this.combatant));
				}
				return true;
			}
			return false;
		}
	}
}
