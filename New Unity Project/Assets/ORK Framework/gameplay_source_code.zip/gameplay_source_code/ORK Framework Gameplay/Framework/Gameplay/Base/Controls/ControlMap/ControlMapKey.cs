
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ControlMapKey : BaseData
	{
		// input settings
		// key
		[ORKEditorHelp("Input Key", "Select the input key used for this control map key.", "")]
		[ORKEditorInfo("Input Settings", "Define the input key and use conditions.", "",
			ORKDataType.InputKey)]
		public int key = 0;

		[ORKEditorHelp("Is Axis", "The key name will be used as an axis instead of a button.\n" +
			"Use this setting e.g. for analog sticks.", "")]
		public bool isAxis = false;

		[ORKEditorHelp("Trigger At", "The value of the axis on which to trigger the input.\n" +
			"Note that an axis has positive and negative values, so you can have one input at " +
			"e.g. 0.2, another at -0.2, which means you can have input in both directions (using 2 control keys).", "")]
		[ORKEditorLayout("isAxis", true)]
		public float triggerAt = 0;

		[ORKEditorHelp("Axis Timeout (s)", "The timeout in seconds between recognizing a key as an axis instead a button.\n" +
			"E.g. when using an analog stick of a joystick the input will be recognized permanently, " +
			"so you can set a timeout to recognize it as a single event.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float axisTimeout = 0.5f;

		// conditions
		[ORKEditorHelp("Use Air/Ground", "Recognize if the combatant's game object is in the air or on the ground to enable this key.", "")]
		[ORKEditorInfo(separator=true, labelText="Conditions")]
		public bool useAG = false;

		[ORKEditorHelp("In Air", "The input will only be recognized when the combatant is in the air (i.e. not on ground).\n" +
			"For this to work your combatant needs to have a CharacterController component attached.\n" +
			"If disabled, the combatant needs to be on the ground.", "")]
		[ORKEditorLayout("useAG", true, endCheckGroup=true)]
		public bool inAir = false;

		[ORKEditorHelp("Use Speed", "Recognize the combatant's current movement speed to enable this key.", "")]
		public bool useSpeed = false;

		[ORKEditorHelp("Minimum Speed", "The minimum movement speed of the combatant to recognize the input.\n" +
			"Use this setting for e.g. sprint attacks, etc.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useSpeed", true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float minSpeed = 0;


		// action settings
		[ORKEditorHelp("Type", "Select the what this control map key will perform:\n" +
			"- Action: An action is performed (e.g. an attack, ability or shortcut slot).\n" +
			"- Auto Attack: Enable/disable the auto attack.\n" +
			"- Global Event: Calls a global event using the combatant as the starting object.", "")]
		[ORKEditorInfo("Action Settings", "Define the action that will be used upon key input.", "")]
		public ControlMapKeyType type = ControlMapKeyType.Action;

		// action
		[ORKEditorLayout("type", ControlMapKeyType.Action, autoInit=true)]
		public ActionSelection actionSettings;

		[ORKEditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		[ORKEditorLayout("showTooltip", false, endCheckGroup=true, endGroups=2)]
		public bool blockBattleCamera = false;


		// global event
		[ORKEditorHelp("Global Event", "Select the global event that will be called.\n" +
			"The combatant is used as the starting object", "")]
		[ORKEditorInfo(ORKDataType.GlobalEvent)]
		[ORKEditorLayout("type", ControlMapKeyType.GlobalEvent, endCheckGroup=true)]
		public int globalEventID = 0;


		// show tooltip
		[ORKEditorHelp("Show Tooltip", "Show the action/shortcut as a tooltip.\n" +
			"A 'Tooltip' HUD can display the information.\n" +
			"When using 'Action', this is only used for ability and item actions.", "")]
		[ORKEditorInfo(separator=true, labelText="Tooltip Settings")]
		[ORKEditorLayout("type", ControlMapKeyType.Action, setDefault=true, defaultValue=false)]
		public bool showTooltip = false;

		[ORKEditorHelp("2nd Call Closes", "Calling the tooltip for the same action/shortcut a 2nd time will close the tooltip.\n" +
			"This only happens if the used ability/item is the same.", "")]
		[ORKEditorLayout("showTooltip", true)]
		public bool closeOn2nd = true;

		[ORKEditorHelp("Auto Close", "Auto close the tooltip after a defined amount of time.\n" +
			"If disabled, the tooltip will stay opened until the control key is used a 2nd time.", "")]
		public bool autoCloseTooltip = false;

		[ORKEditorHelp("Close After (s)", "The time in seconds until the tooltip will be closed.", "")]
		[ORKEditorLayout("autoCloseTooltip", true, endCheckGroup=true)]
		public float autoCloseTime = 3;


		// auto target
		[ORKEditorHelp("Only Cursor Over Target", "This control map key can only be used when the cursor is over a valid target.", "")]
		[ORKEditorInfo(separator=true, labelText="Target Settings")]
		[ORKEditorLayout(elseCheckGroup=true)]
		public bool onlyCursorOverTarget = false;

		[ORKEditorHelp("Only In Range", "Cursor over targets will only be used when the target is in range.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("onlyCursorOverTarget", true, endCheckGroup=true)]
		public bool cursorOverInRange = false;

		[ORKEditorHelp("Use Cursor Over Target", "Use the combatant the cursor is over as the action's target.\n" +
			"If the cursor isn't over a valid target, the auto target or target selection will be used.", "")]
		public bool useCursorOverTarget = false;

		[ORKEditorHelp("Use Auto Target", "Automatically selects the action's targets using " +
			"the 'Auto Targets' settings of abilities/items or the user's AI settings.\n" +
			"The group target is ignored.", "")]
		public bool useAutoTarget = false;

		[ORKEditorHelp("Auto Target Only", "Only use auto target for abilities/items that have " +
			"'Use Auto Target' enabled in their settings.", "")]
		[ORKEditorLayout("useAutoTarget", true, endCheckGroup=true)]
		public bool autoTargetOnly = false;

		[ORKEditorHelp("No Target Selection", "This control map key will not bring up any target selection if auto or cursor targeting fails.\n" + 
			"Using the key will fail in that case.", "")]
		public bool noTargetSelection = false;

		[ORKEditorHelp("Need Targets", "Actions that need target selection require possible targets to display the battle menu.\n" +
			"If no targets are available, the action wont be used and no target menu displayed.\n" +
			"If disabled, the action will display an empty target menu.", "")]
		[ORKEditorLayout("noTargetSelection", false, endCheckGroup=true, endGroups=3,
			setDefault=true, defaultValue=false)]
		public bool needTargets = false;


		// auto attack
		[ORKEditorHelp("Enable Auto Attack", "If enabled, the combatant's auto attack will be enabled.\n" +
			"If disabled, the combatant's auto attack will be disabled.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("type", ControlMapKeyType.AutoAttack, endCheckGroup=true)]
		public bool enableAutoAttack = false;


		// requirements
		[ORKEditorHelp("During Target Selection", "This control map key can be used during target selection.", "")]
		[ORKEditorInfo("Requirements", "Using this control map key can depend on status requirements and " +
			"game variable conditions.\n" +
			"The combatant using the control map is used for status checks and object game variables.", "")]
		public bool duringTargetSelection = true;

		[ORKEditorHelp("Use Requirements", "Use status requirements and game variable conditions.", "")]
		public bool useRequirements = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useRequirements", true, endCheckGroup=true, autoInit=true)]
		public SimpleCombatantRequirement requirement;


		// audio settings
		[ORKEditorHelp("Own Success Clip", "This control map key uses a custom success clip when successfully using the key.", "")]
		[ORKEditorInfo("Audio Settings", "A control map key can optionally override the control map's success clip.", "")]
		public bool ownSuccessClip = false;

		[ORKEditorHelp("Success Clip", "Select the audio clip that will be played when successfully using a control map key.", "")]
		[ORKEditorLayout("ownSuccessClip", true, autoInit=true)]
		public AssetSource<AudioClip> successClip;

		[ORKEditorHelp("Volume (Success)", "The volume used to play the success clip (between 0 and 1).", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float successVolume = 1;


		// ingame
		private float timeout = 0;

		public ControlMapKey()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selection"))
			{
				int tmpType = 0;
				data.Get("type", ref tmpType);
				// action
				if(tmpType == 0)
				{
					this.type = ControlMapKeyType.Action;
					this.actionSettings = new ActionSelection();
					data.Get("selection", ref this.actionSettings.type);
					if(ActionSelectType.Attack == this.actionSettings.type)
					{
						this.actionSettings.SetData(data);
						this.actionSettings.attack = new BaseAttackSelection();
						this.actionSettings.attack.SetData(data);
					}
					else if(ActionSelectType.Ability == this.actionSettings.type)
					{
						data.Get("useID", ref this.actionSettings.abilityID);
					}
					else if(ActionSelectType.Item == this.actionSettings.type)
					{
						data.Get("useID", ref this.actionSettings.itemID);
					}
				}
				// shortcut
				else if(tmpType == 1)
				{
					this.type = ControlMapKeyType.Action;
					this.actionSettings = new ActionSelection();
					this.actionSettings.type = ActionSelectType.Shortcut;
					this.actionSettings.slot = new ShortcutSlot();
					data.Get("isGroupShortcut", ref this.actionSettings.slot.isGroupShortcut);
					data.Get("shortcutIndex", ref this.actionSettings.slot.index);
					this.actionSettings.slot.listIndex = -1;
				}
				// auto attack
				else if(tmpType == 2)
				{
					this.type = ControlMapKeyType.AutoAttack;
				}
				// global event
				else if(tmpType == 3)
				{
					this.type = ControlMapKeyType.GlobalEvent;
				}
			}
			if(this.ownSuccessClip && 
				data.Contains<AudioClip>("successClip"))
			{
				this.successClip = new AssetSource<AudioClip>();
				this.successClip.Upgrade(data, "successClip");
			}
		}


		/*
		============================================================================
		Key functions
		============================================================================
		*/
		public bool KeyValid(Combatant combatant)
		{
			return this.timeout <= Time.realtimeSinceStartup &&
				(!this.useAG || combatant.Object.Component.InAir == this.inAir) &&
				(!this.useSpeed || combatant.Object.Component.HorizontalSpeed >= this.minSpeed) &&
				this.ControlAccepted() &&
				(this.duringTargetSelection || !ORK.Battle.IsTargetSelectionActive) &&
				(!this.useRequirements || this.requirement.Check(combatant));
		}

		private bool ControlAccepted()
		{
			bool accept = false;
			if(this.isAxis)
			{
				float a = ORK.InputKeys.Get(this.key).GetAxis();
				if((this.triggerAt < 0 && a < this.triggerAt) ||
					(this.triggerAt > 0 && a > this.triggerAt))
				{
					accept = true;
					this.timeout = Time.realtimeSinceStartup + this.axisTimeout;
				}
			}
			else if(ORK.InputKeys.Get(this.key).GetButton())
			{
				accept = true;
			}
			return accept;
		}


		/*
		============================================================================
		Action functions
		============================================================================
		*/
		public bool PerformAction(Combatant combatant)
		{
			BaseAction action = null;

			// action
			if(ControlMapKeyType.Action == this.type)
			{
				if(this.showTooltip)
				{
					if(this.actionSettings.ShowTooltip(combatant,
						this.autoCloseTooltip ? this.autoCloseTime : -1, this.closeOn2nd))
					{
						return true;
					}
				}
				else if(this.actionSettings.GetAction(
					 out action, combatant, true, true,
					 this.onlyCursorOverTarget, this.cursorOverInRange, this.useCursorOverTarget,
					 this.useAutoTarget, this.autoTargetOnly,
					 this.noTargetSelection, this.needTargets, this.blockBattleCamera))
				{
					if(action != null)
					{
						combatant.Actions.Add(action,
							!combatant.Actions.IsChoosing);
					}
					return true;
				}
			}
			// auto attack
			else if(ControlMapKeyType.AutoAttack == this.type)
			{
				combatant.Battle.EnableAutoAttack = this.enableAutoAttack;
				return true;
			}
			// global event
			else if(ControlMapKeyType.GlobalEvent == this.type)
			{
				ORK.GlobalEvents.CallGlobalEvent(this.globalEventID, combatant);
				return true;
			}

			if(action != null)
			{
				combatant.Actions.Add(action, !combatant.Actions.IsChoosing);
				return true;
			}
			return false;
		}
	}
}
