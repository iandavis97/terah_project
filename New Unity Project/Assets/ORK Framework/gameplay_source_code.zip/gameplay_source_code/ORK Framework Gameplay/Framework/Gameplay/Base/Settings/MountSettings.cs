
using UnityEngine;

namespace ORKFramework
{
	[System.Serializable]
	public class MountSettings : BaseData
	{
		[ORKEditorHelp("On Child", "A child object of the target's game object is used for " +
			"placement (e.g. Path/to/Child).\n" +
			"Leave empty if you don't want to use a child object.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string childName = "";
		
		[ORKEditorHelp("Local Space", "The offset will be used in local space (local position) of the parent object.", "")]
		public bool localSpace = true;
		
		[ORKEditorHelp("Offset", "The offset added to the target game object's position.", "")]
		public Vector3 offset = Vector3.zero;
		
		[ORKEditorHelp("Use Rotation", "The rotation of the target will be used for placement.", "")]
		public bool useRotation = true;
		
		[ORKEditorHelp("Rotation Offset", "Offset added to the target's rotation.", "")]
		[ORKEditorLayout("useRotation", true, endCheckGroup=true)]
		public Vector3 rotationOffset = Vector3.zero;
		
		[ORKEditorHelp("Set Scale", "Set the scale when placing the object.", "")]
		public bool setScale = false;
		
		[ORKEditorHelp("Scale", "The scale the object will be set to.", "")]
		[ORKEditorLayout("setScale", true, endCheckGroup=true)]
		public Vector3 scale = Vector3.one;
		
		public MountSettings()
		{
			
		}
		
		public void MountTo(Transform parent, Transform child)
		{
			TransformHelper.Mount(
				TransformHelper.GetChild(this.childName, parent), child, 
				this.localSpace, this.offset, 
				this.useRotation, this.rotationOffset, 
				this.setScale, this.scale);
		}
		
		public void Place(Transform parent, Transform child)
		{
			TransformHelper.Place(
				TransformHelper.GetChild(this.childName, parent), child, 
				this.localSpace, this.offset, 
				this.useRotation, this.rotationOffset, 
				this.setScale, this.scale);
		}
		
		public void GetMountTo(Transform parent, ref Vector3 pos, ref Vector3 rot)
		{
			TransformHelper.GetMount(
				TransformHelper.GetChild(this.childName, parent), 
				this.localSpace, this.offset, 
				this.useRotation, this.rotationOffset, 
				ref pos, ref rot);
		}
		
		public void GetPlace(Transform parent, ref Vector3 pos, ref Vector3 rot)
		{
			TransformHelper.GetPlace(
				TransformHelper.GetChild(this.childName, parent), 
				this.localSpace, this.offset, 
				this.useRotation, this.rotationOffset, 
				ref pos, ref rot);
		}
	}
}

