﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface IGridHelper
	{
		/*
		============================================================================
		Direction functions
		============================================================================
		*/
		CubeCoord GetDirection(int direction);

		CubeCoord GetDirectionNonDiagonal(int direction);


		/*
		============================================================================
		Rotation functions
		============================================================================
		*/
		int AngleToDirection(float angle, bool allowSquareDiagonal);

		float DirectionToAngle(int direction, bool allowSquareDiagonal);


		/*
		============================================================================
		Neighbour functions
		============================================================================
		*/
		float GetNeighbourAngle();

		float GetNeighbourAngleOffset();

		BattleGridCellComponent GetNeighbourCell(BattleGridCellComponent cell, int index);

		bool IsNeighbourCell(BattleGridCellComponent origin,
			BattleGridCellComponent cell, bool allowSquareDiagonal, GridCellCheck check);

		void UsePathNeighbourCells(BattleGridCellComponent origin, UsePathCell useCell,
			bool allowSquareDiagonal, GridCellCheck check, GridCellCheck checkDiagonal);

		void UsePathNeighbourCells(BattleGridCellComponent origin,
			UsePathCell useCell, ref List<BattleGridCellComponent> blockedList,
			bool allowSquareDiagonal, bool blockedOccupied,
			GridCellCheck check, GridCellCheck checkDiagonal);


		/*
		============================================================================
		Range functions
		============================================================================
		*/
		void GetRange(BattleGridCellComponent origin, int minDistance, int maxDistance,
			ref List<BattleGridCellComponent> list, ref HashSet<BattleGridCellComponent> contains,
			bool addOrigin, bool addBlocked, bool addNotPassable, bool allowSquareDiagonal, GridCellCheck check);

		void GetRange(Combatant user, int minDistance, int maxDistance,
			ref List<BattleGridCellComponent> list, ref HashSet<BattleGridCellComponent> contains,
			bool allowSquareDiagonal, GridCellOriginCheck check);

		void GetRangeCombatants(BattleGridCellComponent origin, int minDistance, int maxDistance,
		   ref List<Combatant> list, bool addOrigin, bool addBlocked, bool addNotPassable,
		   bool allowSquareDiagonal, GridCellCheck check);

		void GetRangeCombatants(Combatant user, int minDistance, int maxDistance,
		   ref List<Combatant> list, bool allowSquareDiagonal, GridCellOriginCheck check);

		bool CheckRange(BattleGridCellComponent origin, int minDistance, int maxDistance,
			bool addOrigin, bool addBlocked, bool addNotPassable, bool allowSquareDiagonal, GridCellCheck check);


		/*
		============================================================================
		Ring functions
		============================================================================
		*/
		void GetRing(BattleGridCellComponent center, int radius,
			ref List<BattleGridCellComponent> list, ref HashSet<BattleGridCellComponent> contains,
			bool addOrigin, bool addBlocked, bool addNotPassable,
			bool allowSquareDiagonal, GridCellCheck check);

		void GetRingCombatants(BattleGridCellComponent center, int radius,
			ref List<Combatant> list, bool addOrigin, bool addBlocked, bool addNotPassable,
			bool allowSquareDiagonal, GridCellCheck check);

		bool CheckRing(BattleGridCellComponent center, int radius,
			bool addOrigin, bool addBlocked, bool addNotPassable,
			bool allowSquareDiagonal, GridCellCheck check);


		/*
		============================================================================
		Line functions
		============================================================================
		*/
		void GetLine(BattleGridCellComponent origin, BattleGridCellComponent target,
			ref List<BattleGridCellComponent> list, ref HashSet<BattleGridCellComponent> contains,
			bool ignoreBlocked);


		/*
		============================================================================
		Line of sight functions
		============================================================================
		*/
		bool CheckLineOfSight(Combatant user, BattleGridCellComponent origin, BattleGridCellComponent target,
			GridCellOriginCheck blockLOS, float cellArea);


		/*
		============================================================================
		CubeCoord functions
		============================================================================
		*/
		CubeCoord Rotate(CubeCoord origin, int turns);

		int Distance(CubeCoord origin, CubeCoord target);

		int Distance(CubeCoord origin, CubeCoord target, bool blockDiagonalDistance1);
	}
}
