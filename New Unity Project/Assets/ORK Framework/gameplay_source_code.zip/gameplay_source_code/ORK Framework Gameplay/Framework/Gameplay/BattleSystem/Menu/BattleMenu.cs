
using UnityEngine;
using ORKFramework.Menu;
using ORKFramework.UI;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleMenu : BaseIndexData
	{
		// base settings
		[ORKEditorHelp("Name", "The name of the battle menu.", "")]
		[ORKEditorInfo("Base Settings", "Set the name and base settings of the battle menu.", "",
			expandWidth=true)]
		public string name = "";

		// gui box settings
		[ORKEditorHelp("GUI Box", "Select the GUI box used to display this battle menu.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox, separator=true, labelText="GUI Box Settings")]
		public int guiBoxID = 0;

		[ORKEditorHelp("Update Interval (s)", "The time in seconds between two menu checks.\n" +
			"A check updates the availability of the current menu options (e.g. available targets of an ability).", "")]
		[ORKEditorLimit(0.0f, false)]
		public float updateInterval = 0.5f;

		[ORKEditorHelp("Change Time Scale", "Change the time scale while displaying the battle menu.\n" +
			"This can be used to slow down or speed up the battle.", "")]
		public bool setTimeScale = false;

		[ORKEditorHelp("Set ORK Scale", "Set the ORK Framework time scale - " +
			"it's used only for ORK Framework related things, like battles, events, etc.\n" +
			"If disabled, the Unity time scale will be set, affecting everything in the game.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("setTimeScale", true)]
		public bool setORKScale = false;

		[ORKEditorHelp("Time Scale", "Define the time scale that will be used while displaying the battle menu.\n" +
			"A time scale of 1 is normal speed, 0.5 is half speed, 2 is double speed.\n" +
			"A time scale of 0 will freeze time.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float timeScale = 1;

		// sub-menu boxes
		[ORKEditorHelp("Use Sub-Menu Boxes", "Use different GUI boxes when displaying sub-menus " +
			"(e.g. ability types or targets).\n" +
			"If disabled, the selected 'GUI Box' will be used for all menus.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useSubBoxes = false;

		[ORKEditorHelp("Ability Type Box", "Select the GUI box used to display ability type menus.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("useSubBoxes", true)]
		public int abilityTypeBoxID = 0;

		[ORKEditorHelp("Ability Box", "Select the GUI box used to display ability menus.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int abilityBoxID = 0;

		[ORKEditorHelp("Item Type Box", "Select the GUI box used to display item type menus.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int itemTypeBoxID = 0;

		[ORKEditorHelp("Item Box", "Select the GUI box used to display item menus.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int itemBoxID = 0;

		[ORKEditorHelp("Target Box", "Select the GUI box used to display target menus.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int targetBoxID = 0;

		[ORKEditorHelp("Equipment Part Box", "Select the GUI box used to display equipment part menus.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int equipmentPartBoxID = 0;

		[ORKEditorHelp("Equipment Box", "Select the GUI box used to display equipment menus.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int equipmentBoxID = 0;

		[ORKEditorHelp("Command Box", "Select the GUI box used to display command menus.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int commandBoxID = 0;


		// title settings
		[ORKEditorHelp("Show Title", "Show a title in the name box of the selected GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool showTitle = true;

		[ORKEditorHelp("Title", "The title of the battle menu.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {
			"%n = combatant name, %d = combatant description, %i = combatant icon",
			"%ft0% = faction text 0, %ft1% = faction text 1, ..."
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("showTitle", true, endCheckGroup=true)]
		public string[] title = ArrayHelper.CreateArray(ORK.Languages.Count, "%n");


		// options
		[ORKEditorHelp("Select Last Target", "The target menu's selection will " +
			"automatically highlight the last target (if still available).\n" +
			"If disabled, the selection highlights the first target in the list.", "")]
		[ORKEditorInfo(separator=true, labelText="Options")]
		public bool selectLastTarget = false;

		[ORKEditorHelp("Select Self", "The target menu's selection will automatically " +
			"highlight the menu user itself (if available in the list). " +
			"'Select Last Target' will override this setting - i.e. if the user's last target " +
			"is also in the list, it will be selected instead of the user itself.\n" +
			"If disabled, the selection highlights the first target in the list, " +
			"or the last target (if 'Select Last Target' is enabled)", "")]
		public bool selectSelf = false;

		[ORKEditorHelp("Remember Selection", "Remember the last selections made in the menu.\n" +
			"Used in all menus except target menu.\n" +
			"If disabled, the selection highlights the first menu item in the list.", "")]
		public bool rememberSelection = false;

		[ORKEditorHelp("Reset Selection", "Reset the selection to the 1st menu item each time.", "")]
		[ORKEditorLayout("rememberSelection", false, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool resetSelection = false;


		// auto target settings
		[ORKEditorHelp("Use Group Target", "Automatically use a group target for abilities and items (if available).", "")]
		[ORKEditorInfo(separator=true, labelText="Auto Target Settings")]
		public bool useGroupTarget = false;

		[ORKEditorHelp("Use Individual Target", "Automatically use an individual target for abilities and items (if available).", "")]
		public bool useIndividualTarget = false;


		// back button
		[ORKEditorInfo(separator=true, labelText="Back Button Settings")]
		public AddBackButton backButton = new AddBackButton();

		[ORKEditorHelp("Back In Base", "Add the back button in the base battle menu list (with the items defined here).\n" +
			"The back button will only be added in 'Real Time' and 'Phase' battles.", "")]
		[ORKEditorLayout("backButton.type", AddButtonType.None, elseCheckGroup=true, endCheckGroup=true)]
		public bool backInBase = false;


		// audio settings
		[ORKEditorHelp("Open Clip", "Select the audio clip that will be played when opening this menu.\n" +
			"Select none to not play an audio clip.", "")]
		[ORKEditorInfo(separator=true, labelText="Audio Settings")]
		public AudioClip openClip;

		[ORKEditorHelp("Volume (Open)", "The volume used to play the open clip (between 0 and 1).", "")]
		[ORKEditorLayout("openClip", null, elseCheckGroup=true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float openVolume = 1;

		[ORKEditorHelp("Close Clip", "Select the audio clip that will be played when closing this menu.\n" +
			"Select none to not play an audio clip.", "")]
		public AudioClip closeClip;

		[ORKEditorHelp("Volume (Close)", "The volume used to play the close clip (between 0 and 1).", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("closeClip", null, elseCheckGroup=true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float closeVolume = 1;


		// layout
		[ORKEditorInfo("Content Layout", "Define the layout of the buttons.", "",
			endFoldout=true)]
		public ContentLayout contentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.Info);


		// description box
		[ORKEditorHelp("Show Description", "An additional GUI box is used to display the description of selected menu items.", "")]
		[ORKEditorInfo("Description Settings", "A description box can be displayed to show the description of a selected menu item.", "")]
		public bool useDesc = false;

		[ORKEditorHelp("Description Box", "Select the GUI box used to display the description of a selected menu item.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("useDesc", true)]
		public int descBoxID = 0;

		[ORKEditorHelp("Always Visible", "The description box will always be visible, even if no description is available.\n" +
			"If disabled, the description box will only be displayed if the selected menu item has a description.", "")]
		[ORKEditorLayout(setDefault=true, defaultValue=false)]
		public bool descAlways = false;

		[ORKEditorHelp("Show Title", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorLayout(setDefault=true, defaultValue=false)]
		public bool useDescTitle = false;

		[ORKEditorHelp("Description Title", "The title of the description box.", "")]
		[ORKEditorInfo(expandWidth=true, endFoldout=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useDescTitle", true, endCheckGroup=true, endGroups=2, autoInit=true, autoLangSize=true)]
		public string[] descTitle;


		// portrait
		// combatant portrait
		[ORKEditorHelp("Show Combatant Portrait", "Show a portrait of the combatant.", "")]
		[ORKEditorInfo("Portrait Settings", "A portrait of the combatant can be displayed while showing the battle menu.", "",
			labelText="Combatant Portrait")]
		public bool showPortrait = false;

		[ORKEditorHelp("Portrait Type", "Select the portrait type that will be displayed.\n" +
			"The combatant needs to have a portrait with this type.", "")]
		[ORKEditorInfo(ORKDataType.PortraitType)]
		[ORKEditorLayout("showPortrait", true)]
		public int portraitTypeID = 0;

		// own portrait position
		[ORKEditorHelp("Own Position", "Overrides the default, GUI box and combatant portrait position settings.", "")]
		[ORKEditorInfo(separator=true, labelText="Portrait Position")]
		public bool ownPortraitPosition = false;

		[ORKEditorLayout("ownPortraitPosition", true, endCheckGroup=true, autoInit=true, endGroups=2)]
		public PortraitPosition portraitPosition;

		// list portraits
		// item portraits
		[ORKEditorHelp("Show Item Portraits", "Display the portrait of a selected item (if available).", "")]
		[ORKEditorInfo(separator=true, labelText="List Portraits")]
		public bool showItemPortraits = false;

		[ORKEditorHelp("Item Portrait Type", "Select the portrait type that will be displayed for items.", "")]
		[ORKEditorInfo(ORKDataType.PortraitType)]
		[ORKEditorLayout("showItemPortraits", true, endCheckGroup=true)]
		public int itemPortraitTypeID = 0;

		// equipment potraits
		[ORKEditorHelp("Show Equipment Portraits", "Display the portrait of a selected equipment (if available).", "")]
		public bool showEquipPortraits = false;

		[ORKEditorHelp("Equipment Portrait Type", "Select the portrait type that will be displayed for equipment.", "")]
		[ORKEditorInfo(ORKDataType.PortraitType)]
		[ORKEditorLayout("showEquipPortraits", true, endCheckGroup=true)]
		public int equipPortraitTypeID = 0;

		// AI behaviour potraits
		[ORKEditorHelp("Show AI Behaviour Portraits", "Display the portrait of a selected AI behaviour (if available).", "")]
		public bool showAIBehaviourPortraits = false;

		[ORKEditorHelp("AI Behaviour Portrait Type", "Select the portrait type that will be displayed for AI behaviours.", "")]
		[ORKEditorInfo(ORKDataType.PortraitType)]
		[ORKEditorLayout("showAIBehaviourPortraits", true, endCheckGroup=true)]
		public int aiBehaviourPortraitTypeID = 0;

		// AI ruleset potraits
		[ORKEditorHelp("Show AI Ruleset Portraits", "Display the portrait of a selected AI ruleset (if available).", "")]
		public bool showAIRulesetPortraits = false;

		[ORKEditorHelp("AI Ruleset Portrait Type", "Select the portrait type that will be displayed for AI rulesets.", "")]
		[ORKEditorInfo(ORKDataType.PortraitType)]
		[ORKEditorLayout("showAIRulesetPortraits", true, endCheckGroup=true)]
		public int aiRulesetPortraitTypeID = 0;

		// ability portraits
		[ORKEditorHelp("Show Ability Portraits", "Display the portrait of a selected ability (if available).", "")]
		public bool showAbilityPortraits = false;

		[ORKEditorHelp("Ability Portrait Type", "Select the portrait type that will be displayed for abilities.", "")]
		[ORKEditorInfo(ORKDataType.PortraitType)]
		[ORKEditorLayout("showAbilityPortraits", true, endCheckGroup=true)]
		public int abilityPortraitTypeID = 0;

		// target potraits
		[ORKEditorHelp("Show Target Portraits", "Display the portrait of a selected target (if available).", "")]
		public bool showTargetPortraits = false;

		[ORKEditorHelp("Target Portrait Type", "Select the portrait type that will be displayed for the target.\n" +
			"The combatant needs to have a portrait with this type.", "")]
		[ORKEditorInfo(ORKDataType.PortraitType)]
		[ORKEditorLayout("showTargetPortraits", true, endCheckGroup=true)]
		public int targetPortraitTypeID = 0;

		// command portraits
		[ORKEditorHelp("Show Command Portraits", "Display the portrait of a selected group member to give commands to (if available).", "")]
		public bool showCommandPortraits = false;

		[ORKEditorHelp("Command Portrait Type", "Select the portrait type that will be displayed for the combatant.\n" +
			"The combatant needs to have a portrait with this type.", "")]
		[ORKEditorInfo(ORKDataType.PortraitType)]
		[ORKEditorLayout("showCommandPortraits", true, endCheckGroup=true)]
		public int commandPortraitTypeID = 0;

		// change portraits
		[ORKEditorHelp("Show Change Portraits", "Display the portrait of a selected group member available for changing members (if available).", "")]
		public bool showChangePortraits = false;

		[ORKEditorHelp("Change Portrait Type", "Select the portrait type that will be displayed for the combatant.\n" +
			"The combatant needs to have a portrait with this type.", "")]
		[ORKEditorInfo(ORKDataType.PortraitType, endFoldout=true)]
		[ORKEditorLayout("showChangePortraits", true, endCheckGroup=true)]
		public int changePortraitTypeID = 0;


		// own target choice layout
		[ORKEditorHelp("Own Layout", "Override the default combatant choice layout (Menu Settings).", "")]
		[ORKEditorInfo("Combatant Choice Layout", "A battle menu can override the " +
			"default default layout for combatant choices.", "")]
		public bool ownCombatantChoice = false;

		[ORKEditorInfo(endFoldout=true, separator=true)]
		[ORKEditorLayout("ownCombatantChoice", true, endCheckGroup=true, autoInit=true)]
		public CombatantChoiceLayout combatantChoice;


		// header settings
		[ORKEditorInfo("Header Texts", "The header texts displayed above the choices.", "")]
		public HeaderTexts headerTexts = new HeaderTexts();

		[ORKEditorHelp("Use Sub-Menu Headers", "Use different header texts when displaying sub-menus " +
			"(e.g. ability types or targets).\n" +
			"If disabled, the defined header texts will be used for all menus.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useSubHeaders = false;

		[ORKEditorInfo("Ability Type Header Texts", "The header texts displayed above the ability type choices.", "",
			endFoldout=true)]
		[ORKEditorLayout("useSubHeaders", true, autoInit=true)]
		public HeaderTexts abilityTypeHeaderTexts;

		[ORKEditorInfo("Ability Header Texts", "The header texts displayed above the ability choices.", "",
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public HeaderTexts abilityHeaderTexts;

		[ORKEditorInfo("Item Type Header Texts", "The header texts displayed above the item type choices.", "",
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public HeaderTexts itemTypeHeaderTexts;

		[ORKEditorInfo("Item Header Texts", "The header texts displayed above the item choices.", "",
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public HeaderTexts itemHeaderTexts;

		[ORKEditorInfo("Target Header Texts", "The header texts displayed above the target choices.", "",
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public HeaderTexts targetHeaderTexts;

		[ORKEditorInfo("Equipment Part Header Texts", "The header texts displayed above the equipment part choices.", "",
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public TitleHeaderTexts equipPartHeaderTexts;

		[ORKEditorInfo("Equipment Header Texts", "The header texts displayed above the equipment choices.", "",
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public HeaderTexts equipHeaderTexts;

		[ORKEditorInfo("Command Header Texts", "The header texts displayed above the command choices.", "",
			endFoldout=true, endFolds=2)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public HeaderTexts commandHeaderTexts;


		// user highlight
		[ORKEditorInfo("User Highlight", "Define how the menu's user is highlighted.", "",
			endFoldout=true)]
		public HighlightGameObjectSetting userHighlight = new HighlightGameObjectSetting();



		// options/commands
		[ORKEditorArray(false, "Add Menu Item", "Adds a battle menu item to this battle menu.", "",
			"Remove", "Remove this battle menu item.", "", noRemoveCount=1, isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {"Option", "Name and settings of this menu item/command.",""})]
		public BattleMenuItem[] item = new BattleMenuItem[] {new BattleMenuItem()};

		public BattleMenu()
		{

		}

		public BattleMenu(string name)
		{
			this.name = name;
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			// back buttons
			if(data.Contains<bool>("addBack"))
			{
				this.backButton.DataUpgrade(data, "addBack", "backFirst");
			}
		}


		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public void AddBack(List<BMItem> list)
		{
			this.backButton.AddButton(this.contentLayout, list);
		}

		public List<BMItem> GetMenu(Combatant owner)
		{
			List<BMItem> list = new List<BMItem>();

			for(int i = 0; i < this.item.Length; i++)
			{
				this.item[i].AddToMenu(ref list, owner, this);
			}

			if(this.backInBase &&
				(ORK.Battle.IsMenuBackAllowed || owner.Battle.BattleMenu.CommandedBy != null))
			{
				this.AddBack(list);
			}

			return list;
		}

		public string GetDescriptionTitle()
		{
			if(this.useDescTitle)
			{
				return this.descTitle[ORK.Game.Language];
			}
			return "";
		}

		public int GetGUIBoxID(BattleMenuMode mode)
		{
			if(this.useSubBoxes)
			{
				if(BattleMenuMode.AbilityType == mode)
				{
					return this.abilityTypeBoxID;
				}
				else if(BattleMenuMode.Ability == mode)
				{
					return this.abilityBoxID;
				}
				else if(BattleMenuMode.ItemType == mode)
				{
					return this.itemTypeBoxID;
				}
				else if(BattleMenuMode.Item == mode)
				{
					return this.itemBoxID;
				}
				else if(BattleMenuMode.Target == mode)
				{
					return this.targetBoxID;
				}
				else if(BattleMenuMode.EquipmentPart == mode)
				{
					return this.equipmentPartBoxID;
				}
				else if(BattleMenuMode.Equipment == mode)
				{
					return this.equipmentBoxID;
				}
				else if(BattleMenuMode.Command == mode)
				{
					return this.commandBoxID;
				}
			}
			return this.guiBoxID;
		}

		public HeaderContent GetHeaderContent(BattleMenuMode mode)
		{
			if(this.useSubHeaders)
			{
				if(BattleMenuMode.AbilityType == mode)
				{
					return this.abilityTypeHeaderTexts.GetContent();
				}
				else if(BattleMenuMode.Ability == mode)
				{
					return this.abilityHeaderTexts.GetContent();
				}
				else if(BattleMenuMode.ItemType == mode)
				{
					return this.itemTypeHeaderTexts.GetContent();
				}
				else if(BattleMenuMode.Item == mode)
				{
					return this.itemHeaderTexts.GetContent();
				}
				else if(BattleMenuMode.Target == mode)
				{
					return this.targetHeaderTexts.GetContent();
				}
				else if(BattleMenuMode.EquipmentPart == mode)
				{
					return this.equipPartHeaderTexts.GetContent();
				}
				else if(BattleMenuMode.Equipment == mode)
				{
					return this.equipHeaderTexts.GetContent();
				}
				else if(BattleMenuMode.Command == mode)
				{
					return this.commandHeaderTexts.GetContent();
				}
			}
			return this.headerTexts.GetContent();
		}
	}
}
