
using ORKFramework;
using ORKFramework.AI;
using ORKFramework.Behaviours;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI.Steps
{
	[ORKEditorHelp("Attack", "Performs the combatant's base attack or counter attack.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[ORKNodeInfo("Action")]
	public class AttackStep : BaseAIStep
	{
		[ORKEditorHelp("Use Counter", "The combatant's counter attack is used.\n" +
			"If disabled, the combatant's base attack is used.", "")]
		public bool useCounter = false;


		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		[ORKEditorInfo(separator=true)]
		public bool endPhase = false;

		[ORKEditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		[ORKEditorHelp("Force Found Targets", "The action will only have the found targets available.\n" +
			"It can't fall back to other targets based on the combatant's AI settings if none of the targets is in range.", "")]
		public bool forceFoundTargets = false;

		[ORKEditorHelp("Need Targets", "Valid targets must be found within use range, otherwise the attack wont be used.", "")]
		public bool needTargets = false;

		public AttackStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			AbilityAction action = null;
			AbilityShortcut ability = this.useCounter ?
				call.user.Abilities.GetCounterAttack() :
				call.user.Abilities.GetCurrentBaseAttack();

			// get action
			if(!call.user.Status.Effects.BlockAttack)
			{
				action = BaseAction.CreateAbility(call.user, ability, -2);
			}

			// check AI blocks
			if(!call.user.AI.CanUseAction(action))
			{
				action = null;
			}

			// check active time
			if(action != null)
			{
				action.forceFoundTargets = this.forceFoundTargets;
				bool targetsFound = call.user.AI.SetActionTargets(action,
					BattleAI.GetPreferredTargets(call.user, call.foundTargets), call.allies, call.enemies);

				if((this.needTargets && !targetsFound) ||
					(ORK.Battle.IsActiveTime() &&
						(call.user.Battle.UsedActionBar + action.ActionCost) > ORK.Battle.Settings.activeTime.maxTimebar))
				{
					action = null;
				}
			}

			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
				action.blockBattleCamera = this.blockBattleCamera;
			}

			currentStep = this.next;
			return action;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.useCounter ? "Counter Attack" : "Base Attack") +
				(this.endPhase ? ", Ends Phase" : "");
		}
	}

	[ORKEditorHelp("Ability", "Performs an ability of the combatant.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[ORKNodeInfo("Action")]
	public class AbilityStep : BaseAIStep
	{
		// random ability
		[ORKEditorHelp("Use Random Ability", "Use a random ability known by the combatant.", "")]
		public bool useRandom = false;

		[ORKEditorHelp("Limit Ability Type", "Limit the random abilities to a defined ability type.", "")]
		[ORKEditorLayout("useRandom", true)]
		public bool limitType = false;

		[ORKEditorHelp("Ability Type", "Select the ability type that will be used to limit the random abilities.\n" +
			"Only abilities of the selected type will be used.", "")]
		[ORKEditorInfo(ORKDataType.AbilityType)]
		[ORKEditorLayout("limitType", true, endCheckGroup=true)]
		public int typeID = 0;

		// defined ability
		[ORKEditorHelp("Ability", "Select the ability that will be performed.\n" +
			"The combatant must know the ability (e.g. learned the ability, equipment ability), or the action can't be performed.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id = 0;

		// ability setup
		[ORKEditorHelp("Use Highest Level", "The highest available ability level will be used " +
			"(i.e. the highest level that can be used, e.g. due to use costs).\n" +
			"If disabled, a defined ability level will be used - " +
			 "if the defined level can't be used (e.g. due to use costs), the action can't be performed.", "")]
		public bool useHighest = false;

		[ORKEditorHelp("Level", "Set the level of the ability that will be used.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("useHighest", false, endCheckGroup=true)]
		public int level = 1;


		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		[ORKEditorInfo(separator=true)]
		public bool endPhase = false;

		[ORKEditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		[ORKEditorHelp("Force Found Targets", "The action will only have the found targets available.\n" +
			"It can't fall back to other targets based on the combatant's AI settings if none of the targets is in range.", "")]
		public bool forceFoundTargets = false;

		[ORKEditorHelp("Need Targets", "Valid targets must be found within use range, otherwise the ability wont be used.", "")]
		public bool needTargets = false;

		public AbilityStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			AbilityAction action = null;

			// get action
			AbilityShortcut ability = null;
			if(this.useRandom)
			{
				List<AbilityShortcut> list = this.limitType ?
					call.user.Abilities.GetByType(this.typeID, UseableIn.Battle, IncludeCheckType.Yes, true) :
					call.user.Abilities.GetAbilities(UseableIn.Battle, IncludeCheckType.Yes);
				if(list.Count > 0)
				{
					ability = list[UnityWrapper.Range(0, list.Count)];
				}
			}
			else
			{
				ability = call.user.Abilities.Get(this.id);
			}

			if(ability != null)
			{
				action = BaseAction.CreateAbility(call.user, ability, this.useHighest ? -1 : this.level);
			}

			// check AI blocks
			if(!call.user.AI.CanUseAction(action))
			{
				action = null;
			}

			// check active time
			if(action != null)
			{
				action.forceFoundTargets = this.forceFoundTargets;
				bool targetsFound = call.user.AI.SetActionTargets(action,
					BattleAI.GetPreferredTargets(call.user, call.foundTargets), call.allies, call.enemies);

				if((this.needTargets && !targetsFound) ||
					(ORK.Battle.IsActiveTime() &&
						(call.user.Battle.UsedActionBar + action.ActionCost) > ORK.Battle.Settings.activeTime.maxTimebar))
				{
					action = null;
				}
			}

			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
				action.blockBattleCamera = this.blockBattleCamera;
			}

			currentStep = this.next;
			return action;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.useRandom ?
					(this.limitType ? "Random " + ORK.AbilityTypes.GetName(this.typeID) : "Random") :
					ORK.Abilities.GetName(this.id)) +
				(this.useHighest ? ", Highest Level" : ", Level " + this.level) +
				(this.endPhase ? ", Ends Phase" : "");
		}
	}

	[ORKEditorHelp("Class Ability", "Performs the combatant's class ability.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[ORKNodeInfo("Action")]
	public class ClassAbilityStep : BaseAIStep
	{
		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		public bool endPhase = false;

		[ORKEditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		[ORKEditorHelp("Force Found Targets", "The action will only have the found targets available.\n" +
			"It can't fall back to other targets based on the combatant's AI settings if none of the targets is in range.", "")]
		public bool forceFoundTargets = false;

		[ORKEditorHelp("Need Targets", "Valid targets must be found within use range, otherwise the ability wont be used.", "")]
		public bool needTargets = false;

		public ClassAbilityStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			AbilityAction action = null;
			AbilityShortcut ability = null;

			// get action
			if(call.user.Abilities.HasClassAbility())
			{
				ability = call.user.Abilities.GetClassAbility();
				if(ability != null)
				{
					action = BaseAction.CreateAbility(call.user, ability, -1);
				}
			}

			// check AI blocks
			if(!call.user.AI.CanUseAction(action))
			{
				action = null;
			}

			// check active time
			if(action != null)
			{
				action.forceFoundTargets = this.forceFoundTargets;
				bool targetsFound = call.user.AI.SetActionTargets(action,
					BattleAI.GetPreferredTargets(call.user, call.foundTargets), call.allies, call.enemies);

				if((this.needTargets && !targetsFound) ||
					(ORK.Battle.IsActiveTime() &&
					(call.user.Battle.UsedActionBar + action.ActionCost) > ORK.Battle.Settings.activeTime.maxTimebar))
				{
					action = null;
				}
			}

			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
				action.blockBattleCamera = this.blockBattleCamera;
			}

			currentStep = this.next;
			return action;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.endPhase ? "Ends Phase" : "";
		}
	}

	[ORKEditorHelp("Item", "The combatant uses an item.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[ORKNodeInfo("Action")]
	public class ItemStep : BaseAIStep
	{
		[ORKEditorHelp("Use Random Item", "Use a random item in the combatant's inventory.", "")]
		public bool useRandom = false;

		[ORKEditorHelp("Limit Item Type", "Limit the random items to a defined item type.", "")]
		[ORKEditorLayout("useRandom", true)]
		public bool limitType = false;

		[ORKEditorHelp("Item Type", "Select the item type that will be used to limit the random items.\n" +
			"Only items of the selected type will be used.", "")]
		[ORKEditorInfo(ORKDataType.ItemType)]
		[ORKEditorLayout("limitType", true, endCheckGroup=true)]
		public int typeID = 0;

		[ORKEditorHelp("Item", "Select the item that will be used.\n" +
			"The item must be useable in battle, or the action can't be performed.", "")]
		[ORKEditorInfo(ORKDataType.Item)]
		[ORKEditorLayout(elseCheckGroup=true)]
		public int id = 0;

		[ORKEditorHelp("In Inventory", "The item must be in the combatant's inventory, or the action can't be performed.\n" +
			"If disabled, the combatant doesn't need to have the item in the inventory, but it will be consumed if it's in the inventory.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool inInventory = false;


		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		[ORKEditorInfo(separator=true)]
		public bool endPhase = false;

		[ORKEditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		[ORKEditorHelp("Force Found Targets", "The action will only have the found targets available.\n" +
			"It can't fall back to other targets based on the combatant's AI settings if none of the targets is in range.", "")]
		public bool forceFoundTargets = false;

		[ORKEditorHelp("Need Targets", "Valid targets must be found within use range, otherwise the item wont be used.", "")]
		public bool needTargets = false;

		public ItemStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			ItemAction action = null;

			// get action
			ItemShortcut item = null;
			if(this.useRandom)
			{
				List<ItemShortcut> list = this.limitType ?
					call.user.Inventory.Items.GetUseableItemsByType(this.typeID, UseableIn.Battle, true) :
					call.user.Inventory.Items.GetUseableItems(UseableIn.Battle);
				if(list.Count > 0)
				{
					item = list[UnityWrapper.Range(0, list.Count)];
				}
			}
			else
			{
				item = this.inInventory ?
					call.user.Inventory.GetItem(this.id) :
					new ItemShortcut(this.id, 1);
			}

			if(item != null && item.CanUse(call.user, true, true))
			{
				action = new ItemAction(call.user, item);
			}

			// check AI blocks
			if(!call.user.AI.CanUseAction(action))
			{
				action = null;
			}

			// check active time
			if(action != null)
			{
				action.forceFoundTargets = this.forceFoundTargets;
				bool targetsFound = call.user.AI.SetActionTargets(action,
					BattleAI.GetPreferredTargets(call.user, call.foundTargets), call.allies, call.enemies);

				if((this.needTargets && !targetsFound) ||
					(ORK.Battle.IsActiveTime() &&
					(call.user.Battle.UsedActionBar + action.ActionCost) > ORK.Battle.Settings.activeTime.maxTimebar))
				{
					action = null;
				}
			}

			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
				action.blockBattleCamera = this.blockBattleCamera;
			}

			currentStep = this.next;
			return action;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.useRandom ?
					(this.limitType ? "Random " + ORK.ItemTypes.GetName(this.typeID) : "Random") :
					ORK.Items.GetName(this.id)) +
				(this.inInventory ? ", Inventory" : "") +
				(this.endPhase ? ", Ends Phase" : "");
		}
	}

	[ORKEditorHelp("Defend", "The combatant uses the defend command.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[ORKNodeInfo("Action")]
	public class DefendStep : BaseAIStep
	{
		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		public bool endPhase = false;

		[ORKEditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		public DefendStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			BaseAction action = null;

			// get action
			if(!call.user.Status.Effects.BlockDefend)
			{
				action = new DefendAction(call.user);
			}

			// check active time
			if(action != null && (ORK.Battle.IsActiveTime() &&
				(call.user.Battle.UsedActionBar + action.ActionCost) > ORK.Battle.Settings.activeTime.maxTimebar))
			{
				action = null;
			}

			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
				action.blockBattleCamera = this.blockBattleCamera;
			}

			currentStep = this.next;
			return action;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.endPhase ? "Ends Phase" : "";
		}
	}

	[ORKEditorHelp("Escape", "The combatant uses the escape command.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[ORKNodeInfo("Action")]
	public class EscapeStep : BaseAIStep
	{
		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		public bool endPhase = false;

		[ORKEditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		public EscapeStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			BaseAction action = null;

			// get action
			if(!call.user.Status.Effects.BlockEscape)
			{
				action = new EscapeAction(call.user);
			}

			// check AI blocks
			if(!call.user.AI.CanUseAction(action))
			{
				action = null;
			}

			// check active time
			if(action != null && (ORK.Battle.IsActiveTime() &&
				(call.user.Battle.UsedActionBar + action.ActionCost) > ORK.Battle.Settings.activeTime.maxTimebar))
			{
				action = null;
			}

			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
				action.blockBattleCamera = this.blockBattleCamera;
			}

			currentStep = this.next;
			return action;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.endPhase ? "Ends Phase" : "";
		}
	}

	[ORKEditorHelp("Death", "The combatant dies.", "")]
	[ORKNodeInfo("Action")]
	public class DeathStep : BaseAIStep
	{
		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		public bool endPhase = false;

		[ORKEditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		public DeathStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			currentStep = -1;
			BaseAction action = new DeathAction(call.user, false);
			action.endPhaseFlag = this.endPhase;
			action.blockBattleCamera = this.blockBattleCamera;

			return action;
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 0;
		}

		public override int GetNext(int index)
		{
			return -1;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return "Ends the AI" + (this.endPhase ? ", Ends Phase" : "");
		}
	}

	[ORKEditorHelp("None", "The combatant does nothing.", "")]
	[ORKNodeInfo("Action")]
	public class NoneStep : BaseAIStep
	{
		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		public bool endPhase = false;

		[ORKEditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		[ORKEditorHelp("Is Silent", "The 'None' action will be silent, " +
			"i.e. no battle info will be displayed and no battle events will be used.", "")]
		public bool isSilent = false;

		public NoneStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			currentStep = -1;
			BaseAction action = new NoneAction(call.user, this.isSilent);
			action.endPhaseFlag = this.endPhase;
			action.blockBattleCamera = this.blockBattleCamera;
			return action;
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 0;
		}

		public override int GetNext(int index)
		{
			return -1;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return "Ends the AI" +
				(this.isSilent ? " (silent)" : "") +
				(this.endPhase ? ", Ends Phase" : "");
		}
	}

	[ORKEditorHelp("Change Member", "The combatant is exchanged with a member of the combatant's non-battle group.", "")]
	[ORKNodeInfo("Action")]
	public class ChangeMemberStep : BaseAIStep
	{
		[ORKEditorHelp("Member Index", "The index of the non-battle member that will be used.", "")]
		[ORKEditorLimit(0, false)]
		public int memberIndex = 0;

		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		public bool endPhase = false;

		[ORKEditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		public ChangeMemberStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			currentStep = -1;
			BaseAction action = null;

			Combatant target = call.user.Group.NonBattleMemberAt(this.memberIndex);
			if(target != null)
			{
				action = new ChangeMemberAction(call.user, target);
				action.endPhaseFlag = this.endPhase;
				action.blockBattleCamera = this.blockBattleCamera;
			}

			return action;
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 0;
		}

		public override int GetNext(int index)
		{
			return -1;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return "Ends the AI" + (this.endPhase ? ", Ends Phase" : "");
		}
	}

	[ORKEditorHelp("Grid Move", "The combatant moves on the grid, either toward a target, flees from a target or to a random cell within move range.\n" +
		"If the target is reachable, but no grid move action can be performed in this turn " +
		"(e.g. not enough move range left), 'Reachable' will be executed next, otherwise 'Next'.", "")]
	[ORKNodeInfo("Action")]
	public class GridMoveStep : BaseAIStep
	{
		public GridMoveSettings gridMove = new GridMoveSettings();

		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		[ORKEditorInfo(separator=true)]
		public bool endPhase = false;

		[ORKEditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		[ORKEditorInfo(hide=true)]
		public int nextReachable = -1;

		public GridMoveStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("stopDistance"))
			{
				this.gridMove.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			currentStep = this.next;
			GridMoveAction action = null;

			if(this.gridMove.GetMoveAction(call.user,
				BattleAI.GetPreferredTargets(call.user, call.foundTargets), call.allies, call.enemies,
				out action, null))
			{
				currentStep = this.nextReachable;
			}

			// check active time
			if(action != null && (ORK.Battle.IsActiveTime() &&
				(call.user.Battle.UsedActionBar + action.ActionCost) > ORK.Battle.Settings.activeTime.maxTimebar))
			{
				action = null;
			}

			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
				action.blockBattleCamera = this.blockBattleCamera;
			}

			return action;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.gridMove.ToString() + (this.endPhase ? ", Ends Phase" : "");
		}

		public override string GetNextName(int index)
		{
			if(index == 1)
			{
				return "Reachable";
			}
			return "Next";
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 2;
		}

		public override int GetNext(int index)
		{
			if(index == 1)
			{
				return this.nextReachable;
			}
			return this.next;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 1)
			{
				this.nextReachable = next;
			}
			else
			{
				this.next = next;
			}
		}
	}

	[ORKEditorHelp("Shortcut Slot", "Performs an action stored in a shortcut slot.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[ORKNodeInfo("Action")]
	public class ShortcutSlotStep : BaseAIStep
	{
		public ShortcutSlot slot = new ShortcutSlot();

		// other settings
		[ORKEditorHelp("End Phase", "The phase of the combatant's faction will end after this action - " +
			"combatants who didn't chose an action yet will not be able to do so.\n" +
			"Only used in 'Phase' battles.", "")]
		[ORKEditorInfo(separator=true)]
		public bool endPhase = false;

		[ORKEditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		public bool blockBattleCamera = false;

		[ORKEditorHelp("Force Found Targets", "The action will only have the found targets available.\n" +
			"It can't fall back to other targets based on the combatant's AI settings if none of the targets is in range.", "")]
		public bool forceFoundTargets = false;

		[ORKEditorHelp("Need Targets", "Valid targets must be found within use range, otherwise the ability wont be used.", "")]
		public bool needTargets = false;

		public ShortcutSlotStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			BaseAction action = null;
			Combatant owner = null;
			IShortcut shortcut = this.slot.GetShortcut(call.user, out owner);
			bool setTargets = false;

			// get action
			if(call.user == owner &&
				shortcut != null)
			{
				// ability
				if(shortcut is AbilityShortcut)
				{
					AbilityShortcut ability = (AbilityShortcut)shortcut;
					if(AbilityActionType.BaseAttack == ability.Type ||
						AbilityActionType.CounterAttack == ability.Type)
					{
						if(!call.user.Status.Effects.BlockAttack)
						{
							action = BaseAction.CreateAbility(call.user, ability, -2);
						}
					}
					else if(AbilityActionType.Ability == ability.Type)
					{
						if(!call.user.Status.Effects.BlockAbilities)
						{
							action = BaseAction.CreateAbility(call.user, ability, ability.GetLevel());
						}
					}
					setTargets = true;
				}
				// item
				else if(shortcut is ItemShortcut)
				{
					if(!call.user.Status.Effects.BlockItems)
					{
						action = new ItemAction(call.user, (ItemShortcut)shortcut);
					}
					setTargets = true;
				}
				// defend
				else if(shortcut is DefendShortcut)
				{
					if(!call.user.Status.Effects.BlockDefend)
					{
						action = new DefendAction(call.user);
					}
				}
				// escape
				else if(shortcut is EscapeShortcut)
				{
					if(!call.user.Status.Effects.BlockEscape)
					{
						action = new EscapeAction(call.user);
					}
				}
				// none
				else if(shortcut is NoneShortcut)
				{
					action = new NoneAction(call.user, false);
				}
				// grid move
				else if(shortcut is GridMoveShortcut)
				{
					GridMoveAction tmpAction = null;
					GridMoveShortcut gridMove = (GridMoveShortcut)shortcut;
					if(gridMove.gridMove.GetMoveAction(call.user,
						BattleAI.GetPreferredTargets(call.user, call.foundTargets), call.allies, call.enemies,
						out tmpAction, null))
					{
						action = tmpAction;
					}
				}
				// grid orientation
				else if(shortcut is GridOrientationShortcut)
				{
					((GridOrientationShortcut)shortcut).Use(call.user,
						BattleAI.GetPreferredTargets(call.user, call.foundTargets), false);
				}
			}

			// check AI blocks
			if(!call.user.AI.CanUseAction(action))
			{
				action = null;
			}

			// check active time
			if(action != null)
			{
				if(setTargets)
				{
					action.forceFoundTargets = this.forceFoundTargets;
					bool targetsFound = call.user.AI.SetActionTargets(action,
						BattleAI.GetPreferredTargets(call.user, call.foundTargets), call.allies, call.enemies);

					if((this.needTargets && !targetsFound) ||
						(ORK.Battle.IsActiveTime() &&
						(call.user.Battle.UsedActionBar + action.ActionCost) > ORK.Battle.Settings.activeTime.maxTimebar))
					{
						action = null;
					}
				}
			}

			if(action != null)
			{
				action.endPhaseFlag = this.endPhase;
				action.blockBattleCamera = this.blockBattleCamera;
			}

			currentStep = this.next;
			return action;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.slot.GetInfoText() + (this.endPhase ? ", Ends Phase" : "");
		}
	}
}
