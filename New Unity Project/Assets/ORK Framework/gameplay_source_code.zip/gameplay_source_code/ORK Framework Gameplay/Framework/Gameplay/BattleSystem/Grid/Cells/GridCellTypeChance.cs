﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridCellTypeChance : BaseData
	{
		[ORKEditorHelp("Cell Type", "Select the grid cell type that will be used.", "")]
		[ORKEditorInfo(ORKDataType.BattleGridCellType)]
		public int cellType = 0;

		[ORKEditorHelp("Chance (%)", "The chance that this grid cell type will be used.", "")]
		public float chance = 0;

		public GridCellTypeChance()
		{

		}
	}
}
