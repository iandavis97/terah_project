﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class InteractionSettings : BaseData
	{
		// interaction settings
		[ORKEditorHelp("Interact Key", "The key used to start interactions.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int interactKey = 3;

		[ORKEditorHelp("Max Event Steps", "The maximum number of event steps executed without an update cycle.\n" +
			"This setting influences how fast game/battle event steps (without a wait time) will execute after the previous step - " +
			"the lower the number, the slower the event execution.\n" +
			"Reduce this number if you experience stack overflow errors in events.", "")]
		[ORKEditorLimit(0, false)]
		public int maxSteps = 100;


		// click interaction
		[ORKEditorHelp("Max Click Distance", "The maximum distance in world units to allow " +
			"starting an 'Interaction' type interaction by clicking/touching the game object.\n" +
			"Set to 0 to not allow clicking.\n\n" +
			"Set to -1 to allow clicking without checking the distance." +
			"This setting can be overridden by the individual interactions.", "")]
		[ORKEditorLimit(-1.0f, false)]
		[ORKEditorInfo(separator=true, labelText="Click Interaction")]
		public float maxClickDistance = 3;

		[ORKEditorHelp("Layer Mask", "Select the layer the click interactions will use.\n" +
			"Only objects on this layer can be hit by the raycast.", "")]
		public LayerMask clickLayerMask = -1;

		[ORKEditorHelp("Distance", "The distance the raycast will use (from the camera).", "")]
		public float clickRayDistance = 100.0f;


		// interaction controller
		[ORKEditorHelp("Add Automatically", "The interaction controller is automatically added to the player." +
			"If disabled, you need to manually add an interaction controller to the prefab of the player.", "")]
		[ORKEditorInfo(separator=true, labelText="Interaction Controller")]
		public bool addIC = false;

		[ORKEditorHelp("IC Prefab", "The prefab used as interaction controller.", "")]
		[ORKEditorLayout("addIC", true, autoInit=true)]
		public AssetSource<GameObject> icPrefab;

		[ORKEditorLayout(endCheckGroup=true)]
		public MountSettings icMount = new MountSettings();


		// move to interaction
		[ORKEditorInfo("Move To Interaction", "The player can optionally move to an interaction " +
			"(e.g. event interaction, item collector) before starting the interaction.", "", endFoldout=true)]
		public MoveToInteractionSettings moveToInteraction = new MoveToInteractionSettings();

		public InteractionSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(!data.Contains<int>("interactKey"))
			{
				this.interactKey = -1;
			}
			if(this.addIC &&
				data.Contains<GameObject>("icPrefab"))
			{
				this.icPrefab = new AssetSource<GameObject>();
				this.icPrefab.Upgrade(data, "icPrefab");
			}
		}

		public void AddInteractionController(GameObject player)
		{
			if(this.addIC &&
				player != null &&
				this.icPrefab != null &&
				player.GetComponentInChildren<InteractionController>() == null)
			{
				GameObject prefab = this.icPrefab;
				if(prefab != null)
				{
					GameObject ic = UnityWrapper.Instantiate(prefab);
					if(ic != null)
					{
						this.icMount.MountTo(player.transform, ic.transform);
					}
				}
			}
		}

		public void RemoveInteractionController(GameObject player)
		{
			if(this.addIC &&
				player != null &&
				this.icPrefab != null)
			{
				GameObject prefab = this.icPrefab;
				if(prefab != null)
				{
					InteractionController ic = player.GetComponentInChildren<InteractionController>();
					if(ic != null)
					{
						UnityWrapper.Destroy(ic.gameObject);
					}
				}
			}
		}
	}
}
