﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridCellAreaSettings : BaseData
	{
		[ORKEditorHelp("Range Type", "Select which cells around the origin cell will be used:\n" +
			"- Distance: Cells defined by a grid distance.\n" +
			"- Battle Range Template: Cells defined by a battle range template.\n" +
			"- Custom: A custom grid shape.", "")]
		public AIGridMoveRangeType type = AIGridMoveRangeType.Distance;


		// distance
		[ORKEditorHelp("Minimum Distance", "Define the minimum distance around the origin cell.\n" +
			"The minimum distance is 1 (i.e. the cells around the origin cell).", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("type", AIGridMoveRangeType.Distance)]
		public int minDistance = 0;

		[ORKEditorHelp("Maximum Distance", "Define the maximum distance around the origin cell.\n" +
			"The minimum distance is 1 (i.e. the cells around the origin cell).", "")]
		[ORKEditorLimit("minDistance", false)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int maxDistance = 0;


		// battle range template
		[ORKEditorHelp("Battle Range Template", "Select the battle range template that will be used.", "")]
		[ORKEditorInfo(ORKDataType.BattleRangeTemplate)]
		[ORKEditorLayout("type", AIGridMoveRangeType.BattleRangeTemplate, endCheckGroup=true)]
		public int templateID = 0;


		// custom
		[ORKEditorLayout("type", AIGridMoveRangeType.Custom, endCheckGroup=true, autoInit=true)]
		public GridRangeSetting gridRange;


		// in-game
		private BattleRangeTemplate templateSettings;

		public GridCellAreaSettings()
		{

		}

		public GridCellAreaSettings(int distance, bool isRing)
		{
			if(isRing)
			{
				this.type = AIGridMoveRangeType.Custom;
				this.gridRange = new GridRangeSetting();
				this.gridRange.gridShapeType = GridShapeType.Ring;
				this.gridRange.gridRange = distance;
			}
			else
			{
				this.minDistance = distance;
				this.maxDistance = distance;
			}
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("distance"))
			{
				data.Get("distance", ref this.maxDistance);
			}
		}

		public BattleRangeTemplate TemplateSettings
		{
			get
			{
				if(this.templateSettings == null)
				{
					this.templateSettings = ORK.BattleRangeTemplates.Get(this.templateID);
				}
				return this.templateSettings;
			}
		}

		public bool InLocalSpace
		{
			get
			{
				if(AIGridMoveRangeType.BattleRangeTemplate == this.type)
				{
					return this.TemplateSettings.range.gridSettings.InLocalSpace;
				}
				else if(AIGridMoveRangeType.Custom == this.type)
				{
					return this.gridRange.InLocalSpace;
				}
				return false;
			}
		}


		/*
		============================================================================
		Cell functions
		============================================================================
		*/
		public void GetCells(Combatant user, BattleGridCellComponent origin, int direction,
			GridCellCheck check, bool allowSquareDiagonal, ref List<BattleGridCellComponent> list)
		{
			if(AIGridMoveRangeType.Distance == this.type)
			{
				HashSet<BattleGridCellComponent> contains = new HashSet<BattleGridCellComponent>();
				BattleGridHelper.GetRange(origin, this.minDistance, this.maxDistance, ref list, ref contains,
					false, false, false, allowSquareDiagonal, check);
			}
			else if(AIGridMoveRangeType.BattleRangeTemplate == this.type)
			{
				this.TemplateSettings.range.gridSettings.GetCells(
					user, origin, direction, ref list, check);
			}
			else if(AIGridMoveRangeType.Custom == this.type)
			{
				this.gridRange.GetCells(user, origin, direction, ref list, check);
			}
		}

		public void GetCells(Combatant user, int direction,
			GridCellCheck check, bool allowSquareDiagonal, ref List<BattleGridCellComponent> list)
		{
			if(AIGridMoveRangeType.Distance == this.type)
			{
				HashSet<BattleGridCellComponent> contains = new HashSet<BattleGridCellComponent>();
				BattleGridHelper.GetRange(user, this.minDistance, this.maxDistance,
					ref list, ref contains, allowSquareDiagonal,
					delegate (Combatant tmpUser, BattleGridCellComponent origin, BattleGridCellComponent cell)
					{
						return cell != null &&
							origin != cell &&
							cell.IsPassable &&
							(check == null || check(cell));
					});
			}
			else if(AIGridMoveRangeType.BattleRangeTemplate == this.type)
			{
				this.TemplateSettings.range.gridSettings.GetCells(
					user, user, direction, ref list, check);
			}
			else if(AIGridMoveRangeType.Custom == this.type)
			{
				this.gridRange.GetCells(user, user, direction, ref list, check);
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool CheckSizeCells(Combatant user, BattleGridCellComponent origin, int direction, GridCellCheck check)
		{
			if(AIGridMoveRangeType.Distance == this.type)
			{
				return BattleGridHelper.CheckRange(origin, this.minDistance, this.maxDistance,
					false, false, false, true, check);
			}
			else if(AIGridMoveRangeType.BattleRangeTemplate == this.type)
			{
				return this.TemplateSettings.range.gridSettings.CheckSizeCells(
					user, origin, direction, check);
			}
			else if(AIGridMoveRangeType.Custom == this.type)
			{
				return this.gridRange.CheckSizeCells(user, origin, direction, check);
			}
			return false;
		}
	}
}
