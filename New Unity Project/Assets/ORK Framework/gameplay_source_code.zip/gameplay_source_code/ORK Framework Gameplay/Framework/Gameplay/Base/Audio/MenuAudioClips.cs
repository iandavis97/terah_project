
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class MenuAudioClips : BaseData
	{
		// cursor move
		[ORKEditorHelp("Cursor Move", "Played when keys/buttons are used to change the menu/dialogue selection.", "")]
		[ORKEditorInfo(labelText="Cursor Move")]
		public AudioClip cursorMoveAudio;
		
		[ORKEditorHelp("Cursor Move Volume", "The volume (0-1) used to play the cursor move clip.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float cursorMoveVolume = 1.0f;
		
		
		// accept
		[ORKEditorHelp("Accept", "Played when a choice is accepted (e.g. battle menu, dialogue).", "")]
		[ORKEditorInfo(separator=true, labelText="Accept")]
		public AudioClip acceptAudio;
		
		[ORKEditorHelp("Accept Volume", "The volume (0-1) used to play the accept clip.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float acceptVolume = 1.0f;
		
		
		// cancel
		[ORKEditorHelp("Cancel", "Played when a selection is canceled (e.g. cancel the target selection in battles).", "")]
		[ORKEditorInfo(separator=true, labelText="Cancel")]
		public AudioClip cancelAudio;
		
		[ORKEditorHelp("Cancel Volume", "The volume (0-1) used to play the cancel clip.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float cancelVolume = 1.0f;
		
		
		// fail
		[ORKEditorHelp("Fail", "Played when a selection can't be made (e.g. an ability can't be used).", "")]
		[ORKEditorInfo(separator=true, labelText="Fail")]
		public AudioClip failAudio;
		
		[ORKEditorHelp("Fail Volume", "The volume (0-1) used to play the fail clip.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float failVolume = 1.0f;
		
		
		// ability level change
		[ORKEditorHelp("Ability Level", "Played when ability levels are changed by using the ability level plus/minus keys.", "")]
		[ORKEditorInfo(separator=true, labelText="Ability Level Change")]
		public AudioClip abilityLevelAudio;
		
		[ORKEditorHelp("Ability Level Volume", "The volume (0-1) used to play the ability level clip.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float abilityLevelVolume = 1.0f;
		
		
		// user change
		[ORKEditorHelp("Change User", "Played when changing the user (combatant) of menus (e.g. ability menu, battle menu).", "")]
		[ORKEditorInfo(separator=true, labelText="User Change")]
		public AudioClip userChangeAudio;
		
		[ORKEditorHelp("User Change Volume", "The volume (0-1) used to play the user change clip.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float useChangeVolume = 1.0f;
		
		
		// input
		[ORKEditorHelp("Value Input", "Played when the player changes a value input (e.g. options menu, value input dialogue).", "")]
		[ORKEditorInfo(separator=true, labelText="Value Input Change")]
		public AudioClip valueInputAudio;
		
		[ORKEditorHelp("Value Input Volume", "The volume (0-1) used to play the value input clip.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float valueInputVolume = 1.0f;
		
		[ORKEditorHelp("Value Input Timeout", "The time in seconds between playing the value input clip twice.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float valueInputInterval = 0.5f;
		
		
		// ingame
		private float valueInputTime = 0;
		
		public MenuAudioClips()
		{
			
		}
		
		
		/*
		============================================================================
		Audio functions
		============================================================================
		*/
		public void Play(GUIBoxAudioType type)
		{
			if(GUIBoxAudioType.Cursor == type)
			{
				this.PlayCursorMove();
			}
			else if(GUIBoxAudioType.Accept == type)
			{
				this.PlayAccept();
			}
			else if(GUIBoxAudioType.Cancel == type)
			{
				this.PlayCancel();
			}
			else if(GUIBoxAudioType.Fail == type)
			{
				this.PlayFail();
			}
			else if(GUIBoxAudioType.AbilityLevel == type)
			{
				this.PlayAbilityLevel();
			}
			else if(GUIBoxAudioType.ChangeUser == type)
			{
				this.PlayUserChange();
			}
			else if(GUIBoxAudioType.ValueInput == type)
			{
				this.PlayValueInput();
			}
		}

		public void PlayCursorMove()
		{
			if(this.cursorMoveAudio != null && 
				ORK.Audio != null)
			{
				ORK.Audio.PlayOneShot(this.cursorMoveAudio, 
					this.cursorMoveVolume * ORK.Game.SoundVolume);
			}
		}
		
		public void PlayAccept()
		{
			if(this.acceptAudio != null && 
				ORK.Audio != null)
			{
				ORK.Audio.PlayOneShot(this.acceptAudio, 
					this.acceptVolume * ORK.Game.SoundVolume);
			}
		}
		
		public void PlayCancel()
		{
			if(this.cancelAudio != null && 
				ORK.Audio != null)
			{
				ORK.Audio.PlayOneShot(this.cancelAudio, 
					this.cancelVolume * ORK.Game.SoundVolume);
			}
		}
		
		public void PlayFail()
		{
			if(this.failAudio != null && 
				ORK.Audio != null)
			{
				ORK.Audio.PlayOneShot(this.failAudio, 
					this.failVolume * ORK.Game.SoundVolume);
			}
		}
		
		public void PlayAbilityLevel()
		{
			if(this.abilityLevelAudio != null && 
				ORK.Audio != null)
			{
				ORK.Audio.PlayOneShot(this.abilityLevelAudio, 
					this.abilityLevelVolume * ORK.Game.SoundVolume);
			}
		}
		
		public void PlayUserChange()
		{
			if(this.userChangeAudio != null && 
				ORK.Audio != null)
			{
				ORK.Audio.PlayOneShot(this.userChangeAudio, 
					this.useChangeVolume * ORK.Game.SoundVolume);
			}
		}
		
		public void PlayValueInput()
		{
			if(this.valueInputAudio != null && 
				ORK.Audio != null && 
				this.valueInputTime + this.valueInputInterval < Time.realtimeSinceStartup)
			{
				ORK.Audio.PlayOneShot(this.valueInputAudio, 
					this.valueInputVolume * ORK.Game.SoundVolume);
				this.valueInputTime = Time.realtimeSinceStartup;
			}
		}
	}
}
