﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AIRuleBlockItem : BaseData
	{
		// items
		[ORKEditorHelp("Block All Items", "All items are blocked, except for the defined items.\n" +
			"If disabled, all items are allowed, except for the defined items.", "")]
		[ORKEditorInfo("Block Items", "Define items that will be blocked from use for the battle AI.\n" +
			"The combatant can still use the items (e.g. if the player manually uses them), only the AI can't use them.", "")]
		public bool blockAllItems = false;

		[ORKEditorHelp("Block Item Use", "Select the item that will be blocked from using.", "")]
		[ORKEditorInfo(ORKDataType.Item, endFoldout=true, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Item Block", "Adds an item that will be blocked from using.", "",
			"Remove", "Removes the blocked item.", "", isHorizontal=true)]
		public int[] itemID = new int[0];


		// item types
		[ORKEditorHelp("Block All Types", "All item types are blocked, except for the defined types.\n" +
			"If disabled, all item types are allowed, except for the defined types.", "")]
		[ORKEditorInfo("Block Item Types", "Define item types that will be blocked from use for the battle AI, " +
			"items of the blocked types will be blocked from use.\n" +
			"The combatant can still use the items (e.g. if the player manually uses them), only the AI can't use them.", "")]
		public bool blockAllItemTypes = false;

		[ORKEditorHelp("Block Item Type Use", "Select the item type that will be blocked.\n" +
			"A combatant can't use any item of the selected type.", "")]
		[ORKEditorInfo(ORKDataType.ItemType, endFoldout=true, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Item Type Block", "Adds an item type that will be blocked from using.", "",
			"Remove", "Removes the blocked item type.", "", isHorizontal=true)]
		public int[] itemTypeID = new int[0];

		public AIRuleBlockItem()
		{

		}

		public bool CanUse(int itemID)
		{
			// blocked items
			if(this.blockAllItems)
			{
				for(int i = 0; i < this.itemID.Length; i++)
				{
					if(this.itemID[i] == itemID)
					{
						return true;
					}
				}
				return false;
			}
			else
			{
				for(int i = 0; i < this.itemID.Length; i++)
				{
					if(this.itemID[i] == itemID)
					{
						return false;
					}
				}
			}

			// blocked item types
			int typeID = ORK.Items.Get(itemID).itemType;
			if(this.blockAllItemTypes)
			{
				for(int i = 0; i < this.itemTypeID.Length; i++)
				{
					if(this.itemTypeID[i] == typeID)
					{
						return true;
					}
				}
				return false;
			}
			else
			{
				for(int i = 0; i < this.itemTypeID.Length; i++)
				{
					if(this.itemTypeID[i] == typeID)
					{
						return false;
					}
				}
			}
			return true;
		}
	}
}
