﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class AxisControl : BaseData
	{
		[ORKEditorHelp("Use Axis", "Use an input key as an axis.\n" +
			"Enable this setting if you want to e.g. use a mouse wheel or a set up input key axis.\n" +
			"If disabled, you can define independent plus and minus input keys.", "")]
		public bool useAxis = false;

		// axis
		[ORKEditorHelp("Axis Key", "Select the input key (used as axis) that will be used.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("useAxis", true)]
		public int axisKey = 0;


		// separate
		[ORKEditorHelp("Plus Key", "Select the input key used as plus/positive key.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout(elseCheckGroup=true)]
		public int plusKey = 0;

		[ORKEditorHelp("Minus Key", "Select the input key used as minus/negative key.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int minusKey = 0;
		
		// audio settings
		[ORKEditorHelp("Audio Clip", "Select the audio clip that will be played when using the input keys.", "")]
		public AudioClip audioClip;

		[ORKEditorHelp("Volume", "The volume used to play the audio clip (between 0 and 1).", "")]
		[ORKEditorLayout("audioClip", null, elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float volume = 1;

		public AxisControl()
		{

		}

		public bool GetButton()
		{
			if(this.useAxis)
			{
				return ORK.InputKeys.Get(this.axisKey).GetButton();
			}
			else
			{
				return ORK.InputKeys.Get(this.plusKey).GetButton() ||
					ORK.InputKeys.Get(this.minusKey).GetButton();
			}
		}

		public float GetAxis(bool negatePlusMinus)
		{
			if(this.useAxis)
			{
				return ORK.InputKeys.Get(this.axisKey).GetAxis();
			}
			else
			{
				if(ORK.InputKeys.Get(this.plusKey).GetButton())
				{
					this.PlayClip();
					return negatePlusMinus ?
						ORK.InputKeys.Get(this.plusKey).GetAxis() * -1 :
						ORK.InputKeys.Get(this.plusKey).GetAxis();
				}
				else if(ORK.InputKeys.Get(this.minusKey).GetButton())
				{
					this.PlayClip();
					return negatePlusMinus ?
						ORK.InputKeys.Get(this.minusKey).GetAxis() :
						ORK.InputKeys.Get(this.minusKey).GetAxis() * -1;
				}
			}
			return 0;
		}

		public void PlayClip()
		{
			if(this.audioClip != null)
			{
				ORK.Audio.PlayOneShot(this.audioClip, this.volume * ORK.Game.SoundVolume);
			}
		}
	}
}
