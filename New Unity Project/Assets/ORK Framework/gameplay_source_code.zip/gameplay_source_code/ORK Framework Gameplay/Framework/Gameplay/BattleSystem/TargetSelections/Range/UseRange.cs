﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class UseRange : BaseData
	{
		[ORKEditorHelp("Range Type", "Select which range will be used:\n" +
			"- None: No range restriction.\n" +
			"- Template: The range defined in a battle range template.\n" +
			"- Custom: A custom range defined here.", "")]
		public BattleRangeType type = BattleRangeType.None;


		// template
		[ORKEditorHelp("Template", "Select the template that will be used.", "")]
		[ORKEditorInfo(ORKDataType.BattleRangeTemplate)]
		[ORKEditorLayout("type", BattleRangeType.Template, endCheckGroup=true)]
		public int templateID = 0;


		// custom
		[ORKEditorInfo(instanceCallback="button:CustomBattleRangeToTemplate")]
		[ORKEditorLayout("type", BattleRangeType.Custom, endCheckGroup=true, autoInit=true)]
		public BattleRangeSetting custom;

		public UseRange()
		{

		}


		/*
		============================================================================
		Range functions
		============================================================================
		*/
		public bool InRange(Combatant user, Combatant target)
		{
			if(BattleRangeType.Template == this.type)
			{
				return ORK.BattleRangeTemplates.Get(this.templateID).range.InRange(user, target);
			}
			else if(BattleRangeType.Custom == this.type)
			{
				return this.custom.InRange(user, target);
			}
			return true;
		}

		public bool InRange(Combatant user, Vector3 position)
		{
			if(BattleRangeType.Template == this.type)
			{
				return ORK.BattleRangeTemplates.Get(this.templateID).range.InRange(user, position);
			}
			else if(BattleRangeType.Custom == this.type)
			{
				return this.custom.InRange(user, position);
			}
			return true;
		}

		public bool InRange(Combatant user, BattleGridCellComponent target)
		{
			if(BattleRangeType.Template == this.type)
			{
				return ORK.BattleRangeTemplates.Get(this.templateID).range.InRange(user, target);
			}
			else if(BattleRangeType.Custom == this.type)
			{
				return this.custom.InRange(user, target);
			}
			return true;
		}

		public List<Combatant> GetTargets(Combatant user, Consider isEnemy, Consider isDead, Consider inBattle)
		{
			if(BattleRangeType.Template == this.type)
			{
				return ORK.BattleRangeTemplates.Get(this.templateID).range.GetTargets(user, isEnemy, isDead, inBattle);
			}
			else if(BattleRangeType.Custom == this.type)
			{
				return this.custom.GetTargets(user, isEnemy, isDead, inBattle);
			}
			return ORK.Game.Combatants.Get(user, true, Range.Battle, isEnemy, isDead, inBattle, null);
		}


		/*
		============================================================================
		Cell functions
		============================================================================
		*/
		public List<BattleGridCellComponent> GetCells(Combatant user, BattleGridCellComponent origin, GridCellCheck check)
		{
			List<BattleGridCellComponent> list = new List<BattleGridCellComponent>();
			this.GetCells(user, origin, ref list, check);
			return list;
		}

		public void GetCells(Combatant user, BattleGridCellComponent origin,
			ref List<BattleGridCellComponent> list, GridCellCheck check)
		{
			if(BattleRangeType.Template == this.type)
			{
				ORK.BattleRangeTemplates.Get(this.templateID).range.GetCells(user, origin, ref list, check);
			}
			else if(BattleRangeType.Custom == this.type)
			{
				this.custom.GetCells(user, origin, ref list, check);
			}
		}


		/*
		============================================================================
		Move AI functions
		============================================================================
		*/
		public Range GetMoveAIUseRange()
		{
			if(BattleRangeType.Template == this.type)
			{
				return ORK.BattleRangeTemplates.Get(this.templateID).range.GetMoveAIUseRange();
			}
			else if(BattleRangeType.Custom == this.type)
			{
				return this.custom.GetMoveAIUseRange();
			}
			return null;
		}

		public bool CanMoveIntoRange()
		{
			if(BattleRangeType.Template == this.type)
			{
				return ORK.BattleRangeTemplates.Get(this.templateID).range.moveAIMoveIntoRange;
			}
			else if(BattleRangeType.Custom == this.type)
			{
				return this.custom.moveAIMoveIntoRange;
			}
			return false;
		}

		public void MoveIntoRange(ref bool moveIntoRange, ref bool useStopAngle)
		{
			if(BattleRangeType.Template == this.type)
			{
				moveIntoRange = ORK.BattleRangeTemplates.Get(this.templateID).range.moveAIMoveIntoRange;
				useStopAngle = ORK.BattleRangeTemplates.Get(this.templateID).range.moveAIUseStopAngle;
			}
			else if(BattleRangeType.Custom == this.type)
			{
				moveIntoRange = this.custom.moveAIMoveIntoRange;
				useStopAngle = this.custom.moveAIUseStopAngle;
			}
		}
	}
}
