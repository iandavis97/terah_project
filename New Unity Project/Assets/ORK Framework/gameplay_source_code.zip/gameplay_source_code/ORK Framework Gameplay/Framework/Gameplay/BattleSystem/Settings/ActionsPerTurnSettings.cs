﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ActionsPerTurnSettings : BaseData
	{
		// actions per turn
		[ORKEditorInfo("Actions Per Turn", "The number of actions a combatant can perform each turn.\n" +
			"This is used as a float value, i.e. you can also use 0.5 actions for an action.\n" +
			"As long as a combatant has more than 0 actions per turn left, he will be able to perform actions.", "")]
		public FloatValue actionsPerTurn = new FloatValue(1);

		[ORKEditorHelp("Add Count", "The actions per turn will be added to the combatant's previous actions per turn, " +
			"i.e. unused actions per turn can be saved for the next turn.\n" +
			"If disabled, the actions per turn will be set each turn, i.e. unused actions per turn will be lost.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool addActionsPerTurn = false;


		// default action cost
		[ORKEditorInfo("Default Action Cost", "The default cost of an action (e.g. using an ability/item, defend, etc.).\n" +
			"This can be overridden by the individual actions.", "", endFoldout=true)]
		public ActionCost defaultActionCostSetting = new ActionCost();


		// default ability cost
		[ORKEditorHelp("Own Ability Cost", "Abilities use their own action cost, overriding the default action cost.\n" +
			"Individual abilities can also override the default/ability action cost.", "")]
		[ORKEditorInfo("Default Ability Cost", "The default cost for using an ability.\n" +
			"This can be overridden by the individual abilities.", "")]
		public bool ownAbilityCost = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownAbilityCost", true, endCheckGroup=true, autoInit=true)]
		public ActionCost defaultAbilityCostSetting;


		// default item cost
		[ORKEditorHelp("Own Item Cost", "Items use their own action cost, overriding the default action cost.\n" +
			"Individual items can also override the default/item action cost.", "")]
		[ORKEditorInfo("Default Item Cost", "The default cost for using an item.\n" +
			"This can be overridden by the individual items.", "")]
		public bool ownItemCost = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownItemCost", true, endCheckGroup=true, autoInit=true)]
		public ActionCost defaultItemCostSetting;


		// defend cost
		[ORKEditorHelp("Own Defend Cost", "The defend command uses its own action cost, overriding the default action cost.", "")]
		[ORKEditorInfo("Defend Cost", "The action cost for using the defend command.", "")]
		public bool ownDefendCost = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownDefendCost", true, endCheckGroup=true, autoInit=true)]
		public ActionCost defendCostSetting;


		// escape cost
		[ORKEditorHelp("Own Escape Cost", "The escape command uses its own action cost, overriding the default action cost.", "")]
		[ORKEditorInfo("Escape Cost", "The action cost for using the escape command.", "")]
		public bool ownEscapeCost = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownEscapeCost", true, endCheckGroup=true, autoInit=true)]
		public ActionCost escapeCostSetting;


		// none cost
		[ORKEditorHelp("Own None Cost", "A 'None' action (end turn) uses its own action cost, overriding the default action cost.\n" +
			"Please note that a 'None' actions ends the turn of the combatant in any case.", "")]
		[ORKEditorInfo("None Cost", "The action cost for using a 'None' action.", "")]
		public bool ownNoneCost = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownNoneCost", true, endCheckGroup=true, autoInit=true)]
		public ActionCost noneCostSetting;


		// change member cost
		[ORKEditorHelp("Own Change Cost", "Changing a battle member uses its own action cost, overriding the default action cost.", "")]
		[ORKEditorInfo("Change Member Cost", "The action cost for changing a battle member.", "")]
		public bool ownChangeMemberCost = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownChangeMemberCost", true, endCheckGroup=true, autoInit=true)]
		public ActionCost changeMemberCostSetting;


		// grid move cost
		[ORKEditorHelp("Own Grid Move Cost", "A 'Grid Move' action uses its own action cost, overriding the default action cost.", "")]
		[ORKEditorInfo("Grid Move Cost", "The action cost for using a 'Grid Move' action.", "")]
		public bool ownGridMoveCost = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownGridMoveCost", true, endCheckGroup=true, autoInit=true)]
		public ActionCost gridMoveCostSetting;

		public ActionsPerTurnSettings()
		{

		}

		public void SetActionsPerTurn(Combatant combatant)
		{
			if(combatant != null)
			{
				if(this.addActionsPerTurn)
				{
					combatant.Battle.ActionBar += this.actionsPerTurn.GetValue(combatant, combatant);
				}
				else
				{
					combatant.Battle.ActionBar = this.actionsPerTurn.GetValue(combatant, combatant);
				}
				combatant.Battle.UsedActionBar = 0;
				combatant.Battle.MaxActionBar = combatant.Battle.ActionBar;
				combatant.Battle.ReceiveActionsPerTurn = false;
			}
		}
	}
}
