﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridOrientationSelectionSettings : BaseData
	{
		[ORKEditorHelp("Only Neighbour Cells", "The orientation cell selection only uses cells that are neighbours of the combatant's cell.\n" +
			"If disabled, any cell can be selected for the orientation.", "")]
		public bool onlyNeighbourCells = true;

		[ORKEditorHelp("Block Action Use", "Using actions is blocked for the combatant during the grid cell selection.", "")]
		public bool blockActionUse = false;

		[ORKEditorHelp("Rotate On Selection", "The combatant will rotate to the selected cell before accepting it.", "")]
		public bool rotateOnSelection = true;

		[ORKEditorHelp("Block Diagonal Rotation", "Diagonal cells in square grids will be ignored " +
			"(when 'Diagonal Distance 1' is enabled in the grid settings).\n" +
			"The combatant won't rotate to a diagonal direction (square grids).", "")]
		public bool blockDiagonalRotation = false;

		[ORKEditorHelp("Examine Cell", "Display the cell info text for the selected cell ('Examine Grid' settings).", "")]
		public bool examineCell = false;

		[ORKEditorHelp("Examine Cell Combatant", "Display the combatant info dialogue for the selected cell's combatant ('Examine Grid' settings).\n" +
			"Please note that this only shows the information dialogue and " +
			"doesn't show cell highlights (e.g. move range of a combatant).", "")]
		public bool examineCellCombatant = false;


		// camera control target
		[ORKEditorHelp("Camera Control Target", "Changes the camera control target to the selected cell.\n" +
			"The camera control must descent from the 'BaseCameraControl' class (like all built-in camera controls).\n" +
			"When using 'Only Neighbour Cells', the selecting combatant's cell will be the camera control target.", "")]
		[ORKEditorInfo("Camera Control Target", "Optionally change the camera control target to the selected cell.\n" +
			"The camera control must descent from the 'BaseCameraControl' class (like all built-in camera controls).\n" +
			"When using 'Only Neighbour Cells', the selecting combatant's cell will be the camera control target.", "")]
		public bool cameraControlTarget = false;

		[ORKEditorHelp("Own Transition", "Use a custom camera control transition when changing the camera control target.\n" +
			"If disabled, the default transition defined in 'Base/Control > Game Controls' will be used.", "")]
		[ORKEditorLayout("cameraControlTarget", true)]
		public bool ownControlTargetTransition = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownControlTargetTransition", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public CameraControlTargetTransition controlTargetTransition;


		// info text
		[ORKEditorHelp("Show Info Text", "An info text will be displayed while selecting a target cell for the move command.", "")]
		[ORKEditorInfo("Info Text", "Optionally display an info text box while the player selects a target cell for the move command.", "")]
		public bool showInfo = false;

		[ORKEditorInfo(separator=true, endFoldout=true, label=new string[] {
			"%un = user name, %ud = user description, %ui = user icon"
		})]
		[ORKEditorLayout("showInfo", true, endCheckGroup=true, autoInit=true)]
		public InfoBoxChoice info;


		// accept dialogue
		[ORKEditorHelp("Show Accept Question", "A question dialogue will be displayed when a cell was accepted.\n" +
			"If the player accepts the question, the cell will be used, otherwise the cell selection will be resumed.", "")]
		[ORKEditorInfo("Accept Question Dialogue", "Optionally display an accept question dialogue to ask " +
			"if the player wants to use the accepted cell.", "")]
		public bool showAcceptQuestion = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("showAcceptQuestion", true, endCheckGroup=true, autoInit=true)]
		public QuestionChoice acceptQuestion;


		// own cell selection
		[ORKEditorHelp("Own Cell Selection", "The orientation selection uses a different cell selection setup.\n" +
			"If disabled, the cell selection will be used.", "")]
		[ORKEditorInfo("Cell Selection", "The orientation selection can optionally override the cell selection settings.", "")]
		public bool ownCellSelection = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownCellSelection", true, endCheckGroup=true, autoInit=true)]
		public GridCellSelectionSettings selection;


		// in-game
		private NotifyBool notify;

		private Vector3 startRotation = Vector3.zero;

		private GameObject previousCameraControlTarget;


		// selection
		private bool canSelect = true;

		private bool canCancel = true;

		private bool isSelecting = false;

		private int selectedDirection = -1;

		private SelectGridCellBool selectCellFunction;

		private SelectGridCell acceptCellFunction;

		private GridCellCheck acceptCheckFunction;

		private SelectGridDirection selectDirectionFunction;

		public GridOrientationSelectionSettings()
		{

		}

		public void Clear()
		{
			this.CloseInfoBox();
			this.StopHighlights();
			ORK.Control.Cursor.RemoveCursor(CursorType.GridOrientationSelection);

			if(this.isSelecting)
			{
				if(this.blockActionUse &&
					ORK.Battle.SystemSettings.gridSettings.SelectingCombatant != null)
				{
					ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Actions.BlockActionUse = false;
				}
				this.isSelecting = false;
			}

			this.canSelect = true;
			this.selectedDirection = -1;
			this.previousCameraControlTarget = null;
		}


		/*
		============================================================================
		GUI box functions
		============================================================================
		*/
		private string InfoReplace(string text)
		{
			return text.
				Replace("%un", ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.GetName()).
				Replace("%ud", ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.GetDescription()).
				Replace("%ui", ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.GetIconTextCode());
		}

		private void ShowInfoBox()
		{
			if(this.showInfo)
			{
				string tmpTitle = this.info.useTitle ?
					this.InfoReplace(this.info.title[ORK.Game.Language]) : "";
				string tmpText = this.InfoReplace(this.info.infoText[ORK.Game.Language]);

				this.info.Show(tmpTitle, tmpText, null);
			}
		}

		private void CloseInfoBox()
		{
			if(this.showInfo)
			{
				this.info.Close();
			}
		}


		/*
		============================================================================
		Move selection functions
		============================================================================
		*/
		public void Start(Combatant combatant, GridOrientationShortcut gridOrientationShortcut,
			NotifyBool notify, bool canCancel)
		{
			ORK.Battle.SystemSettings.gridSettings.InitSelection(GridSelectionType.Orientation, combatant);
			this.canCancel = canCancel;
			this.previousCameraControlTarget = ORK.Control.CameraControlTarget;

			this.notify = notify == null && combatant.Battle.BattleMenu.IsOpen ?
				combatant.Battle.BattleMenu.EndGridOrientationSelectionClose : notify;
			ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Battle.BattleMenu.CloseSilent();

			if(gridOrientationShortcut == null)
			{
				gridOrientationShortcut = ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.
					Shortcuts.GridOrientationShortcut;
			}
			else
			{
				ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.
					Shortcuts.GridOrientationShortcut = gridOrientationShortcut;
			}
			ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Shortcuts.Active = gridOrientationShortcut;
			ORK.Battle.SystemSettings.gridSettings.SelectedCell = null;

			if(this.blockActionUse)
			{
				ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Actions.BlockActionUse = true;
			}
			if(ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.GameObject != null)
			{
				this.startRotation = ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.GameObject.transform.eulerAngles;
			}

			if(this.selectCellFunction == null)
			{
				this.selectCellFunction = this.SelectCell;
				this.acceptCellFunction = this.AcceptCell;
				this.acceptCheckFunction = this.CheckAcceptCell;
				this.selectDirectionFunction = this.RotateToDirection;
			}

			this.ShowInfoBox();

			this.isSelecting = true;
		}

		public void Restart(Combatant combatant)
		{
			if(ORK.Battle.SystemSettings.gridSettings.SelectingCombatant == combatant)
			{
				BattleGridCellComponent tmpCell = ORK.Battle.SystemSettings.gridSettings.SelectedCell;
				ORK.Battle.SystemSettings.gridSettings.SelectedCell = null;
				this.SelectCell(tmpCell, true);
			}
		}

		public void Close(bool accepted)
		{
			if(!accepted)
			{
				if(ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.GameObject != null)
				{
					ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.
						GameObject.transform.eulerAngles = this.startRotation;
				}
			}

			this.StopHighlights();
			ORK.InputKeys.ResetInputAxes(true);
			if(this.blockActionUse)
			{
				ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Actions.BlockActionUse = false;
			}

			this.ResetCameraControlTarget();
			this.isSelecting = false;
			if(ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Shortcuts.Active is GridOrientationShortcut)
			{
				ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Shortcuts.Active = null;
			}
			ORK.Battle.SystemSettings.gridSettings.ClearCellSelection();

			this.Clear();
			if(this.notify != null)
			{
				this.notify(accepted);
			}
		}

		private void StopHighlights()
		{
			if(ORK.Battle.SystemSettings.gridSettings.SelectedCell != null)
			{
				BattleGridHelper.StopHighlight(ORK.Battle.SystemSettings.gridSettings.SelectedCell, GridHighlightType.OrientationSelection);
				BattleGridHelper.StopHighlight(ORK.Battle.SystemSettings.gridSettings.SelectedCell, GridHighlightType.OrientationSelectionPlayer);
				BattleGridHelper.StopHighlight(ORK.Battle.SystemSettings.gridSettings.SelectedCell, GridHighlightType.OrientationSelectionAlly);
				BattleGridHelper.StopHighlight(ORK.Battle.SystemSettings.gridSettings.SelectedCell, GridHighlightType.OrientationSelectionEnemy);
			}
		}

		private void UseSelectedCell()
		{
			if(ORK.Battle.SystemSettings.gridSettings.SelectedCell != null)
			{
				this.RotateToSelection();
			}
			else if(this.selectedDirection != -1)
			{
				this.RotateToDirection(this.selectedDirection);
			}
			this.Close(true);
		}

		private void ResetCameraControlTarget()
		{
			if(this.cameraControlTarget &&
				this.previousCameraControlTarget != null &&
				(ORK.Battle.SystemSettings.gridSettings.SelectedCell == null ||
				ORK.Control.CameraControlTarget == ORK.Battle.SystemSettings.gridSettings.SelectedCell.gameObject))
			{
				ORK.Control.SetCameraControlTarget(this.previousCameraControlTarget,
					this.ownControlTargetTransition ? this.controlTargetTransition : null);
			}
			this.previousCameraControlTarget = null;
		}

		private void RotateToSelection()
		{
			if(ORK.Battle.SystemSettings.gridSettings.SelectedCell != null)
			{
				BattleGridHelper.RotateToPosition(
					ORK.Battle.SystemSettings.gridSettings.SelectingCombatant,
					ORK.Battle.SystemSettings.gridSettings.SelectedCell.transform.position,
					!this.blockDiagonalRotation);
			}
		}

		private void RotateToDirection(int direction)
		{
			if(this.selectedDirection != direction)
			{
				if(this.ownCellSelection)
				{
					this.selection.PlaySelectAudio();
				}
				else
				{
					ORK.Battle.SystemSettings.gridSettings.cellSelection.PlaySelectAudio();
				}

				this.StopHighlights();
				ORK.Battle.SystemSettings.gridSettings.SelectedCell = null;
				this.ResetCameraControlTarget();

				this.selectedDirection = direction;
				BattleGridHelper.RotateToDirection(
					ORK.Battle.SystemSettings.gridSettings.SelectingCombatant,
					direction, !this.blockDiagonalRotation);
			}
		}


		/*
		============================================================================
		Cell selection functions
		============================================================================
		*/
		public void Tick()
		{
			if(this.canSelect &&
				this.isSelecting &&
				ORK.Battle.SystemSettings.gridSettings.SelectingCombatant != null)
			{
				if(this.canCancel &&
					ORK.GameControls.menuControls.CancelKey.GetButton())
				{
					if(this.ownCellSelection)
					{
						this.selection.PlayCancelAudio();
					}
					else
					{
						ORK.Battle.SystemSettings.gridSettings.cellSelection.PlayCancelAudio();
					}

					this.Close(false);
				}
				else
				{
					if(ORK.Battle.SystemSettings.gridSettings.SelectedCell == null &&
						this.selectedDirection == -1)
					{
						int direction = BattleGridHelper.GetCombatantDirection(
							ORK.Battle.SystemSettings.gridSettings.SelectingCombatant, true);
						BattleGridCellComponent tmpCell = BattleGridHelper.GetNeighbourCell(
							ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Grid.Cell, direction);
						if(tmpCell != null)
						{
							this.SelectCell(tmpCell, true);
						}
						else if(this.rotateOnSelection)
						{
							this.selectedDirection = direction;
							BattleGridHelper.RotateToDirection(
								ORK.Battle.SystemSettings.gridSettings.SelectingCombatant,
								direction, !this.blockDiagonalRotation);
						}
					}
					if(this.ownCellSelection)
					{
						this.selection.SelectCell(
							ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Grid.Cell,
							ORK.Battle.SystemSettings.gridSettings.SelectedCell,
							this.selectCellFunction,
							this.acceptCellFunction, this.acceptCheckFunction,
							this.selectDirectionFunction, this.onlyNeighbourCells, this.blockDiagonalRotation);
					}
					else
					{
						ORK.Battle.SystemSettings.gridSettings.cellSelection.SelectCell(
							ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Grid.Cell,
							ORK.Battle.SystemSettings.gridSettings.SelectedCell,
							this.selectCellFunction,
							this.acceptCellFunction, this.acceptCheckFunction,
							this.selectDirectionFunction, this.onlyNeighbourCells, this.blockDiagonalRotation);
					}
				}
			}
		}

		public void SelectCell(BattleGridCellComponent cell, bool isHover)
		{
			if(ORK.Battle.SystemSettings.gridSettings.SelectedCell != cell &&
				this.CheckAcceptCell(cell))
			{
				// stop selection highlight
				this.StopHighlights();

				this.selectedDirection = -1;
				ORK.Battle.SystemSettings.gridSettings.SelectedCell = cell;

				// new highlights
				if(ORK.Battle.SystemSettings.gridSettings.SelectedCell != null)
				{
					ORK.Control.Cursor.ShowCursor(CursorType.GridOrientationSelection);

					if(this.cameraControlTarget && !isHover)
					{
						ORK.Control.SetCameraControlTarget(this.onlyNeighbourCells ?
								ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Grid.Cell.gameObject :
								ORK.Battle.SystemSettings.gridSettings.SelectedCell.gameObject,
							this.ownControlTargetTransition ? this.controlTargetTransition : null);
					}

					if(ORK.Battle.SystemSettings.gridHighlights.orientationSelectionHighlight.enable)
					{
						BattleGridHelper.Highlight(ORK.Battle.SystemSettings.gridSettings.SelectedCell,
							ORK.Battle.SystemSettings.gridHighlights.GetSelectionHighlight(
								GridHighlightType.OrientationSelection, ORK.Battle.SystemSettings.gridSettings.SelectedCell));
					}

					if(this.rotateOnSelection)
					{
						this.RotateToSelection();
					}
				}

				if(this.examineCell ||
					this.examineCellCombatant)
				{
					ORK.Battle.SystemSettings.gridSettings.examine.ExternalExamine(
						ORK.Battle.SystemSettings.gridSettings.SelectedCell,
						this.examineCell, this.examineCellCombatant);
				}
			}
		}

		public void AcceptCell(BattleGridCellComponent cell)
		{
			if(this.CheckAcceptCell(cell))
			{
				this.CloseInfoBox();
				this.canSelect = false;

				if(ORK.Battle.SystemSettings.gridSettings.SelectedCell != cell)
				{
					this.SelectCell(cell, true);
				}
				if(this.showAcceptQuestion)
				{
					this.acceptQuestion.Show(
						ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.GetName(),
						this.AcceptQuestionClosed);
				}
				else
				{
					this.UseSelectedCell();
				}
			}
			else
			{
				this.SelectCell(cell, true);
			}
		}

		public void AcceptQuestionClosed(bool accepted)
		{
			if(accepted)
			{
				this.UseSelectedCell();
			}
			else
			{
				this.ShowInfoBox();
				this.canSelect = true;
			}
		}

		public bool CheckAcceptCell(BattleGridCellComponent cell)
		{
			return (this.selectedDirection != -1 &&
					ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Grid.CanRotateTo(this.selectedDirection)) ||
				(cell != null &&
					(!this.onlyNeighbourCells ||
						BattleGridHelper.IsNeighbourCell(
							ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Grid.Cell,
							cell, ORK.Battle.SystemSettings.gridSettings.squareDiagonalDistanceOne, null)) &&
					ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Grid.CanRotateTo(
						BattleGridHelper.GetCellDirection(
							ORK.Battle.SystemSettings.gridSettings.SelectingCombatant.Grid.Cell, cell, true)));
		}
	}
}
