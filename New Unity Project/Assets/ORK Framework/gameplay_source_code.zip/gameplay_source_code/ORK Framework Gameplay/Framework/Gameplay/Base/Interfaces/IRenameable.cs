﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface IRenameable
	{
		void SetName(string name);
	}
}
