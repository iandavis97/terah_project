
using UnityEngine;

namespace ORKFramework
{
	public class FloatFader
	{
		private bool fading = false;

		private Function ease;

		private float start = 0;

		private float distance = 0;

		private float time = 0;

		private float time2 = 0;

		public FloatFader(EaseType interpolation, float time)
		{
			this.ease = Interpolate.Ease(interpolation);
			this.time2 = time;
		}

		public bool Fading
		{
			get { return this.fading; }
		}

		public void Start(float start, float end)
		{
			this.start = start;
			this.distance = end - start;
			this.time = 0;
			this.fading = true;
		}

		public void Fade(ref float value, float t)
		{
			this.time += t;
			value = Interpolate.Ease(this.ease, this.start, this.distance, this.time, this.time2);

			if(this.time >= this.time2)
			{
				this.fading = false;
			}
		}
	}
}
