﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DefaultBattleAnimations : BaseData
	{
		//defend animation
		[ORKEditorInfo("Defend Animation", "The defend command will perform a series of battle events when used.", "",
			endFoldout=true)]
		public BattleAnimationSetting defendAnimation = new BattleAnimationSetting();


		// escape animation
		[ORKEditorInfo("Escape Animation", "The escape command will perform a series of battle events when used.", "",
			endFoldout=true)]
		public BattleAnimationSetting escapeAnimation = new BattleAnimationSetting();


		// death animation
		[ORKEditorInfo("Death Animation", "The death of a combatant will perform a series of battle events when used.", "",
			endFoldout=true)]
		public BattleAnimationSetting deathAnimation = new BattleAnimationSetting();


		// none animation
		[ORKEditorInfo("None Animation", "Doing nothing (none action) will perform a series of battle events when used.", "",
			endFoldout=true)]
		public BattleAnimationSetting noneAnimation = new BattleAnimationSetting();


		// retreat animation (change member)
		[ORKEditorInfo("Retreat Animation", "Retreating from battle when changing members will perform a series of battle events.", "",
			endFoldout=true)]
		public BattleAnimationSetting retreatAnimation = new BattleAnimationSetting();


		// enter battle animation (change member)
		[ORKEditorInfo("Enter Battle Animation", "Entering the battle when changing members will perform a series of battle events.", "",
			endFoldout=true)]
		public BattleAnimationSetting enterBattleAnimation = new BattleAnimationSetting();


		// join battle animation (auto join)
		[ORKEditorInfo("Join Battle Animation", "Joining the battle when using 'Auto Join' during battles will perform a series of battle events.", "")]
		public BattleAnimationSetting joinBattleAnimation = new BattleAnimationSetting();

		[ORKEditorHelp("Look At Enemies", "The combatant will automatically look at his enemies when joining a battle.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("joinBattleAnimation.animate", false, endCheckGroup=true)]
		public bool joinLookAt = false;

		public DefaultBattleAnimations()
		{

		}
	}
}
