﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleLoot : ISaveData
	{
		private List<IShortcut> loot = new List<IShortcut>();

		private Dictionary<int, List<ExperienceLoot>> expGains = new Dictionary<int, List<ExperienceLoot>>();

		private Dictionary<int, int> normalSVGains = new Dictionary<int, int>();

		public BattleLoot()
		{

		}

		public void Clear()
		{
			this.loot.Clear();
			this.expGains.Clear();
			this.normalSVGains.Clear();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public bool Has
		{
			get
			{
				return this.loot.Count > 0 ||
					this.expGains.Count > 0 ||
						this.normalSVGains.Count > 0;
			}
		}

		public List<IShortcut> Loot
		{
			get { return this.loot; }
		}

		public Dictionary<int, List<ExperienceLoot>> Experience
		{
			get { return this.expGains; }
		}

		public Dictionary<int, int> NormalStatusValue
		{
			get { return this.normalSVGains; }
		}


		/*
		============================================================================
		Add loot functions
		============================================================================
		*/
		public void AddLoot(ItemGain item)
		{
			if(ORK.Battle.System != null &&
				item != null && item.CheckChance())
			{
				ShortcutHelper.Add(ref this.loot, item.CreateShortcut(),
					ORK.Battle.System.gainsUseInventoryAddType);
			}
		}

		public void AddLoot(IShortcut item)
		{
			if(ORK.Battle.System != null &&
				item != null)
			{
				ShortcutHelper.Add(ref this.loot, item,
					ORK.Battle.System.gainsUseInventoryAddType);
			}
		}

		public void AddExperience(int statusID, int exp, int level, int classLevel)
		{
			List<ExperienceLoot> list = null;
			if(!this.expGains.TryGetValue(statusID, out list))
			{
				list = new List<ExperienceLoot>();
				this.expGains.Add(statusID, list);
			}
			list.Add(new ExperienceLoot(exp, level, classLevel));
		}

		public void AddNormalStatusValue(int statusID, int value)
		{
			if(!this.normalSVGains.ContainsKey(statusID))
			{
				this.normalSVGains.Add(statusID, 0);
			}
			this.normalSVGains[statusID] += value;
		}

		public void GetGainsFrom(Combatant combatant)
		{
			if(combatant != null &&
				!combatant.LootCollected)
			{
				combatant.LootCollected = true;

				// battle gains
				if(ORK.Battle.System != null)
				{
					// combatant gains
					combatant.GetLoot(ref this.loot, ORK.Battle.System.gainsUseInventoryAddType);

					// group gains
					if(combatant.Group.AllDeadBattle() &&
						combatant.Group.HasLoot)
					{
						for(int i = 0; i < combatant.Group.Loot.Count; i++)
						{
							ShortcutHelper.Add(ref this.loot, combatant.Group.Loot[i],
								ORK.Battle.System.gainsUseInventoryAddType);
						}
					}
				}

				// experience reward
				if(combatant.Setting.useExpReward)
				{
					if(combatant.Setting.expReward != null)
					{
						for(int i = 0; i < combatant.Setting.expReward.Length; i++)
						{
							if(!combatant.Setting.expReward[i].useChance ||
								ORK.GameSettings.CheckRandom(
									combatant.Setting.expReward[i].chance.GetValue(combatant, combatant)))
							{
								DifficultyFaction factionMultipliers = ORK.Difficulties.Get(ORK.Game.Difficulty).
									GetMultipliers(combatant.Group.FactionID);
								int exp = (int)(combatant.Setting.expReward[i].rewardValue.GetValue(combatant, combatant) *
									(factionMultipliers != null ?
										factionMultipliers.statusMultiplier[combatant.Setting.expReward[i].statusID] : 1));
								if(exp != 0)
								{
									if(ORK.BattleEnd.splitExp)
									{
										if(ORK.BattleEnd.wholePartyExp)
										{
											exp /= ORK.Game.ActiveGroup.Size;
										}
										else
										{
											exp /= ORK.Game.ActiveGroup.BattleSize;
										}
										if(exp == 0)
										{
											exp = 1;
										}
									}

									this.AddExperience(combatant.Setting.expReward[i].statusID,
										exp, combatant.Status.Level, combatant.Class.Level);
								}
							}
						}
					}
				}
				else
				{
					for(int i = 0; i < ORK.StatusValues.Count; i++)
					{
						if(combatant.Status[i].IsExperience())
						{
							int exp = combatant.Status[i].GetBaseValue();
							if(exp != 0)
							{
								if(ORK.BattleEnd.splitExp)
								{
									if(ORK.BattleEnd.wholePartyExp)
									{
										exp /= ORK.Game.ActiveGroup.Size;
									}
									else
									{
										exp /= ORK.Game.ActiveGroup.BattleSize;
									}
									if(exp == 0)
									{
										exp = 1;
									}
								}

								this.AddExperience(i, exp, combatant.Status.Level, combatant.Class.Level);
							}
						}
					}
				}

				// noraml status value reward
				for(int i = 0; i < combatant.Setting.normalSVReward.Length; i++)
				{
					if(!combatant.Setting.normalSVReward[i].useChance ||
						ORK.GameSettings.CheckRandom(
							combatant.Setting.normalSVReward[i].chance.GetValue(combatant, combatant)))
					{
						int value = (int)combatant.Setting.normalSVReward[i].rewardValue.GetValue(combatant, combatant);
						if(value != 0)
						{
							if(ORK.BattleEnd.splitNormalSV)
							{
								if(ORK.BattleEnd.wholePartyNormalSV)
								{
									value /= ORK.Game.ActiveGroup.Size;
								}
								else
								{
									value /= ORK.Game.ActiveGroup.BattleSize;
								}
							}

							this.AddNormalStatusValue(
								combatant.Setting.normalSVReward[i].statusID, value);
						}
					}
				}

				// collect gains
				if(ORK.Battle.System != null &&
					ORK.Battle.System.gainsCollectImmediately)
				{
					if(combatant.GameObject != null &&
						(ORK.Battle.System.gainsDropItems ||
							ORK.Battle.System.gainsDropMoney ||
							ORK.Battle.System.gainsDropAI ||
							ORK.Battle.System.gainsDropRecipes))
					{
						for(int i = 0; i < this.loot.Count; i++)
						{
							if((ORK.Battle.System.gainsDropMoney &&
									this.loot[i] is MoneyShortcut) ||
								(ORK.Battle.System.gainsDropItems &&
									(this.loot[i] is ItemShortcut ||
									this.loot[i] is EquipShortcut)) ||
								(ORK.Battle.System.gainsDropAI &&
									(this.loot[i] is AIBehaviourShortcut ||
									this.loot[i] is AIRulesetShortcut)) ||
								(ORK.Battle.System.gainsDropRecipes &&
									this.loot[i] is CraftingRecipeShortcut))
							{
								ORK.Game.Scene.Drop(this.loot[i],
									combatant.GameObject.transform.position,
									ORK.InventorySettings.dropUseRotation ?
										combatant.GameObject.transform.eulerAngles :
										Vector3.zero);
								this.loot.RemoveAt(i--);
							}
						}
					}

					ORK.Battle.System.collectGains.CollectGains(null, -1);
				}
			}
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			// loot
			if(this.loot.Count > 0)
			{
				DataObject[] lootData = new DataObject[this.loot.Count];
				for(int i = 0; i < lootData.Length; i++)
				{
					lootData[i] = this.loot[i].SaveGame();
				}
				data.Set("loot", lootData);
			}

			// exp gains
			if(this.expGains.Count > 0)
			{
				DataObject expGainsData = new DataObject();
				foreach(KeyValuePair<int, List<ExperienceLoot>> pair in this.expGains)
				{
					DataObject[] expLootData = new DataObject[pair.Value.Count];
					for(int i = 0; i < expLootData.Length; i++)
					{
						expLootData[i] = pair.Value[i].SaveGame();
					}
					expGainsData.Set(pair.Key.ToString(), expLootData);
				}
				data.Set("expGains", expGainsData);
			}

			// normal SV gains
			if(this.normalSVGains.Count > 0)
			{
				DataObject normalSVGainsData = new DataObject();
				Dictionary<string, int> tmpGain = new Dictionary<string, int>();
				foreach(KeyValuePair<int, int> pair in this.normalSVGains)
				{
					tmpGain.Add(pair.Key.ToString(), pair.Value);
				}
				normalSVGainsData.SetData<int>(tmpGain, typeof(int));
				data.Set("normalSVGains", normalSVGainsData);
			}

			return data;
		}

		public void LoadGame(DataObject data)
		{
			if(data != null)
			{
				// loot
				DataObject[] lootData = data.GetFileArray("loot");
				if(lootData != null)
				{
					for(int i = 0; i < lootData.Length; i++)
					{
						IShortcut tmpShortcut = ShortcutHelper.Load(lootData[i]);
						if(tmpShortcut != null)
						{
							this.loot.Add(tmpShortcut);
						}
					}
				}

				// exp gains
				DataObject expGainsData = data.GetFile("expGains");
				if(expGainsData != null)
				{
					Dictionary<string, DataObject[]> expLootData = data.GetData<DataObject[]>(typeof(DataObject[]));
					if(expLootData != null && expLootData.Count > 0)
					{
						foreach(KeyValuePair<string, DataObject[]> pair in expLootData)
						{
							List<ExperienceLoot> list = new List<ExperienceLoot>();
							for(int i = 0; i < pair.Value.Length; i++)
							{
								list.Add(new ExperienceLoot(pair.Value[i]));
							}
							this.expGains.Add(int.Parse(pair.Key), list);
						}
					}
				}

				// normal SV gains
				DataObject noralSVGainsData = data.GetFile("normalSVGains");
				if(noralSVGainsData != null)
				{
					Dictionary<string, int> tmpGain = noralSVGainsData.GetData<int>(typeof(int));
					if(tmpGain != null && tmpGain.Count > 0)
					{
						foreach(KeyValuePair<string, int> pair in tmpGain)
						{
							this.normalSVGains.Add(int.Parse(pair.Key), pair.Value);
						}
					}
				}
			}
		}
	}
}
