﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TooltipRequirement : BaseData
	{
		[ORKEditorHelp("Has Equip Durability", "Select if the tooltip has to be an equipment that uses durability:\n" +
			"- Yes: The tooltip is an equipment using durability.\n" +
			"- No: The tooltip isn't an equipment using durability.\n" +
			"- Ignore: The type of tooltip is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider hasEquipDurability = Consider.Ignore;

		// variable conditions
		[ORKEditorHelp("Use Tooltip Variables", "Use variables of the displayed tooltip.\n" +
			"E.g. when displaying a combatant, this'll use object variables of the combatant.\n" +
			"E.g. when displaying an item, this'll use item variables of the item.", "")]
		[ORKEditorInfo(separator=true, labelText="Variable Conditions")]
		public bool useTooltipVariables = false;

		public VariableCondition condition = new VariableCondition();

		public TooltipRequirement()
		{

		}

		public bool Check(IContentSimple tooltip)
		{
			if(tooltip is PreviewSelection)
			{
				tooltip = ((PreviewSelection)tooltip).Content;
			}

			// equip durability
			if(Consider.Yes == this.hasEquipDurability)
			{
				EquipShortcut equip = tooltip as EquipShortcut;
				if(equip == null ||
					equip.Durability == -1)
				{
					return false;
				}
			}
			else if(Consider.No == this.hasEquipDurability)
			{
				EquipShortcut equip = tooltip as EquipShortcut;
				if(equip != null &&
					equip.Durability != -1)
				{
					return false;
				}
			}

			// variables
			if(this.condition.gameVariable.Length > 0)
			{
				VariableHandler handler = this.GetUsedVariableHandler(tooltip);
				if(handler == null ||
					!this.condition.CheckVariables(handler))
				{
					return false;
				}
			}
			return true;
		}

		private VariableHandler GetUsedVariableHandler(IContentSimple tooltip)
		{
			if(this.useTooltipVariables)
			{
				return VariableHandler.GetHandler(tooltip);
			}
			else
			{
				return ORK.Game.Variables;
			}
		}
	}
}
