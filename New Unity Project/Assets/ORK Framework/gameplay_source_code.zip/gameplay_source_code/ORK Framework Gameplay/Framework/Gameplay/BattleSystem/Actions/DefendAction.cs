
using System.Collections.Generic;

namespace ORKFramework
{
	public class DefendAction : BaseAction
	{
		public DefendAction(Combatant user)
		{
			this.user = user;
			this.target = new List<Combatant>();
			this.target.Add(user);

			this.actionCost = ORK.Battle.GetDefendActionCost(this.user);

			this.CheckActionAffiliation();
		}

		public override bool IsType(ActionType t)
		{
			return ActionType.Defend == t;
		}

		public override IShortcut Shortcut
		{
			get { return this.user.Shortcuts.DefendShortcut; }
		}


		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		public override bool CanUse()
		{
			return this.user != null && !this.user.Status.IsDead &&
				!this.user.Status.Effects.BlockDefend;
		}

		public override void ActionAdded()
		{
			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleAddDefend)
				{
					this.user.Setting.consoleAddDefend.Print(this.user);
				}
				else
				{
					ORK.ConsoleSettings.actionAddDefend.Print(this.user);
				}
			}
		}

		protected override void ActionStartSetup()
		{
			if(ORK.BattleTexts.showInfo)
			{
				ORK.BattleTexts.defendInfo.Show(this.user, "");
			}

			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleDefend)
				{
					this.user.Setting.consoleDefend.Print(this.user);
				}
				else
				{
					ORK.ConsoleSettings.actionDefend.Print(this.user);
				}
			}

			this.user.GetBattleAnimation(BattleAnimationType.Defend, ref this.events);
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate)
		{
			if(!this.blockBattleCamera &&
				!ORK.BattleSettings.camera.IsNone &&
				!ORK.BattleSettings.camera.latestDamageActionBlock.IsBlocked(this))
			{
				if(ts.Count == 1 &&
					ts[0] != null &&
					ts[0].GameObject != null)
				{
					ORK.BattleSettings.camera.SetLatestDamage(
						this.user.GameObject != null ? this.user.GameObject.transform : null,
						ts[0].GameObject.transform);
				}
				else if(ts.Count > 1)
				{
					ORK.BattleSettings.camera.SetLatestDamage(
						this.user.GameObject != null ? this.user.GameObject.transform : null,
						ORK.Battle.GetGroupCenter(ts).transform);
				}
			}

			if(this.user != null && !this.user.Status.IsDead &&
				ts.Count > 0 && ts[0] != null &&
				!this.user.Status.Effects.BlockDefend)
			{
				this.user.Battle.Defending = true;
				this.userConsumeDone = true;
			}
		}

		protected override void ActionEndSetup()
		{
			this.user.Abilities.LastAbilityID = -1;
		}
	}
}
