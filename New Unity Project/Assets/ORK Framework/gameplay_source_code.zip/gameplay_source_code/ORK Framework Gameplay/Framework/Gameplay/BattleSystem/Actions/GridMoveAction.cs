﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridMoveAction : BaseAction
	{
		private GridMoveShortcut gridMoveShortcut;

		public GridMoveAction(Combatant user, Combatant target, List<BattleGridCellComponent> path,
			float moveCost, float actionCost, GridMoveShortcut gridMoveShortcut)
		{
			this.user = user;
			this.target = new List<Combatant>();
			this.target.Add(target != null ? target : user);

			this.gridMoveShortcut = gridMoveShortcut;
			if(this.gridMoveShortcut == null)
			{
				this.gridMoveShortcut = this.user.Shortcuts.GridMoveShortcut;
			}

			this.gridPath = new GridPath(this.user, path, moveCost);

			this.actionCost = actionCost;

			this.CheckActionAffiliation();
		}

		public override bool IsType(ActionType t)
		{
			return ActionType.GridMove == t;
		}

		public override IShortcut Shortcut
		{
			get { return this.gridMoveShortcut; }
		}


		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		public override bool CanUse()
		{
			return this.user != null && !this.user.Status.IsDead &&
				!this.user.Status.Effects.BlockAllActions &&
				!this.user.Status.Effects.StopMovement &&
				this.user.Battle.GridMoveState != GridMoveState.Performed;
		}

		public override void ActionAdded()
		{
			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleAddGridMove)
				{
					this.user.Setting.consoleAddGridMove.Print(this.user);
				}
				else
				{
					ORK.ConsoleSettings.actionAddGridMove.Print(this.user);
				}
			}
		}

		protected override void ActionStartSetup()
		{
			if(ORK.BattleTexts.showInfo)
			{
				ORK.BattleTexts.gridMoveInfo.Show(this.user, "");
			}

			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleGridMove)
				{
					this.user.Setting.consoleGridMove.Print(this.user);
				}
				else
				{
					ORK.ConsoleSettings.actionGridMove.Print(this.user);
				}
			}

			this.user.GetBattleAnimation(BattleAnimationType.GridMove, ref this.events);
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate)
		{

		}

		protected override void ActionEndSetup()
		{
			if(this.user != null)
			{
				// change move state
				if(ORK.Battle.Settings.gridSettings.moveCommand.useOnlyOnce)
				{
					if(CombatantAffiliationType.Player == this.ActionAffiliation)
					{
						this.user.Battle.GridMoveState = ORK.Battle.Settings.gridSettings.moveCommand.useOnlyOncePlayer ?
							GridMoveState.Performed : GridMoveState.Available;
					}
					else if(CombatantAffiliationType.Ally == this.ActionAffiliation)
					{
						this.user.Battle.GridMoveState = ORK.Battle.Settings.gridSettings.moveCommand.useOnlyOnceAlly ?
							GridMoveState.Performed : GridMoveState.Available;
					}
					else if(CombatantAffiliationType.Enemy == this.ActionAffiliation)
					{
						this.user.Battle.GridMoveState = ORK.Battle.Settings.gridSettings.moveCommand.useOnlyOnceEnemy ?
							GridMoveState.Performed : GridMoveState.Available;
					}
				}
				else
				{
					this.user.Battle.GridMoveState = GridMoveState.Available;
				}

				// end path
				if(this.gridPath != null)
				{
					if(this.user.Status.IsDead)
					{
						this.gridPath.Clear();
					}
					else
					{
						this.gridPath.End();
					}
					this.gridPath = null;
				}
			}
		}
	}
}
