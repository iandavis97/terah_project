﻿
using UnityEngine;
using ORKFramework.Events;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridTargetCellSelectionSettings : BaseData
	{
		// settings
		[ORKEditorHelp("Allow Cancel", "The target cell selection can be canceled using the 'Cancel' key defined in the game controls.", "")]
		public bool allowCancel = false;

		[ORKEditorHelp("Block Action Use", "Using actions is blocked for the combatant during the grid cell selection.", "")]
		public bool blockActionUse = false;

		[ORKEditorHelp("Start From User", "The target cell selection will always start from the user's cell.\n" +
			"If disabled, a previously selected cell (also from other cell selections) will be used.", "")]
		public bool startFromUser = true;

		[ORKEditorHelp("Rotate To Cell", "Rotate the user to the selected cell.\n" +
			"If disabled, a previously selected cell (also from other cell selections) will be used.", "")]
		public bool rotateToCell = false;

		[ORKEditorHelp("Grid Rotation", "Limit the rotation to the nearest grid rotation during grid battles.", "")]
		[ORKEditorLayout("rotateToCell", true, endCheckGroup=true)]
		public bool gridRotation = false;

		[ORKEditorHelp("Examine Cell", "Display the cell info text for the selected cell ('Examine Grid' settings).", "")]
		public bool examineCell = false;

		[ORKEditorHelp("Examine Cell Combatant", "Display the combatant info dialogue for the selected cell's combatant ('Examine Grid' settings).\n" +
			"Please note that this only shows the information dialogue and " +
			"doesn't show cell highlights (e.g. move range of a combatant).", "")]
		public bool examineCellCombatant = false;


		// camera control target
		[ORKEditorHelp("Camera Control Target", "Changes the camera control target to the selected cell.\n" +
			"The camera control must descent from the 'BaseCameraControl' class (like all built-in camera controls).", "")]
		[ORKEditorInfo("Camera Control Target", "Optionally change the camera control target to the selected cell.\n" +
			"The camera control must descent from the 'BaseCameraControl' class (like all built-in camera controls).", "")]
		public bool cameraControlTarget = false;

		[ORKEditorHelp("Own Transition", "Use a custom camera control transition when changing the camera control target.\n" +
			"If disabled, the default transition defined in 'Base/Control > Game Controls' will be used.", "")]
		[ORKEditorLayout("cameraControlTarget", true)]
		public bool ownControlTargetTransition = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownControlTargetTransition", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public CameraControlTargetTransition controlTargetTransition;


		// info text
		[ORKEditorHelp("Show Info Text", "An info text will be displayed while selecting a target cell.", "")]
		[ORKEditorInfo("Info Text", "Optionally display an info text box while the player selects a target cell.", "")]
		public bool showInfo = false;

		[ORKEditorInfo(separator=true, endFoldout=true, label=new string[] {
			"%un = user name, %ud = user description, %ui = user icon",
			"%an = action name, %ad = action description, %ai = action icon"
		})]
		[ORKEditorLayout("showInfo", true, endCheckGroup=true, autoInit=true)]
		public InfoBoxChoice info;


		// accept dialogue
		[ORKEditorHelp("Show Accept Question", "A question dialogue will be displayed when a cell was accepted.\n" +
			"If the player accepts the question, the cell will be used, otherwise the cell selection will be resumed.", "")]
		[ORKEditorInfo("Accept Question Dialogue", "Optionally display an accept question dialogue to ask " +
			"if the player wants to use the accepted cell.", "")]
		public bool showAcceptQuestion = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("showAcceptQuestion", true, endCheckGroup=true, autoInit=true)]
		public QuestionChoice acceptQuestion;


		// own cell selection
		[ORKEditorHelp("Own Cell Selection", "The target cell selection uses a different cell selection setup.\n" +
			"If disabled, the cell selection will be used.", "")]
		[ORKEditorInfo("Cell Selection", "The target cell selection can optionally override the cell selection settings.", "")]
		public bool ownCellSelection = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownCellSelection", true, endCheckGroup=true, autoInit=true)]
		public GridCellSelectionSettings selection;


		// in-game
		private IShortcut shortcut;

		private bool blockBattleCamera = false;

		private TargetSettings targetSettings;

		private CombatantCheck canTarget;

		private GameObject previousCameraControlTarget;

		private NotifyBool notify;


		// selection
		private bool canSelect = true;

		private bool isSelecting = false;

		private List<BattleGridCellComponent> useRangeCells;

		private List<BattleGridCellComponent> affectRangeCells;

		private List<Combatant> availableTargets;

		private SelectGridCellBool selectCellFunction;

		private SelectGridCell acceptCellFunction;

		private GridCellCheck acceptCheckFunction;


		public GridTargetCellSelectionSettings()
		{
			this.canTarget = this.CanTarget;
		}

		public void Clear()
		{
			this.CloseInfoBox();
			ORK.BattleSettings.CloseTargetInformation();
			this.StopHighlights();

			if(this.isSelecting)
			{
				if(this.blockActionUse &&
					ORK.BattleSystem.gridSettings.SelectingCombatant != null)
				{
					ORK.BattleSystem.gridSettings.SelectingCombatant.Actions.BlockActionUse = false;
				}
				this.isSelecting = false;

				ORK.GUI.ForcedPreviewShortcut = null;
			}

			this.canSelect = true;
			this.shortcut = null;
			this.blockBattleCamera = false;
			this.targetSettings = null;
			this.previousCameraControlTarget = null;
		}

		public bool CanTarget(Combatant target)
		{
			return this.shortcut != null &&
				this.shortcut.CanTarget(
					ORK.BattleSystem.gridSettings.SelectingCombatant,
					target);
		}


		/*
		============================================================================
		GUI box functions
		============================================================================
		*/
		private string InfoReplace(string text)
		{
			return text.
				Replace("%un", ORK.BattleSystem.gridSettings.SelectingCombatant.GetName()).
				Replace("%ud", ORK.BattleSystem.gridSettings.SelectingCombatant.GetDescription()).
				Replace("%ui", ORK.BattleSystem.gridSettings.SelectingCombatant.GetIconTextCode()).
				Replace("%an", this.shortcut.GetName()).
				Replace("%ad", this.shortcut.GetDescription()).
				Replace("%ai", this.shortcut.GetIconTextCode());
		}

		private void ShowInfoBox()
		{
			if(this.showInfo)
			{
				string tmpTitle = this.info.useTitle ?
					this.InfoReplace(this.info.title[ORK.Game.Language]) : "";
				string tmpText = this.InfoReplace(this.info.infoText[ORK.Game.Language]);

				this.info.Show(tmpTitle, tmpText, null);
			}
		}

		private void CloseInfoBox()
		{
			if(this.showInfo)
			{
				this.info.Close();
			}
		}


		/*
		============================================================================
		Target cell selection functions
		============================================================================
		*/
		public void Start(Combatant combatant, IShortcut shortcut, NotifyBool notify, bool blockBattleCamera)
		{
			ORK.BattleSystem.gridSettings.InitSelection(GridSelectionType.Target, combatant);
			this.shortcut = shortcut;
			this.blockBattleCamera = blockBattleCamera;
			this.targetSettings = TargetSettings.Get(this.shortcut);
			this.previousCameraControlTarget = ORK.Control.CameraControlTarget;
			this.notify = notify;

			ORK.BattleSystem.gridSettings.SelectingCombatant.Actions.SelectingGridHighlight(
				ORK.BattleSystem.gridHighlights.selectingCombatantTargetSelection);

			if(this.selectCellFunction == null)
			{
				this.selectCellFunction = this.SelectCell;
				this.acceptCellFunction = this.AcceptCell;
				this.acceptCheckFunction = this.CheckAcceptCell;
			}

			ORK.BattleSystem.gridSettings.SelectingCombatant.Shortcuts.Active = this.shortcut;
			if(this.blockActionUse)
			{
				ORK.BattleSystem.gridSettings.SelectingCombatant.Actions.BlockActionUse = true;
			}
			this.ShowInfoBox();

			ArrayHelper.GetBlank<BattleGridCellComponent>(ref this.useRangeCells);
			if(this.targetSettings != null)
			{
				this.targetSettings.GetUseRangeCells(
					ORK.BattleSystem.gridSettings.SelectingCombatant,
					ref this.useRangeCells, null);
			}

			BattleGridHelper.Highlight(this.useRangeCells, GridHighlightType.UseRange);

			BattleGridCellComponent tmpCell = ORK.BattleSystem.gridSettings.SelectedCell;
			ORK.BattleSystem.gridSettings.SelectedCell = null;
			this.SelectCell(this.startFromUser || tmpCell == null ?
				ORK.BattleSystem.gridSettings.SelectingCombatant.Grid.Cell : tmpCell, true);

			this.isSelecting = true;
		}

		private void Close(bool accepted)
		{
			this.StopHighlights();
			ORK.InputKeys.ResetInputAxes(true);
			if(this.blockActionUse)
			{
				ORK.BattleSystem.gridSettings.SelectingCombatant.Actions.BlockActionUse = false;
			}

			ORK.GUI.ForcedPreviewShortcut = null;
			this.ResetCameraControlTarget();
			this.isSelecting = false;
			ORK.BattleSystem.gridSettings.ClearCellSelection();

			this.Clear();
			if(this.notify != null)
			{
				this.notify(accepted);
			}
		}

		private void StopHighlights()
		{
			this.StopSelectedCellHighlight();
			if(this.useRangeCells != null &&
				this.useRangeCells.Count > 0)
			{
				BattleGridHelper.StopHighlight(this.useRangeCells, GridHighlightType.UseRange);
				this.useRangeCells.Clear();
			}
			if(this.affectRangeCells != null &&
				this.affectRangeCells.Count > 0)
			{
				BattleGridHelper.StopHighlight(this.affectRangeCells, GridHighlightType.AffectRange);
				this.affectRangeCells.Clear();
			}
		}

		private void StopSelectedCellHighlight()
		{
			if(ORK.BattleSystem.gridSettings.SelectedCell != null)
			{
				BattleGridHelper.StopHighlight(ORK.BattleSystem.gridSettings.SelectedCell, GridHighlightType.TargetCellSelection);
				BattleGridHelper.StopHighlight(ORK.BattleSystem.gridSettings.SelectedCell, GridHighlightType.NoTargetCellSelection);
				BattleGridHelper.StopHighlight(ORK.BattleSystem.gridSettings.SelectedCell, GridHighlightType.TargetCellSelectionPlayer);
				BattleGridHelper.StopHighlight(ORK.BattleSystem.gridSettings.SelectedCell, GridHighlightType.TargetCellSelectionAlly);
				BattleGridHelper.StopHighlight(ORK.BattleSystem.gridSettings.SelectedCell, GridHighlightType.TargetCellSelectionEnemy);
			}
		}

		private void UseSelectedCell()
		{
			Combatant tmp = ORK.BattleSystem.gridSettings.SelectingCombatant;
			BaseAction action = null;
			if(this.shortcut is ItemShortcut)
			{
				action = new ItemAction(
					ORK.BattleSystem.gridSettings.SelectingCombatant,
					(ItemShortcut)this.shortcut);
			}
			else if(this.shortcut is AbilityShortcut)
			{
				action = new AbilityAction(
					ORK.BattleSystem.gridSettings.SelectingCombatant,
					(AbilityShortcut)this.shortcut);
			}

			if(action != null)
			{
				action.rayTargetSet = true;
				action.rayPoint = ORK.BattleSystem.gridSettings.SelectedCell.transform.position;
				action.rayObject = ORK.BattleSystem.gridSettings.SelectedCell.gameObject;
				action.blockBattleCamera = this.blockBattleCamera;
			}
			this.Close(true);
			tmp.BattleMenu.AddAction(action);
		}

		private void ResetCameraControlTarget()
		{
			if(this.cameraControlTarget &&
				this.previousCameraControlTarget != null &&
				(ORK.BattleSystem.gridSettings.SelectedCell == null ||
				ORK.Control.CameraControlTarget == ORK.BattleSystem.gridSettings.SelectedCell.gameObject))
			{
				ORK.Control.SetCameraControlTarget(this.previousCameraControlTarget,
					this.ownControlTargetTransition ? this.controlTargetTransition : null);
			}
			this.previousCameraControlTarget = null;
		}


		/*
		============================================================================
		Cell selection functions
		============================================================================
		*/
		public void Tick()
		{
			if(this.canSelect &&
				this.isSelecting &&
				ORK.BattleSystem.gridSettings.SelectingCombatant != null)
			{
				if(this.allowCancel &&
					ORK.InputKeys.Get(ORK.GameControls.menuControls.cancelKeyID).GetButton())
				{
					if(this.ownCellSelection)
					{
						this.selection.PlayCancelAudio();
					}
					else
					{
						ORK.BattleSystem.gridSettings.cellSelection.PlayCancelAudio();
					}

					this.Close(false);
				}
				else
				{
					if(ORK.BattleSystem.gridSettings.SelectedCell == null)
					{
						this.SelectCell(ORK.BattleSystem.gridSettings.SelectingCombatant.Grid.Cell, true);
					}
					if(this.ownCellSelection)
					{
						this.selection.SelectCell(
							ORK.BattleSystem.gridSettings.SelectingCombatant.Grid.Cell,
							ORK.BattleSystem.gridSettings.SelectedCell,
							this.selectCellFunction, this.acceptCellFunction,
							this.acceptCheckFunction, null, false, false);
					}
					else
					{
						ORK.BattleSystem.gridSettings.cellSelection.SelectCell(
							ORK.BattleSystem.gridSettings.SelectingCombatant.Grid.Cell,
							ORK.BattleSystem.gridSettings.SelectedCell,
							this.selectCellFunction, this.acceptCellFunction,
							this.acceptCheckFunction, null, false, false);
					}
				}
			}
		}

		public void TargetCellCursor(BattleGridCellComponent cell)
		{
			if(this.isSelecting &&
				this.useRangeCells != null)
			{
				if(cell == null)
				{
					if(!ORK.Control.Cursor.ShowTargetOverBox(
						ORK.BattleSystem.gridSettings.SelectingCombatant, this.shortcut))
					{
						ORK.Control.Cursor.ShowTargetNone(this.targetSettings);
					}
				}
				else if(this.useRangeCells.Contains(cell))
				{
					ORK.Control.Cursor.ShowTargetValid(this.targetSettings);
				}
				else
				{
					ORK.Control.Cursor.ShowTargetInvalid(this.targetSettings);
				}
			}
		}

		public void SelectCell(BattleGridCellComponent cell, bool isHover)
		{
			if(ORK.BattleSystem.gridSettings.SelectedCell != cell)
			{
				// stop affect range highlight
				if(ORK.BattleSystem.gridHighlights.affectRangeHighlight.enable &&
					this.affectRangeCells != null)
				{
					BattleGridHelper.StopHighlight(this.affectRangeCells, GridHighlightType.AffectRange);
					this.affectRangeCells.Clear();
				}
				// stop selection highlight
				this.StopSelectedCellHighlight();

				ORK.BattleSystem.gridSettings.SelectedCell = cell;
				ArrayHelper.GetBlank<Combatant>(ref this.availableTargets);

				// new highlights
				if(ORK.BattleSystem.gridSettings.SelectedCell != null)
				{
					if(this.cameraControlTarget && !isHover)
					{
						ORK.Control.SetCameraControlTarget(ORK.BattleSystem.gridSettings.SelectedCell.gameObject,
							this.ownControlTargetTransition ? this.controlTargetTransition : null);
					}

					// rotation
					if(this.rotateToCell)
					{
						ORK.BattleSystem.gridSettings.RotateToSelectedCell(this.gridRotation);

						// update use range
						if(this.useRangeCells != null &&
							this.useRangeCells.Count > 0)
						{
							BattleGridHelper.StopHighlight(this.useRangeCells, GridHighlightType.UseRange);
						}
						ArrayHelper.GetBlank<BattleGridCellComponent>(ref this.useRangeCells);
						if(this.targetSettings != null)
						{
							this.targetSettings.GetUseRangeCells(
								ORK.BattleSystem.gridSettings.SelectingCombatant,
								ref this.useRangeCells, null);
							BattleGridHelper.Highlight(this.useRangeCells, GridHighlightType.UseRange);
						}
					}

					if(this.useRangeCells.Contains(ORK.BattleSystem.gridSettings.SelectedCell))
					{
						ArrayHelper.GetBlank<BattleGridCellComponent>(ref this.affectRangeCells);
						if(this.targetSettings != null)
						{
							this.targetSettings.GetAffectRangeCells(
								ORK.BattleSystem.gridSettings.SelectingCombatant,
								ORK.BattleSystem.gridSettings.SelectedCell,
								ref this.affectRangeCells, null);
						}
						if(ORK.BattleSystem.gridHighlights.affectRangeHighlight.enable)
						{
							BattleGridHelper.Highlight(this.affectRangeCells, GridHighlightType.AffectRange);
						}
						if(ORK.BattleSystem.gridHighlights.targetCellSelectionHighlight.enable)
						{
							BattleGridHelper.Highlight(ORK.BattleSystem.gridSettings.SelectedCell,
								ORK.BattleSystem.gridHighlights.GetSelectionHighlight(
									GridHighlightType.TargetCellSelection, ORK.BattleSystem.gridSettings.SelectedCell));
						}

						// available targets
						for(int i = 0; i < this.affectRangeCells.Count; i++)
						{
							if(this.affectRangeCells[i] != null &&
								!this.affectRangeCells[i].IsEmpty)
							{
								this.affectRangeCells[i].GetCombatants(ref this.availableTargets, this.canTarget);
							}
						}
					}
					else if(ORK.BattleSystem.gridHighlights.noTargetCellSelectionHighlight.enable)
					{
						BattleGridHelper.Highlight(ORK.BattleSystem.gridSettings.SelectedCell,
							ORK.BattleSystem.gridHighlights.GetSelectionHighlight(
								GridHighlightType.NoTargetCellSelection, ORK.BattleSystem.gridSettings.SelectedCell));
					}
				}
				else
				{
					this.ResetCameraControlTarget();
				}

				if(this.examineCell ||
					this.examineCellCombatant)
				{
					ORK.BattleSystem.gridSettings.examine.ExternalExamine(
						ORK.BattleSystem.gridSettings.SelectedCell,
						this.examineCell, this.examineCellCombatant);
				}

				ORK.GUI.ForcedPreviewShortcut = new PreviewSelection(
					ORK.BattleSystem.gridSettings.SelectingCombatant,
					this.availableTargets, this.shortcut);
				ORK.BattleSettings.ShowTargetInformation(
					ORK.BattleSystem.gridSettings.SelectingCombatant,
					this.availableTargets, this.shortcut);
			}
		}

		public void AcceptCell(BattleGridCellComponent cell)
		{
			if(this.CheckAcceptCell(cell))
			{
				this.CloseInfoBox();
				this.canSelect = false;

				if(ORK.BattleSystem.gridSettings.SelectedCell != cell)
				{
					this.SelectCell(cell, true);
				}
				if(this.showAcceptQuestion)
				{
					this.acceptQuestion.Show(
						ORK.BattleSystem.gridSettings.SelectingCombatant.GetName(),
						this.AcceptQuestionClosed);
				}
				else
				{
					this.UseSelectedCell();
				}
			}
			else
			{
				this.SelectCell(cell, true);
			}
		}

		public void AcceptQuestionClosed(bool accepted)
		{
			if(accepted)
			{
				this.UseSelectedCell();
			}
			else
			{
				this.ShowInfoBox();
				this.canSelect = true;
			}
		}

		public bool CheckAcceptCell(BattleGridCellComponent cell)
		{
			return cell != null &&
				this.useRangeCells.Contains(cell);
		}
	}
}
