
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ControlMap : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of the control map.", "")]
		[ORKEditorInfo("Control Map Settings", "Define the name, battle system availability, control keys and actions of this control map.", "",
			expandWidth=true)]
		public string name = "";


		// audio settings
		[ORKEditorHelp("Success Clip", "Select the audio clip that will be played when successfully using a control map key.", "")]
		[ORKEditorInfo(separator=true, labelText="Audio Settings")]
		public AudioClip successClip;

		[ORKEditorHelp("Volume (Success)", "The volume used to play the success clip (between 0 and 1).", "")]
		[ORKEditorLayout("successClip", null, elseCheckGroup=true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float successVolume = 1;

		[ORKEditorHelp("Fail Clip", "Select the audio clip that will be played when failing to use any control map key.", "")]
		public AudioClip failClip;

		[ORKEditorHelp("Volume (Fail)", "The volume used to play the fail clip (between 0 and 1).", "")]
		[ORKEditorLayout("failClip", null, elseCheckGroup=true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float failVolume = 1;


		// system types
		[ORKEditorHelp("Field", "Available in the field (i.e. outside of battles).", "")]
		[ORKEditorInfo(separator=true, labelText="Useable In")]
		public bool field = false;

		public BattleSystemCheck battleSystemCheck = new BattleSystemCheck();

		[ORKEditorHelp("While Choosing", "The control map will be available while the combatant's battle menu is active.\n" +
			"If disabled, the control map will only be available if no battle menu is active.", "")]
		public bool whileChoosing = false;

		[ORKEditorHelp("While Auto Attacking", "The control map will be available while the combatant is using an auto attack.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool whileAutoAttacking = false;


		// requirements
		[ORKEditorHelp("Use Requirements", "Use status requirements and game variable conditions.", "")]
		[ORKEditorInfo("Requirements", "Using this control map can depend on status requirements and " +
			"game variable conditions.\n" +
			"The combatant using the control map is used for status checks and object game variables.", "")]
		public bool useRequirements = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useRequirements", true, endCheckGroup=true, autoInit=true)]
		public SimpleCombatantRequirement requirement;


		// keys
		[ORKEditorInfo(separator=true)]
		[ORKEditorArray(false, "Add Control Key", "Add a control key to this control map.", "",
			"Remove", "Remove this control key", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {"Control Key", "A control key can trigger a battle action.\n" +
			"Define the key and action in this settings.\n" +
			"You can have multiple controls on the same key, the first action that can be performed will be performed.\n" +
			"E.g. have multiple refreshing items on the same key, the first item which is in the inventory will be used.", ""},
			typeCheckField="selection", removeCheckField="useID")]
		public ControlMapKey[] controlKey = new ControlMapKey[0];


		// ingame
		private bool blocked = false;

		public ControlMap()
		{

		}

		public ControlMap(string name)
		{
			this.name = name;
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			if(data.Contains<bool>("turnBased"))
			{
				this.battleSystemCheck.SetData(data);
			}
		}


		/*
		============================================================================
		Control functions
		============================================================================
		*/
		public bool Tick(Combatant combatant)
		{
			if(!this.blocked &&
				this.controlKey.Length > 0 &&
				(combatant.Actions.ActionState == CombatantActionState.Available ||
					(this.whileAutoAttacking && combatant.Actions.AutoAttacking)) &&
				// requirements
				(!this.useRequirements || this.requirement.Check(combatant)) &&
				// in field
				((!combatant.Battle.InBattle && this.field &&
					(!ORK.Control.Blocked || (this.whileChoosing && combatant.Actions.IsChoosing))) ||
				// in battle
				(combatant.Battle.InBattle && ORK.Control.InBattle &&
					ORK.Battle.IsBattleRunning() && this.battleSystemCheck.Check() &&
					// combatant can perform actions
					(this.whileAutoAttacking || !combatant.Actions.AutoAttacking) &&
					((this.whileChoosing && combatant.Actions.IsChoosing) ||
						combatant.Actions.CanChoose))))
			{
				bool any = false;
				for(int i = 0; i < this.controlKey.Length; i++)
				{
					if(this.controlKey[i].KeyValid(combatant))
					{
						any = true;
						if(this.controlKey[i].PerformAction(combatant))
						{
							if(this.controlKey[i].ownSuccessClip)
							{
								if(this.controlKey[i].successClip != null)
								{
									ORK.Audio.PlayOneShot(this.controlKey[i].successClip,
										this.controlKey[i].successVolume * ORK.Game.SoundVolume);
								}
							}
							else if(this.successClip != null)
							{
								ORK.Audio.PlayOneShot(this.successClip,
									this.successVolume * ORK.Game.SoundVolume);
							}
							return true;
						}
					}
				}
				if(any &&
					this.failClip != null)
				{
					ORK.Audio.PlayOneShot(this.failClip,
						this.failVolume * ORK.Game.SoundVolume);
				}
			}
			return false;
		}

		public bool Blocked
		{
			get { return this.blocked; }
			set { this.blocked = value; }
		}
	}
}
