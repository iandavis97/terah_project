
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Formulas
{
	public class FormulaFloat : BaseData
	{
		[ORKEditorHelp("Value Type", "Select which kind of value will be used:\n" +
			"- Value: A defined value.\n" +
			"- Game Variable: The value of a game variable (float).\n" +
			"- Player Prefs: The value of a PlayerPrefs (int or float) variable.\n" +
			"- Formula: The result of a formula (using this formula's user and target).\n" +
			"- Game Time: The current game time in seconds (time since 'New Game').\n" +
			"- Time Of Day: The current real time since midnight in seconds.\n" +
			"- Date And Time: The current real date and time in seconds (since 1-1-1970).\n" +
			"- Random: A random value between two defined values.\n" +
			"- Current Value: The current value of the formula.", "")]
		public FormulaFloatType type = FormulaFloatType.Value;


		// variable and player prefs
		[ORKEditorHelp("Variable Key", "The key (name) of the game variable (float) or PlayerPrefs that contains the value.", "")]
		[ORKEditorInfo(expandWidth=true, isVariableField=true)]
		[ORKEditorLayout(new string[] {"type", "type"},
			new System.Object[] {FormulaFloatType.GameVariable, FormulaFloatType.PlayerPrefs},
			needed=Needed.One, endCheckGroup=true)]
		public string name = "";

		[ORKEditorHelp("Is Int", "The value will be taken from an Integer PlayerPrefs (using GetInt).\n" +
			"If disabled, the value will be taken from a Float PlayerPrefs (using GetFloat).", "")]
		[ORKEditorLayout("type", FormulaFloatType.PlayerPrefs, endCheckGroup=true)]
		public bool isInt = false;

		// variable origin
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used while calculating a formula and don't interfere with global variables. " +
			"The variable will be gone once the formula finished calculating.\n" +
			"When a formula is called from an event, the local variables are shared with the event and " +
			"will also be available in the running event (until the event ends)." +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.\n" +
			"- Selected: Variables assigned to selected data coming from an event.\n" +
			"When coming from a battle event, the variables are usually assigned to the ability or item of the action.\n" +
			"Only available when the formula was initially called by an event.", "")]
		[ORKEditorLayout("type", FormulaFloatType.GameVariable)]
		public VariableOrigin variableOrigin = VariableOrigin.Global;

		[ORKEditorHelp("Multi Value Use", "Select how values of multiple variable sources will be used:\n" +
			"- First: Use the first available value.\n" +
			"- Lowest: Use the lowest available value.\n" +
			"- Highest: Use the highest available value.\n" +
			"- Average: Use the average of all available values.\n" +
			"- Add: Sum all available values (i.e. value1 + value 2 + value3 ...).\n" +
			"- Sub: Subtract all available values (i.e. value1 - value2 - value3 ...).\n" +
			"- Multiply: Multiply all available values (i.e. value1 * value2 * value3 ...).\n" +
			"- Divide: Divide all available values (i.e. value1 / value2 / value3 ...).", "")]
		[ORKEditorLayout("variableOrigin", VariableOrigin.Selected)]
		public MultiFloatValueUse multiVariableUseType = MultiFloatValueUse.First;

		[ORKEditorInfo(labelText="Selected Key")]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public StringValue selectedKey;

		[ORKEditorLayout("variableOrigin", VariableOrigin.Object, endCheckGroup=true, endGroups=2, autoInit=true)]
		public FormulaStatusOrigin origin;


		// formula
		[ORKEditorHelp("Formula", "Select the formula used for calculation.", "")]
		[ORKEditorInfo(ORKDataType.Formula)]
		[ORKEditorLayout("type", FormulaFloatType.Formula)]
		public int id = 0;

		[ORKEditorHelp("Initial Value", "The initial value passed to the formula.\n" +
			"The formula will use the initial value as it's base and start the calculation with that value.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float initialValue = 0;


		// game time offset
		[ORKEditorHelp("Time Offset (s)", "The offset time in seconds that will be added to the current game time.", "")]
		[ORKEditorLayout(new string[] {"type", "type", "type"},
			new System.Object[] {FormulaFloatType.GameTime, FormulaFloatType.TimeOfDay, FormulaFloatType.DateAndTime},
			needed=Needed.One, endCheckGroup=true)]
		public float offset = 0;

		[ORKEditorHelp("Is UTC", "The date and time are in UTC format.\n" +
			"If disabled, the local date and time is used.", "")]
		[ORKEditorLayout("type", FormulaFloatType.DateAndTime, endCheckGroup=true)]
		public bool isUTC = false;


		// value
		[ORKEditorHelp("Value", "Define the value that will be used.", "")]
		[ORKEditorLayout(new string[] {"type", "type"},
			new System.Object[] {FormulaFloatType.Value, FormulaFloatType.Random},
			needed=Needed.One, endCheckGroup=true)]
		public float value = 0;

		[ORKEditorHelp("Value 2", "Define the value that will be used.", "")]
		[ORKEditorLimit("value", false)]
		[ORKEditorLayout("type", FormulaFloatType.Random, endCheckGroup=true)]
		public float value2 = 0;

		public FormulaFloat()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useObjectVariable"))
			{
				bool tmpObjVar = false;
				data.Get("useObjectVariable", ref tmpObjVar);
				if(tmpObjVar)
				{
					this.variableOrigin = VariableOrigin.Object;
				}
			}
		}


		/*
		============================================================================
		Value functions
		============================================================================
		*/
		public float GetValue(FormulaCall call)
		{
			if(FormulaFloatType.Value == this.type)
			{
				return this.value;
			}
			else if(FormulaFloatType.GameVariable == this.type)
			{
				if(VariableOrigin.Local == this.variableOrigin)
				{
					return call.Variables.GetFloat(this.name);
				}
				else if(VariableOrigin.Global == this.variableOrigin)
				{
					return ORK.Game.Variables.GetFloat(this.name);
				}
				else if(VariableOrigin.Object == this.variableOrigin)
				{
					Combatant combatant = this.origin.GetCombatant(call);
					if(combatant != null && combatant.GameObject != null)
					{
						ObjectVariablesComponent comp = ComponentHelper.
							GetInChildren<ObjectVariablesComponent>(combatant.GameObject);
						if(comp != null)
						{
							return comp.GetHandler().GetFloat(this.name);
						}
					}
				}
				else if(VariableOrigin.Selected == this.variableOrigin)
				{
					return VariableHandler.GetMultiFloat(this.name,
						SelectedDataHelper.GetVariableHandlers(
							call.SelectedData.Get(this.selectedKey.GetValue())),
						this.multiVariableUseType);
				}
			}
			else if(FormulaFloatType.PlayerPrefs == this.type)
			{
				if(this.isInt)
				{
					return PlayerPrefs.GetInt(this.name);
				}
				else
				{
					return PlayerPrefs.GetFloat(this.name);
				}
			}
			else if(FormulaFloatType.Formula == this.type)
			{
				return ORK.Formulas.Get(this.id).Calculate(
					new FormulaCall(this.initialValue,
						call.user, call.target,
						call.Variables, call.SelectedData));
			}
			else if(FormulaFloatType.GameTime == this.type)
			{
				return ORK.Game.GameTime + this.offset;
			}
			else if(FormulaFloatType.TimeOfDay == this.type)
			{
				return (float)(System.DateTime.Now.TimeOfDay.TotalSeconds) + this.offset;
			}
			else if(FormulaFloatType.DateAndTime == this.type)
			{
				return (float)((System.DateTime.Now - new System.DateTime(1970, 1, 1, 0, 0, 0)).TotalSeconds) +
					this.offset;
			}
			else if(FormulaFloatType.Random == this.type)
			{
				return UnityWrapper.Range(this.value, this.value2);
			}
			else if(FormulaFloatType.CurrentValue == this.type)
			{
				return call.result;
			}
			return 0;
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			if(FormulaFloatType.Value == this.type)
			{
				return this.value.ToString();
			}
			else if(FormulaFloatType.GameVariable == this.type)
			{
				return this.name + "(" +
					(VariableOrigin.Object == this.variableOrigin ?
						this.origin.GetInfoText() :
						this.variableOrigin.ToString()) + ")";
			}
			else if(FormulaFloatType.Formula == this.type)
			{
				return ORK.Formulas.GetName(this.id);
			}
			else if(FormulaFloatType.GameTime == this.type)
			{
				return "Game time + " + this.offset;
			}
			else if(FormulaFloatType.TimeOfDay == this.type)
			{
				return "Real time since midnight + " + this.offset;
			}
			else if(FormulaFloatType.DateAndTime == this.type)
			{
				return "Real date/time + " + this.offset;
			}
			else if(FormulaFloatType.Random == this.type)
			{
				return this.value.ToString() + "~" + this.value2.ToString();
			}
			else if(FormulaFloatType.CurrentValue == this.type)
			{
				return "Current Formula Value";
			}
			return this.name;
		}
	}
}
