﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridHighlight : BaseData
	{
		[ORKEditorHelp("Use Highlight", "Use this cell highlight.", "")]
		public bool enable = false;


		// highlight settings
		[ORKEditorHelp("Own Highlight Settings", "This grid highlight defines its own highlight settings.\n" +
			"If disabled, a selected base highlight will be used.", "")]
		[ORKEditorLayout("enable", true)]
		public bool ownHighlight = false;

		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("ownHighlight", true, autoInit=true)]
		public BaseGridHighlight highlight;

		[ORKEditorHelp("Base Highlight", "Select which base highlight will be used:\n" +
			"- Area: The area highlight.\n" +
			"- Selection: The selection highlight.\n" +
			"- No Selection: The no selection highlight.", "")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public BaseGridHighlightType baseType = BaseGridHighlightType.Area;

		public GridHighlight()
		{

		}

		public GridHighlight(BaseGridHighlightType baseType)
		{
			this.baseType = baseType;
		}

		public BaseGridHighlight HighlightSetting
		{
			get
			{
				if(this.ownHighlight)
				{
					return this.highlight;
				}
				else if(BaseGridHighlightType.Area == this.baseType)
				{
					return ORK.BattleSystem.gridHighlights.areaHighlight;
				}
				else if(BaseGridHighlightType.Selection == this.baseType)
				{
					return ORK.BattleSystem.gridHighlights.selectionHighlight;
				}
				else if(BaseGridHighlightType.NoSelection == this.baseType)
				{
					return ORK.BattleSystem.gridHighlights.noSelectionHighlight;
				}
				return null;
			}
		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public void Tick(float t)
		{
			if(this.enable && this.ownHighlight)
			{
				this.highlight.Tick(t);
			}
		}

		public void GetColorFade(ref float time, ref bool reverting)
		{
			this.HighlightSetting.GetColorFade(ref time, ref reverting);
		}


		public void Highlight(BattleGridCellComponent cell)
		{
			if(this.enable && cell != null)
			{
				this.HighlightSetting.Highlight(cell);
			}
		}

		public void StopHighlight(BattleGridCellComponent cell)
		{
			if(this.enable && cell != null)
			{
				this.HighlightSetting.StopHighlight(cell);
			}
		}


		/*
		============================================================================
		Line renderer functions
		============================================================================
		*/
		public void AddLineCell(BattleGridCellComponent cell, GridHighlightType type)
		{
			if(this.enable)
			{
				this.HighlightSetting.AddLineCell(cell, type);
			}
		}

		public void AddLineCells(List<BattleGridCellComponent> cells, GridHighlightType type)
		{
			if(this.enable)
			{
				this.HighlightSetting.AddLineCells(cells, type);
			}
		}

		public void RemoveLineCell(BattleGridCellComponent cell, GridHighlightType type)
		{
			if(this.enable)
			{
				this.HighlightSetting.RemoveLineCell(cell, type);
			}
		}

		public void RemoveLineCells(List<BattleGridCellComponent> cells, GridHighlightType type)
		{
			if(this.enable)
			{
				this.HighlightSetting.RemoveLineCells(cells, type);
			}
		}
	}
}
