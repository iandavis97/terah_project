
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class BackBMItem : BMItem
	{
		public BackBMItem(ChoiceContent content)
		{
			this.content = content;
		}

		public override bool Accepted(Combatant owner)
		{
			if(owner.BattleMenu != null)
			{
				owner.BattleMenu.Back();
				return true;
			}
			return false;
		}
	}
}
