
using System.Collections.Generic;

namespace ORKFramework
{
	public class DeathAction : BaseAction
	{
		public bool natural = true;

		public bool cancelDeath = false;

		public DeathAction(Combatant user)
		{
			this.user = user;
			this.target = user.Battle.GetAttackedBy();

			this.consumeTime = false;

			this.CheckActionAffiliation();
		}

		public DeathAction(Combatant user, bool natural) : this(user)
		{
			this.natural = natural;
		}

		public override bool IsType(ActionType t)
		{
			return ActionType.Death == t;
		}


		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		public override bool CanUse()
		{
			return this.user != null;
		}

		public override void ActionAdded()
		{
			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleAddDeath)
				{
					this.user.Setting.consoleAddDeath.Print(this.user);
				}
				else
				{
					ORK.ConsoleSettings.actionAddDeath.Print(this.user);
				}
			}
		}

		protected override void ActionStartSetup()
		{
			if(ORK.BattleTexts.showInfo)
			{
				ORK.BattleTexts.deathInfo.Show(this.user, "");
			}

			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleDeath)
				{
					this.user.Setting.consoleDeath.Print(this.user);
				}
				else
				{
					ORK.ConsoleSettings.actionDeath.Print(this.user);
				}
			}

			this.user.GetDeathEvent(ref this.events);
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate)
		{
			if(!this.blockBattleCamera &&
				!ORK.BattleSettings.camera.IsNone &&
				!ORK.BattleSettings.camera.latestDamageActionBlock.IsBlocked(this))
			{
				if(ts.Count == 1 &&
					ts[0] != null &&
					ts[0].GameObject != null)
				{
					ORK.BattleSettings.camera.SetLatestDamage(
						this.user.GameObject != null ? this.user.GameObject.transform : null,
						ts[0].GameObject.transform);
				}
				else if(ts.Count > 1)
				{
					ORK.BattleSettings.camera.SetLatestDamage(
						this.user.GameObject != null ? this.user.GameObject.transform : null,
						ORK.Battle.GetGroupCenter(ts).transform);
				}
			}

			if(this.user != null)
			{
				if(animate)
				{
					this.user.Animations.Play(ORK.AnimationTypes.deathID);
				}
				this.userConsumeDone = true;
			}
		}

		protected override void ActionEndSetup()
		{
			this.user.Abilities.LastAbilityID = -1;
			if(!this.cancelDeath)
			{
				this.user.Died();
			}
		}
	}
}
