﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CubeCoord : BaseData
	{
		public int x = 0;

		public int y = 0;

		public int z = 0;

		public CubeCoord()
		{

		}

		public CubeCoord(int x, int y, int z)
		{
			this.x = x;
			this.y = y;
			this.z = z;
		}

		public CubeCoord(CubeCoord coord)
		{
			this.x = coord.x;
			this.y = coord.y;
			this.z = coord.z;
		}

		public bool IsZero
		{
			get { return this.x == 0 && this.y == 0 && this.z == 0; }
		}

		public override string ToString()
		{
			return "(x=" + this.x + ",y=" + this.y + ",z=" + this.z + ")";
		}

		public override bool Equals(object obj)
		{
			if(obj is CubeCoord)
			{
				CubeCoord other = (CubeCoord)obj;
				return other.x == this.x &&
					other.y == this.y &&
					other.z == this.z;
			}
			return false;
		}

		public override int GetHashCode()
		{
			unchecked
			{
				int hash = 17;
				hash = hash * 23 + this.x.GetHashCode();
				hash = hash * 23 + this.y.GetHashCode();
				hash = hash * 23 + this.z.GetHashCode();
				return hash;
			}
		}


		/*
		============================================================================
		Get offset functions
		============================================================================
		*/
		public void ToOffset(ref int row, ref int column)
		{
			if(BattleGridType.Square == ORK.Battle.Settings.gridSettings.type)
			{
				row = this.x;
				column = this.y;
			}
			else if(BattleGridType.Hexagonal == ORK.Battle.Settings.gridSettings.type)
			{
				if(HexagonalGridType.HorizontalEven == ORK.Battle.Settings.gridSettings.hexagonalType)
				{
					this.TotHorizontalEven(ref row, ref column);
				}
				else if(HexagonalGridType.HorizontalOdd == ORK.Battle.Settings.gridSettings.hexagonalType)
				{
					this.TotHorizontalOdd(ref row, ref column);
				}
				else if(HexagonalGridType.VerticalEven == ORK.Battle.Settings.gridSettings.hexagonalType)
				{
					this.ToVerticalEven(ref row, ref column);
				}
				else if(HexagonalGridType.VerticalOdd == ORK.Battle.Settings.gridSettings.hexagonalType)
				{
					this.ToVerticalOdd(ref row, ref column);
				}
			}
		}

		public void TotHorizontalEven(ref int row, ref int column)
		{
			column = this.x + (this.z + (this.z % 2)) / 2;
			row = this.z;
		}

		public void TotHorizontalOdd(ref int row, ref int column)
		{
			column = this.x + (this.z - (this.z % 2)) / 2;
			row = this.z;
		}

		public void ToVerticalEven(ref int row, ref int column)
		{
			column = this.x;
			row = this.z + (this.x + (this.x % 2)) / 2;
		}

		public void ToVerticalOdd(ref int row, ref int column)
		{
			column = this.x;
			row = this.z + (this.x - (this.x % 2)) / 2;
		}


		/*
		============================================================================
		Conversion functions
		============================================================================
		*/
		public static CubeCoord FromOffset(int row, int column)
		{
			if(BattleGridType.Square == ORK.Battle.Settings.gridSettings.type)
			{
				return new CubeCoord(row, column, 0);
			}
			else
			{
				CubeCoord cube = new CubeCoord();

				if(BattleGridType.Hexagonal == ORK.Battle.Settings.gridSettings.type)
				{
					if(HexagonalGridType.HorizontalEven == ORK.Battle.Settings.gridSettings.hexagonalType)
					{
						cube.x = column - (row + (row & 1)) / 2;
						cube.z = row;
						cube.y = -cube.x - cube.z;
					}
					else if(HexagonalGridType.HorizontalOdd == ORK.Battle.Settings.gridSettings.hexagonalType)
					{
						cube.x = column - (row - (row % 2)) / 2;
						cube.z = row;
						cube.y = -cube.x - cube.z;
					}
					else if(HexagonalGridType.VerticalEven == ORK.Battle.Settings.gridSettings.hexagonalType)
					{
						cube.x = column;
						cube.z = row - (column + (column % 2)) / 2;
						cube.y = -cube.x - cube.z;
					}
					else if(HexagonalGridType.VerticalOdd == ORK.Battle.Settings.gridSettings.hexagonalType)
					{
						cube.x = column;
						cube.z = row - (column - (column % 2)) / 2;
						cube.y = -cube.x - cube.z;
					}
				}
				return cube;
			}
		}

		public static CubeCoord FromVerticalOdd(int row, int column)
		{
			CubeCoord cube = new CubeCoord();
			cube.x = column;
			cube.z = row - (column - (column % 2)) / 2;
			cube.y = -cube.x - cube.z;
			return cube;
		}

		public Vector3 ToVector3()
		{
			return new Vector3(this.x, this.y, this.z);
		}

		public static CubeCoord FromVector3(Vector3 value)
		{
			return new CubeCoord((int)value.x, (int)value.y, (int)value.z);
		}


		/*
		============================================================================
		Distance functions
		============================================================================
		*/
		public int Distance(CubeCoord target)
		{
			return BattleGridHelper.Helper.Distance(this, target);
		}

		public int Distance(CubeCoord target, bool blockDiagonalDistance1)
		{
			return BattleGridHelper.Helper.Distance(this, target, blockDiagonalDistance1);
		}

		public static bool IsSquareDiagonal(CubeCoord origin, CubeCoord target)
		{
			return (Mathf.Abs(origin.x - target.x) - Mathf.Abs(origin.y - target.y)) == 0;
		}

		public static int ZeroDistanceSquareDiagonal(int x, int y)
		{
			return Mathf.Max(Mathf.Abs(x), Mathf.Abs(y));
		}

		public static int ZeroDistanceSquareNonDiagonal(int x, int y)
		{
			return Mathf.Abs(x) + Mathf.Abs(y);
		}

		public static int ZeroDistanceHexagonal(int x, int y, int z)
		{
			return (Mathf.Abs(x) +
				Mathf.Abs(y) +
				Mathf.Abs(z)) / 2;
		}


		/*
		============================================================================
		Rotation functions
		============================================================================
		*/
		public CubeCoord Rotate(int turns)
		{
			return BattleGridHelper.Helper.Rotate(this, turns);
		}


		/*
		============================================================================
		Operators
		============================================================================
		*/
		public void SetAdd(CubeCoord set, CubeCoord add)
		{
			this.x = set.x + add.x;
			this.y = set.y + add.y;
			this.z = set.z + add.z;
		}

		public void SetAdd(CubeCoord set, int x, int y, int z)
		{
			this.x = set.x + x;
			this.y = set.y + y;
			this.z = set.z + z;
		}

		public void Set(CubeCoord other)
		{
			this.x = other.x;
			this.y = other.y;
			this.z = other.z;
		}

		public void Set(int x, int y, int z)
		{
			this.x = x;
			this.y = y;
			this.z = z;
		}

		public void Add(CubeCoord other)
		{
			this.x += other.x;
			this.y += other.y;
			this.z += other.z;
		}

		public void Add(int x, int y, int z)
		{
			this.x += x;
			this.y += y;
			this.z += z;
		}

		public void Scale(int scale)
		{
			this.x *= scale;
			this.y *= scale;
			this.z *= scale;
		}

		public static CubeCoord operator +(CubeCoord c1, CubeCoord c2)
		{
			return new CubeCoord(c1.x + c2.x, c1.y + c2.y, c1.z + c2.z);
		}

		public static CubeCoord operator -(CubeCoord c1, CubeCoord c2)
		{
			return new CubeCoord(c1.x - c2.x, c1.y - c2.y, c1.z - c2.z);
		}

		public static CubeCoord operator *(CubeCoord c, int scale)
		{
			return new CubeCoord(c.x * scale, c.y * scale, c.z * scale);
		}

		public static bool operator ==(CubeCoord c1, CubeCoord c2)
		{
			if(object.ReferenceEquals(c1, null))
			{
				return object.ReferenceEquals(c2, null);
			}
			else if(object.ReferenceEquals(c2, null))
			{
				return object.ReferenceEquals(c1, null);
			}
			return c1.x == c2.x && c1.y == c2.y && c1.z == c2.z;
		}

		public static bool operator !=(CubeCoord c1, CubeCoord c2)
		{
			if(object.ReferenceEquals(c1, null))
			{
				return !object.ReferenceEquals(c2, null);
			}
			else if(object.ReferenceEquals(c2, null))
			{
				return !object.ReferenceEquals(c1, null);
			}
			return c1.x != c2.x || c1.y != c2.y || c1.z != c2.z;
		}


		/*
		============================================================================
		Math functions
		============================================================================
		*/
		public static CubeCoord Round(Vector3 coord)
		{
			int rx = Mathf.RoundToInt(coord.x);
			int ry = Mathf.RoundToInt(coord.y);
			int rz = Mathf.RoundToInt(coord.z);

			float x_diff = Mathf.Abs(rx - coord.x);
			float y_diff = Mathf.Abs(ry - coord.y);
			float z_diff = Mathf.Abs(rz - coord.z);

			if(x_diff > y_diff && x_diff > z_diff)
			{
				rx = -ry - rz;
			}
			else if(y_diff > z_diff)
			{
				ry = -rx - rz;
			}
			else
			{
				rz = -rx - ry;
			}

			return new CubeCoord(rx, ry, rz);
		}

		public static Vector3 Lerp(CubeCoord origin, CubeCoord target, float time)
		{
			return new Vector3(
				origin.x + (target.x - origin.x) * time,
				origin.y + (target.y - origin.y) * time,
				origin.z + (target.z - origin.z) * time);
		}

		public static Vector3 Lerp(CubeCoord origin, Vector3 target, float time)
		{
			return new Vector3(
				origin.x + (target.x - origin.x) * time,
				origin.y + (target.y - origin.y) * time,
				origin.z + (target.z - origin.z) * time);
		}
	}
}
