﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public static class BattleGridGenerator
	{
		public static void Generate(BattleGridComponent gridComponent)
		{
			if(ORK.BattleSystem.gridSettings.IsSquare)
			{
				BattleGridGenerator.CreateSquare(gridComponent);
			}
			else if(ORK.BattleSystem.gridSettings.IsHorizontalHex)
			{
				BattleGridGenerator.CreateHexagonalHorizontal(gridComponent);
			}
			else if(ORK.BattleSystem.gridSettings.IsVerticalHex)
			{
				BattleGridGenerator.CreateHexagonalVertical(gridComponent);
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public static Vector3 GetGridStartPosition(BattleGridComponent gridComponent,
			float rowReduction, float columnReduction, Vector2 cellSize)
		{
			Vector3 position = gridComponent.transform.position;

			// column/horizontal
			if(TextAnchor.UpperCenter == gridComponent.positionAnchor ||
				TextAnchor.MiddleCenter == gridComponent.positionAnchor ||
				TextAnchor.LowerCenter == gridComponent.positionAnchor)
			{
				position.x -= ((gridComponent.columns - columnReduction) / 2.0f) * cellSize.x;
			}
			else if(TextAnchor.UpperRight == gridComponent.positionAnchor ||
				TextAnchor.MiddleRight == gridComponent.positionAnchor ||
				TextAnchor.LowerRight == gridComponent.positionAnchor)
			{
				position.x -= (gridComponent.columns - columnReduction) * cellSize.x;
			}

			// row/vertical
			if(TextAnchor.MiddleLeft == gridComponent.positionAnchor ||
				TextAnchor.MiddleCenter == gridComponent.positionAnchor ||
				TextAnchor.MiddleRight == gridComponent.positionAnchor)
			{
				position.z += ((gridComponent.rows - rowReduction) / 2.0f) * cellSize.y;
			}
			else if(TextAnchor.LowerLeft == gridComponent.positionAnchor ||
				TextAnchor.LowerCenter == gridComponent.positionAnchor ||
				TextAnchor.LowerRight == gridComponent.positionAnchor)
			{
				position.z += (gridComponent.rows - rowReduction) * cellSize.y;
			}

			return position;
		}

		public static void CreateCell(int row, int column, Vector3 position, BattleGridComponent gridComponent)
		{
			GameObject cellObject = new GameObject("Cell " + row + ", " + column);
			gridComponent.cellRow[row].cell[column] = cellObject.AddComponent<BattleGridCellComponent>();
			gridComponent.cellRow[row].cell[column].Init(gridComponent, row, column);

			RaycastOutput hit;
			if(RaycastHelper.Raycast(position + gridComponent.raySourceOffset,
				-Vector3.up, out hit, gridComponent.rayDistance, gridComponent.rayLayerMask))
			{
				if(gridComponent.useBlockedType &&
					gridComponent.blockedTypeSlope < Vector3.Angle(hit.normal, Vector3.up))
				{
					gridComponent.cellRow[row].cell[column].cellTypeID = gridComponent.blockedCellTypeID;
					if(gridComponent.useSlope)
					{
						gridComponent.cellRow[row].cell[column].transform.SetPositionAndRotation(
							hit.point + gridComponent.rayHitOffset,
							Quaternion.FromToRotation(Vector3.up, hit.normal));
					}
					else
					{
						gridComponent.cellRow[row].cell[column].transform.position = hit.point + gridComponent.rayHitOffset;
					}
				}
				else
				{
					gridComponent.cellRow[row].cell[column].cellTypeID = gridComponent.cellTypeID;
					if(gridComponent.useSlope)
					{
						gridComponent.cellRow[row].cell[column].transform.SetPositionAndRotation(
							hit.point + gridComponent.rayHitOffset,
							Quaternion.FromToRotation(Vector3.up, hit.normal));
					}
					else
					{
						gridComponent.cellRow[row].cell[column].transform.position = hit.point + gridComponent.rayHitOffset;
					}
				}
			}
			else
			{
				gridComponent.cellRow[row].cell[column].cellTypeID = gridComponent.emptyCellTypeID;
				gridComponent.cellRow[row].cell[column].transform.position = position;
			}
			cellObject.transform.SetParent(gridComponent.transform);
		}


		/*
		============================================================================
		Square grid functions
		============================================================================
		*/
		public static void CreateSquare(BattleGridComponent gridComponent)
		{
			Vector2 cellOffset = ORK.BattleSystem.gridSettings.CellOffset;
			Vector3 position = BattleGridGenerator.GetGridStartPosition(gridComponent, 1, 1, cellOffset);
			gridComponent.cellRow = new BattleGridCellRow[gridComponent.rows];

			for(int row = 0; row < gridComponent.rows; row++)
			{
				gridComponent.cellRow[row] = new BattleGridCellRow(gridComponent.columns);

				for(int column = 0; column < gridComponent.columns; column++)
				{
					BattleGridGenerator.CreateCell(row, column,
						new Vector3(
							position.x + column * cellOffset.x,
							position.y,
							position.z - row * cellOffset.y),
						gridComponent);
				}
			}
		}


		/*
		============================================================================
		Hexagonal grid functions
		============================================================================
		*/
		public static void CreateHexagonalHorizontal(BattleGridComponent gridComponent)
		{
			Vector2 cellOffset = ORK.BattleSystem.gridSettings.CellOffset;
			Vector3 position = BattleGridGenerator.GetGridStartPosition(gridComponent, 1, 0.5f, cellOffset);
			gridComponent.cellRow = new BattleGridCellRow[gridComponent.rows];

			int modFactor = HexagonalGridType.HorizontalEven == ORK.BattleSystem.gridSettings.hexagonalType ?
				1 : 0;

			for(int row = 0; row < gridComponent.rows; row++)
			{
				gridComponent.cellRow[row] = new BattleGridCellRow(gridComponent.columns);

				float rowMod = (row + modFactor) % 2;

				for(int column = 0; column < gridComponent.columns; column++)
				{
					BattleGridGenerator.CreateCell(row, column,
						new Vector3(
							position.x + (column + (rowMod * 0.5f)) * cellOffset.x,
							position.y,
							position.z - row * cellOffset.y),
						gridComponent);
				}
			}
		}

		public static void CreateHexagonalVertical(BattleGridComponent gridComponent)
		{
			Vector2 cellOffset = ORK.BattleSystem.gridSettings.CellOffset;
			Vector3 position = BattleGridGenerator.GetGridStartPosition(gridComponent, 0.5f, 1, cellOffset);
			gridComponent.cellRow = new BattleGridCellRow[gridComponent.rows];

			int modFactor = HexagonalGridType.VerticalEven == ORK.BattleSystem.gridSettings.hexagonalType ?
				1 : 0;

			for(int row = 0; row < gridComponent.rows; row++)
			{
				gridComponent.cellRow[row] = new BattleGridCellRow(gridComponent.columns);

				for(int column = 0; column < gridComponent.columns; column++)
				{
					float colMod = (column + modFactor) % 2;
					BattleGridGenerator.CreateCell(row, column,
						new Vector3(
							position.x + column * cellOffset.x,
							position.y,
							position.z - (row + (colMod * 0.5f)) * cellOffset.y),
						gridComponent);
				}
			}
		}
	}
}
