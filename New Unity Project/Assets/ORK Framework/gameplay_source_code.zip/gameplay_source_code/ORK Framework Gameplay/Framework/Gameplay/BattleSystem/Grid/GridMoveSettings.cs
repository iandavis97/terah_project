﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public enum ConsiderFormationCombatants { None, All, IgnoreFormation }

	public class GridMoveSettings : BaseData
	{
		[ORKEditorHelp("Move Type", "Select how the combatant will move:\n" +
			"- Move Toward Target: Moves near a target on the battle grid.\n" +
			"- Flee From Target: Moves away from the target to the cell with the biggest grid distance.\n" +
			"- Random: Moves to a random cell within move range.\n" +
			"- Grid Formation: Moves to the combatant's grid formation position " +
			"(only if part of a formation and not on the position's cell).\n" +
			"- Grid Cell Type: Moves to the nearest or farthest cell of a defined grid cell type.", "")]
		public AIGridMove moveType = AIGridMove.MoveTowardTarget;


		// move toward target
		[ORKEditorHelp("Target Cell", "Select which cell will be moved to:\n" +
			"- Nearest: The nearest cell (to the moving combatant).\n" +
			"- North: A cell north of the target (global space).\n" +
			"- East: A cell east of the target (global space).\n" +
			"- South: A cell south of the target (global space).\n" +
			"- West: A cell west of the target (global space).\n" +
			"- Front: A cell in front of the target (local space).\n" +
			"- Back: A cell in the back of the target (local space).\n" +
			"- Left: A cell left of the target (local space).\n" +
			"- Right: A cell right of the target (local space).", "")]
		[ORKEditorLayout("moveType", AIGridMove.MoveTowardTarget)]
		public AIGridMoveTargetType targetType = AIGridMoveTargetType.Nearest;

		[ORKEditorHelp("Ignore Blocking Combatants", "Ignore combatants that are blocking the path.\n" +
			"They'll still block the path, i.e. you can't move over them, " +
			"but the path will still be used, going as far as possible.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool ignoreBlockingCombatants = false;


		// grid cell type
		[ORKEditorHelp("Nearest/Farthest", "Moves toward the nearest cell of the defined grid cell types.\n" +
			"If disabled, moves toward the farthest cell of the defined grid cell types.", "")]
		[ORKEditorLayout("moveType", AIGridMove.GridCellType)]
		public bool gridCellTypeNearest = true;

		[ORKEditorHelp("From Target", "The grid cell types are searched from the target (e.g. nearest cell to the target).\n" +
			"If disabled, they're searched from the user.", "")]
		public bool gridCellTypeFromTarget = false;

		[ORKEditorHelp("Use Distance", "Only use cells within a defined grid distance to the user/target.", "")]
		public bool gridCellTypeUseDistance = false;

		[ORKEditorHelp("Minimum Distance", "The minimum grid distance a cell can have to the user/target to be used.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("gridCellTypeUseDistance", true)]
		public int gridCellTypeMinDistance = 1;

		[ORKEditorHelp("Maximum Distance", "The maximum grid distance a cell can have to the user/target to be used.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int gridCellTypeMaxDistance = 1;

		[ORKEditorHelp("Grid Cell Type", "Select the grid cell type that will be used.", "")]
		[ORKEditorInfo(ORKDataType.BattleGridCellType, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Grid Cell Type", "Adds a grid cell type that will be used.", "",
			"Remove", "Removes the grid cell type.", "", isHorizontal=true, noRemoveCount=1)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int[] gridCellTypeID = new int[1];


		// consider formation (all but formation move)
		[ORKEditorHelp("Consider Formation", "If the user is the leader of a grid formation, " +
			"the formation positions will be considered when moving.\n" +
			"The user will move to a position along the path that allows all formation positions to not be blocked cells.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("moveType", AIGridMove.GridFormation, elseCheckGroup=true)]
		public bool considerGridFormation = false;

		[ORKEditorHelp("Check Combatants", "Select if combatants blocking a cell will also prevent a formation from being placed:\n" +
			"- None: Combatants will not be checked.\n" +
			"- All: All combatants can block the formation.\n" +
			"- Ignore Formation: Combatants that are part of the formation are ignored, others can block the formation.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("considerGridFormation", true)]
		public ConsiderFormationCombatants considerGridFormationCombatants = ConsiderFormationCombatants.None;

		[ORKEditorHelp("Check Reachable", "Checks if the formation position is within " +
			"move range of their combatants and if they can reach it.", "")]
		[ORKEditorInfo(indent=true)]
		public bool considerGridFormationReachable = true;

		[ORKEditorHelp("Same Cell Type", "Checks if all formation positions have the same cell type.", "")]
		[ORKEditorInfo(indent=true)]
		public bool considerGridFormationCellType = false;

		[ORKEditorHelp("Rotate To Target", "The grid formation will be checked rotated toward the target (if using the leader's rotation).\n" +
			"If disabled, the rotation from the last cell move will be used for the check.\n" +
			"Keep in mind that this doesn't change the rotation of the combatant at the end of the grid move.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public bool formationRotateToTarget = true;


		// move into formation
		[ORKEditorHelp("Move To Nearest", "Move to the nearest available cell if the cell of " +
			"the formation position is blocked or occupied.\n" +
			"If disabled, the combatant will not move if the cell is blocked or occupied.", "")]
		[ORKEditorLayout("moveType", AIGridMove.GridFormation, endCheckGroup=true)]
		public bool formationToNearest = true;


		// other settings
		[ORKEditorHelp("Block Diagonal Distance 1", "Diagonal cells around combatants in square grids will have a distance of 2 instead of 1 " +
			"(when 'Diagonal Distance 1' is enabled in the grid settings).\n" +
			"This forces the combatant to move to a non-diagonal cell around the target.", "")]
		public bool blockTargetDiagonalDistance1 = false;

		[ORKEditorHelp("In Move Range", "Limit movement to targets within move range.\n" +
			"If disabled, the user can also move toward targets outside of move range.", "")]
		public bool inMoveRange = false;

		[ORKEditorHelp("Direct Move Only", "Only move if the target cell can be reached directly.\n" +
			"'Reachable' will be executed next in case the cell is reachable, " +
			"but other conditions (e.g. grid formation) prevent directly moving on it.", "")]
		public bool directMoveOnly = false;

		[ORKEditorHelp("Mark Target Cell", "Mark the target cell to prevent other AI controlled combatants from moving on it.\n" +
			"This is only done if the combatant can't reach the target cell within one move.", "")]
		public bool markTargetCell = false;

		[ORKEditorHelp("No Move Over", "Moving over other combatants (if allowed) is ignored " +
			"when the found path results in not being able to move at all.\n" +
			"E.g. used if the path to a target cell is reachable, but the combatant can't move " +
			"due to all path cells being occupied by other combatants, it'll try to find a path around the combatants.", "")]
		public bool noMoveOver = false;


		// avoid settings
		[ORKEditorHelp("Avoid Enemies", "Avoid cells around enemies when moving to the target.", "")]
		[ORKEditorInfo(separator=true)]
		public bool avoidEnemies = false;

		[ORKEditorHelp("Avoid Allies", "Avoid cells around allies when moving to the target.", "")]
		public bool avoidAllies = false;

		[ORKEditorHelp("Ignore Avoided Cells", "Ignore avoided cells if no valid path is found when using them.", "")]
		[ORKEditorLayout(new string[] { "avoidEnemies", "avoidAllies" },
			new object[] { true, true },
			needed=Needed.One, endCheckGroup=true)]
		public bool ignoreAvoidedCells = false;

		[ORKEditorInfo("Avoid Enemies", "Optionally avoid cells around enemies when moving to a target.", "",
			endFoldout=true)]
		[ORKEditorLayout("avoidEnemies", true, endCheckGroup=true, autoInit=true)]
		public GridMoveDistanceSettings enemyAvoidRange;

		[ORKEditorInfo("Avoid Allies", "Optionally avoid cells around allies when moving to a target.", "",
			endFoldout=true)]
		[ORKEditorLayout("avoidAllies", true, endCheckGroup=true, autoInit=true)]
		public GridMoveDistanceSettings allyAvoidRange;


		// stop distance
		[ORKEditorInfo("Target Cell Settings", "Define which cells around the target are available to move to.\n" +
			"You need a cell that isn't the target's cell for a valid move target cell.", "")]
		[ORKEditorLayout("moveType", AIGridMove.MoveTowardTarget, endCheckGroup=true)]
		public GridMoveDistanceSettings targetCells = new GridMoveDistanceSettings();


		// enemy distance
		[ORKEditorHelp("Use Enemy Distance", "Only allow target cells that are a defined grid distance away from enemies.", "")]
		[ORKEditorInfo(separator=true, labelText="Distance To Enemies")]
		public bool useEnemyDistance = false;

		[ORKEditorHelp("Check Non-Direct Move", "If the user can't reach the target cell in one move (direct move), " +
			"the cell the combatant moves to must also match the enemy distance conditions.\n" +
			"If disabled, the enemy distance is only checked for the target cell.", "")]
		[ORKEditorLayout("useEnemyDistance", true)]
		public bool enemyDistanceCheckPath = false;

		[ORKEditorHelp("Minimum Distance", "The minimum grid distance a target cell must have to an enemy combatant.\n" +
			"The minimum distance is inclusive, i.e. cells within this distance to enemies are allowed.", "")]
		[ORKEditorLimit(1, false)]
		public int enemyDistanceMin = 1;

		[ORKEditorHelp("Use Maximum Distance", "Use a maximum grid distance an enemy must have to the target cell.", "")]
		public bool useEnemyDistanceMax = false;

		[ORKEditorHelp("Maximum Distance", "The maximum grid distance a target cell can have to an enemy combatant.\n" +
			"The maximum distance is inclusive, i.e. cells within this distance to enemies are allowed.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("useEnemyDistanceMax", true, endCheckGroup=true, endGroups=2)]
		public int enemyDistanceMax = 1;


		// line of sight
		[ORKEditorHelp("Use Line of Sight", "Use a line of sight between the center of the user's cell " +
			"and the center of the target cells to determine if they're available.", "")]
		[ORKEditorInfo(separator=true, labelText="Line of Sight")]
		[ORKEditorLayout("moveType", AIGridMove.GridCellType)]
		public bool useLineOfSight = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useLineOfSight", true, endCheckGroup=true, endGroups=2)]
		public GridLineOfSight lineOfSight = new GridLineOfSight();

		public GridMoveSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("stopDistance"))
			{
				int tmp = 1;
				data.Get("stopDistance", ref tmp);
				this.targetCells = new GridMoveDistanceSettings(tmp, tmp > 1);
			}
			if(data.Contains<int>("gridCellTypeDistance"))
			{
				data.Get("gridCellTypeDistance", ref this.gridCellTypeMaxDistance);
			}
		}

		public bool GetMoveAction(Combatant user, List<Combatant> targets,
			List<Combatant> allies, List<Combatant> enemies,
			out GridMoveAction action, GridMoveShortcut gridMoveShortcut)
		{
			action = null;

			// get action
			if(user.Grid.Cell != null &&
				user.Battle.GridMoveRange > 0 &&
				!user.Status.StopMove &&
				!user.Status.StopMovement &&
				user.Battle.GridMoveState == GridMoveState.Available)
			{
				// enemy distance check
				GridCellCheck enemyDistanceCheck = null;
				if(this.useEnemyDistance)
				{
					enemyDistanceCheck = delegate (BattleGridCellComponent cell)
					{
						for(int i = 0; i < enemies.Count; i++)
						{
							if(enemies[i] != null &&
								enemies[i].Grid.Cell != null)
							{
								int distance = cell.CubeCoord.Distance(enemies[i].Grid.Cell.CubeCoord);
								if(distance < this.enemyDistanceMin ||
									(this.useEnemyDistanceMax &&
										distance > this.enemyDistanceMax))
								{
									return false;
								}
							}
						}
						return true;
					};
				}

				// random move
				if(AIGridMove.Random == this.moveType)
				{
					List<BattleGridCellComponent> ignoreCells = this.GetIgnoreCells(user, allies, enemies);
					BattleGridPathFinder path = new BattleGridPathFinder(false, this.blockTargetDiagonalDistance1);

					BattleGridCellComponent targetCell = null;
					for(int i = 0; i < targets.Count; i++)
					{
						if(targets[i] != null &&
							targets[i].Grid.Cell != null)
						{
							targetCell = targets[i].Grid.Cell;
							break;
						}
					}

					if(this.DoMoveRandom(path, user, ignoreCells, out action,
						gridMoveShortcut, targetCell, enemyDistanceCheck))
					{
						if(action == null &&
							this.noMoveOver)
						{
							path.NoMoveOver = true;
							path.Clear();
							this.DoMoveRandom(path, user, ignoreCells, out action,
								gridMoveShortcut, targetCell, enemyDistanceCheck);
						}
						return true;
					}

					// ignore avoided cells
					if(this.ignoreAvoidedCells &&
						ignoreCells != null &&
						ignoreCells.Count > 0)
					{
						path.Clear();
						if(this.DoMoveRandom(path, user, null, out action,
							gridMoveShortcut, targetCell, enemyDistanceCheck))
						{
							if(action == null &&
								this.noMoveOver)
							{
								path.NoMoveOver = true;
								path.Clear();
								this.DoMoveRandom(path, user, null, out action,
									gridMoveShortcut, targetCell, enemyDistanceCheck);
							}
							return true;
						}
					}
				}
				// move toward target
				else if(AIGridMove.MoveTowardTarget == this.moveType)
				{
					if(targets.Count > 0)
					{
						List<BattleGridCellComponent> ignoreCells = this.GetIgnoreCells(user, allies, enemies);
						BattleGridPathFinder path = new BattleGridPathFinder(false, this.blockTargetDiagonalDistance1);

						// first try to find a valid path
						if(this.DoMoveToTarget(path, false, user, targets, ignoreCells,
							out action, gridMoveShortcut, enemyDistanceCheck))
						{
							if(action == null &&
								this.noMoveOver)
							{
								path.NoMoveOver = true;
								path.Clear();
								this.DoMoveToTarget(path, false, user, targets, ignoreCells,
									out action, gridMoveShortcut, enemyDistanceCheck);
							}
							return true;
						}
						// no valid path > try to find a blocked path
						if(this.ignoreBlockingCombatants)
						{
							path.Clear();
							if(this.DoMoveToTarget(path, true, user, targets, ignoreCells,
								out action, gridMoveShortcut, enemyDistanceCheck))
							{
								if(action == null &&
									this.noMoveOver)
								{
									path.NoMoveOver = true;
									path.Clear();
									this.DoMoveToTarget(path, true, user, targets, ignoreCells,
										out action, gridMoveShortcut, enemyDistanceCheck);
								}
								return true;
							}
						}

						// ignore avoided cells
						if(this.ignoreAvoidedCells &&
							ignoreCells != null &&
							ignoreCells.Count > 0)
						{
							// first try to find a valid path
							path.Clear();
							if(this.DoMoveToTarget(path, false, user, targets, null,
								out action, gridMoveShortcut, enemyDistanceCheck))
							{
								if(action == null &&
									this.noMoveOver)
								{
									path.NoMoveOver = true;
									path.Clear();
									this.DoMoveToTarget(path, false, user, targets, null,
										out action, gridMoveShortcut, enemyDistanceCheck);
								}
								return true;
							}
							// no valid path > try to find a blocked path
							if(this.ignoreBlockingCombatants)
							{
								path.Clear();
								if(this.DoMoveToTarget(path, true, user, targets, null,
									out action, gridMoveShortcut, enemyDistanceCheck))
								{
									if(action == null &&
										this.noMoveOver)
									{
										path.NoMoveOver = true;
										path.Clear();
										this.DoMoveToTarget(path, true, user, targets, null,
											out action, gridMoveShortcut, enemyDistanceCheck);
									}
									return true;
								}
							}
						}
					}
				}
				// flee from target
				else if(AIGridMove.FleeFromTarget == this.moveType)
				{
					List<BattleGridCellComponent> ignoreCells = this.GetIgnoreCells(user, allies, enemies);
					BattleGridPathFinder path = new BattleGridPathFinder(false, this.blockTargetDiagonalDistance1);

					if(this.DoFleeFromTarget(path, user, targets, ignoreCells,
						out action, gridMoveShortcut, enemyDistanceCheck))
					{
						if(action == null &&
							this.noMoveOver)
						{
							path.NoMoveOver = true;
							path.Clear();
							this.DoFleeFromTarget(path, user, targets, ignoreCells,
								out action, gridMoveShortcut, enemyDistanceCheck);
						}
						return true;
					}

					// ignore avoided cells
					if(this.ignoreAvoidedCells &&
						ignoreCells != null &&
						ignoreCells.Count > 0)
					{
						path.Clear();
						if(this.DoFleeFromTarget(path, user, targets, null,
							out action, gridMoveShortcut, enemyDistanceCheck))
						{
							if(action == null &&
								this.noMoveOver)
							{
								path.NoMoveOver = true;
								path.Clear();
								this.DoFleeFromTarget(path, user, targets, null,
									out action, gridMoveShortcut, enemyDistanceCheck);
							}
							return true;
						}
					}
				}
				// move into grid formation
				else if(AIGridMove.GridFormation == this.moveType)
				{
					if(user.Group.InFormation)
					{
						BattleGridCellComponent targetCell = user.Group.GridFormation.GetMoveToPositionCell(user);
						if(this.formationToNearest &&
							targetCell != null &&
							(targetCell.IsBlocked ||
								!targetCell.IsEmpty ||
								(targetCell.MarkedForAI != null &&
									targetCell.MarkedForAI != user) ||
								(enemyDistanceCheck != null && !enemyDistanceCheck(targetCell))))
						{
							targetCell = BattleGridHelper.GetNearestFreeCell(targetCell, user.Grid.Cell,
								ORK.BattleSystem.gridSettings.moveCommand.squareDiagonalMove, enemyDistanceCheck);
						}
						if(targetCell != null)
						{
							List<BattleGridCellComponent> ignoreCells = this.GetIgnoreCells(user, allies, enemies);
							BattleGridPathFinder path = new BattleGridPathFinder(false, this.blockTargetDiagonalDistance1);

							if(this.DoGridFormation(path, targetCell, user, ignoreCells,
								out action, gridMoveShortcut, enemyDistanceCheck))
							{
								if(action == null &&
										this.noMoveOver)
								{
									path.NoMoveOver = true;
									path.Clear();
									this.DoGridFormation(path, targetCell, user, ignoreCells,
										out action, gridMoveShortcut, enemyDistanceCheck);
								}
								return true;
							}

							// ignore avoided cells
							if(this.ignoreAvoidedCells &&
								ignoreCells != null &&
								ignoreCells.Count > 0)
							{
								path.Clear();
								if(this.DoGridFormation(path, targetCell, user, null,
									out action, gridMoveShortcut, enemyDistanceCheck))
								{
									if(action == null &&
										this.noMoveOver)
									{
										path.NoMoveOver = true;
										path.Clear();
										this.DoGridFormation(path, targetCell, user, null,
											out action, gridMoveShortcut, enemyDistanceCheck);
									}
									return true;
								}
							}
						}
					}
				}
				// move to grid cell type
				else if(AIGridMove.GridCellType == this.moveType)
				{
					GridCellCheck check = delegate (BattleGridCellComponent cell)
					{
						return (user.Grid.Cell == cell || BattleGridHelper.IsFreeCell(cell)) &&
							(enemyDistanceCheck == null || enemyDistanceCheck(cell));
					};

					if(this.gridCellTypeFromTarget)
					{
						List<BattleGridCellComponent> ignoreCells = this.GetIgnoreCells(user, allies, enemies);
						BattleGridPathFinder path = new BattleGridPathFinder(false, this.blockTargetDiagonalDistance1);

						for(int i = 0; i < targets.Count; i++)
						{
							if(targets[i] != null &&
								targets[i].Grid.Cell != null)
							{
								if(this.useLineOfSight)
								{
									check = delegate (BattleGridCellComponent cell)
									{
										if(cell == null ||
											!BattleGridHelper.CheckLineOfSight(user, targets[i].Grid.Cell,
												cell, this.lineOfSight.BlocksLineOfSight,
												this.lineOfSight.visibleCellArea))
										{
											return false;
										}
										if((user.Grid.Cell == cell || BattleGridHelper.IsFreeCell(cell)) &&
											(enemyDistanceCheck == null || enemyDistanceCheck(cell)))
										{
											return true;
										}
										return false;
									};
								}

								// target cells
								List<BattleGridCellComponent> availableCells = this.gridCellTypeUseDistance ?
									BattleGridHelper.GetCellsOfType(targets[i].Grid.Cell, this.gridCellTypeID,
										this.gridCellTypeMinDistance, this.gridCellTypeMaxDistance, false, false, false,
										!this.blockTargetDiagonalDistance1, check) :
									BattleGridHelper.GetCellsOfType(ORK.Battle.Grid, this.gridCellTypeID, check);
								availableCells.Sort(new GridDistanceSorter(targets[i].Grid.Cell, !this.gridCellTypeNearest));

								if(this.DoGridCellType(path, user, availableCells, ignoreCells,
									targets[i].Grid.Cell, out action, gridMoveShortcut, enemyDistanceCheck))
								{
									if(action == null &&
										this.noMoveOver)
									{
										path.NoMoveOver = true;
										path.Clear();
										this.DoGridCellType(path, user, availableCells, ignoreCells,
											targets[i].Grid.Cell, out action, gridMoveShortcut, enemyDistanceCheck);
									}
									return true;
								}

								// ignore avoided cells
								if(this.ignoreAvoidedCells &&
									ignoreCells != null &&
									ignoreCells.Count > 0)
								{
									path.Clear();
									if(this.DoGridCellType(path, user, availableCells, null,
										targets[i].Grid.Cell, out action, gridMoveShortcut, enemyDistanceCheck))
									{
										if(action == null &&
											this.noMoveOver)
										{
											path.NoMoveOver = true;
											path.Clear();
											this.DoGridCellType(path, user, availableCells, null,
												targets[i].Grid.Cell, out action, gridMoveShortcut, enemyDistanceCheck);
										}
										return true;
									}
								}
							}
						}
					}
					else
					{
						if(this.gridCellTypeNearest &&
							BattleGridHelper.IsCellType(user.Grid.Cell, this.gridCellTypeID))
						{
							return true;
						}

						if(this.useLineOfSight)
						{
							check = delegate (BattleGridCellComponent cell)
							{
								if(cell == null ||
									!BattleGridHelper.CheckLineOfSight(user, user.Grid.Cell,
											cell, this.lineOfSight.BlocksLineOfSight,
											this.lineOfSight.visibleCellArea))
								{
									return false;
								}
								return (user.Grid.Cell == cell || BattleGridHelper.IsFreeCell(cell)) &&
									(enemyDistanceCheck == null || enemyDistanceCheck(cell));
							};
						}

						List<BattleGridCellComponent> ignoreCells = this.GetIgnoreCells(user, allies, enemies);
						BattleGridPathFinder path = new BattleGridPathFinder(false, this.blockTargetDiagonalDistance1);

						// target cells
						List<BattleGridCellComponent> availableCells = this.gridCellTypeUseDistance ?
							BattleGridHelper.GetCellsOfType(user.Grid.Cell, this.gridCellTypeID,
								this.gridCellTypeMinDistance, this.gridCellTypeMaxDistance, false, false, false,
								!this.blockTargetDiagonalDistance1, check) :
							BattleGridHelper.GetCellsOfType(ORK.Battle.Grid, this.gridCellTypeID, check);
						availableCells.Sort(new GridDistanceSorter(user.Grid.Cell, !this.gridCellTypeNearest));

						BattleGridCellComponent targetCell = targets.Count > 0 ? targets[0].Grid.Cell : null;

						if(this.DoGridCellType(path, user, availableCells, ignoreCells,
							targetCell, out action, gridMoveShortcut, enemyDistanceCheck))
						{
							if(action == null &&
								this.noMoveOver)
							{
								path.NoMoveOver = true;
								path.Clear();
								this.DoGridCellType(path, user, availableCells, ignoreCells,
									targetCell, out action, gridMoveShortcut, enemyDistanceCheck);
							}
							return true;
						}

						// ignore avoided cells
						if(this.ignoreAvoidedCells &&
							ignoreCells != null &&
							ignoreCells.Count > 0)
						{
							path.Clear();
							if(this.DoGridCellType(path, user, availableCells, null,
								targetCell, out action, gridMoveShortcut, enemyDistanceCheck))
							{
								if(action == null &&
									this.noMoveOver)
								{
									path.NoMoveOver = true;
									path.Clear();
									this.DoGridCellType(path, user, availableCells, null,
										targetCell, out action, gridMoveShortcut, enemyDistanceCheck);
								}
								return true;
							}
						}
					}
				}
			}
			return false;
		}

		private bool DoMoveRandom(BattleGridPathFinder path,
			Combatant user, List<BattleGridCellComponent> ignoreCells,
			out GridMoveAction action, GridMoveShortcut gridMoveShortcut,
			BattleGridCellComponent targetCell, GridCellCheck enemyDistanceCheck)
		{
			bool canReach = false;
			action = null;

			if(this.considerGridFormation &&
				user.Group.InFormation &&
				user.Group.GridFormation.Leader == user)
			{
				path.SetConsiderGridFormation(true, this.considerGridFormationCombatants,
					this.considerGridFormationReachable, this.considerGridFormationCellType);
			}

			if(!path.MoveRangeCreated)
			{
				path.CreateMoveRange(user,
					this.inMoveRange ? MoveRangeType.Current : MoveRangeType.All,
					ignoreCells, null);
			}

			if(path.availableTargets.Count > 0)
			{
				BattleGridCellComponent cell = null;
				while(cell == null &&
					path.availableTargets.Count > 0)
				{
					cell = path.availableTargets[UnityWrapper.Range(0, path.availableTargets.Count)];
					if(cell != null &&
						(enemyDistanceCheck == null || enemyDistanceCheck(cell)))
					{
						BattleGridCellComponent reachableCell = path.GetLastReachablePathCell(
							cell, this.directMoveOnly, ref canReach,
							this.formationRotateToTarget ? targetCell : null, ignoreCells, null,
							this.enemyDistanceCheckPath ? enemyDistanceCheck : null);

						if(canReach &&
							reachableCell != null &&
							user.Grid.Cell != reachableCell)
						{
							action = path.GetMoveAction(reachableCell, gridMoveShortcut, null);
							if(this.markTargetCell &&
								cell != reachableCell)
							{
								cell.MarkedForAI = user;
							}
							else
							{
								user.Grid.CellMarkedForAI = null;
							}
							return true;
						}
					}
					path.availableTargets.Remove(cell);
				}
			}
			return canReach;
		}

		private bool DoMoveToTarget(BattleGridPathFinder path, bool ignoreCombatants, Combatant user,
			List<Combatant> targets, List<BattleGridCellComponent> ignoreCells,
			out GridMoveAction action, GridMoveShortcut gridMoveShortcut, GridCellCheck enemyDistanceCheck)
		{
			bool canReach = false;
			action = null;
			BattleGridCellComponent cell = null;
			GridCellCheck newCheck = ignoreCombatants ?
				enemyDistanceCheck :
				delegate(BattleGridCellComponent checkCell)
				{
					return (user.Grid.Cell == checkCell ||
							BattleGridHelper.IsFreeCell(checkCell)) &&
						(enemyDistanceCheck == null || enemyDistanceCheck(checkCell));
				};
			path.IgnoreBlockingCombatants = ignoreCombatants;

			if(this.considerGridFormation &&
				user.Group.InFormation &&
				user.Group.GridFormation.Leader == user)
			{
				path.SetConsiderGridFormation(true, this.considerGridFormationCombatants,
					this.considerGridFormationReachable, this.considerGridFormationCellType);
			}

			List<BattleGridCellComponent> availableCells = null;

			for(int i = 0; i < targets.Count; i++)
			{
				if(targets[i] != null &&
					targets[i].Grid.Cell != null)
				{
					// get target cells
					ArrayHelper.GetBlank(ref availableCells);
					this.targetCells.GetCells(user, targets[i].Grid.Cell, newCheck,
						!this.blockTargetDiagonalDistance1, ref availableCells);

					if(availableCells.Count > 0)
					{
						availableCells.Sort(new GridDistanceSorter(targets[i].Grid.Cell, user.Grid.Cell, false));

						if(availableCells[0] == user.Grid.Cell)
						{
							return true;
						}

						BattleGridHelper.FilterTargetCells(user.Grid.Cell, targets[i].Grid.Cell,
							ref availableCells, this.targetType);
					}

					if(availableCells.Count > 0)
					{
						if(ignoreCells != null &&
							ignoreCells.Count > 0)
						{
							path.Clear();
						}

						// create move range
						if(!path.MoveRangeCreated)
						{
							path.CreateMoveRange(user,
								this.inMoveRange ? MoveRangeType.Current : MoveRangeType.All,
								ignoreCells, availableCells);
						}

						for(int j = 0; j < availableCells.Count; j++)
						{
							if(availableCells[j] != null)
							{
								if(user.Grid.Cell == availableCells[j])
								{
									return true;
								}
								cell = path.GetLastReachablePathCell(
									availableCells[j], this.directMoveOnly, ref canReach,
									this.formationRotateToTarget ? targets[i].Grid.Cell : null, ignoreCells, availableCells,
									this.enemyDistanceCheckPath ? enemyDistanceCheck : null);

								if(canReach &&
									cell != null &&
									user.Grid.Cell != cell)
								{
									action = path.GetMoveAction(cell, gridMoveShortcut, targets[i]);
									if(this.markTargetCell &&
										availableCells[j] != cell)
									{
										availableCells[j].MarkedForAI = user;
									}
									else
									{
										user.Grid.CellMarkedForAI = null;
									}
									return true;
								}
							}
						}
					}
				}
			}
			return canReach;
		}

		private bool DoFleeFromTarget(BattleGridPathFinder path, Combatant user,
			List<Combatant> targets, List<BattleGridCellComponent> ignoreCells,
			out GridMoveAction action, GridMoveShortcut gridMoveShortcut,
			GridCellCheck enemyDistanceCheck)
		{
			bool canReach = false;
			action = null;

			if(this.considerGridFormation &&
				user.Group.InFormation &&
				user.Group.GridFormation.Leader == user)
			{
				path.SetConsiderGridFormation(true, this.considerGridFormationCombatants,
					this.considerGridFormationReachable, this.considerGridFormationCellType);
			}

			for(int i = 0; i < targets.Count; i++)
			{
				if(targets[i] != null &&
					targets[i].Grid.Cell != null)
				{
					if(!path.MoveRangeCreated)
					{
						path.CreateMoveRange(user,
							this.inMoveRange ? MoveRangeType.Current : MoveRangeType.All,
							ignoreCells, null);
					}

					BattleGridCellComponent cell = path.GetMostDistantCell(targets[i].Grid.Cell, enemyDistanceCheck);
					if(cell != null)
					{
						BattleGridCellComponent reachableCell = path.GetLastReachablePathCell(
							cell, this.directMoveOnly, ref canReach,
							this.formationRotateToTarget ? targets[i].Grid.Cell : null, ignoreCells, null,
							this.enemyDistanceCheckPath ? enemyDistanceCheck : null);

						if(canReach &&
							reachableCell != null &&
							user.Grid.Cell != reachableCell)
						{
							action = path.GetMoveAction(reachableCell, gridMoveShortcut, targets[i]);
							if(this.markTargetCell &&
								cell != reachableCell)
							{
								cell.MarkedForAI = user;
							}
							else
							{
								user.Grid.CellMarkedForAI = null;
							}
							return true;
						}
					}
				}
			}
			return canReach;
		}

		private bool DoGridFormation(BattleGridPathFinder path, BattleGridCellComponent targetCell,
			Combatant user, List<BattleGridCellComponent> ignoreCells,
			out GridMoveAction action, GridMoveShortcut gridMoveShortcut, GridCellCheck enemyDistanceCheck)
		{
			bool canReach = false;
			action = null;
			if(!path.MoveRangeCreated)
			{
				path.CreateMoveRange(user,
					this.inMoveRange ? MoveRangeType.Current : MoveRangeType.All,
					ignoreCells, null);
			}

			BattleGridCellComponent cell = path.GetLastReachablePathCell(
				targetCell, this.directMoveOnly, ref canReach, null, null, null,
				this.enemyDistanceCheckPath ? enemyDistanceCheck : null);

			if(canReach)
			{
				if(cell != null &&
					user.Grid.Cell != cell)
				{
					action = path.GetMoveAction(cell, gridMoveShortcut, null);
					if(this.markTargetCell &&
						targetCell != cell)
					{
						targetCell.MarkedForAI = user;
					}
					else
					{
						user.Grid.CellMarkedForAI = null;
					}
					return true;
				}
			}
			return canReach;
		}

		private bool DoGridCellType(BattleGridPathFinder path, Combatant user,
			List<BattleGridCellComponent> targetCells, List<BattleGridCellComponent> ignoreCells,
			BattleGridCellComponent targetCell, out GridMoveAction action,
			GridMoveShortcut gridMoveShortcut, GridCellCheck enemyDistanceCheck)
		{
			bool canReach = false;
			action = null;

			if(this.considerGridFormation &&
				user.Group.InFormation &&
				user.Group.GridFormation.Leader == user)
			{
				path.SetConsiderGridFormation(true, this.considerGridFormationCombatants,
					this.considerGridFormationReachable, this.considerGridFormationCellType);
			}

			if(!path.MoveRangeCreated)
			{
				path.CreateMoveRange(user,
					this.inMoveRange ? MoveRangeType.Current : MoveRangeType.All,
					ignoreCells, null);
			}

			for(int i = 0; i < targetCells.Count; i++)
			{
				if(targetCells[i] != null)
				{
					if(targetCells[i].IsEmpty &&
						(targetCells[i].MarkedForAI == null ||
							targetCells[i].MarkedForAI == user))
					{
						BattleGridCellComponent cell = path.GetLastReachablePathCell(
							targetCells[i], this.directMoveOnly, ref canReach,
							this.formationRotateToTarget ? targetCell : null, ignoreCells, null,
							this.enemyDistanceCheckPath ? enemyDistanceCheck : null);

						if(canReach)
						{
							if(cell != null &&
								user.Grid.Cell != cell)
							{
								action = path.GetMoveAction(cell, gridMoveShortcut, null);
								if(this.markTargetCell &&
									targetCells[i] != cell)
								{
									targetCells[i].MarkedForAI = user;
								}
								else
								{
									user.Grid.CellMarkedForAI = null;
								}
								return true;
							}
						}
					}
					else if(user.Grid.Cell == targetCells[i])
					{
						return true;
					}
				}
			}
			return canReach;
		}

		private List<BattleGridCellComponent> GetIgnoreCells(Combatant user, List<Combatant> allies, List<Combatant> enemies)
		{
			// avoid ranges
			List<BattleGridCellComponent> ignoreCells = null;
			if(this.avoidAllies)
			{
				if(allies == null)
				{
					allies = ORK.Game.Combatants.Get(user, true, Range.Battle,
						Consider.No, Consider.Ignore, Consider.Ignore, null);
				}
				if(allies.Count > 0)
				{
					if(ignoreCells == null)
					{
						ignoreCells = new List<BattleGridCellComponent>();
					}
					for(int i = 0; i < allies.Count; i++)
					{
						if(allies[i] != null &&
							allies[i] != user &&
							allies[i].Grid.Cell != null)
						{
							this.enemyAvoidRange.GetCells(user, allies[i].Grid.Cell, null,
								!this.blockTargetDiagonalDistance1, ref ignoreCells);
						}
					}
				}
			}
			if(this.avoidEnemies)
			{
				if(enemies == null)
				{
					enemies = ORK.Game.Combatants.Get(user, true, Range.Battle,
						Consider.Yes, Consider.Ignore, Consider.Ignore, null);
				}
				if(enemies.Count > 0)
				{
					if(ignoreCells == null)
					{
						ignoreCells = new List<BattleGridCellComponent>();
					}
					for(int i = 0; i < enemies.Count; i++)
					{
						if(enemies[i] != null &&
							enemies[i] != user &&
							enemies[i].Grid.Cell != null)
						{
							this.enemyAvoidRange.GetCells(user, enemies[i].Grid.Cell, null,
								!this.blockTargetDiagonalDistance1, ref ignoreCells);
						}
					}
				}
			}
			return ignoreCells;
		}

		public override string ToString()
		{
			if(AIGridMove.MoveTowardTarget == this.moveType)
			{
				return "Move toward target (" + this.targetType + ")";
			}
			else if(AIGridMove.FleeFromTarget == this.moveType)
			{
				return "Flee from target";
			}
			else if(AIGridMove.Random == this.moveType)
			{
				return "Random";
			}
			else if(AIGridMove.GridFormation == this.moveType)
			{
				return "Grid formation";
			}
			else if(AIGridMove.GridFormation == this.moveType)
			{
				return "Grid cell type";
			}
			return "";
		}
	}
}
