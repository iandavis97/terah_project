﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public enum BattleGridFormationLeaderDeath { Keep, Break, Select };

	public class BattleGridFormationLeader : BaseData
	{
		[ORKEditorHelp("Is Group Leader", "The leader of the group will be the formation leader.\n" +
			"If disabled, the combatant that used the formation will be the formation leader.", "")]
		[ORKEditorInfo(instanceCallback="editor:GridFormationChange")]
		public bool isGroupLeader = true;

		[ORKEditorHelp("Local Space", "The formation is defined in local space of the leader.", "")]
		public bool isLocalSpace = true;


		// leader death
		[ORKEditorHelp("Leader Death", "Select what happens with the formation when the leader dies:\n" +
			"- Keep: The dead combatant will remain the leader of the formation. " +
			"The formation ends if the leader is removed from the group.\n" +
			"- Break: The formation ends.\n" +
			"- Select: A new leader is selected (optionally based on requirements). " +
			"The formation ends if no new leader is found.", "")]
		[ORKEditorInfo(separator=true)]
		public BattleGridFormationLeaderDeath onDeath = BattleGridFormationLeaderDeath.Keep;

		[ORKEditorHelp("From Positions", "Use a combatant from positions if no other combatant is available.", "")]
		[ORKEditorLayout("onDeath", BattleGridFormationLeaderDeath.Select)]
		public bool fromPositions = false;

		[ORKEditorHelp("Ignore Requirements", "Ignore the requirements if no combatant is found.\n" +
			"The formation will end if no combatant is found.", "")]
		public bool ignoreRequirements = true;


		// new leader requirements
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public SimpleCombatantRequirement newLeaderRequirement;


		// placement in editor
		[ORKEditorInfo(hide=true)]
		public int row = -1;

		[ORKEditorInfo(hide=true)]
		public int column = -1;

		public BattleGridFormationLeader()
		{

		}

		public BattleGridFormationLeader(int row, int column)
		{
			this.row = row;
			this.column = column;
		}
	}
}
