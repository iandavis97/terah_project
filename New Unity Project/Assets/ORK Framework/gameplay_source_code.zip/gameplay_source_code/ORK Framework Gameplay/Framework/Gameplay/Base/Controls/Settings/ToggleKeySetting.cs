﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ToggleKeySetting : BaseData
	{
		[ORKEditorHelp("Start Toggle State", "If enabled, the toggle state will be on when starting the game.\n" +
			"If disabled, the toggle state will be off when starting the game.\n" +
			"When using 'Only While Key', the toggle state will be inversed, " +
			"i.e. if enabled, the toggle state will be on when the input key is not valid, " +
			"if disabled, the toggle state will be on when the input key is valid.", "")]
		public bool toggleStartState = true;

		[ORKEditorHelp("Use Toggle Key", "Use a toggle key", "")]
		public bool useKey = false;

		[ORKEditorHelp("Toggle Key", "Select the input key used to toggle on/off.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("useKey", true)]
		public int keyID = 0;

		[ORKEditorHelp("Only While Key", "The toggle state is only changed while the selected toggle input key " +
			"is valid and returned to the original state when the key is invalid " +
			"(e.g. use a 'Hold' input key to have the key valid while holding it).\n" +
			"This depends on the 'Start Toggle State' setting, i.e. " +
			"if enabled, the toggle state will be on when the input key is not valid, " +
			"if disabled, the toggle state will be on when the input key is valid.", "")]
		public bool onlyWhileKey = false;


		// audio settings
		[ORKEditorHelp("Audio Clip", "Select the audio clip that will be played when using the toggle key.", "")]
		[ORKEditorLayout(autoInit=true)]
		public AssetSource<AudioClip> audioClip;

		[ORKEditorHelp("Volume", "The volume used to play the audio clip (between 0 and 1).", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float volume = 1;

		public ToggleKeySetting()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(this.useKey &&
				data.Contains<AudioClip>("audioClip"))
			{
				this.audioClip = new AssetSource<AudioClip>();
				this.audioClip.Upgrade(data, "audioClip");
			}
		}

		public void GetToggleState(ref bool state)
		{
			if(this.useKey)
			{
				if(this.onlyWhileKey)
				{
					bool newState = state;
					if(this.toggleStartState)
					{
						newState = !ORK.InputKeys.Get(this.keyID).GetButton();
					}
					else
					{
						newState = ORK.InputKeys.Get(this.keyID).GetButton();
					}
					if(state != newState)
					{
						this.PlayClip();
						state = newState;
					}
				}
				else if(ORK.InputKeys.Get(this.keyID).GetButton())
				{
					this.PlayClip();
					state = !state;
				}
			}
		}

		public void PlayClip()
		{
			ORK.PlaySound(this.audioClip, this.volume);
		}
	}
}
