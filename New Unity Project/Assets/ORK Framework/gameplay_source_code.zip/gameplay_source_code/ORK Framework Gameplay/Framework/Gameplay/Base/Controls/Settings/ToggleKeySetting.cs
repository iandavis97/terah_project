﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ToggleKeySetting : BaseData
	{
		[ORKEditorHelp("Use Toggle Key", "Use a toggle key", "")]
		public bool useKey = false;

		[ORKEditorHelp("Start Toggle State", "If enabled, the toggle state will be on when starting the game.\n" +
			"If disabled, the toggle state will be off when starting the game.\n" +
			"When using 'Only While Key', the toggle state will be inversed, " +
			"i.e. if enabled, the toggle state will be on when the input key is not valid, " +
			"if disabled, the toggle state will be on when the input key is valid.", "")]
		[ORKEditorLayout("useKey", true)]
		public bool toggleStartState = true;

		[ORKEditorHelp("Toggle Key", "Select the input key used to toggle on/off.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int keyID = 0;

		[ORKEditorHelp("Only While Key", "The toggle state is only changed while the selected toggle input key " +
			"is valid and returned to the original state when the key is invalid " +
			"(e.g. use a 'Hold' input key to have the key valid while holding it).\n" +
			"This depends on the 'Start Toggle State' setting, i.e. " +
			"if enabled, the toggle state will be on when the input key is not valid, " +
			"if disabled, the toggle state will be on when the input key is valid.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool onlyWhileKey = false;

		public ToggleKeySetting()
		{

		}

		public void GetToggleState(ref bool state)
		{
			if(this.useKey)
			{
				if(this.onlyWhileKey)
				{
					if(this.toggleStartState)
					{
						state = ORK.InputKeys.Get(this.keyID).GetButton();
					}
					else
					{
						state = !ORK.InputKeys.Get(this.keyID).GetButton();
					}
				}
				else if(ORK.InputKeys.Get(this.keyID).GetButton())
				{
					state = !state;
				}
			}
		}
	}
}
