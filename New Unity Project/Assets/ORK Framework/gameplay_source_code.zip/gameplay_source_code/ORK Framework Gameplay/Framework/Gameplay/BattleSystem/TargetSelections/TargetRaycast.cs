
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TargetRaycast : BaseData
	{
		// raycast settings
		[ORKEditorHelp("Use Target Raycast", "Use a raycast to set the target (position) for an ability or item.\n" +
			"Use this setting for 'area of effect'-spells, etc.", "")]
		public bool active = false;

		[ORKEditorHelp("Distance", "The distance the raycast will use.\n" +
			"If nothing is hit within this distance, no target will be found.", "")]
		[ORKEditorLayout("active", true)]
		public float distance = 100.0f;

		[ORKEditorHelp("Layer Mask", "Select the layer the raycast will use.\n" +
			"Only objects on this layer can be hit by the raycast.", "")]
		public LayerMask layerMask = -1;

		[ORKEditorHelp("Ignore User", "The game object of the user of this ability/item will be ignored by the raycast.", "")]
		public bool ignoreUser = false;

		[ORKEditorHelp("Ray Origin", "The origin position of the raycast.\n" +
			"- User: The user of the ability/item is the origin.\n" +
			"- Screen: The screen is the origin. If you use mouse/touch control, " +
			"the point you clicked/touched the screen is the origin, otherwise the center of the screen.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75)]
		public TargetRayOrigin rayOrigin = TargetRayOrigin.User;

		[ORKEditorHelp("Path to Child", "You can define a child object of the user to be the origin.\n" +
			"Leave empty if you only want the user to be the origin.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("rayOrigin", TargetRayOrigin.User, endCheckGroup=true)]
		public string pathToChild = "";

		[ORKEditorHelp("Offset", "The offset will be added to the origin position of the raycast.", "")]
		public Vector3 offset = Vector3.zero;

		[ORKEditorHelp("Direction", "The direction in local space the raycast will be sent to.\n" +
			"E.g. X=0, Y=0, Z=1 will send the raycast forward.\n" +
			"This setting is only used when no mouse/touch control is enabled.", "")]
		[ORKEditorLayout(checkCallback="check:raydirection")]
		public Vector3 rayDirection = Vector3.forward;


		// control blocks
		[ORKEditorHelp("Block Player Control", "Block the player control while selecting the raycast target.", "")]
		[ORKEditorInfo(separator=true, labelText="Control Settings")]
		public bool blockPlayerControl = false;

		[ORKEditorHelp("Block Camera Control", "Block the camera control while selecting the raycast target.", "")]
		public bool blockCameraControl = false;

		[ORKEditorHelp("Rotate To Raycast", "Rotate the user to the raycast position during raycast targeting.", "")]
		public bool rotateToRaycast = false;


		// AI settings
		[ORKEditorHelp("Auto Target", "AI/Auto targeting will automatically target " +
			"a nearby combatant according to the target type.\n" +
			"If disabled (or no combatant available), the screen center will be used.", "")]
		[ORKEditorInfo(separator=true, labelText="AI/Auto Target Settings")]
		public bool autoTarget = true;

		[ORKEditorHelp("Path to Child", "If this ability/item is used by an AI controlled combatant, the raycast will " +
			"target a nearby combatant according to the target type.\n" +
			"You can define a child object of the target to be the raycast target.\n" +
			"Leave empty if you only want the target to be the raycast target.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("autoTarget", true)]
		public string pathToTarget = "";

		[ORKEditorHelp("Target Offset", "Offset added to the AI target position (nearby combatant).", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public Vector3 targetOffset = Vector3.zero;

		[ORKEditorHelp("Use Mouse Position", "Use the current mouse position instead of the screen center for targeting.", "")]
		public bool useMousePosition = false;

		[ORKEditorHelp("Only Player (Mouse)", "Use the mouse position only when the player is the user.", "")]
		[ORKEditorLayout("useMousePosition", true, endCheckGroup=true)]
		public bool mouseOnlyPlayer = true;

		[ORKEditorHelp("Screen Offset", "Offset added to the screen center or mouse position.", "")]
		public Vector3 screenOffset = Vector3.zero;


		// mouse/touch control
		[ORKEditorInfo("Mouse/Touch Control", "Input settings for mouse and touch control.", "",
			endFoldout=true, separatorForce=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public MouseTouchControl mouseTouch = new MouseTouchControl();


		// cursor settings
		// mouse cursor
		[ORKEditorInfo("Cursor Settings", "You can use a mouse cursor and cursor game object to visually display the raycast target selection.", "",
			"Mouse Cursor", "Optionally define a mouse cursor to change the displayed cursor during raycast target selection.\n" +
			"Using this cursor will override the target selection cursor settings in 'Menus > Menu Settings'.", "",
			endFoldout=true)]
		public CursorChange cursorChange = new CursorChange();

		// cursor object
		[ORKEditorHelp("Use Cursor", "A cursor game object is used to highlighted the raycast position.", "")]
		[ORKEditorInfo("Cursor Object", "A cursor game object can be used to highlight the raycast position.", "")]
		public bool useRayCursor = false;

		[ORKEditorHelp("Prefab", "Select the prefab used as cursor.", "")]
		[ORKEditorLayout("useRayCursor", true)]
		public GameObject rayCursorPrefab;

		[ORKEditorHelp("Offset", "The offset added to the raycast's position.", "")]
		public Vector3 rayCursorOffset = Vector3.zero;

		// cursor input
		[ORKEditorHelp("Use Input Keys", "Use input keys to move the raycast cursor.\n" +
			"Use the 'Accept' key to use the current cursor position for the racast target.", "")]
		[ORKEditorInfo(separator=true, labelText="Input Key Settings")]
		public bool useInputKeys = false;

		[ORKEditorHelp("Cursor Speed", "The speed in world units per second the cursor will be moved using the input keys.", "")]
		[ORKEditorLayout("useInputKeys", true)]
		public float inputCursorSpeed = 3;

		[ORKEditorInfo(endFoldout=true, endFolds=2)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2, autoInit=true)]
		public CursorInput cursorInput;


		// user highlight
		[ORKEditorHelp("Highlight User", "Highlight the user's game object during raycast selection.", "")]
		public bool useUserHighlight = false;

		[ORKEditorInfo("User Highlight", "Define how the user is highlighted.", "",
			endFoldout=true)]
		[ORKEditorLayout("useUserHighlight", true, endCheckGroup=true, autoInit=true)]
		public HighlightGameObjectSetting userHighlight;

		public TargetRaycast()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<Texture>("cursorTexture"))
			{
				data.Get("cursorTexture", ref this.cursorChange.texture);
				data.Get("cursorHotSpot", ref this.cursorChange.hotSpot);
				data.Get("cursorMode", ref this.cursorChange.cursorMode);
			}
		}


		/*
		============================================================================
		Handling functions
		============================================================================
		*/
		public void Start(Combatant user)
		{
			if(this.blockPlayerControl)
			{
				ORK.Control.SetBlockPlayer(1, true);
			}
			if(this.blockCameraControl)
			{
				ORK.Control.SetBlockCamera(1, true);
			}

			if(this.cursorChange.texture != null)
			{
				ORK.Control.Cursor.ShowCustomCursor(this.cursorChange);
			}

			if(user.GameObject != null)
			{
				user.BattleMenu.RayAction.rayPoint = user.GameObject.transform.position;
				if(this.useUserHighlight)
				{
					this.userHighlight.Highlight(user.GameObject, ref user.BattleMenu.raycastUserCursorInstance);
				}
				if(this.useRayCursor &&
					this.rayCursorPrefab != null)
				{
					if(user.BattleMenu.raycastCursorInstance == null)
					{
						user.BattleMenu.raycastCursorInstance = UnityWrapper.Instantiate(this.rayCursorPrefab);
					}
					if(user.BattleMenu.raycastCursorInstance != null)
					{
						user.BattleMenu.raycastCursorInstance.SetActive(true);
						user.BattleMenu.raycastCursorInstance.transform.position = user.GameObject.transform.position + this.offset;
					}
				}
			}
		}

		public void Stop(Combatant user)
		{
			if(this.blockPlayerControl)
			{
				ORK.Control.SetBlockPlayer(-1, true);
			}
			if(this.blockCameraControl)
			{
				ORK.Control.SetBlockCamera(-1, true);
			}

			if(this.cursorChange.texture == null)
			{
				ORK.Control.Cursor.RemoveTargetSelection();
			}
			else
			{
				ORK.Control.Cursor.RemoveCustomCursor(this.cursorChange);
			}

			if(this.useUserHighlight)
			{
				this.userHighlight.StopHighlight(user.GameObject, ref user.BattleMenu.raycastUserCursorInstance);
				UnityWrapper.Destroy(user.BattleMenu.raycastUserCursorInstance);
			}
			if(this.useRayCursor &&
				this.rayCursorPrefab != null)
			{
				UnityWrapper.Destroy(user.BattleMenu.raycastCursorInstance);
			}
		}


		/*
		============================================================================
		Raycast functions
		============================================================================
		*/
		public bool NeedInteraction()
		{
			return this.active && this.mouseTouch.Active();
		}

		public void Tick(Combatant user)
		{
			if(user.GameObject != null)
			{
				Vector3 point = Vector3.zero;

				if(this.useInputKeys)
				{
					point = this.cursorInput.GetInput(HorizontalPlaneType.XZ) * this.inputCursorSpeed * Time.deltaTime;
					if(point.sqrMagnitude > 0)
					{
						point = Camera.main.WorldToScreenPoint(user.BattleMenu.RayAction.rayPoint + point);
						if(TargetRayOrigin.User == this.rayOrigin)
						{
							point = this.ScreenRayPoint(point);
						}
						point = this.GetRayPoint(user.GameObject, point);
						if(user.BattleMenu.RayAction.InRange(point))
						{
							user.BattleMenu.RayAction.rayPoint = point;

							if(this.useRayCursor &&
								this.rayCursorPrefab != null &&
								user.BattleMenu.raycastCursorInstance != null)
							{
								user.BattleMenu.raycastCursorInstance.transform.position = user.BattleMenu.RayAction.rayPoint;
							}
						}
						if(this.rotateToRaycast)
						{
							user.LookAt(point);
						}
					}
					if(ORK.InputKeys.Get(ORK.GameControls.menuControls.acceptKeyID).GetButton())
					{
						if(user.BattleMenu.RayAction.InRange(user.BattleMenu.RayAction.rayPoint))
						{
							user.BattleMenu.SetRayPoint(user.BattleMenu.RayAction.rayPoint);
							return;
						}
					}
					point = Vector3.zero;
				}

				if(this.mouseTouch.Active())
				{
					if(this.mouseTouch.Interacted(ref point))
					{
						if(TargetRayOrigin.User == this.rayOrigin)
						{
							point = this.ScreenRayPoint(point);
						}
						point = this.GetRayPoint(user.GameObject, point);
						if(user.BattleMenu.RayAction.InRange(point))
						{
							user.BattleMenu.SetRayPoint(point);
						}
						if(this.rotateToRaycast)
						{
							user.LookAt(point);
						}
					}
					else if(this.cursorChange.texture == null ||
						(this.useRayCursor &&
							this.rayCursorPrefab != null &&
							user.BattleMenu.raycastCursorInstance != null))
					{
						point = ORK.Core.UIMatrix.Matrix.MultiplyPoint3x4(ORK.Control.MousePosition);
						point.y = Screen.height - point.y;
						if(TargetRayOrigin.User == this.rayOrigin)
						{
							point = this.ScreenRayPoint(point);
						}
						point = this.GetRayPoint(user.GameObject, point);

						if(user.BattleMenu.RayAction.InRange(point))
						{
							if(this.useRayCursor &&
								this.rayCursorPrefab != null &&
								user.BattleMenu.raycastCursorInstance != null)
							{
								user.BattleMenu.raycastCursorInstance.transform.position = point;
							}
							if(this.cursorChange.texture == null)
							{
								if(!ORK.Control.Cursor.ShowTargetOverBox(
									user, user.BattleMenu.RayAction.Shortcut))
								{
									ORK.Control.Cursor.ShowTargetValid(
										TargetSettings.Get(user.BattleMenu.RayAction));
								}
							}
						}
						else if(this.cursorChange.texture == null)
						{
							if(!ORK.Control.Cursor.ShowTargetOverBox(
									user, user.BattleMenu.RayAction.Shortcut))
							{
								ORK.Control.Cursor.ShowTargetInvalid(
									TargetSettings.Get(user.BattleMenu.RayAction));
							}
						}
						if(this.rotateToRaycast)
						{
							user.LookAt(point);
						}
					}
				}
			}
		}

		private Vector3 ScreenRayPoint(Vector3 point)
		{
			Ray ray = Camera.main.ScreenPointToRay(point);
			RaycastOutput hit;
			if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit, this.distance, this.layerMask))
			{
				point = hit.point;
			}
			else
			{
				point = ray.GetPoint(this.distance);
			}
			return point;
		}

		private Vector3 GetRayPoint(GameObject user, Vector3 target)
		{
			Vector3 point = Vector3.zero;
			if(this.active && user != null)
			{
				Ray ray;
				if(TargetRayOrigin.User == this.rayOrigin)
				{
					if(this.pathToChild != "")
					{
						Transform tr = user.transform.Find(this.pathToChild);
						if(tr != null)
							user = tr.gameObject;
					}
					Vector3 origin = user.transform.position + offset;
					Vector3 dir = Vector3.zero;
					if(this.mouseTouch.Active())
					{
						dir = VectorHelper.GetDirection(origin, target);
					}
					else
					{
						dir = user.transform.TransformDirection(this.rayDirection);
					}
					ray = new Ray(origin, dir);
				}
				else
				{
					ray = Camera.main.ScreenPointToRay(target + this.offset);
				}

				List<RaycastOutput> hit = RaycastHelper.RaycastAll(ray.origin, ray.direction, this.distance, this.layerMask);
				if(hit.Count > 0)
				{
					for(int i = 0; i < hit.Count; i++)
					{
						if(!this.ignoreUser || user.transform.root != hit[i].transform.root)
						{
							point = hit[i].point;
							break;
						}
					}
				}
				else
				{
					point = ray.GetPoint(this.distance);
				}
			}
			return point;
		}

		public void GetAutoPoint(GameObject user, Vector3 point, BaseAction action)
		{
			point = this.GetRayPoint(user, point);
			if(action.InRange(point))
			{
				action.rayTargetSet = true;
				action.rayPoint = point;
			}
		}

		public void GetAIPoint(Combatant user, GameObject target, BaseAction action)
		{
			Vector3 point = Vector3.zero;

			if(this.autoTarget && target != null)
			{
				if(this.pathToTarget != "" && target != null)
				{
					Transform t = target.transform.Find(this.pathToChild);
					if(t != null)
					{
						target = t.gameObject;
					}
				}
				point = target.transform.position + this.targetOffset;
				if(TargetRayOrigin.Screen == this.rayOrigin &&
					Camera.main != null)
				{
					point = Camera.main.WorldToScreenPoint(point);
				}
			}
			else
			{
				if(this.useMousePosition &&
					(!this.mouseOnlyPlayer || ORK.Game.ActiveGroup.Leader == user))
				{
					point = this.screenOffset + (Vector3)ORK.Control.MousePosition;
				}
				else
				{
					point = ORK.GameSettings.GetScreenCenter() + this.screenOffset;
				}
				point = ORK.Core.UIMatrix.Matrix.MultiplyPoint3x4(point);
				point.y = Screen.height - point.y;

				if(TargetRayOrigin.User == this.rayOrigin)
				{
					point = this.ScreenRayPoint(point);
				}
			}

			point = this.GetRayPoint(user.GameObject, point);
			if(action.InRange(point))
			{
				action.rayTargetSet = true;
				action.rayPoint = point;
			}
		}
	}
}
