
using UnityEngine;
using ORKFramework;
using ORKFramework.AI.Steps;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class BattleAI : BaseNode
	{
		[ORKEditorHelp("Name", "The name of the battle AI.", "")]
		[ORKEditorInfo("AI Settings", "Set the name and base settings of the battle AI.", "",
			expandWidth=true)]
		public string name = "";

		[ORKEditorHelp("Clear Found Targets", "Clear the found targets list at the start of this battle AI.\n" +
			"Removes all targets that where found by battle AIs that where executed before this one.", "")]
		[ORKEditorInfo(endFoldout=true, separator=true)]
		public bool clearFoundTargets = false;


		// AI steps
		[ORKEditorInfo(hide=true)]
		public int startIndex = -1;

		[ORKEditorInfo(hide=true)]
		public BaseAIStep[] step = new BaseAIStep[0];

		public BattleAI()
		{

		}

		public BattleAI(string name)
		{
			this.name = name;
		}

		public BaseAction GetAction(Combatant user, List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			BaseAction action = null;
			int currentStep = this.startIndex;

			if(this.clearFoundTargets)
			{
				foundTargets.Clear();
			}

			while(action == null &&
				currentStep >= 0 &&
				currentStep < this.step.Length)
			{
				if(this.step[currentStep].IsEnabled)
				{
					action = this.step[currentStep].Execute(ref currentStep, user, allies, enemies, foundTargets);
				}
				else
				{
					currentStep = this.step[currentStep].GetNext(0);
				}
			}

			return action;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeName()
		{
			return "Battle AI Settings";
		}

		public override string GetNodeDetails()
		{
			return "";
		}

		public override string GetNextName(int index)
		{
			return "Start";
		}

		public override bool IsRemovable()
		{
			return false;
		}


		/*
		============================================================================
		Next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 1;
		}

		public override int GetNext(int index)
		{
			return this.startIndex;
		}

		public override void SetNext(int index, int next)
		{
			this.startIndex = next;
		}
	}
}
