﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class AIBehaviourSlotSetting : BaseData
	{
		// unequip
		[ORKEditorHelp("Unequip", "This AI behaviour slot will be unequipped.", "")]
		public bool unequip = false;

		[ORKEditorHelp("Collect", "Collect the currently equipped AI behaviour.\n" +
			"Only used for combatants of the player group.", "")]
		public bool collect = false;


		// equip
		[ORKEditorHelp("AI Behaviour", "Select the AI behaviour that will be equipped.", "")]
		[ORKEditorInfo(ORKDataType.AIBehaviour)]
		[ORKEditorLayout("unequip", false)]
		public int aiBehaviourID = 0;

		[ORKEditorHelp("From Collection", "The AI behaviour will be taken from the collection, " +
			"i.e. it must be collected and available to be equipped.\n" +
			"This is only used for combatants of the player group.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool fromCollection = false;

		public AIBehaviourSlotSetting()
		{

		}

		public void Use(Combatant user, int slotIndex, bool notify)
		{
			if(this.unequip)
			{
				user.AI.UnequipAIBehaviour(slotIndex, this.collect, notify);
			}
			else
			{
				user.AI.EquipAIBehaviour(this.aiBehaviourID, slotIndex, this.collect, this.fromCollection, notify);
			}
		}

		public string GetInfoText()
		{
			return this.unequip ? "Unequip" : ORK.AIBehaviours.GetName(this.aiBehaviourID);
		}
	}
}
