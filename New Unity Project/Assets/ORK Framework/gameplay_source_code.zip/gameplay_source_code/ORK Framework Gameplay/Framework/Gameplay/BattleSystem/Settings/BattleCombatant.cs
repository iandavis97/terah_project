
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class BattleCombatant : BaseData, ISerializationCallbackReceiver
	{
		[ORKEditorHelp("Faction", "Select the faction the combatant/group will be part of.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		public int factionID = 0;

		[ORKEditorHelp("Use Group", "Use a combatant group.\n" +
			"If disabled, a single combatant will be used.", "")]
		public bool useGroup = true;

		[ORKEditorHelp("Combatant Group", "Select the combatant group that will be used.", "")]
		[ORKEditorInfo(ORKDataType.CombatantGroup)]
		[ORKEditorLayout("useGroup", true)]
		public int id = 0;

		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public CombatantInit member = new CombatantInit();

		[System.NonSerialized]
		[ORKEditorInfo("Requirements", "You can optionally use requirements to determine " +
			"if the combatant is added to the goup.", "",
			endFoldout=true, foldoutDefault=false)]
		public CombatantGroupMemberRequirement requirement = new CombatantGroupMemberRequirement();

		[SerializeField]
		private ORKDataFile serialize_settings;

		public BattleCombatant()
		{

		}

		public Group GetGroup()
		{
			Group group = null;
			if((this.requirement == null || this.requirement.Check()))
			{
				if(this.useGroup)
				{
					group = ORK.CombatantGroups.Create(this.id, this.factionID);
				}
				else if(this.member != null)
				{
					group = new Group(this.factionID);
					this.member.Create(group);
				}
			}
			return group;
		}

		public Group GetGroup(CombatantSpawner spawner, int spawnerIndex, bool respawn)
		{
			Group group = this.GetGroup();
			if(group != null)
			{
				group.SetSpawner(spawner, spawnerIndex, respawn);
			}
			return group;
		}

		public string GetInfoText()
		{
			return this.useGroup ?
				ORK.CombatantGroups.GetName(this.id) :
				this.member.GetInfoText();
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public void OnBeforeSerialize()
		{
			DataObject data = new DataObject();
			data.Set("requirement", this.requirement.GetData());
			this.serialize_settings = data.GetDataFile("settings", false);
		}

		public void OnAfterDeserialize()
		{
			if(this.serialize_settings != null)
			{
				DataObject data = this.serialize_settings.ToDataObject();
				this.requirement.SetData(data.GetFile("requirement"));
				this.serialize_settings = null;
			}
		}
	}
}
