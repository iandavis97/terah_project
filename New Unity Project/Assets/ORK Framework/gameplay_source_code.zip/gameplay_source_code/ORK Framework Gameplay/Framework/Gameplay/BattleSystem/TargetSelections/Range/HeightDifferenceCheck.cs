﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class HeightDifferenceCheck : BaseData
	{
		// above
		[ORKEditorHelp("Is Above", "The target is above the user.", "")]
		public bool isAbove = false;

		[ORKEditorHelp("Minimum", "The minimum height difference the target has to be above the user.", "")]
		[ORKEditorInfo(label=new string[] {
			"Define in positive values, negative values allow targets below the user."
		})]
		[ORKEditorLayout("isAbove", true)]
		public float aboveMin = 0;

		[ORKEditorHelp("Use Maximum", "A maximum height difference is used.", "")]
		public bool aboveUseMax = false;

		[ORKEditorHelp("Maximum", "The maximum height difference the target has to be above the user.", "")]
		[ORKEditorLayout("aboveUseMax", true, endCheckGroup=true, endGroups=2)]
		public float aboveMax = 5;


		// below
		[ORKEditorHelp("Is Below", "The target is below the user.", "")]
		[ORKEditorInfo(separator=true)]
		public bool isBelow = false;

		[ORKEditorHelp("Minimum", "The minimum height difference the target has to be below the user.", "")]
		[ORKEditorInfo(label=new string[] {
			"Define in positive values, negative values allow targets above the user."
		})]
		[ORKEditorLayout("isBelow", true)]
		public float belowMin = 0;

		[ORKEditorHelp("Use Maximum", "A maximum height difference is used.", "")]
		public bool belowUseMax = false;

		[ORKEditorHelp("Maximum", "The maximum height difference the target has to be below the user.", "")]
		[ORKEditorLayout("belowUseMax", true, endCheckGroup=true, endGroups=2)]
		public float belowMax = 5;

		public HeightDifferenceCheck()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool Check(Combatant user, Vector3 target)
		{
			return user != null && user.GameObject != null &&
				this.Check(user.GameObject.transform.position, target,
					ORK.GameSettings.horizontalPlane);
		}

		public bool Check(Combatant user, Combatant target)
		{
			return user != null && user.GameObject != null &&
				target != null && target.GameObject != null &&
				this.Check(user.GameObject.transform.position,
					target.GameObject.transform.position,
					ORK.GameSettings.horizontalPlane);
		}

		public bool Check(Vector3 user, Vector3 target)
		{
			return this.Check(user, target, ORK.GameSettings.horizontalPlane);
		}

		public bool Check(Vector3 user, Vector3 target, HorizontalPlaneType horizontalPlane)
		{
			float difference = 0;
			if(HorizontalPlaneType.XZ == horizontalPlane)
			{
				difference = target.y - user.y;
			}
			else if(HorizontalPlaneType.XY == horizontalPlane)
			{
				difference = target.z - user.z;
			}

			// check above
			if(this.isAbove &&
				difference >= this.aboveMin &&
				(!this.aboveUseMax || difference <= this.aboveMax))
			{
				return true;
			}

			// check below
			difference *= -1;
			if(this.isBelow &&
				difference >= this.belowMin &&
				(!this.belowUseMax || difference <= this.belowMax))
			{
				return true;
			}
			return !this.isAbove && !this.isBelow;
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			return (this.isAbove ?
				(this.isBelow ? "Above, Below" : "Above") :
				(this.isBelow ? "Below" : ""));
		}
	}
}
