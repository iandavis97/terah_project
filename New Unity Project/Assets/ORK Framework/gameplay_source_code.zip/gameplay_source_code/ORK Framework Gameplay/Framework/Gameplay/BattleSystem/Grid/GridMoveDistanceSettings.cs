﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridMoveDistanceSettings : BaseData
	{
		[ORKEditorHelp("Range Type", "Select which cells around the origin cell will be used:\n" +
			"- Distance: Cells defined by a grid distance.\n" +
			"- Battle Range Template: Cells defined by a battle range template.\n" +
			"- Custom: A custom grid shape.", "")]
		public AIGridMoveRangeType type = AIGridMoveRangeType.Distance;


		// distance
		[ORKEditorHelp("Minimum Distance", "Define the minimum distance around the origin cell.\n" +
			"The minimum distance is 1 (i.e. the cells around the origin cell).", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("type", AIGridMoveRangeType.Distance)]
		public int minDistance = 0;

		[ORKEditorHelp("Maximum Distance", "Define the maximum distance around the origin cell.\n" +
			"The minimum distance is 1 (i.e. the cells around the origin cell).", "")]
		[ORKEditorLimit("minDistance", false)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int maxDistance = 0;


		// battle range template
		[ORKEditorHelp("Battle Range Template", "Select the battle range template that will be used.", "")]
		[ORKEditorInfo(ORKDataType.BattleRangeTemplate)]
		[ORKEditorLayout("type", AIGridMoveRangeType.BattleRangeTemplate, endCheckGroup=true)]
		public int templateID = 0;


		// custom
		[ORKEditorLayout("type", AIGridMoveRangeType.Custom, endCheckGroup=true, autoInit=true)]
		public GridRangeSetting gridRange;

		public GridMoveDistanceSettings()
		{

		}

		public GridMoveDistanceSettings(int distance, bool isRing)
		{
			if(isRing)
			{
				this.type = AIGridMoveRangeType.Custom;
				this.gridRange = new GridRangeSetting();
				this.gridRange.gridShapeType = GridShapeType.Ring;
				this.gridRange.gridRange = distance;
			}
			else
			{
				this.minDistance = distance;
				this.maxDistance = distance;
			}
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("distance"))
			{
				data.Get("distance", ref this.maxDistance);
			}
		}

		public List<BattleGridCellComponent> GetCells(Combatant user, BattleGridCellComponent origin, GridCellCheck check, bool allowSquareDiagonal)
		{
			List<BattleGridCellComponent> list = new List<BattleGridCellComponent>();
			this.GetCells(user, origin, check, allowSquareDiagonal, ref list);
			return list;
		}

		public void GetCells(Combatant user, BattleGridCellComponent origin, GridCellCheck check,
			bool allowSquareDiagonal, ref List<BattleGridCellComponent> list)
		{
			if(AIGridMoveRangeType.Distance == this.type)
			{
				HashSet<BattleGridCellComponent> contains = new HashSet<BattleGridCellComponent>();
				BattleGridHelper.GetRange(origin, this.minDistance, this.maxDistance, ref list, ref contains,
					false, false, false, allowSquareDiagonal, check);
			}
			else if(AIGridMoveRangeType.BattleRangeTemplate == this.type)
			{
				ORK.BattleRangeTemplates.Get(this.templateID).range.GetCells(user, origin, ref list, check);
			}
			else if(AIGridMoveRangeType.Custom == this.type)
			{
				this.gridRange.GetCells(user, origin, ref list, check);
			}
		}
	}
}
