﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleGridCellTypeSingle : BaseData
	{
		// prefab
		[ORKEditorInfo("Prefab Settings", "Define the prefab of this grid cell type.", "")]
		public GridCellPrefab prefab = new GridCellPrefab();

		// highlight offsets
		[ORKEditorHelp("Highlight Position Offset", "The position offset added to all highlight prefabs.", "")]
		[ORKEditorInfo(separator=true)]
		public Vector3 highlightPositionOffset = Vector3.zero;

		[ORKEditorHelp("Highlight Rotation Offset", "The rotation offset added to all highlight prefabs.", "")]
		[ORKEditorInfo(separator=true)]
		public Vector3 highlightRotationOffset = Vector3.zero;

		[ORKEditorHelp("Line Position Offset", "The position offset added to all line renderer highlights.", "")]
		[ORKEditorInfo(separator=true)]
		public Vector3 lineHighlightPositionOffset = Vector3.zero;

		// editor prefab
		[ORKEditorHelp("Editor Prefab", "Optionally use a different prefab when displaying this grid cell type in the editor (not when playing).\n" +
			"This can be useful to visualize different grid cell types using the same prefab.", "")]
		[ORKEditorInfo(separator=true)]
		public GameObject editorPrefab;

		// random prefabs
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Random Prefab", "Adds a prefab that will be selected randomly when creating the cell in-game.\n" +
			"The original prefab defined above will also be part of the random prefabs.", "",
			"Remove", "Removes this random prefab.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[]
			{
				"Random Prefab", "Define the random prefab that will be used.\n" +
				"A random prefab will be used when a cell of this cell type is created in-game.", ""
			})]
		public GridCellPrefab[] randomPrefab = new GridCellPrefab[0];


		// cell settings
		[ORKEditorHelp("Blocked", "This is a blocked cell, i.e. combatants can't move on it.", "")]
		[ORKEditorInfo("Cell Settings", "Define settings that affect cells using this grid cell type.", "")]
		public bool blocked = false;

		[ORKEditorHelp("Passable", "The blocked cell can still be moved over by combatants.\n" +
			"I.e. combatant's can't stop on the cell, but can move over it on their path.", "")]
		[ORKEditorLayout("blocked", true)]
		public bool passable = false;

		[ORKEditorHelp("Block Diagonal Move", "The blocked cell blocks diagonal movement around it in 'Square' type grids.\n" +
			"A diagonal move is blocked if the cell is a neighbour of both cells that would be part of the diagonal move.\n" +
			"This is only used in 'Square' type grids that allow diagonal movement.", "")]
		[ORKEditorLayout("battlegrid:square", endCheckGroup=true)]
		public bool blockDiagonalMove = true;

		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public GridDeploymentCell deployment = new GridDeploymentCell();

		[ORKEditorInfo("Move Cost", "Defines how much moving on/over this cell will reduce a combatant's move points.", "",
			endFoldout=true)]
		[ORKEditorLayout(new string[] { "blocked", "passable" },
			new System.Object[] { false, true },
			needed=Needed.One)]
		public FloatValue moveCost = new FloatValue(1);

		[ORKEditorInfo("Action Cost", "Defines how much moving on/over this cell will reduce a combatant's actions per turn.\n" +
			"This is only used in turn based and phase battles.", "",
			endFoldout=true)]
		public FloatValue actionCost = new FloatValue(0);

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Cell Type Costs", "Add different move/action costs when coming from defined grid cell types.", "",
			"Remove", "Removes this cell type costs.", "", isMove=true, isCopy=true, foldout=true, foldoutText=new string[] {
				"Cell Type Costs", "Define the grid cell types the move/action costs when moving from them to this cell type.", ""
		})]
		[ORKEditorLayout(endCheckGroup=true)]
		public GridCellTypeCost[] cellTypeCost = new GridCellTypeCost[0];


		// object variables
		[ORKEditorHelp("Use Object Variables", "Automatically adds an 'Object Variables' component " +
			"to the game objects of this cell type.\n" +
			"Object variables are used to bind game variables to game objects in the scene.", "")]
		[ORKEditorInfo("Object Variable Settings",
			"You can automatically add an 'Object Variables' component to the game object of this cell type.\n" +
			"The object variables can be initialized with default values.", "")]
		public bool useObjectVariables = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useObjectVariables", true, endCheckGroup=true, autoInit=true)]
		public ObjectVariableSetting objectVariables;


		// cell events
		[ORKEditorInfo("Cell Events", "A cell event can perform abilities and game events on combatants that " +
			"move to/over or start/end their turn on cells of this type.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Cell Event", "Adds a cell event (abilities and game events) that can be performed on combatants on cells of this type.", "",
			"Remove", "Removes this cell event.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[]
			{
				"Cell Event", "Define when this cell event will be performed and what abilities and game events will be used.", ""
			})]
		public GridCellEvent[] cellEvent = new GridCellEvent[0];


		// in-game
		private Dictionary<int, GridCellTypeCost> costLookup;

		public BattleGridCellTypeSingle()
		{

		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public GameObject CreatePrefabInstance(BattleGridCellComponent cell)
		{
			if(this.randomPrefab.Length > 0)
			{
				int index = Random.Range(0, this.randomPrefab.Length + 1);
				if(index < this.randomPrefab.Length)
				{
					return this.randomPrefab[index].CreatePrefabInstance(cell, false);
				}
			}
			return this.prefab.CreatePrefabInstance(cell, false);
		}


		/*
		============================================================================
		Cost functions
		============================================================================
		*/
		private GridCellTypeCost GetCosts(int typeID)
		{
			if(this.costLookup == null)
			{
				this.costLookup = new Dictionary<int, GridCellTypeCost>();
				for(int i = 0; i < this.cellTypeCost.Length; i++)
				{
					for(int j = 0; j < this.cellTypeCost[i].cellTypeID.Length; j++)
					{
						if(!this.costLookup.ContainsKey(this.cellTypeCost[i].cellTypeID[j]))
						{
							this.costLookup.Add(this.cellTypeCost[i].cellTypeID[j], this.cellTypeCost[i]);
						}
					}
				}
			}
			GridCellTypeCost cost;
			if(this.costLookup.TryGetValue(typeID, out cost))
			{
				return cost;
			}
			return null;
		}

		public bool CanMoveFrom(BattleGridCellComponent fromCell)
		{
			if(fromCell != null)
			{
				GridCellTypeCost cost = this.GetCosts(fromCell.CellType.RealID);
				if(cost != null)
				{
					return !cost.blockMovement;
				}
			}
			return true;
		}

		public string ReplaceMoveCosts(string text, Combatant user)
		{
			float cost = this.GetMoveCost(user);
			return text.
				Replace("%2", cost.ToString("0.00")).
				Replace("%1", cost.ToString("0.0")).
				Replace("%", cost.ToString("0"));
		}

		public float GetMoveCost(Combatant user)
		{
			return this.moveCost.GetValue(user, user);
		}

		public float GetMoveCost(Combatant user, BattleGridCellComponent fromCell)
		{
			if(fromCell != null)
			{
				GridCellTypeCost cost = this.GetCosts(fromCell.CellType.RealID);
				if(cost != null)
				{
					return cost.moveCost.GetValue(user, user);
				}
			}
			return this.moveCost.GetValue(user, user);
		}

		public float GetActionCost(Combatant user)
		{
			return this.actionCost.GetValue(user, user);
		}

		public float GetActionCost(Combatant user, BattleGridCellComponent fromCell)
		{
			if(fromCell != null)
			{
				GridCellTypeCost cost = this.GetCosts(fromCell.CellType.RealID);
				if(cost != null)
				{
					return cost.actionCost.GetValue(user, user);
				}
			}
			return this.actionCost.GetValue(user, user);
		}
	}
}
