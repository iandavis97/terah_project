﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TargetHighlight
	{
		private Combatant owner;

		private IShortcut shortcut;


		// target highlight
		private List<Combatant> availableTargets = new List<Combatant>();

		private List<Combatant> selectedTargets = new List<Combatant>();

		private bool rotatedToTarget = false;


		// grid cell highlight
		private bool useRangeHighlight = false;

		private List<BattleGridCellComponent> useRangeCells = new List<BattleGridCellComponent>();

		private bool affectRangeHighlight = false;

		private List<BattleGridCellComponent> affectRangeCells = new List<BattleGridCellComponent>();

		public TargetHighlight(Combatant owner)
		{
			this.owner = owner;
		}

		public void Clear()
		{
			ORK.GUI.ForcedPreviewShortcut = null;
			this.shortcut = null;

			this.owner.Actions.SelectingGridHighlight(true);

			// clear old data
			if(this.useRangeCells.Count > 0)
			{
				this.HighlightUseRangeCells(false);
				this.useRangeCells.Clear();
			}
			if(this.affectRangeCells.Count > 0)
			{
				this.HighlightAffectRangeCells(false);
				this.affectRangeCells.Clear();
			}
			if(this.availableTargets.Count > 0)
			{
				this.HighlightAvailableTargetCells(false);
				this.availableTargets.Clear();
			}
			this.ClearSelectedTargets(true);
			ORK.BattleSettings.CloseTargetInformation();
			ORK.Control.Cursor.RemoveTargetSelection();
		}

		public IShortcut Shortcut
		{
			get { return this.shortcut; }
		}

		public List<Combatant> AvailableTargets
		{
			get { return this.availableTargets; }
		}


		/*
		============================================================================
		Target functions
		============================================================================
		*/
		public void SelectTarget(Combatant combatant, IShortcut shortcut)
		{
			this.ClearSelectedTargets(false);
			this.shortcut = shortcut;
			if(combatant != null)
			{
				this.selectedTargets.Add(combatant);
			}

			this.HighlightSelectedTargets();
		}

		public void SelectTargets(List<Combatant> list, IShortcut shortcut)
		{
			this.ClearSelectedTargets(false);
			this.shortcut = shortcut;
			this.selectedTargets.AddRange(list);

			if(ORK.MenuSettings.preview.targetSelectionPreview &&
				shortcut != null)
			{
				ORK.GUI.ForcedPreviewShortcut = new PreviewSelection(
					this.owner, this.availableTargets, this.shortcut, false);
			}

			this.HighlightSelectedTargets();
		}

		private void HighlightSelectedTargets()
		{
			ORK.BattleSettings.ShowTargetInformation(this.owner, this.selectedTargets, this.shortcut);

			if(!ORK.BattleSettings.rotateToTargetCursorOver ||
				(ORK.Battle.CursorOverCombatant != null &&
					this.selectedTargets.Contains(ORK.Battle.CursorOverCombatant)))
			{
				this.RotateToTarget();
			}

			TargetSettings targetSettings = null;

			if(ORK.Battle.Grid != null)
			{
				targetSettings = TargetSettings.Get(this.shortcut);

				if(ORK.Battle.Settings.gridHighlights.useRangeTargetSelection &&
					targetSettings != null)
				{
					if(this.useRangeCells.Count > 0)
					{
						this.HighlightUseRangeCells(false);
						this.useRangeCells.Clear();
					}
					targetSettings.GetUseRangeCells(
						this.owner, ref this.useRangeCells, null);
					this.HighlightUseRangeCells(true);
				}

				if(ORK.Battle.Settings.gridSettings.examine.ExamineTarget)
				{
					for(int i = 0; i < this.selectedTargets.Count; i++)
					{
						if(this.selectedTargets[i] != null &&
							this.selectedTargets[i].Grid.Cell != null)
						{
							ORK.Battle.Settings.gridSettings.SelectedCell = this.selectedTargets[i].Grid.Cell;
							ORK.Battle.Settings.gridSettings.examine.ExternalExamine(
								this.selectedTargets[i].Grid.Cell,
								ORK.Battle.Settings.gridSettings.examine.targetExamineCell,
								ORK.Battle.Settings.gridSettings.examine.targetExamineCellCombatant);
							break;
						}
					}
				}
			}

			bool cam = false;
			for(int i = 0; i < this.selectedTargets.Count; i++)
			{
				if(this.selectedTargets[i] != null)
				{
					if(targetSettings != null &&
						ORK.Battle.Grid != null &&
						ORK.Battle.Settings.gridHighlights.affectRangeTargetSelection &&
						!targetSettings.IsNoneTarget())
					{
						targetSettings.GetAffectRangeCells(
							this.owner, this.selectedTargets[i],
							ref this.affectRangeCells, null);
					}

					TargetHelper.Blink(this.selectedTargets[i], true);

					if(!cam &&
						!ORK.BattleSettings.camera.IsNone &&
						this.selectedTargets[i].GameObject != null)
					{
						ORK.BattleSettings.camera.SetSelection(
							this.owner.GameObject != null ? this.owner.GameObject.transform : null,
							this.selectedTargets[i].GameObject.transform);
						cam = true;
					}
				}
			}

			if(ORK.Battle.Grid != null)
			{
				this.HighlightAffectRangeCells(true);

				if(ORK.Battle.Settings.gridHighlights.availableTargetTargetSelection)
				{
					this.HighlightAvailableTargetCells(true);
				}
			}
		}

		private void ClearSelectedTargets(bool resetBattleCamera)
		{
			this.rotatedToTarget = false;

			if(this.affectRangeCells.Count > 0)
			{
				this.HighlightAffectRangeCells(false);
				this.affectRangeCells.Clear();
			}
			if(this.availableTargets.Count > 0)
			{
				this.HighlightAvailableTargetCells(false);
			}

			if(this.selectedTargets.Count > 0)
			{
				if(resetBattleCamera &&
					!ORK.BattleSettings.camera.IsNone)
				{
					ORK.BattleSettings.camera.SetSelection(null, null);
				}
				for(int i = 0; i < this.selectedTargets.Count; i++)
				{
					TargetHelper.Blink(this.selectedTargets[i], false);
				}
				this.selectedTargets.Clear();
			}
		}

		public void RotateToTarget()
		{
			if(ORK.BattleSettings.rotateToTarget &&
				!this.rotatedToTarget &&
				this.owner.GameObject != null &&
				this.selectedTargets.Count > 0)
			{
				this.rotatedToTarget = true;

				this.owner.LookAt(TransformHelper.GetCenterPosition(this.selectedTargets));
				if(ORK.Battle.Grid != null &&
					ORK.BattleSettings.rotateToTargetGridRotation)
				{
					Vector3 tmpRotation = this.owner.GameObject.transform.eulerAngles;
					tmpRotation.y = BattleGridHelper.GetDirectionRotation(
						this.owner.GameObject, GridDirectionRotationType.Nearest, true);
					this.owner.GameObject.transform.eulerAngles = tmpRotation;
				}
			}
		}


		/*
		============================================================================
		Action functions
		============================================================================
		*/
		public void SelectAction(IShortcut shortcut)
		{
			if(this.shortcut != shortcut)
			{
				this.Clear();
				this.shortcut = shortcut;

				this.UpdateData();

				if(ORK.MenuSettings.preview.actionSelectionPreview)
				{
					ORK.GUI.ForcedPreviewShortcut = new PreviewSelection(
						this.owner, this.availableTargets, this.shortcut, false);
				}

				if(this.shortcut != null &&
					ORK.Battle.Grid != null)
				{
					if(ORK.Battle.Settings.gridHighlights.useRangeActionSelection)
					{
						this.HighlightUseRangeCells(true);
					}
					if(ORK.Battle.Settings.gridHighlights.affectRangeActionSelection)
					{
						this.HighlightAffectRangeCells(true);
					}
					if(ORK.Battle.Settings.gridHighlights.availableTargetActionSelection)
					{
						this.HighlightAvailableTargetCells(true);
					}

					this.owner.Actions.SelectingGridHighlight(
						ORK.Battle.Settings.gridHighlights.selectingCombatantActionSelection);
				}
			}
		}

		public void AcceptAction(IShortcut shortcut)
		{
			if(this.shortcut != shortcut)
			{
				this.Clear();
				this.shortcut = shortcut;

				this.UpdateData();
			}
		}

		public void AcceptHighlights()
		{
			if(this.shortcut != null)
			{
				this.owner.Shortcuts.Active = this.shortcut;

				if(ORK.MenuSettings.preview.targetSelectionPreview)
				{
					ORK.GUI.ForcedPreviewShortcut = new PreviewSelection(
						this.owner, this.availableTargets, this.shortcut, false);
				}

				if(ORK.Battle.Grid != null)
				{
					if(ORK.Battle.Settings.gridHighlights.useRangeTargetSelection)
					{
						this.HighlightUseRangeCells(true);
					}
					else
					{
						this.HighlightUseRangeCells(false);
					}

					this.HighlightAffectRangeCells(false);
					this.HighlightAvailableTargetCells(false);

					this.owner.Actions.SelectingGridHighlight(
						ORK.Battle.Settings.gridHighlights.selectingCombatantTargetSelection);
				}
			}
		}

		private void UpdateData()
		{
			if(this.shortcut != null)
			{
				// ability
				if(this.shortcut is AbilityShortcut)
				{
					ActiveAbility activeLevel = ((AbilityShortcut)this.shortcut).GetActiveLevel();
					if(activeLevel != null)
					{
						if(ORK.Battle.Grid != null)
						{
							this.GetCells(activeLevel.targetSettings);
						}
						else
						{
							activeLevel.targetSettings.GetPossibleTargets(
								ref this.availableTargets, owner, null);
						}
					}
				}
				// item
				else if(this.shortcut is ItemShortcut)
				{
					if(ORK.Battle.Grid != null)
					{
						this.GetCells(((ItemShortcut)this.shortcut).Setting.targetSettings);
					}
					else
					{
						((ItemShortcut)this.shortcut).Setting.targetSettings.GetPossibleTargets(
							ref this.availableTargets, owner, null);
					}
				}
			}
		}


		/*
		============================================================================
		Cell functions
		============================================================================
		*/
		private void GetCells(TargetSettings targetSettings)
		{
			// get use range cells
			targetSettings.GetUseRangeCells(
				this.owner, ref this.useRangeCells, null);

			if(!targetSettings.IsNoneTarget())
			{
				CombatantCheck check = delegate(Combatant combatant)
				{
					return targetSettings.CanTarget(this.owner, combatant);
				};

				// get available targets
				for(int i = 0; i < this.useRangeCells.Count; i++)
				{
					if(this.useRangeCells[i] != null &&
						!this.useRangeCells[i].IsEmpty &&
						targetSettings.InRange(this.owner, this.useRangeCells[i]))
					{
						this.useRangeCells[i].GetCombatants(ref this.availableTargets, check);
					}
				}

				// get affect range cells
				for(int i = 0; i < this.availableTargets.Count; i++)
				{
					targetSettings.GetAffectRangeCells(
						this.owner, this.availableTargets[i],
						ref this.affectRangeCells, null);
				}
			}
		}

		public void HighlightUseRangeCells(bool doHighlight)
		{
			if(ORK.Battle.Settings.gridHighlights.useRangeHighlight.enable &&
				this.useRangeCells.Count > 0)
			{
				if(doHighlight)
				{
					if(!this.useRangeHighlight)
					{
						this.useRangeHighlight = true;
						BattleGridHelper.Highlight(this.useRangeCells, GridHighlightType.UseRange);
					}
				}
				else if(this.useRangeHighlight)
				{
					this.useRangeHighlight = false;
					BattleGridHelper.StopHighlight(this.useRangeCells, GridHighlightType.UseRange);
				}
			}
		}

		public void HighlightAffectRangeCells(bool doHighlight)
		{
			if(ORK.Battle.Settings.gridHighlights.affectRangeHighlight.enable &&
				this.affectRangeCells.Count > 0)
			{
				if(doHighlight)
				{
					if(!this.affectRangeHighlight)
					{
						this.affectRangeHighlight = true;
						BattleGridHelper.Highlight(this.affectRangeCells, GridHighlightType.AffectRange);
					}
				}
				else if(this.affectRangeHighlight)
				{
					this.affectRangeHighlight = false;
					BattleGridHelper.StopHighlight(this.affectRangeCells, GridHighlightType.AffectRange);
				}
			}
		}

		public void HighlightAvailableTargetCells(bool doHighlight)
		{
			if(this.availableTargets.Count > 0)
			{
				for(int i = 0; i < this.availableTargets.Count; i++)
				{
					if(this.availableTargets[i] != null &&
						this.availableTargets[i].Grid.Cell != null)
					{
						GridHighlightType highlightType = GridHighlightType.None;
						// player
						if(this.owner.Group == this.availableTargets[i].Group)
						{
							if(ORK.Battle.Settings.gridHighlights.availableTargetPlayerHighlight.enable)
							{
								highlightType = GridHighlightType.AvailableTargetPlayer;
							}
						}
						// enemy
						else if(this.owner.IsEnemy(this.availableTargets[i]))
						{
							if(ORK.Battle.Settings.gridHighlights.availableTargetEnemyHighlight.enable)
							{
								highlightType = GridHighlightType.AvailableTargetEnemy;
							}
						}
						// ally
						else if(ORK.Battle.Settings.gridHighlights.availableTargetAllyHighlight.enable)
						{
							highlightType = GridHighlightType.AvailableTargetAlly;
						}

						if(highlightType != GridHighlightType.None)
						{
							if(doHighlight)
							{
								this.availableTargets[i].Grid.HighlightCells(highlightType);
							}
							else
							{
								this.availableTargets[i].Grid.StopHighlightCells(highlightType);
							}
						}
					}
				}
			}
		}
	}
}
