﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public enum GridDeploymentType { None, Player, Ally, Enemy, All, Faction, Combatant };

	[System.Serializable]
	public class GridDeploymentCell : BaseData, ISerializationCallbackReceiver
	{
		[ORKEditorHelp("Deployment Type", "Select if the cell is available for deployment:\n" +
			"- None: The cell is not available for deployment.\n" +
			"- Player: Player combatants can be deployed on the cell.\n" +
			"- Ally: Allies of the player can be deployed on the cell.\n" +
			"- Enemy: Enemies of the player can be deployed on the cell.\n" +
			"- All: All combatants can be deployed on the cell.\n" +
			"- Faction: Combatants of a selected faction can be deployed on the cell.\n" +
			"- Combatant: Places the defined combatant on the cell.", "")]
		public GridDeploymentType type = GridDeploymentType.None;


		// faction
		[ORKEditorHelp("Faction", "Faction: Select the faction that can deploy on the cell.\n" +
			"Combatant: Select the faction of the combatant that will be placed on the cell.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		[ORKEditorLayout(new string[] { "type", "type" },
			new object[] { GridDeploymentType.Faction, GridDeploymentType.Combatant },
			needed=Needed.One, endCheckGroup=true)]
		public int factionID = 0;


		// combatant
		[ORKEditorInfo("Combatant", "Define the combatant that will be placed on the cell.", "",
			endFoldout=true)]
		[ORKEditorLayout("type", GridDeploymentType.Combatant, autoInit=true)]
		[System.NonSerialized]
		public CombatantInit combatant;


		// preferred member index
		[ORKEditorHelp("Preferred Member Index", "Prefer the combatant of the defined " +
			"group member index when placing combatants on cells.\n" +
			"0 is the group leader (1st member), 1 is the 2nd member, 2 is the 3rd member, etc." +
			"Use -1 to not use a preferred member.\n" +
			"This is only used when placing combatants on cells automatically, i.e. not by the player combatant placement.", "")]
		[ORKEditorLimit(-1, false)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int preferredMemberIndex = -1;


		// requirements
		[ORKEditorHelp("Use Requirements", "Use status requirements and game variable conditions " +
			"to check if a combatant can be placed on the cell.", "")]
		[ORKEditorLayout("type", GridDeploymentType.None, elseCheckGroup=true)]
		public bool useRequirements = false;

		[ORKEditorInfo("Deploy Requirements", "Deployment on the cell can depend on status requirements and " +
			"game variable conditions.\n" +
			"If the requirements aren't met, the combatant can't be placed here.", "",
			endFoldout=true)]
		[ORKEditorLayout("useRequirements", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		[System.NonSerialized]
		public SimpleCombatantRequirement requirement;


		// component saving
		[SerializeField]
		private ORKDataFile serialize_combatant;

		[SerializeField]
		private ORKDataFile serialize_requirement;

		public GridDeploymentCell()
		{

		}

		public bool CanDeploy(Combatant combatant)
		{
			if(!this.useRequirements ||
				this.requirement.Check(combatant))
			{
				if(GridDeploymentType.All == this.type)
				{
					return true;
				}
				else if(GridDeploymentType.Player == this.type)
				{
					return combatant.IsPlayerControlled();
				}
				else if(GridDeploymentType.Ally == this.type)
				{
					return !combatant.Group.IsEnemy(ORK.Game.ActiveGroup.Leader);
				}
				else if(GridDeploymentType.Enemy == this.type)
				{
					return combatant.Group.IsEnemy(ORK.Game.ActiveGroup.Leader);
				}
				else if(GridDeploymentType.Faction == this.type)
				{
					return combatant.Group.FactionID == this.factionID;
				}
			}
			return false;
		}

		public Combatant GetDeploymentCombatant(BattleSystemType battleType)
		{
			if(GridDeploymentType.Combatant == this.type &&
				this.combatant != null)
			{
				Group group = new Group(this.factionID);
				group.BattleType = battleType;
				Combatant combatant = this.combatant.Create(group);
				if(!this.useRequirements ||
					this.requirement.Check(combatant))
				{
					return combatant;
				}
			}
			return null;
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public void OnBeforeSerialize()
		{
			if(GridDeploymentType.Combatant == this.type &&
				this.combatant != null)
			{
				this.serialize_combatant = this.combatant.GetData().GetDataFile("combatant", false);
			}
			if(this.useRequirements &&
				this.requirement != null)
			{
				this.serialize_requirement = this.requirement.GetData().GetDataFile("requirement", false);
			}
		}

		public void OnAfterDeserialize()
		{
			// combatant
			if(GridDeploymentType.Combatant == this.type)
			{
				this.combatant = new CombatantInit();
				if(this.serialize_combatant != null)
				{
					this.combatant.SetData(this.serialize_combatant.ToDataObject());
				}
				this.serialize_combatant = null;
			}
			else
			{
				this.combatant = null;
			}

			// requirement
			if(this.useRequirements)
			{
				this.requirement = new SimpleCombatantRequirement();
				if(this.serialize_requirement != null)
				{
					this.requirement.SetData(this.serialize_requirement.ToDataObject());
				}
				this.serialize_requirement = null;
			}
			else
			{
				this.requirement = null;
			}
		}
	}
}
