﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class GridDeploymentCell : BaseData, ISerializationCallbackReceiver
	{
		[ORKEditorHelp("Deployment Type", "Select if this cell is available for deployment:\n" +
			"- None: This cell is not available for deployment.\n" +
			"- Player: Player combatants can be deployed on this cell.\n" +
			"- Ally: Allies of the player can be deployed on this cell.\n" +
			"- Enemy: Enemies of the player can be deployed on this cell.\n" +
			"- All: All combatants can be deployed on this cell.\n" +
			"- Faction: Combatants of a selected faction can be deployed on this cell.", "")]
		public GridDeploymentType type = GridDeploymentType.None;

		[ORKEditorHelp("Faction", "Select the faction that can deploy on this cell.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		[ORKEditorLayout("type", GridDeploymentType.Faction, endCheckGroup=true)]
		public int factionID = 0;
		
		[ORKEditorHelp("Preferred Member Index", "Prefer the combatant of the defined " + 
			"group member index when placing combatants on cells.\n" + 
			"0 is the group leader (1st member), 1 is the 2nd member, 2 is the 3rd member, etc." +
			"Use -1 to not use a preferred member.\n" +
			"This is only used when placing combatants on cells automatically, i.e. not by the player combatant placement.", "")]
		[ORKEditorLimit(-1, false)]
		public int preferredMemberIndex = -1;


		// requirements
		[ORKEditorHelp("Use Requirements", "Use status requirements and game variable conditions " +
			"to check if a combatant can be placed on this cell.", "")]
		[ORKEditorLayout("type", GridDeploymentType.None, elseCheckGroup=true)]
		public bool useRequirements = false;

		[ORKEditorInfo("Deploy Requirements", "Deployment on this cell can depend on status requirements and " +
			"game variable conditions.\n" +
			"If the requirements aren't met, the combatant can't be placed here.", "",
			endFoldout=true)]
		[ORKEditorLayout("useRequirements", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		[System.NonSerialized]
		public SimpleCombatantRequirement requirement;


		// component saving
		[SerializeField]
		private ORKDataFile serialize_requirement;

		public GridDeploymentCell()
		{

		}

		public bool CanDeploy(Combatant combatant)
		{
			if(!this.useRequirements ||
				this.requirement.Check(combatant))
			{
				if(this.type == GridDeploymentType.All)
				{
					return true;
				}
				else if(this.type == GridDeploymentType.Player)
				{
					return combatant.IsPlayerControlled();
				}
				else if(this.type == GridDeploymentType.Ally)
				{
					return !combatant.Group.IsEnemy(ORK.Game.ActiveGroup.Leader);
				}
				else if(this.type == GridDeploymentType.Enemy)
				{
					return combatant.Group.IsEnemy(ORK.Game.ActiveGroup.Leader);
				}
				else if(this.type == GridDeploymentType.Faction)
				{
					return combatant.Group.FactionID == this.factionID;
				}
			}
			return false;
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public void OnBeforeSerialize()
		{
			if(this.useRequirements &&
				this.requirement != null)
			{
				this.serialize_requirement = this.requirement.GetData().GetDataFile("requirement", false);
			}
		}

		public void OnAfterDeserialize()
		{
			if(this.useRequirements)
			{
				if(this.serialize_requirement != null)
				{
					this.requirement = new SimpleCombatantRequirement();
					this.requirement.SetData(this.serialize_requirement.ToDataObject());
				}
				else
				{
					this.requirement = new SimpleCombatantRequirement();
				}
				this.serialize_requirement = null;
			}
			else
			{
				this.requirement = null;
			}
		}
	}
}
