﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface IPreviewable : IContent
	{
		StatusPreview GetPreview(Combatant combatant, PreviewSelection selectedPreview);
	}
}
