﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ActionComboStageSettings : BaseData
	{
		[ORKEditorHelp("Available Time (s)", "The time in seconds this stage will be available to perform.\n" +
			"Set to 0 if you don't want to use time.\n" +
			"The available time of stage 0 (first stage) will be ignored.", "")]
		public float availableTime = 0;


		// required actions
		[ORKEditorArray(false, "Add Required Action", "Adds an action that can trigger this stage.\n" +
			"If none of the required actions match the action used by the combatant, the action combo resets to stage 0.", "",
			"Remove", "Removes this action.", "",
			isMove=true, isCopy=true, noRemoveCount=1, foldout=true, foldoutText=new string[] {
				"Required Action", "Define the action that can trigger this stage.\n" +
				"If none of the required actions match the action used by the combatant, the action combo resets to stage 0.", ""
		})]
		public ActionComboRequirement[] requirementAction = new ActionComboRequirement[] {
			new ActionComboRequirement()
		};


		// replacement action
		[ORKEditorHelp("Use Replacement Action", "Use an action to replace the required action.", "")]
		[ORKEditorInfo("Replacement Action", "You can optionally define an action that will replace the required action when it's used.\n" +
			"To use the replacement action, this stage must be the current stage of the combo, " +
			"the combatant must use one of the required actions and be able to use the replacement action.", "")]
		public bool useReplacementAction = false;

		[ORKEditorHelp("Reset Stage On Fail", "Reset to stage 0 (first stage) of the action combo when the replacement action can't be used.", "")]
		[ORKEditorLayout("useReplacementAction", true)]
		public bool resetStageOnFail = false;

		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		[ORKEditorInfo(endFoldout=true)]
		public ActionSelection replacementAction;

		public ActionComboStageSettings()
		{

		}
	}
}
