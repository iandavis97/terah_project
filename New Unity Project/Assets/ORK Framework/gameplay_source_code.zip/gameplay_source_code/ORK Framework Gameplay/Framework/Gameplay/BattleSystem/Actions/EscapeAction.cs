
using System.Collections.Generic;

namespace ORKFramework
{
	public class EscapeAction : BaseAction
	{
		public EscapeAction(Combatant user)
		{
			this.user = user;
			this.target = new List<Combatant>();
			this.target.Add(user);

			this.actionCost = ORK.Battle.GetEscapeActionCost(this.user);

			this.CheckActionAffiliation();
		}

		public override bool IsType(ActionType t)
		{
			return ActionType.Escape == t;
		}

		public override IShortcut Shortcut
		{
			get { return this.user.Shortcuts.EscapeShortcut; }
		}


		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		public override bool CanUse()
		{
			return this.user != null && !this.user.Status.IsDead &&
				!this.user.Status.Effects.BlockEscape;
		}

		public override void ActionAdded()
		{
			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleAddEscape)
				{
					this.user.Setting.consoleAddEscape.Print(this.user);
				}
				else
				{
					ORK.ConsoleSettings.actionAddEscape.Print(this.user);
				}
			}
		}

		protected override void ActionStartSetup()
		{
			if(ORK.BattleTexts.showInfo)
			{
				ORK.BattleTexts.escapeInfo.Show(this.user, "");
			}

			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleEscape)
				{
					this.user.Setting.consoleEscape.Print(this.user);
				}
				else
				{
					ORK.ConsoleSettings.actionEscape.Print(this.user);
				}
			}

			this.user.GetBattleAnimation(BattleAnimationType.Escape, ref this.events);
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate)
		{
			this.results = new ActionResults();

			if(!this.blockBattleCamera &&
				!ORK.BattleSettings.camera.IsNone &&
				!ORK.BattleSettings.camera.latestDamageActionBlock.IsBlocked(this))
			{
				if(ts.Count == 1 &&
					ts[0] != null &&
					ts[0].GameObject != null)
				{
					ORK.BattleSettings.camera.SetLatestDamage(
						this.user.GameObject != null ? this.user.GameObject.transform : null,
						ts[0].GameObject.transform);
				}
				else if(ts.Count > 1)
				{
					ORK.BattleSettings.camera.SetLatestDamage(
						this.user.GameObject != null ? this.user.GameObject.transform : null,
						ORK.Battle.GetGroupCenter(ts).transform);
				}
			}

			if(this.user != null && !this.user.Status.IsDead &&
				ts.Count > 0 && ts[0] != null &&
				!this.user.Status.Effects.BlockEscape)
			{
				if(ORK.GameSettings.CheckRandom(this.user.Status.GetEscapeChance()))
				{
					this.results.hit = 1;
					user.Battle.Escape();
				}
				this.userConsumeDone = true;
			}
			if(this.results.hit != 1)
			{
				this.results.miss = 1;
			}
		}

		protected override void ActionEndSetup()
		{
			this.user.Abilities.LastAbilityID = -1;
		}
	}
}
