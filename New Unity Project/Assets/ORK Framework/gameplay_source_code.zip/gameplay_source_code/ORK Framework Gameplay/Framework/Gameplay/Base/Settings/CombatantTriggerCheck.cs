﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantTriggerCheck : BaseData
	{
		[ORKEditorHelp("Check Time", "Check the time the combatant is within the combatant trigger.", "")]
		public bool checkTime = false;

		[ORKEditorHelp("Check Type", "Checks if the time is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the time is between two defined values, including the values.\n" +
			"Range exclusive checks if the time is between two defined values, excluding the values.\n" +
			"Approximately checks if the time is similar to the defined value.", "")]
		[ORKEditorLayout("checkTime", true)]
		public VariableValueCheck check = VariableValueCheck.IsEqual;

		[ORKEditorInfo(separator=true, labelText="Check Value")]
		[ORKEditorLayout(autoInit=true)]
		public FloatValue value;

		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"},
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive},
			needed=Needed.One, endCheckGroup=true, endGroups=2, autoInit=true)]
		public FloatValue value2;


		// tags
		[ORKEditorHelp("Needed", "Either all or only one tag must be on added to the combatant trigger component.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Tags")]
		public Needed needed = Needed.All;

		[ORKEditorInfo(hideName=true, separator=true)]
		[ORKEditorArray(false, "Add Tag", "Adds a tag that will be checked.", "",
			"Remove", "Removes this tag.", "", isHorizontal=true)]
		public string[] tags = new string[0];

		public CombatantTriggerCheck()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool Check(Combatant combatant, CombatantTriggerComponent trigger)
		{
			if(combatant != null &&
				trigger != null &&
				trigger.IsActive &&
				(this.tags.Length == 0 ||
					trigger.CheckTags(this.tags, this.needed)))
			{
				if(this.checkTime)
				{
					float time = trigger.GetTime(combatant);
					return time >= 0 &&
						ValueHelper.CheckVariableValue(time,
							this.value.GetValue(combatant, combatant),
							this.value2 != null ? this.value2.GetValue(combatant, combatant) : 0,
							this.check);
				}
				else
				{
					return trigger.Contains(combatant);
				}
			}
			return false;
		}

		public bool Check(Combatant user, Combatant combatant)
		{
			if(user != null &&
				combatant != null)
			{
				List<CombatantTriggerComponent> triggers = user.Triggers;
				if(triggers.Count > 0)
				{
					float tmpValue = this.value.GetValue(user, combatant);
					float tmpValue2 = this.value2 != null ? this.value2.GetValue(user, combatant) : 0;
					for(int i = 0; i < triggers.Count; i++)
					{
						if(triggers[i] != null &&
							triggers[i].IsActive &&
							(this.tags.Length == 0 ||
								triggers[i].CheckTags(this.tags, this.needed)))
						{
							if(this.checkTime)
							{
								float time = triggers[i].GetTime(combatant);
								return time >= 0 &&
									ValueHelper.CheckVariableValue(time, tmpValue, tmpValue2, this.check);
							}
							else
							{
								return triggers[i].Contains(combatant);
							}
						}
					}
				}
			}
			return false;
		}
	}
}
