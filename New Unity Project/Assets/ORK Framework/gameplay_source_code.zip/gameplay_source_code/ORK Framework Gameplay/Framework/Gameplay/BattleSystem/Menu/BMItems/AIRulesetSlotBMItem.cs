﻿
using UnityEngine;
using ORKFramework.AI;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class AIRulesetSlotBMItem : BMItem
	{
		private int slotIndex = -1;

		private BattleMenuItem parent;

		public AIRulesetSlotBMItem(ChoiceContent content, int slotIndex, BattleMenuItem parent)
		{
			this.content = content;
			this.slotIndex = slotIndex;
			this.parent = parent;
		}

		public override bool Accepted(Combatant owner)
		{
			if(owner.BattleMenu != null)
			{
				AIRulesetBattleMenuItem settings = (AIRulesetBattleMenuItem)this.parent.settings;
				BattleMenuMode mode = BattleMenuMode.List;

				List<BMItem> list = new List<BMItem>();

				// list AI ruleset slots
				if(this.slotIndex == -1)
				{
					mode = BattleMenuMode.AIRulesetSlot;

					for(int i = 0; i < owner.AI.AIRulesetSlot.Length; i++)
					{
						list.Add(new AIRulesetSlotBMItem(
							settings.GetChoiceContent(owner, i),
							i, this.parent));
					}
				}
				// list AI types
				else if(settings.showTypes)
				{
					mode = BattleMenuMode.AIType;

					List<int> types = owner.Inventory.AICollection.GetAIRulesetTypes(
						settings.limitAIType ? settings.typeID : -1);
					settings.typeSorter.Sort(ref types, ORKDataType.AbilityType);

					for(int i = 0; i < types.Count; i++)
					{
						AIType aiType = ORK.AITypes.Get(types[i]);
						TypeBMItem tmp = new TypeBMItem(
							owner.BattleMenu.Settings.contentLayout.GetChoiceContent(aiType),
							types[i], this.parent, false);
						tmp.slotIndex = this.slotIndex;
						tmp.hasSubTypes = aiType.HasSubTypes();
						list.Add(tmp);
					}
				}
				// list AI rulesets
				else
				{
					mode = BattleMenuMode.AIRuleset;

					List<AIRulesetShortcut> rulesets = owner.Inventory.AICollection.GetAIRulesetsByType(-1, true);

					for(int i = 0; i < rulesets.Count; i++)
					{
						list.Add(new AIRulesetBMItem(this.slotIndex, rulesets[i],
							owner.BattleMenu.Settings.contentLayout.GetChoiceContent(rulesets[i])));
					}

					if(settings.unequipButton.UnequipFirst)
					{
						list.Insert(0, new AIRulesetBMItem(this.slotIndex, null,
							settings.unequipButton.GetButton(owner.BattleMenu.Settings.contentLayout)));
					}
					else if(settings.unequipButton.UnequipLast)
					{
						list.Add(new AIRulesetBMItem(this.slotIndex, null,
							settings.unequipButton.GetButton(owner.BattleMenu.Settings.contentLayout)));
					}
				}

				owner.BattleMenu.Settings.AddBack(list);

				owner.BattleMenu.Show(list, 0, mode);
				return true;
			}
			return false;
		}
	}
}
