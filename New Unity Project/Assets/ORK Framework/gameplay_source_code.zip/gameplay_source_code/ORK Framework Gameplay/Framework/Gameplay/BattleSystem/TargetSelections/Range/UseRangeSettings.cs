
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class UseRangeSettings : BaseData
	{
		// default
		[ORKEditorInfo("Default Range", "The default range that will be used " +
			"if no battle system specific range is defined.", "",
			endFoldout=true)]
		public UseRange rangeDefault = new UseRange();


		// field
		[ORKEditorHelp("Own Field", "Use a differant range in the field.\n" +
			"If disabled, the default range will be used.", "")]
		public bool useFieldRange = false;

		[ORKEditorInfo("Field Range", "The range used in the field.", "",
			endFoldout=true)]
		[ORKEditorLayout("useFieldRange", true, endCheckGroup=true, autoInit=true)]
		public UseRange rangeField;


		// turn based
		[ORKEditorHelp("Own Turn Based", "Use a differant range in turn based battles.\n" +
			"If disabled, the default range will be used.", "")]
		public bool useTurnBasedRange = false;

		[ORKEditorInfo("Turn Based Range", "The range used in turn based battles.", "",
			endFoldout=true)]
		[ORKEditorLayout("useTurnBasedRange", true, endCheckGroup=true, autoInit=true)]
		public UseRange rangeTurnBased;


		// active time
		[ORKEditorHelp("Own Active Time", "Use a differant range in active time battles.\n" +
			"If disabled, the default range will be used.", "")]
		public bool useActiveTimeRange = false;

		[ORKEditorInfo("Active Time Range", "The range used in active time battles.", "",
			endFoldout=true)]
		[ORKEditorLayout("useActiveTimeRange", true, endCheckGroup=true, autoInit=true)]
		public UseRange rangeActiveTime;


		// real time
		[ORKEditorHelp("Own Real Time", "Use a differant range in real time battles.\n" +
			"If disabled, the default range will be used.", "")]
		public bool useRealTimeRange = false;

		[ORKEditorInfo("Real Time Range", "The range used in real time battles.", "",
			endFoldout=true)]
		[ORKEditorLayout("useRealTimeRange", true, endCheckGroup=true, autoInit=true)]
		public UseRange rangeRealTime;


		// phase
		[ORKEditorHelp("Own Phase", "Use a differant range in phase battles.\n" +
			"If disabled, the default range will be used.", "")]
		public bool usePhaseRange = false;

		[ORKEditorInfo("Phase Range", "The range used in phase battles.", "",
			endFoldout=true)]
		[ORKEditorLayout("usePhaseRange", true, endCheckGroup=true, autoInit=true)]
		public UseRange rangePhase;

		public UseRangeSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("field"))
			{
				// field
				this.useFieldRange = true;
				this.rangeField = this.OldDataUpdate(data,
					"fieldMin", "fieldMinRange", "field", "fieldRange");
				// turn based
				this.useTurnBasedRange = true;
				this.rangeTurnBased = this.OldDataUpdate(data,
					"turnBasedMin", "turnBasedMinRange", "turnBased", "turnBasedRange");
				// active time
				this.useActiveTimeRange = true;
				this.rangeActiveTime = this.OldDataUpdate(data,
					"activeTimeMin", "activeTimeMinRange", "activeTime", "activeTimeRange");
				// real time
				this.useRealTimeRange = true;
				this.rangeRealTime = this.OldDataUpdate(data,
					"realTimeMin", "realTimeMinRange", "realTime", "realTimeRange");
				// phase
				this.usePhaseRange = true;
				this.rangePhase = this.OldDataUpdate(data,
					"phaseMin", "phaseMinRange", "phase", "phaseRange");
			}
		}

		private UseRange OldDataUpdate(DataObject data, string bMin, string rMin, string bMax, string rMax)
		{
			UseRange range = new UseRange();
			range.type = BattleRangeType.Custom;
			range.custom = new BattleRangeSetting();
			data.Get(bMin, ref range.custom.useMin);
			if(range.custom.useMin)
			{
				range.custom.minRange = new Range();
				range.SetData(data.GetFile(rMin));
			}
			data.Get(bMax, ref range.custom.useMax);
			if(range.custom.useMax)
			{
				range.custom.maxRange = new Range();
				range.SetData(data.GetFile(rMax));
			}
			return range;
		}


		/*
		============================================================================
		Range functions
		============================================================================
		*/
		public bool InRange(Combatant user, Combatant target)
		{
			// in field
			if(!user.Battle.InBattle)
			{
				if(this.useFieldRange)
				{
					return this.rangeField.InRange(user, target);
				}
			}
			// in battle
			else if(user.Battle.InBattle &&
				ORK.Control.InBattle &&
				ORK.Battle.IsBattleRunning())
			{
				if(ORK.Battle.IsTurnBased())
				{
					if(this.useTurnBasedRange)
					{
						return this.rangeTurnBased.InRange(user, target);
					}
				}
				else if(ORK.Battle.IsActiveTime())
				{
					if(this.useActiveTimeRange)
					{
						return this.rangeActiveTime.InRange(user, target);
					}
				}
				else if(ORK.Battle.IsRealTime())
				{
					if(this.useRealTimeRange)
					{
						return this.rangeRealTime.InRange(user, target);
					}
				}
				else if(ORK.Battle.IsPhase())
				{
					if(this.usePhaseRange)
					{
						return this.rangePhase.InRange(user, target);
					}
				}
			}
			return this.rangeDefault.InRange(user, target);
		}

		public bool InRange(Combatant user, Vector3 position)
		{
			// in field
			if(!user.Battle.InBattle)
			{
				if(this.useFieldRange)
				{
					return this.rangeField.InRange(user, position);
				}
			}
			// in battle
			else if(user.Battle.InBattle &&
				ORK.Control.InBattle &&
				ORK.Battle.IsBattleRunning())
			{
				if(ORK.Battle.IsTurnBased())
				{
					if(this.useTurnBasedRange)
					{
						return this.rangeTurnBased.InRange(user, position);
					}
				}
				else if(ORK.Battle.IsActiveTime())
				{
					if(this.useActiveTimeRange)
					{
						return this.rangeActiveTime.InRange(user, position);
					}
				}
				else if(ORK.Battle.IsRealTime())
				{
					if(this.useRealTimeRange)
					{
						return this.rangeRealTime.InRange(user, position);
					}
				}
				else if(ORK.Battle.IsPhase())
				{
					if(this.usePhaseRange)
					{
						return this.rangePhase.InRange(user, position);
					}
				}
			}
			return this.rangeDefault.InRange(user, position);
		}

		public bool InRange(Combatant user, BattleGridCellComponent target)
		{
			// in field
			if(!user.Battle.InBattle)
			{
				if(this.useFieldRange)
				{
					return this.rangeField.InRange(user, target);
				}
			}
			// in battle
			else if(user.Battle.InBattle &&
				ORK.Control.InBattle &&
				ORK.Battle.IsBattleRunning())
			{
				if(ORK.Battle.IsTurnBased())
				{
					if(this.useTurnBasedRange)
					{
						return this.rangeTurnBased.InRange(user, target);
					}
				}
				else if(ORK.Battle.IsActiveTime())
				{
					if(this.useActiveTimeRange)
					{
						return this.rangeActiveTime.InRange(user, target);
					}
				}
				else if(ORK.Battle.IsRealTime())
				{
					if(this.useRealTimeRange)
					{
						return this.rangeRealTime.InRange(user, target);
					}
				}
				else if(ORK.Battle.IsPhase())
				{
					if(this.usePhaseRange)
					{
						return this.rangePhase.InRange(user, target);
					}
				}
			}
			return this.rangeDefault.InRange(user, target);
		}

		public List<Combatant> GetTargets(Combatant user, Consider isEnemy, Consider isDead, Consider inBattle)
		{
			// in field
			if(!user.Battle.InBattle)
			{
				if(this.useFieldRange)
				{
					return this.rangeField.GetTargets(user, isEnemy, isDead, inBattle);
				}
			}
			// in battle
			else if(user.Battle.InBattle &&
				ORK.Control.InBattle &&
				ORK.Battle.IsBattleRunning())
			{
				if(ORK.Battle.IsTurnBased())
				{
					if(this.useTurnBasedRange)
					{
						return this.rangeTurnBased.GetTargets(user, isEnemy, isDead, inBattle);
					}
				}
				else if(ORK.Battle.IsActiveTime())
				{
					if(this.useActiveTimeRange)
					{
						return this.rangeActiveTime.GetTargets(user, isEnemy, isDead, inBattle);
					}
				}
				else if(ORK.Battle.IsRealTime())
				{
					if(this.useRealTimeRange)
					{
						return this.rangeRealTime.GetTargets(user, isEnemy, isDead, inBattle);
					}
				}
				else if(ORK.Battle.IsPhase())
				{
					if(this.usePhaseRange)
					{
						return this.rangePhase.GetTargets(user, isEnemy, isDead, inBattle);
					}
				}
			}
			return this.rangeDefault.GetTargets(user, isEnemy, isDead, inBattle);
		}


		/*
		============================================================================
		Cell functions
		============================================================================
		*/
		public List<BattleGridCellComponent> GetCells(Combatant user, BattleGridCellComponent originCell, GridCellCheck check)
		{
			List<BattleGridCellComponent> list = new List<BattleGridCellComponent>();
			this.GetCells(user, originCell, ref list, check);
			return list;
		}

		public void GetCells(Combatant user, BattleGridCellComponent originCell,
			ref List<BattleGridCellComponent> list, GridCellCheck check)
		{
			bool used = false;
			// only in battle
			if(user.Battle.InBattle &&
				ORK.Control.InBattle &&
				ORK.Battle.IsBattleRunning())
			{
				if(ORK.Battle.IsTurnBased())
				{
					if(this.useTurnBasedRange)
					{
						used = true;
						this.rangeTurnBased.GetCells(user, originCell, ref list, check);
					}
				}
				else if(ORK.Battle.IsActiveTime())
				{
					if(this.useActiveTimeRange)
					{
						used = true;
						this.rangeActiveTime.GetCells(user, originCell, ref list, check);
					}
				}
				else if(ORK.Battle.IsRealTime())
				{
					if(this.useRealTimeRange)
					{
						used = true;
						this.rangeRealTime.GetCells(user, originCell, ref list, check);
					}
				}
				else if(ORK.Battle.IsPhase())
				{
					if(this.usePhaseRange)
					{
						used = true;
						this.rangePhase.GetCells(user, originCell, ref list, check);
					}
				}
			}
			if(!used)
			{
				this.rangeDefault.GetCells(user, originCell, ref list, check);
			}
		}


		/*
		============================================================================
		Move AI functions
		============================================================================
		*/
		public Range GetMoveAIUseRange(Combatant user)
		{
			// in field
			if(!user.Battle.InBattle)
			{
				if(this.useFieldRange)
				{
					return this.rangeField.GetMoveAIUseRange();
				}
			}
			// in battle
			else if(user.Battle.InBattle &&
				ORK.Control.InBattle &&
				ORK.Battle.IsBattleRunning())
			{
				if(ORK.Battle.IsTurnBased())
				{
					if(this.useTurnBasedRange)
					{
						return this.rangeTurnBased.GetMoveAIUseRange();
					}
				}
				else if(ORK.Battle.IsActiveTime())
				{
					if(this.useActiveTimeRange)
					{
						return this.rangeActiveTime.GetMoveAIUseRange();
					}
				}
				else if(ORK.Battle.IsRealTime())
				{
					if(this.useRealTimeRange)
					{
						return this.rangeRealTime.GetMoveAIUseRange();
					}
				}
				else if(ORK.Battle.IsPhase())
				{
					if(this.usePhaseRange)
					{
						return this.rangePhase.GetMoveAIUseRange();
					}
				}
			}
			return this.rangeDefault.GetMoveAIUseRange();
		}

		public bool CanMoveIntoRange(Combatant user)
		{
			// in field
			if(!user.Battle.InBattle)
			{
				if(this.useFieldRange)
				{
					return this.rangeField.CanMoveIntoRange();
				}
			}
			// in battle
			else if(user.Battle.InBattle &&
				ORK.Control.InBattle &&
				ORK.Battle.IsBattleRunning())
			{
				if(ORK.Battle.IsTurnBased())
				{
					if(this.useTurnBasedRange)
					{
						return this.rangeTurnBased.CanMoveIntoRange();
					}
				}
				else if(ORK.Battle.IsActiveTime())
				{
					if(this.useActiveTimeRange)
					{
						return this.rangeActiveTime.CanMoveIntoRange();
					}
				}
				else if(ORK.Battle.IsRealTime())
				{
					if(this.useRealTimeRange)
					{
						return this.rangeRealTime.CanMoveIntoRange();
					}
				}
				else if(ORK.Battle.IsPhase())
				{
					if(this.usePhaseRange)
					{
						return this.rangePhase.CanMoveIntoRange();
					}
				}
			}
			return this.rangeDefault.CanMoveIntoRange();
		}

		public void MoveIntoRange(Combatant user, ref bool moveIntoRange, ref bool useStopAngle)
		{
			// in field
			if(!user.Battle.InBattle)
			{
				if(this.useFieldRange)
				{
					this.rangeField.MoveIntoRange(ref moveIntoRange, ref useStopAngle);
				}
			}
			// in battle
			else if(user.Battle.InBattle &&
				ORK.Control.InBattle &&
				ORK.Battle.IsBattleRunning())
			{
				if(ORK.Battle.IsTurnBased())
				{
					if(this.useTurnBasedRange)
					{
						this.rangeTurnBased.MoveIntoRange(ref moveIntoRange, ref useStopAngle);
					}
				}
				else if(ORK.Battle.IsActiveTime())
				{
					if(this.useActiveTimeRange)
					{
						this.rangeActiveTime.MoveIntoRange(ref moveIntoRange, ref useStopAngle);
					}
				}
				else if(ORK.Battle.IsRealTime())
				{
					if(this.useRealTimeRange)
					{
						this.rangeRealTime.MoveIntoRange(ref moveIntoRange, ref useStopAngle);
					}
				}
				else if(ORK.Battle.IsPhase())
				{
					if(this.usePhaseRange)
					{
						this.rangePhase.MoveIntoRange(ref moveIntoRange, ref useStopAngle);
					}
				}
			}
			this.rangeDefault.MoveIntoRange(ref moveIntoRange, ref useStopAngle);
		}
	}
}
