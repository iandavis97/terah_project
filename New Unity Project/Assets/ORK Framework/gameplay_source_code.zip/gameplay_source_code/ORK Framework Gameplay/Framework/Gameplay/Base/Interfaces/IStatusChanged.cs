
namespace ORKFramework
{
	public interface IStatusChanged
	{
		void AttackAttributeChanged(Combatant combatant, int id, int id2, float change);
		
		void DefenceAttributeChanged(Combatant combatant, int id, int id2, float change);
		
		void DefenceAttributeIDChanged(Combatant combatant, int id, int id2);
		
		void StatusValueChanged(Combatant combatant, int id, int change);
		
		void StatusEffectChanged(Combatant combatant, int id);
		
		void LevelChanged(Combatant combatant, int id);
		
		void ClassLevelChanged(Combatant combatant, int id);
		
		void ClassChanged(Combatant combatant, int id);
		
		void AbilitiesChanged(Combatant combatant);
		
		void EquipmentChanged(Combatant combatant);
		
		void CombatantGroupChanged(Combatant combatant);
		
		void CombatantInventoryChanged(Combatant combatant);

		void CombatantBattleStateChanged(Combatant combatant);

		void CombatantActionStateChanged(Combatant combatant);

		void CombatantCastingStateChanged(Combatant combatant);

		void CombatantChoosingStateChanged(Combatant combatant);

		void CombatantTurnStateChanged(Combatant combatant);

		void CombatantGridMoveRangeChanged(Combatant combatant);

		void CombatantResearchChanged(Combatant combatant);

		void CombatantAIChanged(Combatant combatant);

		void CombatantActionBarChanged(Combatant combatant);

		void CombatantDeathStateChanged(Combatant combatant);
	}
}

