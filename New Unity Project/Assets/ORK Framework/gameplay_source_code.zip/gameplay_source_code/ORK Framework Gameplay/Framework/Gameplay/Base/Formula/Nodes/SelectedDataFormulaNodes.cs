﻿
using UnityEngine;
using ORKFramework;
using ORKFramework.Formulas;
using System.Collections.Generic;

namespace ORKFramework.Formulas.Steps
{
	[ORKEditorHelp("Clear Selected Data", "Clears selected data, i.e. either all or " +
		"the selected data of the defined key will be removed.", "")]
	[ORKNodeInfo("Selected Data")]
	public class ClearSelectedDataStep : BaseFormulaStep
	{
		[ORKEditorHelp("Clear All", "Clears all selected data.\n" +
			"If disabled, only the selected data of a defined selected key will be cleared.", "")]
		public bool all = false;

		[ORKEditorInfo(labelText="Selected Key")]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public StringValue selectedKey = new StringValue();

		public ClearSelectedDataStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(this.all)
			{
				call.SelectedData.Clear();
			}
			else
			{
				call.SelectedData.Change(this.selectedKey.GetValue(), null, ListChangeType.Clear);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.all ? "All" : this.selectedKey.GetInfoText();
		}
	}

	[ORKEditorHelp("Selected Data Count", "Checks how many data is stored in a selected data list.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Selected Data")]
	public class SelectedDataCountStep : BaseFormulaCheckStep
	{
		[ORKEditorInfo(labelText="Selected Key")]
		public StringValue selectedKey = new StringValue();

		[ORKEditorHelp("Check Type", "Checks if the count is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the count is between two defined values, including the values.\n" +
			"Range exclusive checks if the count is between two defined values, excluding the values.\n" +
			"Approximately checks if the count is similar to the defined value.", "")]
		public VariableValueCheck check = VariableValueCheck.IsEqual;

		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public FormulaFloat checkValue = new FormulaFloat();

		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"},
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive},
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public FormulaFloat checkValue2;

		public SelectedDataCountStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ValueHelper.CheckVariableValue(
				call.SelectedData.GetCount(this.selectedKey.GetValue()),
				this.checkValue.GetValue(call),
				this.checkValue2 != null ? this.checkValue2.GetValue(call) : 0,
				this.check))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.selectedKey.GetInfoText() + " " +
				this.check + " " + this.checkValue.GetInfoText() +
				((VariableValueCheck.RangeInclusive == this.check ||
					VariableValueCheck.RangeExclusive == this.check) ?
					" - " + this.checkValue2.GetInfoText() : "");
		}
	}

	[ORKEditorHelp("Select Combatant", "Uses combatants as selected data.", "")]
	[ORKNodeInfo("Selected Data")]
	public class SelectCombatantStep : BaseFormulaStep
	{
		[ORKEditorInfo(labelText="Selected Key")]
		public StringValue selectedKey = new StringValue();

		[ORKEditorHelp("Change Type", "Select how the selected data will be changed:\n" +
			"- Add: The combatants will be added to the selected data.\n" +
			"- Remove: The combatants will be removed from the selected data.\n" +
			"- Clear: The selected data will be cleared.\n" +
			"- Set: The combatants will be set as selected data, removing previous data.", "")]
		public ListChangeType changeType = ListChangeType.Set;


		// combatants
		[ORKEditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group.", "")]
		[ORKEditorInfo(separator=true, labelText="Combatant Settings",
			isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("changeType", ListChangeType.Clear, elseCheckGroup=true)]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[ORKEditorHelp("Use Random", "Use a random combatant from the group.", "")]
		[ORKEditorLayout("combatantScope", MenuCombatantScope.Current, elseCheckGroup=true, endCheckGroup=true)]
		public bool useRandom = false;

		[ORKEditorInfo(separator=true)]
		public SelectCombatantSettings selectCombatant = new SelectCombatantSettings();

		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();


		// requirements
		[ORKEditorHelp("Use Requirements", "Use status requirements and game variable conditions " +
			"to check if a combatant will be used.\n" +
			"The requirements are only checked for the combatant itself, not e.g. the combatant's last targets.", "")]
		[ORKEditorInfo("Filter Settings", "Optionally filter the used combatants by using status requirements and variable conditions on them.", "")]
		public bool useRequirements = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useRequirements", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public SimpleCombatantRequirement requirement;

		public SelectCombatantStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ListChangeType.Clear == this.changeType)
			{
				call.SelectedData.Change(
					this.selectedKey.GetValue(),
					null, this.changeType);
			}
			else
			{
				List<Combatant> found = new List<Combatant>();
				Combatant combatant = this.origin.GetCombatant(call);

				if(combatant != null)
				{
					if(MenuCombatantScope.Current == this.combatantScope)
					{
						if(!this.useRequirements || this.requirement.Check(combatant))
						{
							this.selectCombatant.Get(combatant, found);
						}
					}
					else
					{
						List<Combatant> list = new List<Combatant>();
						combatant.Group.GetMembers(this.combatantScope, ref list);
						if(this.useRequirements)
						{
							this.requirement.FilterList(ref list);
						}

						if(this.useRandom)
						{
							this.selectCombatant.Get(list[UnityWrapper.Range(0, list.Count)], found);
						}
						else
						{
							for(int i = 0; i < list.Count; i++)
							{
								this.selectCombatant.Get(list[i], found);
							}
						}
					}
				}

				if(found.Count == 1)
				{
					call.SelectedData.Change(this.selectedKey.GetValue(), found[0], this.changeType);
				}
				else if(found.Count > 1)
				{
					call.SelectedData.Change(this.selectedKey.GetValue(), found, this.changeType);
				}
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.selectedKey.GetInfoText() + " " + this.changeType +
				(ListChangeType.Clear == this.changeType ?
					"" : (" " + this.origin.GetInfoText()));
		}
	}

	[ORKEditorHelp("Select Ability", "Uses abilities of combatants or a newly created ability as selected data.", "")]
	[ORKNodeInfo("Selected Data")]
	public class SelectAbilityStep : BaseFormulaStep
	{
		[ORKEditorInfo(labelText="Selected Key")]
		public StringValue selectedKey = new StringValue();

		[ORKEditorHelp("Change Type", "Select how the selected data will be changed:\n" +
			"- Add: The abilities will be added to the selected data.\n" +
			"- Remove: The abilities will be removed from the selected data.\n" +
			"- Clear: The selected data will be cleared.\n" +
			"- Set: The abilities will be set as selected data, removing previous data.", "")]
		public ListChangeType changeType = ListChangeType.Set;


		// ability settings
		[ORKEditorHelp("Create Ability", "Create a new instance of the defined ability.\n" +
			"If disabled, abilities known by a combatant will be used.", "")]
		[ORKEditorInfo(separator=true, labelText="Ability Settings")]
		[ORKEditorLayout("changeType", ListChangeType.Clear, elseCheckGroup=true)]
		public bool createAbility = false;

		// all abilities
		[ORKEditorHelp("All Abilities", "Get all abilities of the combatant.", "")]
		[ORKEditorLayout("createAbility", false, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool allAbilities = false;

		[ORKEditorHelp("Useable In", "Select where the abilities can be used:\n" +
			"- Field: Useable in the field (i.e. not in battles).\n" +
			"- Battle: Useable in battles (i.e. not in the field).\n" +
			"- Both: Useable in battles and in the field.\n" +
			"- None: Passive abilities.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("allAbilities", true)]
		public UseableIn useableIn = UseableIn.Both;

		[ORKEditorHelp("Add Temporary Abilities", "Select if temporary abilities will be included:\n" +
			"- Yes: Temporary abilities will be included.\n" +
			"- No: Temporary abilities will not be included.\n" +
			"- Only: Only temporary abilities will be used.", "")]
		public IncludeCheckType addTemporary = IncludeCheckType.Yes;

		[ORKEditorHelp("Limit Ability Type", "Limit the abilities to a defined ability type and it's sub-types.", "")]
		public bool limitAbilityType = false;

		[ORKEditorHelp("Ability Type", "Select the ability type that will be used to limit the abilities.", "")]
		[ORKEditorInfo(ORKDataType.AbilityType)]
		[ORKEditorLayout("limitAbilityType", true, endCheckGroup=true)]
		public int abilityTypeID = 0;

		// ability
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public AbilitySelection ability = new AbilitySelection();


		// combatant
		[ORKEditorInfo(separator=true, labelText="Combatant Settings")]
		[ORKEditorLayout("createAbility", false, endCheckGroup=true, endGroups=2)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		public SelectAbilityStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("abilityID"))
			{
				this.ability.SetData(data);
			}
		}

		public override int Calculate(FormulaCall call)
		{
			if(ListChangeType.Clear == this.changeType)
			{
				call.SelectedData.Change(
					this.selectedKey.GetValue(),
					null, this.changeType);
			}
			else if(this.createAbility)
			{
				call.SelectedData.Change(this.selectedKey.GetValue(),
					this.ability.CreateShortcut(AbilityActionType.Ability),
					this.changeType);
			}
			else
			{
				Combatant combatant = this.origin.GetCombatant(call);

				if(combatant != null)
				{
					if(this.allAbilities)
					{
						call.SelectedData.Change(
							this.selectedKey.GetValue(),
							this.limitAbilityType ?
								combatant.Abilities.GetByType(this.abilityTypeID, this.useableIn, this.addTemporary, true) :
								combatant.Abilities.GetAbilities(this.useableIn, this.addTemporary),
							this.changeType);
					}
					else
					{
						AbilityShortcut ability = this.ability.GetAbility(combatant);

						if(ability != null)
						{
							call.SelectedData.Change(
								this.selectedKey.GetValue(),
								ability, this.changeType);
						}
					}
				}
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.selectedKey.GetInfoText() + " " + this.changeType +
				(ListChangeType.Clear == this.changeType ? "" :
				(" " + (this.createAbility ?
					"Create" :
					this.origin.GetInfoText()) +
				(this.allAbilities ? " all abilities" : " " + this.ability.GetInfoText())));
		}
	}

	[ORKEditorHelp("Select Base Attack", "Uses base attacks of combatants as selected data.", "")]
	[ORKNodeInfo("Selected Data")]
	public class SelectBaseAttackStep : BaseFormulaStep
	{
		[ORKEditorInfo(labelText="Selected Key")]
		public StringValue selectedKey = new StringValue();

		[ORKEditorHelp("Change Type", "Select how the selected data will be changed:\n" +
			"- Add: The base attacks will be added to the selected data.\n" +
			"- Remove: The base attacks will be removed from the selected data.\n" +
			"- Clear: The selected data will be cleared.\n" +
			"- Set: The base attacks will be set as selected data, removing previous data.", "")]
		public ListChangeType changeType = ListChangeType.Set;


		// attack settings
		[ORKEditorHelp("Base Attack Scope", "Select the scope of the base attack that will be used:\n" +
			"- Current: Use the current base attack of the combatant.\n" +
			"- Index: Use a base attack at a defined index.\n" +
			"- All: Use all base attacks of the combatant.", "")]
		[ORKEditorInfo(separator=true, labelText="Base Attack Settings")]
		[ORKEditorLayout("changeType", ListChangeType.Clear, elseCheckGroup=true)]
		public BaseAttackScope attackScope = BaseAttackScope.Current;

		[ORKEditorLayout("attackScope", BaseAttackScope.Index, endCheckGroup=true, autoInit=true)]
		public FormulaFloat attackIndex;


		// combatant
		[ORKEditorInfo(separator=true, labelText="Combatant Settings")]
		[ORKEditorLayout(endCheckGroup=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		public SelectBaseAttackStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ListChangeType.Clear == this.changeType)
			{
				call.SelectedData.Change(
					this.selectedKey.GetValue(),
					null, this.changeType);
			}
			else
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null)
				{
					if(BaseAttackScope.All == this.attackScope)
					{
						List<AbilityShortcut> abilities = new List<AbilityShortcut>();
						combatant.Abilities.GetBaseAttacks(ref abilities);
						call.SelectedData.Change(
							this.selectedKey.GetValue(),
							abilities, this.changeType);
					}
					else
					{
						AbilityShortcut ability = null;

						if(BaseAttackScope.Current == this.attackScope)
						{
							ability = combatant.Abilities.GetCurrentBaseAttack();
						}
						else if(BaseAttackScope.Index == this.attackScope)
						{
							ability = combatant.Abilities.GetBaseAttack((int)this.attackIndex.GetValue(call));
						}

						if(ability != null)
						{
							call.SelectedData.Change(
								this.selectedKey.GetValue(),
								ability, this.changeType);
						}
					}
				}
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.selectedKey.GetInfoText() + " " + this.changeType +
				(ListChangeType.Clear == this.changeType ? "" :
				(" " + this.origin.GetInfoText() + " " + this.attackScope.ToString()));
		}
	}

	[ORKEditorHelp("Select Counter Attack", "Uses counter attacks of combatants as selected data.", "")]
	[ORKNodeInfo("Selected Data")]
	public class SelectCounterAttackStep : BaseFormulaStep
	{
		[ORKEditorInfo(labelText="Selected Key")]
		public StringValue selectedKey = new StringValue();

		[ORKEditorHelp("Change Type", "Select how the selected data will be changed:\n" +
			"- Add: The counter attacks will be added to the selected data.\n" +
			"- Remove: The counter attacks will be removed from the selected data.\n" +
			"- Clear: The selected data will be cleared.\n" +
			"- Set: The counter attacks will be set as selected data, removing previous data.", "")]
		public ListChangeType changeType = ListChangeType.Set;


		// combatant
		[ORKEditorInfo(separator=true, labelText="Combatant Settings")]
		[ORKEditorLayout("changeType", ListChangeType.Clear,
			elseCheckGroup=true, endCheckGroup=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		public SelectCounterAttackStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ListChangeType.Clear == this.changeType)
			{
				call.SelectedData.Change(
					this.selectedKey.GetValue(),
					null, this.changeType);
			}
			else
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null)
				{
					call.SelectedData.Change(this.selectedKey.GetValue(),
							combatant.Abilities.GetCounterAttack(), this.changeType);
				}
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.selectedKey.GetInfoText() + " " + this.changeType +
				(ListChangeType.Clear == this.changeType ? "" :
				(" " + this.origin.GetInfoText()));
		}
	}

	[ORKEditorHelp("Select Equipment", "Uses the equipment currently equipped on combatants as selected data.", "")]
	[ORKNodeInfo("Selected Data")]
	public class SelectEquipmentStep : BaseFormulaStep
	{
		[ORKEditorInfo(labelText="Selected Key")]
		public StringValue selectedKey = new StringValue();

		[ORKEditorHelp("Change Type", "Select how the selected data will be changed:\n" +
			"- Add: The equipment will be added to the selected data.\n" +
			"- Remove: The equipment will be removed from the selected data.\n" +
			"- Clear: The selected data will be cleared.\n" +
			"- Set: The equipment will be set as selected data, removing previous data.", "")]
		public ListChangeType changeType = ListChangeType.Set;


		// equipment
		[ORKEditorHelp("All Equipment", "Use all currently equipped weapons and armors of the combatant.\n" +
			"If disabled, only the equipment of a defined equipment part will be used.", "")]
		[ORKEditorInfo(separator=true, labelText="Equipment Settings")]
		[ORKEditorLayout("changeType", ListChangeType.Clear, elseCheckGroup=true)]
		public bool allEquipment = false;

		[ORKEditorHelp("Equipment Part", "Select the equipment part which's current equipment will be used.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		[ORKEditorLayout("allEquipment", false, endCheckGroup=true)]
		public int equipmentPartID = 0;

		[ORKEditorHelp("Limit Item Type", "Limit the equipment to a defined item type and its sub-types.", "")]
		public bool limitItemType = false;

		[ORKEditorHelp("Item Type", "Select the item type that will be used to limit the equipment.", "")]
		[ORKEditorInfo(ORKDataType.ItemType)]
		[ORKEditorLayout("limitItemType", true, endCheckGroup=true)]
		public int itemTypeID = 0;


		// combatant
		[ORKEditorInfo(separator=true, labelText="Combatant Settings")]
		[ORKEditorLayout(endCheckGroup=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		public SelectEquipmentStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ListChangeType.Clear == this.changeType)
			{
				call.SelectedData.Change(
					this.selectedKey.GetValue(),
					null, this.changeType);
			}
			else
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null)
				{
					if(this.allEquipment)
					{
						List<EquipShortcut> equipment = new List<EquipShortcut>();

						for(int j = 0; j < ORK.EquipmentParts.Count; j++)
						{
							if(combatant.Equipment[j].Available &&
								combatant.Equipment[j].Equipped)
							{
								EquipShortcut equip = combatant.Equipment[j].Equipment;

								if(equip != null &&
									!equipment.Contains(equip) &&
									(!this.limitItemType ||
										equip.TypeID == this.itemTypeID ||
										ORK.ItemTypes.Get(equip.TypeID).IsSubTypeOf(this.itemTypeID)))
								{
									equipment.Add(equip);
								}
							}
						}

						call.SelectedData.Change(
							this.selectedKey.GetValue(),
							equipment, this.changeType);
					}
					else if(combatant.Equipment[this.equipmentPartID].Available &&
						combatant.Equipment[this.equipmentPartID].Equipped)
					{
						EquipShortcut equip = combatant.Equipment[this.equipmentPartID].Equipment;

						if(equip != null &&
							(!this.limitItemType ||
								equip.TypeID == this.itemTypeID ||
								ORK.ItemTypes.Get(equip.TypeID).IsSubTypeOf(this.itemTypeID)))
						{
							call.SelectedData.Change(
								this.selectedKey.GetValue(),
								equip, this.changeType);
						}
					}
				}
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.selectedKey.GetInfoText() + " " + this.changeType +
				(ListChangeType.Clear == this.changeType ? "" :
				(" " + this.origin.GetInfoText() +
				(this.allEquipment ?
					" all equipment" :
					" " + ORK.EquipmentParts.GetName(this.equipmentPartID))));
		}
	}

	[ORKEditorHelp("Select Item", "Uses items from the inventory of combatants or newly created items as selected data.", "")]
	[ORKNodeInfo("Selected Data")]
	public class SelectItemStep : BaseFormulaStep
	{
		[ORKEditorInfo(labelText="Selected Key")]
		public StringValue selectedKey = new StringValue();

		[ORKEditorHelp("Change Type", "Select how the selected data will be changed:\n" +
			"- Add: The items will be added to the selected data.\n" +
			"- Remove: The items will be removed from the selected data.\n" +
			"- Clear: The items data will be cleared.\n" +
			"- Set: The items will be set as selected data, removing previous data.", "")]
		public ListChangeType changeType = ListChangeType.Set;


		// item settings
		[ORKEditorHelp("Create Item", "Create new instances of the defined items.\n" +
			"If disabled, items from the inventories of combatants will be used.", "")]
		[ORKEditorInfo(separator=true, labelText="Item Settings")]
		[ORKEditorLayout("changeType", ListChangeType.Clear, elseCheckGroup=true)]
		public bool createItem = false;

		// all items
		[ORKEditorHelp("All Items", "Use all items currently in the combatant's inventory.\n" +
			"If disabled, only the defined items will be used.", "")]
		[ORKEditorLayout("createItem", false, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool allItems = false;

		[ORKEditorHelp("Add Money", "Money will be added to the list.", "")]
		[ORKEditorLayout("allItems", true)]
		public bool addMoney = false;

		[ORKEditorHelp("Add Items", "Items will be added to the list.", "")]
		public bool addItems = true;

		[ORKEditorHelp("Add Weapons", "Weapons will be added to the list.", "")]
		public bool addWeapons = true;

		[ORKEditorHelp("Add Armors", "Armors will be added to the list.", "")]
		public bool addArmors = true;

		[ORKEditorHelp("Add AI Behaviours", "AI behaviours will be added to the list.", "")]
		public bool addAIBehavoiurs = true;

		[ORKEditorHelp("Add AI Rulesets", "AI rulesets will be added to the list.", "")]
		public bool addAIRulesets = true;

		[ORKEditorHelp("Add Crafting Recipes", "Crafting recipes will be added to the list.", "")]
		public bool addCraftingRecipes = true;

		// item type
		[ORKEditorHelp("Limit Item Type", "Limit the items to a defined item type and its sub-types.", "")]
		[ORKEditorInfo(separator=true)]
		public bool limitItemType = false;

		[ORKEditorHelp("Item Type", "Select the item type that will be used to limit the items.", "")]
		[ORKEditorInfo(ORKDataType.ItemType)]
		[ORKEditorLayout("limitItemType", true, endCheckGroup=true)]
		public int itemTypeID = 0;

		// define items
		[ORKEditorArray(false, "Add Item", "Adds an item to the list.", "",
			"Remove", "Removes this item from the list.", "",
			noRemoveCount=1, isCopy=true, isMove=true, foldout=true, foldoutText=new string[] {
				"Item", "Define the item.", ""
		})]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public ItemGain[] item = new ItemGain[] {new ItemGain()};


		// combatant
		[ORKEditorInfo(separator=true, labelText="Combatant Settings")]
		[ORKEditorLayout("createItem", false, endCheckGroup=true, endGroups=2)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		public SelectItemStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ListChangeType.Clear == this.changeType)
			{
				call.SelectedData.Change(
					this.selectedKey.GetValue(),
					null, this.changeType);
			}
			else if(this.createItem)
			{
				List<IShortcut> items = new List<IShortcut>();
				for(int i = 0; i < this.item.Length; i++)
				{
					items.Add(this.item[i].CreateShortcut());
				}
				call.SelectedData.Change(
					this.selectedKey.GetValue(),
					items, this.changeType);
			}
			else
			{
				Combatant combatant = this.origin.GetCombatant(call);
				if(combatant != null)
				{
					List<IShortcut> items = new List<IShortcut>();
					if(this.allItems)
					{
						combatant.Inventory.GetAll(
							this.addMoney, this.addItems, this.addWeapons, this.addArmors,
							this.addAIBehavoiurs, this.addAIRulesets, this.addCraftingRecipes,
							this.limitItemType ? this.itemTypeID : -1, true, ref items);
					}
					else
					{
						for(int j = 0; j < this.item.Length; j++)
						{
							this.item[j].GetFromInventory(combatant.Inventory, true, ref items);
						}
					}
					call.SelectedData.Change(
						this.selectedKey.GetValue(),
						items, this.changeType);
				}
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.selectedKey.GetInfoText() + " " + this.changeType +
				(ListChangeType.Clear == this.changeType ? "" :
				(" " + (this.createItem ?
					"Create" :
					(this.origin.GetInfoText() + (this.allItems ? " all items" : "")))));
		}
	}
}
