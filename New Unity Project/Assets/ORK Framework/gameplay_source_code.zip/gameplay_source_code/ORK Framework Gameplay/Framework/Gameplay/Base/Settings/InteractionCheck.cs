
using UnityEngine;
using ORKFramework.Behaviours;
using ORKFramework.UI;
using System.Collections.Generic;

namespace ORKFramework
{
	public class InteractionCheck : BaseData
	{
		[ORKEditorHelp("Any Interaction", "Any interaction is available.", "")]
		public bool any = true;

		[ORKEditorHelp("Battle Interaction", "A battle interaction is available.", "")]
		[ORKEditorLayout("any", false)]
		public bool battle = false;

		[ORKEditorHelp("Event Interaction", "An event interaction is available.", "")]
		public bool evtInt = false;

		[ORKEditorHelp("Shop Interaction", "A shop interaction is available.", "")]
		public bool shop = false;

		[ORKEditorHelp("Item Interaction", "An item interaction is available.", "")]
		public bool item = false;

		[ORKEditorHelp("Item Box", "An item box is available.", "")]
		public bool itemBox = false;

		[ORKEditorHelp("Music Player Interaction", "A music player interaction is available.", "")]
		public bool musicPlayer = false;

		[ORKEditorHelp("Save Point Interaction", "A save point interaction is available.", "")]
		public bool savePoint = false;

		[ORKEditorHelp("Scene Change Interaction", "A scene change interaction is available.", "")]
		public bool sceneChanger = false;

		[ORKEditorHelp("Variable Event Interaction", "A variable event interaction is available.", "")]
		public bool variableEvent = false;

		[ORKEditorHelp("Custom Interaction", "A custom interaction is available.", "")]
		public bool custom = false;

		[ORKEditorHelp("Custom Type", "The name of the custom interaction type.\n" +
			"Leave empty if no specific custom type is needed (i.e. all custom interactions).", "")]
		[ORKEditorLayout("custom", true, endCheckGroup=true, endGroups=2)]
		public string customType = "";

		public InteractionCheck()
		{

		}

		public bool Check()
		{
			return (this.any && ORK.Control.InteractionsAvailable(InteractionType.Any, "")) ||
				(this.battle && ORK.Control.InteractionsAvailable(InteractionType.Battle, "")) ||
				(this.evtInt && ORK.Control.InteractionsAvailable(InteractionType.Event, "")) ||
				(this.shop && ORK.Control.InteractionsAvailable(InteractionType.Shop, "")) ||
				(this.item && ORK.Control.InteractionsAvailable(InteractionType.Item, "")) ||
				(this.itemBox && ORK.Control.InteractionsAvailable(InteractionType.ItemBox, "")) ||
				(this.musicPlayer && ORK.Control.InteractionsAvailable(InteractionType.MusicPlayer, "")) ||
				(this.savePoint && ORK.Control.InteractionsAvailable(InteractionType.SavePoint, "")) ||
				(this.sceneChanger && ORK.Control.InteractionsAvailable(InteractionType.SceneChange, "")) ||
				(this.variableEvent && ORK.Control.InteractionsAvailable(InteractionType.VariableEvent, "")) ||
				(this.custom && ORK.Control.InteractionsAvailable(InteractionType.Custom, this.customType));
		}

		public bool Interact(InteractionController ic)
		{
			return (this.any && ic.Interact(InteractionType.Any, "")) ||
				(this.battle && ic.Interact(InteractionType.Battle, "")) ||
				(this.evtInt && ic.Interact(InteractionType.Event, "")) ||
				(this.shop && ic.Interact(InteractionType.Shop, "")) ||
				(this.item && ic.Interact(InteractionType.Item, "")) ||
				(this.itemBox && ic.Interact(InteractionType.ItemBox, "")) ||
				(this.musicPlayer && ic.Interact(InteractionType.MusicPlayer, "")) ||
				(this.savePoint && ic.Interact(InteractionType.SavePoint, "")) ||
				(this.sceneChanger && ic.Interact(InteractionType.SceneChange, "")) ||
				(this.variableEvent && ic.Interact(InteractionType.VariableEvent, "")) ||
				(this.custom && ic.Interact(InteractionType.Custom, this.customType));
		}

		public bool IsType(BaseInteraction interaction)
		{
			return this.any ||
				(this.battle && InteractionType.Battle == interaction.Type) ||
				(this.evtInt && InteractionType.Event == interaction.Type) ||
				(this.shop && InteractionType.Shop == interaction.Type) ||
				(this.item && InteractionType.Item == interaction.Type) ||
				(this.itemBox && InteractionType.ItemBox == interaction.Type) ||
				(this.musicPlayer && InteractionType.MusicPlayer == interaction.Type) ||
				(this.savePoint && InteractionType.SavePoint == interaction.Type) ||
				(this.sceneChanger && InteractionType.SceneChange == interaction.Type) ||
				(this.variableEvent && InteractionType.VariableEvent == interaction.Type) ||
				(this.custom && InteractionType.Custom == interaction.Type) &&
					(this.customType == "" || interaction.customType == this.customType);
		}

		public List<BaseInteraction> GetAll()
		{
			if(this.any)
			{
				return ORK.Game.Interactions.GetAll();
			}
			else
			{
				List<BaseInteraction> list = new List<BaseInteraction>();
				if(this.battle)
				{
					list.AddRange(ORK.Game.Interactions.Get(InteractionType.Battle, this.customType));
				}
				if(this.evtInt)
				{
					list.AddRange(ORK.Game.Interactions.Get(InteractionType.Event, this.customType));
				}
				if(this.shop)
				{
					list.AddRange(ORK.Game.Interactions.Get(InteractionType.Shop, this.customType));
				}
				if(this.item)
				{
					list.AddRange(ORK.Game.Interactions.Get(InteractionType.Item, this.customType));
				}
				if(this.itemBox)
				{
					list.AddRange(ORK.Game.Interactions.Get(InteractionType.ItemBox, this.customType));
				}
				if(this.musicPlayer)
				{
					list.AddRange(ORK.Game.Interactions.Get(InteractionType.MusicPlayer, this.customType));
				}
				if(this.savePoint)
				{
					list.AddRange(ORK.Game.Interactions.Get(InteractionType.SavePoint, this.customType));
				}
				if(this.sceneChanger)
				{
					list.AddRange(ORK.Game.Interactions.Get(InteractionType.SceneChange, this.customType));
				}
				if(this.variableEvent)
				{
					list.AddRange(ORK.Game.Interactions.Get(InteractionType.VariableEvent, this.customType));
				}
				if(this.custom)
				{
					list.AddRange(ORK.Game.Interactions.Get(InteractionType.Custom, this.customType));
				}
				return list;
			}
		}

		public BaseInteraction GetFirst(InteractionHUDSource source)
		{
			BaseInteraction interaction = null;
			if(InteractionHUDSource.InteractionController == source)
			{
				interaction = this.GetFirstIC(ORK.Control.InteractionController);
			}
			else if(InteractionHUDSource.Cursor == source)
			{
				interaction = this.GetFirstCursor(ORK.Game.GetPlayer());
			}
			else if(InteractionHUDSource.InteractionControllerFirst == source)
			{
				interaction = this.GetFirstIC(ORK.Control.InteractionController);
				if(interaction == null)
				{
					interaction = this.GetFirstCursor(ORK.Game.GetPlayer());
				}
			}
			else if(InteractionHUDSource.CursorFirst == source)
			{
				interaction = this.GetFirstCursor(ORK.Game.GetPlayer());
				if(interaction == null)
				{
					interaction = this.GetFirstIC(ORK.Control.InteractionController);
				}
			}
			return interaction;
		}

		public BaseInteraction GetFirstCursor(GameObject startingObject)
		{
			if(ORK.Game.Interactions.CursorInteractions.Count > 0)
			{
				List<BaseInteraction> interactions = ORK.Game.Interactions.CursorInteractions;
				for(int i = 0; i < interactions.Count; i++)
				{
					if(interactions[i] != null &&
						interactions[i].enabled &&
						interactions[i].CanInteract(EventStartType.Interact, startingObject) &&
						(this.IsType(interactions[i]) &&
							(customType == "" || interactions[i].customType == customType)))
					{
						return interactions[i];
					}
				}
			}
			return null;
		}

		public BaseInteraction GetFirstIC(InteractionController ic)
		{
			if(ic != null)
			{
				if(this.any)
				{
					return ic.GetFirstAvailable(InteractionType.Any, "");
				}
				else
				{
					BaseInteraction baseInteraction = null;
					if(this.battle)
					{
						baseInteraction = ic.GetFirstAvailable(InteractionType.Battle, "");
						if(baseInteraction != null)
						{
							return baseInteraction;
						}
					}
					if(this.evtInt)
					{
						baseInteraction = ic.GetFirstAvailable(InteractionType.Event, "");
						if(baseInteraction != null)
						{
							return baseInteraction;
						}
					}
					if(this.shop)
					{
						baseInteraction = ic.GetFirstAvailable(InteractionType.Shop, "");
						if(baseInteraction != null)
						{
							return baseInteraction;
						}
					}
					if(this.item)
					{
						baseInteraction = ic.GetFirstAvailable(InteractionType.Item, "");
						if(baseInteraction != null)
						{
							return baseInteraction;
						}
					}
					if(this.itemBox)
					{
						baseInteraction = ic.GetFirstAvailable(InteractionType.ItemBox, "");
						if(baseInteraction != null)
						{
							return baseInteraction;
						}
					}
					if(this.musicPlayer)
					{
						baseInteraction = ic.GetFirstAvailable(InteractionType.MusicPlayer, "");
						if(baseInteraction != null)
						{
							return baseInteraction;
						}
					}
					if(this.savePoint)
					{
						baseInteraction = ic.GetFirstAvailable(InteractionType.SavePoint, "");
						if(baseInteraction != null)
						{
							return baseInteraction;
						}
					}
					if(this.sceneChanger)
					{
						baseInteraction = ic.GetFirstAvailable(InteractionType.SceneChange, "");
						if(baseInteraction != null)
						{
							return baseInteraction;
						}
					}
					if(this.variableEvent)
					{
						baseInteraction = ic.GetFirstAvailable(InteractionType.VariableEvent, "");
						if(baseInteraction != null)
						{
							return baseInteraction;
						}
					}
					if(this.custom)
					{
						baseInteraction = ic.GetFirstAvailable(InteractionType.Custom, this.customType);
						if(baseInteraction != null)
						{
							return baseInteraction;
						}
					}
					return baseInteraction;
				}
			}
			return null;
		}
	}
}
