
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class AbilityBMItem : BMItem
	{
		private AbilityShortcut ability;

		private bool blockBattleCamera = false;

		public AbilityBMItem(AbilityShortcut ability, ChoiceContent content) : this(ability, content, false)
		{

		}

		public AbilityBMItem(AbilityShortcut ability, ChoiceContent content, bool blockBattleCamera)
		{
			this.ability = ability;
			this.content = content;
			this.blockBattleCamera = blockBattleCamera;
		}

		public override void CreateDrag(Combatant owner)
		{
			if(this.content.Data == null)
			{
				// drag+drop
				this.content.isDragable = ORK.Battle.Settings.bmDrag;
				this.content.clickCount = ORK.Battle.Settings.bmClick ? ORK.Battle.Settings.bmClickCount : 0;
				this.content.isTooltip = ORK.Battle.Settings.bmTooltip;
				if(this.content.isDragable || this.content.clickCount > 0 || this.content.isTooltip)
				{
					this.content.Data = this.ability.GetDrag(owner);
				}
			}

			// portrait
			if(this.content.portrait == null &&
				owner.Battle.BattleMenu.Settings.showAbilityPortraits)
			{
				this.content.portrait = this.ability.GetPortrait(owner.Battle.BattleMenu.Settings.abilityPortraitTypeID);
			}
		}

		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			this.content.Active = this.ability.CanUse(owner,
					AbilityActionType.CounterAttack != this.ability.Type, true) &&
				(this.ability.IsNoneTarget() || 
					this.ability.HasPossibleTargets(owner, null));
			return tmp != this.content.Active;
		}

		public override void Selected(Combatant owner)
		{
			owner.Battle.BattleMenu.TargetHighlight.SelectAction(this.ability);
		}

		public override bool Accepted(Combatant owner)
		{
			if(owner.Battle.BattleMenu != null)
			{
				TargetSettings targetSettings = TargetSettings.Get(this.ability);
				if(targetSettings.TargetSelf())
				{
					BaseAction action = new AbilityAction(owner, this.ability);
					action.blockBattleCamera = this.blockBattleCamera;
					action.SetTarget(owner);
					owner.Battle.BattleMenu.AddAction(action);
					return true;
				}
				else if(this.ability.IsNoneTarget())
				{
					if(ORK.Battle.Grid != null &&
						targetSettings.noneSelectGridCell)
					{
						owner.Battle.BattleMenu.StartGridTargetCellSelection(this.ability, this.blockBattleCamera);
						owner.Battle.BattleMenu.CloseSilent();
					}
					else
					{
						BaseAction action = new AbilityAction(owner, this.ability);
						action.blockBattleCamera = this.blockBattleCamera;
						if(action.targetRaycast.NeedInteraction())
						{
							owner.Battle.BattleMenu.RayAction = action;
							owner.Battle.BattleMenu.CloseSilent();
						}
						else
						{
							if(action.targetRaycast.active)
							{
								action.targetRaycast.GetAutoPoint(owner.GameObject, VectorHelper.GetScreenCenter(), action);
							}
							owner.Battle.BattleMenu.AddAction(action);
						}
					}
					return true;
				}
				else
				{
					// use on group target
					if(owner.Battle.BattleMenu.Settings.useGroupTarget)
					{
						Combatant target = owner.Group.SelectedTargets.GetAbilityTarget(owner, this.ability);
						if(target != null)
						{
							BaseAction action = new AbilityAction(owner, this.ability);
							action.blockBattleCamera = this.blockBattleCamera;
							action.SetTarget(target);
							owner.Battle.BattleMenu.AddAction(action);
							return true;
						}
					}
					// use on individual target
					if(owner.Battle.BattleMenu.Settings.useIndividualTarget)
					{
						Combatant target = owner.SelectedTargets.GetAbilityTarget(owner, this.ability);
						if(target != null)
						{
							BaseAction action = new AbilityAction(owner, this.ability);
							action.blockBattleCamera = this.blockBattleCamera;
							action.SetTarget(target);
							owner.Battle.BattleMenu.AddAction(action);
							return true;
						}
					}

					// display target menu
					owner.Battle.BattleMenu.TargetHighlight.AcceptAction(this.ability);
					List<BMItem> list = new List<BMItem>();

					int selection = -1;
					if(this.ability.IsSingleTarget())
					{
						for(int i = 0; i < owner.Battle.BattleMenu.TargetHighlight.AvailableTargets.Count; i++)
						{
							List<Combatant> tmp = new List<Combatant>();
							tmp.Add(owner.Battle.BattleMenu.TargetHighlight.AvailableTargets[i]);
							list.Add(new TargetBMItem(
								owner.Battle.BattleMenu.GetCombatantChoice(owner.Battle.BattleMenu.TargetHighlight.AvailableTargets[i]),
								this.ability, tmp, this.blockBattleCamera));

							if(selection < 0 &&
								targetSettings.autoTarget.useAutoTarget &&
								targetSettings.autoTarget.autoTarget.Check(owner.Battle.BattleMenu.TargetHighlight.AvailableTargets[i]))
							{
								selection = i;
							}
						}
					}
					else if(this.ability.IsGroupTarget())
					{
						list.Add(new TargetBMItem(
							ORK.BattleTexts.GetAllCombatantsContent(
								targetSettings.targetType,
								owner.Battle.BattleMenu.Settings.contentLayout),
							this.ability, new List<Combatant>(owner.Battle.BattleMenu.TargetHighlight.AvailableTargets),
							this.blockBattleCamera));
					}

					if(list.Count > 0)
					{
						if(ORK.Battle.TargetSettings.useTargetMenu)
						{
							owner.Battle.BattleMenu.Settings.AddBack(list);
						}

						owner.Battle.BattleMenu.TargetHighlight.AcceptHighlights();
						owner.Battle.BattleMenu.Show(list, selection < 0 ? 0 : selection, BattleMenuMode.Target);
						return true;
					}
				}
			}
			return false;
		}

		public override bool ChangeUseLevel(int change, Combatant owner)
		{
			if(this.ability.ChangeUseLevel(change, ORK.GameControls.loopAbilityLevels))
			{
				if(owner.Battle.BattleMenu != null)
				{
					if(owner.Battle.BattleMenu.Box != null)
					{
						owner.Battle.BattleMenu.Box.Audio.PlayAbilityLevel();
					}
					this.content = owner.Battle.BattleMenu.Settings.contentLayout.GetChoiceContent(this.ability, owner);
				}
				return true;
			}
			return false;
		}
	}
}
