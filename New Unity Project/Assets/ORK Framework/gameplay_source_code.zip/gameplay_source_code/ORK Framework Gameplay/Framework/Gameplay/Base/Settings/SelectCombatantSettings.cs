﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public enum SelectCombatantType { Combatant, GroupTarget, IndividualTarget, LastTarget, AttackedBy, KilledBy };

	public class SelectCombatantSettings : BaseData
	{
		[ORKEditorHelp("Combatant Origin", "Select if the combatant itself or e.g. the combatant's last target is used:\n" +
			"- Combatant: Uses the combatant itself.\n" +
			"- Group Target: Uses the combatant's group targets.\n" +
			"- Individual Target: Uses the combatant's individual targets.\n" +
			"- Last Target: Uses the last target(s) of the combatant.\n" +
			"- Attacked By: Uses the combatants the combatant was attacked by.\n" +
			"- Killed By: Uses the combatant that previously killed the combatant.", "")]
		public SelectCombatantType origin = SelectCombatantType.Combatant;


		// group/individual target
		[ORKEditorHelp("Target Index", "The index of the group/individual target.\n" +
			"Set to -1 to use all available group/individual targets.", "")]
		[ORKEditorLimit(-1, false)]
		[ORKEditorLayout(new string[] { "origin", "origin"},
			new System.Object[] { SelectCombatantType.GroupTarget, SelectCombatantType.IndividualTarget},
			needed=Needed.One, endCheckGroup=true)]
		public int targetIndex = -1;

		public SelectCombatantSettings()
		{

		}

		public void Get(Combatant combatant, List<Combatant> list)
		{
			if(combatant != null)
			{
				if(SelectCombatantType.Combatant == this.origin)
				{
					if(!list.Contains(combatant))
					{
						list.Add(combatant);
					}
				}
				else if(SelectCombatantType.GroupTarget == this.origin)
				{
					this.GetSelectedTargets(combatant.Group.SelectedTargets, list);
				}
				else if(SelectCombatantType.IndividualTarget == this.origin)
				{
					this.GetSelectedTargets(combatant.SelectedTargets, list);
				}
				else if(SelectCombatantType.LastTarget == this.origin)
				{
					for(int i = 0; i < combatant.Battle.LastTargets.Count; i++)
					{
						if(list[i] != null &&
							!list.Contains(combatant.Battle.LastTargets[i]))
						{
							list.Add(combatant.Battle.LastTargets[i]);
						}
					}
				}
				else if(SelectCombatantType.AttackedBy == this.origin)
				{
					for(int i = 0; i < combatant.Battle.AttackedBy.Count; i++)
					{
						if(list[i] != null &&
							!list.Contains(combatant.Battle.AttackedBy[i]))
						{
							list.Add(combatant.Battle.AttackedBy[i]);
						}
					}
				}
				else if(SelectCombatantType.KilledBy == this.origin)
				{
					if(combatant.Battle.KilledBy != null &&
						!list.Contains(combatant.Battle.KilledBy))
					{
						list.Add(combatant.Battle.KilledBy);
					}
				}
			}
		}

		private void GetSelectedTargets(SelectedTargets selectedTargets, List<Combatant> list)
		{
			if(this.targetIndex == -1)
			{
				for(int i = 0; i < selectedTargets.Count; i++)
				{
					if(selectedTargets[i] != null &&
						!list.Contains(selectedTargets[i]))
					{
						list.Add(selectedTargets[i]);
					}
				}
			}
			else if(this.targetIndex >= 0 &&
				this.targetIndex < selectedTargets.Count &&
				selectedTargets[this.targetIndex] != null &&
				!list.Contains(selectedTargets[this.targetIndex]))
			{
				list.Add(selectedTargets[this.targetIndex]);
			}
		}
	}
}
