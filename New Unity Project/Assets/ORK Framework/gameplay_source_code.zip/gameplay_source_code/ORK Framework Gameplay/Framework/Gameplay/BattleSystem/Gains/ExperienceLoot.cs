
using System.Collections.Generic;

namespace ORKFramework
{
	public class ExperienceLoot : ISaveData
	{
		public int experience = 0;

		public int baseLevel = 1;

		public int classLevel = 1;

		public ExperienceLoot(int exp, int lvl, int clvl)
		{
			this.experience = exp;
			this.baseLevel = lvl;
			this.classLevel = clvl;
		}

		public ExperienceLoot(DataObject data)
		{
			this.LoadGame(data);
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			data.Set("experience", this.experience);
			data.Set("baseLevel", this.baseLevel);
			data.Set("classLevel", this.classLevel);

			return data;
		}

		public void LoadGame(DataObject data)
		{
			if(data != null)
			{
				data.Get("experience", ref this.experience);
				data.Get("baseLevel", ref this.baseLevel);
				data.Get("classLevel", ref this.classLevel);
			}
		}
	}
}
