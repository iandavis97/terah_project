﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class EquipmentPrefabSettings : BaseData
	{
		// prefab
		public EquipmentPrefab prefab = new EquipmentPrefab();


		// conditional prefabs
		[ORKEditorInfo(separator=true)]
		[ORKEditorArray(false, "Add Conditional Prefab", "Adds a conditional prefab.\n" +
			"A conditional prefab can replace the item's prefab based on variable conditions.\n" +
			"The first conditional prefab with valid conditions will be used. " +
			"If none is valid, the base prefab will be used.", "",
			"Remove", "Removes this conditional prefab.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Conditional Prefab", "A conditional prefab can replace the item's " +
				"prefab based on variable conditions.\n" +
				"The first conditional prefab with valid conditions will be used. " +
				"If none is valid, the base prefab will be used.", ""
		})]
		public EquipmentConditionalPrefab[] conditionalPrefab = new EquipmentConditionalPrefab[0];

		public EquipmentPrefabSettings()
		{

		}

		public bool HasConditions
		{
			get
			{
				for(int i = 0; i < this.conditionalPrefab.Length; i++)
				{
					if(this.conditionalPrefab[i].condition.gameVariable.Length > 0)
					{
						return true;
					}
				}
				return false;
			}
		}

		public int GetPrefabIndex(IVariableSource variableSource)
		{
			// conditional prefab
			for(int i = 0; i < this.conditionalPrefab.Length; i++)
			{
				if(this.conditionalPrefab[i].Check(variableSource))
				{
					return i;
				}
			}
			return -1;
		}

		public EquipmentPrefab Get(int index)
		{
			if(index >= 0 && 
				index < this.conditionalPrefab.Length)
			{
				return this.conditionalPrefab[index].prefab;
			}
			return this.prefab;
		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public GameObject GetPrefab(IVariableSource variableSource, bool isPrefabView)
		{
			GameObject prefab = null;

			// conditional prefab
			for(int i = 0; i < this.conditionalPrefab.Length; i++)
			{
				if(this.conditionalPrefab[i].Check(variableSource))
				{
					if(isPrefabView)
					{
						prefab = this.conditionalPrefab[i].prefab.prefabViewPrefab;
					}
					if(prefab == null)
					{
						prefab = this.conditionalPrefab[i].prefab.itemPrefab.prefab;
					}
					return prefab;
				}
			}

			// base prefab
			if(isPrefabView &&
				prefab == null)
			{
				prefab = this.prefab.prefabViewPrefab;
			}
			if(prefab == null)
			{
				prefab = this.prefab.itemPrefab.prefab;
			}
			return prefab;
		}

		public GameObject GetPrefab(IVariableSource variableSource, ref int prefabIndex, ref Vector3 offset)
		{
			// conditional prefab
			for(int i = 0; i < this.conditionalPrefab.Length; i++)
			{
				if(this.conditionalPrefab[i].Check(variableSource))
				{
					prefabIndex = i;
					offset = this.conditionalPrefab[i].prefab.itemPrefab.spawnOffset;
					return this.conditionalPrefab[i].prefab.itemPrefab.prefab;
				}
			}

			// base prefab
			prefabIndex = -1;
			offset = this.prefab.itemPrefab.spawnOffset;
			return this.prefab.itemPrefab.prefab;
		}


		/*
		============================================================================
		Equipment viewer functions
		============================================================================
		*/
		public GameObject CreateViewerPrefab(Transform parent, IVariableSource variableSource, bool isPrefabView)
		{
			// conditional prefab
			for(int i = 0; i < this.conditionalPrefab.Length; i++)
			{
				if(this.conditionalPrefab[i].Check(variableSource))
				{
					return this.conditionalPrefab[i].prefab.CreateViewerPrefab(parent, isPrefabView);
				}
			}

			// base prefab
			return this.prefab.CreateViewerPrefab(parent, isPrefabView);
		}

		public Material GetViewerMaterial(IVariableSource variableSource, bool isPrefabView)
		{
			// conditional prefab
			for(int i = 0; i < this.conditionalPrefab.Length; i++)
			{
				if(this.conditionalPrefab[i].Check(variableSource))
				{
					return this.conditionalPrefab[i].prefab.GetViewerMaterial(isPrefabView);
				}
			}

			// base prefab
			return this.prefab.GetViewerMaterial(isPrefabView);
		}


		/*
		============================================================================
		Portrait functions
		============================================================================
		*/
		public GameObject GetPortraitPrefab(IVariableSource variableSource)
		{
			GameObject prefab = null;

			// conditional prefab
			for(int i = 0; i < this.conditionalPrefab.Length; i++)
			{
				if(this.conditionalPrefab[i].Check(variableSource))
				{
					if(prefab == null)
					{
						prefab = this.conditionalPrefab[i].prefab.prefabViewViewerPrefab;
					}
					if(prefab == null)
					{
						prefab = this.conditionalPrefab[i].prefab.viewerPrefab;
					}
					if(prefab == null)
					{
						prefab = this.conditionalPrefab[i].prefab.prefabViewPrefab;
					}
					if(prefab == null)
					{
						prefab = this.conditionalPrefab[i].prefab.itemPrefab.prefab;
					}
					return prefab;
				}
			}

			// base prefab
			if(prefab == null)
			{
				prefab = this.prefab.prefabViewViewerPrefab;
			}
			if(prefab == null)
			{
				prefab = this.prefab.viewerPrefab;
			}
			if(prefab == null)
			{
				prefab = this.prefab.prefabViewPrefab;
			}
			if(prefab == null)
			{
				prefab = this.prefab.itemPrefab.prefab;
			}
			return prefab;
		}

		public void SetPortraitPrefab(TypePrefabViewPortrait portrait, IVariableSource variableSource)
		{
			if(portrait != null &&
				portrait.CanSetPrefab)
			{
				portrait.SetPrefab(this.GetPortraitPrefab(variableSource));
				if(this.HasConditions &&
					portrait.PrefabView.clearCall == null)
				{
					// check
					Notify check = delegate()
					{
						portrait.SetPrefab(this.GetPortraitPrefab(variableSource));
					};

					// register
					ORK.Game.Variables.Changed += check;
					if(variableSource != null &&
						variableSource.HasVariables)
					{
						variableSource.Variables.Changed += check;
					}

					// remove
					portrait.PrefabView.clearCall = delegate ()
					{
						ORK.Game.Variables.Changed -= check;
						if(variableSource != null &&
							variableSource.HasVariables)
						{
							variableSource.Variables.Changed -= check;
						}
					};

				}
			}
		}
	}
}
