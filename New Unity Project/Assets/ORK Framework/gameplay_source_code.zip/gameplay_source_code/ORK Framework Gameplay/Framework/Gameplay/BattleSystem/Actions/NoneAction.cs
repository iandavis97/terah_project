
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class NoneAction : BaseAction
	{
		private bool isSilent = false;

		public NoneAction(Combatant user, bool isSilent)
		{
			this.user = user;
			this.target = new List<Combatant>();
			this.target.Add(user);

			this.isSilent = isSilent;

			if(!this.isSilent ||
				ORK.Battle.IsActiveTime())
			{
				this.actionCost = ORK.Battle.GetNoneActionCost(user);
			}

			this.CheckActionAffiliation();
		}

		public override bool IsType(ActionType t)
		{
			return ActionType.None == t;
		}

		public override IShortcut Shortcut
		{
			get { return this.user.Shortcuts.NoneShortcut; }
		}


		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		public override bool CanUse()
		{
			return this.isSilent ||
				(this.user != null &&
					!this.user.Status.IsDead &&
					!this.user.Status.Effects.BlockAllActions);
		}

		public override void ActionAdded()
		{
			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleAddNone)
				{
					this.user.Setting.consoleAddNone.Print(this.user);
				}
				else
				{
					ORK.ConsoleSettings.actionAddNone.Print(this.user);
				}
			}
			this.user.Battle.InitTurnEnd(false);
		}

		protected override void ActionStartSetup()
		{
			if(!this.isSilent)
			{
				if(ORK.BattleTexts.showInfo)
				{
					ORK.BattleTexts.noneInfo.Show(this.user, "");
				}

				if(ORK.ConsoleSettings.displayActions)
				{
					if(this.user.Setting.ownConsoleNone)
					{
						this.user.Setting.consoleNone.Print(this.user);
					}
					else
					{
						ORK.ConsoleSettings.actionNone.Print(this.user);
					}
				}

				this.user.GetBattleAnimation(BattleAnimationType.None, ref this.events);
			}
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate)
		{

		}

		protected override void ActionEndSetup()
		{
			if(!this.isSilent)
			{
				this.user.Abilities.LastAbilityID = -1;
			}
			this.user.Battle.InitTurnEnd(true);
		}
	}
}
