﻿
namespace ORKFramework
{
	// data sorting
	public enum TypeSorting { None, Name, ID };
	public enum ContentSorting { None, Name, ID, Type, TypeName, TypeID };

	// new content mark
	public enum MarkNewContentType { None, FirstAdd, EachAdd, EachChange };
	public enum UnmarkNewContentType { None, View, Selection };


	// input/control
	public enum InputKeyType { None, UnityInputManager, KeyCode, ORKInputKey, KeyCombo, Mouse, Touch, Custom };
	public enum InputHandling { Down, Hold, Up, Any };
	public enum BattleControlBlock { None, Battle, AllActions, PlayerActions };
	public enum AllowTurnControl { None, Always, WhileChoosing, WhileInAction };
	public enum Orientation { None, Front, Back, Left, Right };
	public enum HorizontalPlaneType { XZ, XY };
	public enum ControlMapKeyType { Action, AutoAttack, GlobalEvent };
	public enum PlayerControlType { None, Button, Mouse };
	public enum CameraControlType { None, Follow, Look, Mouse, FirstPerson, TopDownBorder };
	public enum CustomControlType { Player, Camera };
	public enum MouseControlMoveType { CharacterController, EventMover, NavMeshAgent };
	public enum CollisionCameraType { Center, Horizontal, Vertical, Cross };
	public enum RaycastType { Only3D, Only2D, First3D, First2D };


	// formula
	public enum StatusOrigin { User, Target, Player, Selected };
	public enum FormulaOperator { Add, Sub, Multiply, Divide, Modulo, PowerOf, Log, Set };
	public enum SimpleOperator { Add, Sub, Set };
	public enum ValueOrigin { Value, Status, Formula, Random };
	public enum Rounding { None, Ceil, Floor, Round };
	public enum StatusValueOrigin { Base, Current, Maximum };
	public enum Vector3Operator { Add, Sub, Set, Cross, Min, Max, Scale, Project, Reflect };
	public enum FormulaFloatType { Value, GameVariable, PlayerPrefs, Formula, GameTime, TimeOfDay, DateAndTime, Random, CurrentValue };


	// development
	public enum StatDevType { None, Curve, Formula };
	public enum LevelUpType { None, Auto, Spend, Uses };
	public enum LearnCostType { Experience, Item };

	// research trees
	public enum ResearchItemType { None, Ability, StatusValue, Item };
	public enum ResearchItemDuration { None, Manual, Time };
	public enum ResearchTreeStateCheck { Known, Unknown, Complete };
	public enum ResearchItemState { Unresearched, InResearch, Researched, Complete };
	public enum ResearchSelection { All, ResearchType, ResearchTree, ResearchItem };
	public enum ResearchDisplayType { Researchable, LimitFail, CostsFail, RequirementsFail, InResearch, Complete };
	public enum HUDResearchItemType { Information, Progress, ResearchCount };


	// inventory
	public enum CombatantScope { Group, Individual };
	public enum ItemDropType { Item, Weapon, Armor, Currency, AIBehaviour, AIRuleset, CraftingRecipe };
	public enum ItemDropTypeSimple { Item, Weapon, Armor, Currency };
	public enum SaveOption { None, Game, Save };
	public enum CombatantSaveOption { None, Current, All };
	public enum InventoryAddType { Add, AutoStack, AutoSplit };


	// event
	public enum ActorType { Object, Player, Member, Camera, StartingObject };
	public enum StepObjectType { Actor, Waypoint, Prefab, FoundObjects, GlobalObjects, SelectedData };
	public enum NumberValueType { Value, GameVariable, PlayerPrefs, Formula, GameTime, TimeOfDay, DateAndTime, Random };
	public enum StringValueType { Value, GameVariable, PlayerPrefs, SceneName };
	public enum Vector3ValueType { Value, GameVariable, ScenePosition, PlayerPosition, Random };
	public enum EventVector3ValueType
	{
		Value, GameVariable, ScenePosition, PlayerPosition, Random,
		GameObjectPosition, GameObjectRotation, GameObjectScale
	};
	public enum GlobalEventType { Call, Auto, Key, Scene };
	public enum GameVariableType { String, Bool, Float, Vector3 };
	public enum GameVariableCheckType { Variable, Conditions, Template };
	public enum GameVariableInputType { String, Bool, Float };
	public enum VariableOrigin { Local, Global, Object, Selected };
	public enum LootVariableOrigin { Global, Combatant, Spawner };
	public enum UserVariableOrigin { Global, Object, Both };
	public enum FindObjectType { Name, Tag, Component };
	public enum PlayerSpawnTarget { SpawnPoint, Position, Object };
	public enum MultiFloatValueUse { First, Lowest, Highest, Average, Add, Sub, Multiply, Divide };
	public enum UseRangeOriginType { Attack, CounterAttack, Ability, ClassAbility, Item, ShortcutSlot, BattleRangeTemplate, Custom };
	public enum StoreGridCellType { BattleRangeTemplate, Custom, Path };
	public enum SubActionType { Ability, Item, ShortcutSlot };

	// dialogue
	public enum DialogueType { Message, Choice, AutoClose, Notification }
	public enum CombatantSelectionDialogueType
	{
		Defined,
		BattleGroup, NonBattleGroup, LockedBattleGroup,
		Members, InactiveMembers, HiddenMembers
	};


	// animation
	public enum LegacyAnimationPlayMode { Play, PlayQueued, CrossFade, CrossFadeQueued, Blend, Stop };
	public enum MecanimPlayMode { None, Play, CrossFade };
	public enum AnimationSystem { Legacy, Mecanim, Custom };
	public enum MecanimParameterType { Bool, Int, Float, Trigger };
	public enum MoveAnimationMode
	{
		None, Idle, Walk, Run, Sprint, Jump, Fall, Land,
		ActionChooseIdle, ActionWaitIdle, ActionCastIdle, TurnEndedIdle
	};
	public enum MecanimRotationType { FullDegree, Direction4, Direction8 };


	// interaction
	public enum EventStartType
	{
		Interact, Autostart, TriggerEnter, TriggerExit, None, KeyPress, Drop,
		TriggerStay, CollisionEnter, CollisionExit, CollisionStay, UI
	};
	public enum InteractionType
	{
		Any, Battle, Event, Shop, Item, ItemBox, MusicPlayer,
		SavePoint, SceneChange, VariableEvent, Custom
	};
	public enum SavePointType { SavePoint, AutoSave, RetryPoint }
	public enum MusicPlayType { Play, Stop, FadeIn, FadeOut, FadeTo };
	public enum MusicPlaySimpleType { Play, FadeIn, FadeTo };
	public enum CollectionType { Single, Random, Box };


	// scene
	public enum SceneTargetType { SpawnID, Position, ScenePosition, Variable };
	public enum SceneChangeClear { None, Current, Next, Both };
	public enum SceneConnectionSearch { One, Multi, All };
	public enum SceneLoadType { All, SceneChange, Battle, NewGame, LoadGame };
	public enum SceneIDChangeType { Item, Battle };


	// GUI
	public enum GUISystemType { LegacyGUI, NewUI };
	public enum PortraitBoxPosition { Behind, Within, InFront };
	public enum PortraitScaleType { None, Horizontal, Vertical };
	public enum VerticalTextAlignment { Top, Middle, Bottom };
	public enum BoxHeightAdjustment { None, Auto, Scroll };
	public enum TabsPosition { Top, Bottom };
	public enum ArrowButtonPosition { Left, LeftRight, Right };
	public enum ChoiceButtonMode { List, Circle, Position };
	public enum ChildColorFadeMode { None, Alpha, Color };
	public enum GUIBoxAudioType { None, Cursor, Accept, Cancel, Fail, AbilityLevel, ChangeUser, ValueInput };
	public enum ChoiceInfoPosition { Left, Right };
	public enum GUIBoxClosingBehaviour { None, Default, Cancel, Root, Exit };
	public enum AddButtonType { None, First, Last };
	public enum IconSizeType { OriginalSize, WidthScale, HeightScale, WidthAndHeight }

	// cursor type > value is used for sorting, lower value == higher priority
	public enum CursorType
	{
		Custom, Default,
		TargetSelfValid, TargetAllyValid, TargetEnemyValid, TargetAllValid,
		TargetSelfInvalid, TargetAllyInvalid, TargetEnemyInvalid, TargetAllInvalid,
		TargetSelfNone, TargetAllyNone, TargetEnemyNone, TargetAllNone,
		AttackRange,
		InActionPlayer, InActionAlly, InActionEnemy
	};

	// UI updates
	public enum UIContentOrigin { Player, Member, FindObject, GameObject };
	public enum UIVariableOrigin { Global, ContentObject, Object }
	public enum UINumberOrigin { StatusValue, AttackAttribute, DefenceAttribute }


	// menu
	public enum MenuCombatantScope { Current, Battle, Group };
	public enum GroupMenuCombatantScope { Battle, NonBattle, Both };
	public enum MenuTypeDisplay { None, GUIBox, Merged, Tabs };
	public enum MenuBoxDisplay { Same, One, Multi, Sequence };
	public enum MenuStatus { Opening, Opened, Closing, Closed };
	public enum MenuItemType { MenuScreen, Save, Load, ExitGame, GlobalEvent, Close };
	public enum SubMenuAction { Use, Give, Remove, Drop, Back, Cancel, LevelUp, AssignShortcut, CraftingList, None };
	public enum GroupMenuAction { Change, Remove, Screen, Back, Cancel }
	public enum ContentLayoutType { Text, Icon, Both, Custom, None };
	public enum ContentLayoutInfoType { None, Info, LevelUpCost, Custom };
	public enum CraftingListMenuItemType { Back, Cancel, Create, Clear, Items };
	public enum CraftingListCreationType { Exact, One, Multi };
	public enum MenuDetailsBoxMode { None, Use, Info, HUD };


	// quantity selection
	public enum QuantitySelectionMode { Remove, Drop, Give, Buy, Sell };
	public enum QuantityInputType { HorizontalButtons, VerticalButtons, BothButtons };
	public enum QuantityType { Default, One, All, Select };


	// battle menu
	public enum BMItemType
	{
		Attack, Ability, ClassAbility, Item,
		Defend, Escape, End, Auto, Equipment, Command, ChangeMember,
		GridMove, GridOrientation, GridExamine,
		AIBehaviour, AIRuleset
	};
	public enum BMTypeDisplay { Combined, Type, List };
	public enum BattleMenuMode
	{
		None, List, AbilityType, Ability, ItemType, Item,
		Target, EquipmentPart, Equipment, Command, ChangeMember,
		AIType, AIBehaviourSlot, AIBehaviour, AIRulesetSlot, AIRuleset,
		GridMove, GridOrientation, GridExamine
	};
	public enum BestiaryLearnType { None, Encounter, Attack, AttackedBy, Death };


	// hud
	public enum HUDType { Information, Interaction, Combatant, Control, Navigation, Tooltip, Console, TurnOrder, Quest, LatestTurn };
	public enum HUDStatusType
	{
		Information, Faction, StatusValue, StatusEffect,
		AttackAttribute, DefenceAttribute, DefenceAttributeID,
		Timebar, CastTime, InventorySpace, Portrait, Shortcut, Equipment, DelayTime,
		ActionsPerTurn, GridMoveRange, ActionTime, Console,
		HitChance, CriticalChance, ResearchItem
	};
	public enum HUDNavigationType { Separation, North, East, South, West, Interaction, Combatant, NavigationMarker };
	public enum HUDStatusOrigin { Current, Preview, PreviewHide, PreviewHideNoChange, PreviewHideChange };
	public enum HUDStatusCombatantOrigin { User, GroupTarget, IndividualTarget, LastTarget };
	public enum HUDBarFilling { LeftToRight, RightToLeft, TopToBottom, BottomToTop };
	public enum HUDControlType { PositiveButton, NegativeButton, Axis, Joystick };
	public enum HUDInfoClickType { None, GlobalEvent, MenuScreen };
	public enum HUDQuestClickType { None, ToggleTasks };
	public enum HUDQuestTaskClickType { None, ToggleMarkers };
	public enum HUDCombatantClickType { None, MenuScreen, ChangeMenuUser, ChangePlayer, SelectTarget, GlobalEvent };
	public enum ShortcutInnerAssignType { None, Keep, Remove, Swap };
	public enum HUDShortcutValueType { LevelPoints, Durability, Information };


	// shop
	public enum ShopMode { Buy, Sell, Exit };


	// reflection
	public enum ParameterType { String, Bool, Int, Float, Vector2, Vector3 };


	// game settings
	public enum SaveGameType { PlayerPrefs, File, Custom };
	public enum Selector { None, Select, All };
	public enum GameOptionType { Custom, MusicVolume, SoundVolume, TextSpeed, RandomBattleChance, GlobalVolume };
	public enum StatisticType
	{
		TotalKilled, SingleKilled,
		TotalUsed, SingleUsed,
		TotalCreated, SingleCreatedItem, SingleCreatedWeapon, SingleCreatedArmor,
		TotalBattles, WonBattles, LostBattles, EscapedBattles,
		Custom,
		SingleCreatedAIBehaviour, SingleCreatedAIRuleset, SingleCreatedCraftingRecipes
	};


	// div
	public enum ValueSetter { Percent, Value };
	public enum ColumnFill { Vertical, Horizontal };
	public enum MouseTouch { Start, Move, End, Hold }
	public enum Consider { Yes, No, Ignore };
	public enum ShortcutType
	{
		Empty, Item, Weapon, Armor, Money, Ability, Attack, CounterAttack,
		Defend, Escape, None, GridMove, GridOrientation, GridExamine
	};
	public enum ShortcutAbilityLinkType { BaseAttack, CounterAttack };
	public enum ShortcutListChange { Next, Previous, DefinedIndex };
	public enum TransformVectorOrigin { Position, Rotation, Scale };
	public enum RequirementTargetType { None, User, Target };
	public enum EnableSelection { Enable, Disable, Toggle };
	public enum GroupMemberSelectionType { Combatant, Leader, Index, Offset };
	public enum GroupSelectionType { ActivePlayerGroup, PlayerGroupID, Combatant };


	// change types
	public enum SimpleChangeType { Add, Remove };
	public enum ListChangeType { Add, Remove, Clear, Set };


	// status values
	public enum StatusValueType { Normal, Consumable, Experience };
	public enum StatusValueDeathType { None, OnMinimum, OnMaximum };
	public enum ExperienceType { None, Level, ClassLevel };
	public enum StatusValueGetValue { CurrentValue, BaseValue, MinValue, MaxValue, DisplayValue, PreviewValue, PreviewMaxValue, PreviewMinValue };
	public enum UpgradeDisplayType { Upgradeable, CostsFail, RequirementsFail, NoUpgrade };
	public enum StatusValueListType { No, All, StatusType, StatusValueType };
	public enum NoneExperienceMaxType { NextLevel, CurrentLevel, MaxValue };


	// attributes
	public enum AttributeGetValue { CurrentValue, BaseValue, MinValue, MaxValue, StartValue, PreviewValue };


	// status effect
	public enum EndAfter { None, Turn, Time };
	public enum EndAfterType { None, TurnStart, TurnEnd, Time };
	public enum EffectRecast { Add, Reset, None };
	public enum EffectStacking { None, Enabled, OncePerCombatant };
	public enum StatusConditionExecution { Cast, Turn, Time };
	public enum StatusConditionSetOn { Apply, Remove, TurnStart, TurnEnd, Time };
	public enum ChangeBlock { None, Negative, Positive, All };


	// status requirement
	public enum StatusRequirementType { Status, Requirements, Template };
	public enum StatusNeeded
	{
		StatusValue, StatusEffect, AttackAttribute, DefenceAttribute,
		Level, Ability, Class, Death, Weapon, Armor, Combatant, GroupLeader, GroupSize, Inventory,
		StatusEffectType, WeaponItemType, ArmorItemType, CombatantType,
		InBattle, InAction, IsCasting, IsChoosing, TurnState,
		GridMoveRange, ResearchTree, ResearchItem,
		AIType, AIBehaviour, AIRuleset, AIBehaviourSlotCount, AIRulesetSlotCount,
		ActionBar, IsResearching
	};


	// ability/item
	public enum EffectCast { None, Add, Remove, Toggle };
	public enum TargetType { Self, Ally, Enemy, All };
	public enum TargetRange { None, Single, Group };
	public enum UseableIn { Field, Battle, Both, None };
	public enum UseBlockType { Ability, Item };
	public enum UseBlockScope { Single, Type, RootType, All };
	public enum AbilityCheckType { Known, Learned, GroupAbility, Temporary };
	public enum IncludeCheckType { Yes, No, Only };
	public enum ItemAbilityType { None, Learn, Use };
	public enum UseCostAutoConsumeType { No, WithoutTargets, Always };
	public enum BattleRangeType { None, Template, Custom };
	public enum AffectRangeType { None, Calculation, Execution };


	// equipment
	public enum EquipType { Single, Multi };
	public enum ValueCheck { IsEqual, IsLess, IsGreater, NotEqual };
	public enum VariableValueCheck { IsEqual, IsLess, IsGreater, NotEqual, RangeInclusive, RangeExclusive, Approximately };
	public enum EquipSet { None, Weapon, Armor };
	public enum EquipmentDurabilityType { NoBonuses, Unequip, Destroy };
	public enum AddRandomBonus { All, Random, First };
	public enum EquipPartChangeType { AdditionalPart, BlockedPart, BlockedViewer };


	// combatant
	public enum CombatantLevelInitType { Default, Player, Random, Variable, Formula };
	public enum AggressionType { Always, OnDamage, OnSelection, OnAction };
	public enum CombatantLootOrigin { StartInventory, Loot, Both };
	public enum CombatantAffiliationType { Player, Ally, Enemy };
	public enum CombatantDeathState { Alive, Dying, Dead };


	// ai
	public enum FoundTargets { Keep, Check, Clear, CheckKeep };
	public enum MoveDetectionType { Sight, Movement, CombatantTrigger };
	public enum MoveSpeedType { Walk, Run, Sprint, Value };
	public enum MoveComponentType { Default, NavMeshAgent, Custom };
	public enum MoveConditionType { Level, ClassLevel, GroupSize, Status };
	public enum MoveAIMode { Idle, Waypoint, Follow, GiveWay, Hunt, Flee, CautionHunt, CautionFlee };
	public enum MoveAIUseMode { Auto, Idle, Hunt, Flee, Caution };
	public enum BattleAITargetType { Self, Ally, Enemy, All, None };
	public enum AIGridMove { MoveTowardTarget, FleeFromTarget, Random, GridFormation, GridCellType };
	public enum AIGridMoveTargetType { Nearest, North, East, South, West, Front, Back, Left, Right };
	public enum AIGridMoveRangeType { Distance, BattleRangeTemplate, Custom };
	public enum AIRuleType { Action, BattleAI, BlockAbility, BlockAttack, BlockCounterAttack, BlockItem, Target, MoveAI };
	public enum AIRuleTargetType { Self, Ally, Enemy, All, MemberTarget, TargetingMember };
	public enum BattleAITargetOrigin { User, Leader, Group, Allies, Enemies, FoundTargets };
	public enum WeightedGroupType { Smallest, Largest };
	public enum DistanceType { Nearest, NearestAverage, Farthest, FarthestAverage, All };


	// battle system
	public enum BattleSystemType { TurnBased, ActiveTime, RealTime, Phase };
	public enum TurnBasedMode { Classic, Active, MultiTurns };
	public enum DamageDealerType { TriggerEnter, TriggerExit, TriggerStay, CollisionEnter, CollisionExit, CollisionStay, Custom };
	public enum TargetRayOrigin { User, Screen };
	public enum EnemyCounting { None, Letters, Numbers };
	public enum UseTimebarAction { ActionBorder, MaxTimebar, EndTurn };
	public enum GroupAdvantageType { None, Player, Enemy };
	public enum BattleOutcome { None, Victory, Escape, Defeat, LeaveArena };
	public enum ActionTimeDecreaseType { Always, WhileChoosing, WhileInAction };
	public enum PhaseTurnStartType { None, PhaseStart, PhaseEnd };

	// battle camera
	public enum BattleCameraType { None, BlockEvents, AllowEvents };
	public enum CameraLookAtType { SimpleLook, CameraPosition, CameraControlTarget };
	public enum BattleCameraDistanceOrigin { User, CameraControlTarget, Player, Arena };


	// battle grid
	public enum BattleGridType { Square, Hexagonal };
	public enum HexagonalGridType { VerticalEven, VerticalOdd, HorizontalEven, HorizontalOdd };
	public enum BaseGridHighlightType { Area, Selection, NoSelection };
	public enum GridHighlightType
	{
		None,
		// placement
		Placement, PlacementSelection, NoPlacementSelection,
		PlacementSelectionPlayer, PlacementSelectionAlly, PlacementSelectionEnemy,
		// move command
		MoveRange, MoveRangeBlocked, MoveRangePassable, MoveSelection, NoMoveSelection, MovePath,
		MoveSelectionPlayer, MoveSelectionAlly, MoveSelectionEnemy,
		// orientation 
		OrientationSelection, OrientationSelectionPlayer,
		OrientationSelectionAlly, OrientationSelectionEnemy,
		// marked cell
		MarkedCell,
		// ranges
		UseRange, AffectRange,
		// available targets
		AvailableTargetPlayer, AvailableTargetAlly, AvailableTargetEnemy,
		// target cell
		TargetCellSelection, NoTargetCellSelection,
		TargetCellSelectionPlayer, TargetCellSelectionAlly, TargetCellSelectionEnemy,
		// examine
		ExamineSelection, ExamineSelectionBlocked, ExamineMoveRange, ExamineMoveRangeBlocked, ExamineMoveRangePassable, ExamineUseRange,
		ExamineSelectionPlayer, ExamineSelectionAlly, ExamineSelectionEnemy,
		// selecting combatant
		SelectingPlayer, SelectingAlly, SelectingEnemy,
		// combatant cell
		CellPlayer, CellPlayerTurnEnded, CellAlly, CellAllyTurnEnded, CellEnemy, CellEnemyTurnEnded
	};
	public enum GridShapeType { None, All, Range, Mask, Ring };
	public enum GridUseBattleType { NoGrid, NearestGrid, DefinedGrid };
	public enum GridDeploymentType { None, Player, Ally, Enemy, All, Faction };
	public enum GridPathCellSelection { Next, Last, All };
	public enum GridDirectionRotationType { Nearest, Left, Right, Target };
	public enum GridCellEventStartType { None, Any, MoveTo, MoveOver, StartTurn, EndTurn };
	public enum GridCellEventType { Ability, StatusEffect, GameEvent };
	public enum SetCellCombatantType { Combatant, Guest, Move, Remove };
	public enum GridMoveState { Available, Selected, Performed };
	public enum AutoGridMoveType { None, FirstAction, Always };
	public enum GridSelectionType { None, Placement, Orientation, Move, Examine, Target };


	// actions
	public enum ActionSelectType
	{
		Attack, CounterAttack, Ability, Item,
		Defend, Escape, Death, None, ChangeMember,
		ClassAbility, Shortcut
	};
	public enum ActionType { Attack, CounterAttack, Ability, Item, Defend, Escape, Death, None, ChangeMember, Join, GridMove };
	public enum AbilityActionType { Ability, BaseAttack, CounterAttack };
	public enum BattleActionResult { Hit, Critical, Miss, Block };
	public enum AutoAttackTargetType { All, GroupTargets, IndividualTargets, GroupAndIndividual }
	public enum BattleActionAddType { Try, NextAction, SubAction };
	public enum NextBattleActionChange { Add, Set, First };
	public enum BaseAttackScope { Current, Index, All };
	public enum CombatantActionState { Available, Casting, InAction, EndingAction };
	public enum CombatantTurnState { BeforeTurn, InTurn, AfterTurn };


	// quests
	public enum QuestStatusType { Inactive, Active, Finished, Failed };
	public enum QuestCheckType { Inactive, Active, Finished, Failed, NotAdded };
}
