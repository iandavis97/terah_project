
using System.Collections.Generic;

namespace ORKFramework
{
	public class TypeIDContentSorter : IComparer<IContent>
	{
		private bool invert = false;
		
		public TypeIDContentSorter(bool invert)
		{
			this.invert = invert;
		}
		
		public int Compare(IContent x, IContent y)
		{
			if(this.invert)
			{
				int sort = y.TypeID.CompareTo(x.TypeID);
				if(sort == 0)
				{
					return y.ID.CompareTo(x.ID);
				}
				else
				{
					return sort;
				}
			}
			else
			{
				int sort = x.TypeID.CompareTo(y.TypeID);
				if(sort == 0)
				{
					return x.ID.CompareTo(y.ID);
				}
				else
				{
					return sort;
				}
			}
		}
	}
}
