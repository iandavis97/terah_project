
using System.Collections.Generic;

namespace ORKFramework
{
	public delegate string GetName(int index);
	
	public class NameSorter : IComparer<int>
	{
		private GetName GetName;
		
		private bool invert = false;
		
		public NameSorter(GetName getName, bool invert)
		{
			this.GetName = getName;
			this.invert = invert;
		}
		
		public int Compare(int x , int y)
		{
			if(this.invert)
			{
				return this.GetName(y).CompareTo(this.GetName(x));
			}
			else
			{
				return this.GetName(x).CompareTo(this.GetName(y));
			}
		}
	}

	public class NameDataTypeSorter : IComparer<SortIDDataType>
	{
		private bool invert = false;

		public NameDataTypeSorter(bool invert)
		{
			this.invert = invert;
		}

		public int Compare(SortIDDataType x, SortIDDataType y)
		{
			if(this.invert)
			{
				return ORK.GetNameFunction(y.type)(y.id).CompareTo(ORK.GetNameFunction(x.type)(x.id));
			}
			else
			{
				return ORK.GetNameFunction(x.type)(x.id).CompareTo(ORK.GetNameFunction(y.type)(y.id));
			}
		}
	}
}
