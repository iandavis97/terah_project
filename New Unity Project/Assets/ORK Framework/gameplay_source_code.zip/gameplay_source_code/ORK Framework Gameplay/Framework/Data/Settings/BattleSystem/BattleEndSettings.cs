
using UnityEngine;
using ORKFramework.UI;

namespace ORKFramework
{
	public class BattleEndSettings : BaseSettings
	{
		// general settings
		[ORKEditorHelp("Loot Dialogue Type", "Select which type of loot dialogue is used:", "")]
		[ORKEditorInfo("Base Settings", "Define the experience and normal status value gain options.", "",
			settingBaseType=typeof(BaseLootDialogueSettings), settingAutoSetup="lootDialogue")]
		public string lootDialogueType = typeof(SimpleLootDialogueSettings).ToString();

		// experience
		[ORKEditorHelp("Split Experience Rewards", "The experience points gained from enemies will be split through " +
			"the battle group members, i.e. every group member will only get a part of the experience.", "")]
		[ORKEditorInfo(separator=true, labelText="Experience Reward Settings")]
		public bool splitExp = false;

		[ORKEditorHelp("Whole Party", "The whole (active) group will receive experience.\n" +
			"If the experience is splitted, it will be splitted by all (active) group members.", "")]
		public bool wholePartyExp = false;

		[ORKEditorHelp("Dead Receive Exp.", "Dead group members will also receive experience.\n" +
			"If disabled, only group members who are alive will receive experience.", "")]
		public bool deadExp = false;

		// normal
		[ORKEditorHelp("Split Normal Rewards", "The 'Normal' status value points gained from enemies will be split through " +
			"the battle group members, i.e. every group member will only get a part of the 'Normal' status value reward.", "")]
		[ORKEditorInfo(separator=true, labelText="Normal Status Value Reward Settings")]
		public bool splitNormalSV = false;

		[ORKEditorHelp("Whole Party", "The whole (active) group will receive 'Normal' status value rewards.\n" +
			"If the 'Normal' status value rewards are splitted, it will be splitted by all (active) group members.", "")]
		public bool wholePartyNormalSV = false;

		[ORKEditorHelp("Dead Receive Normal", "Dead group members will also receive 'Normal' status value rewards.\n" +
			"If disabled, only group members who are alive will receive 'Normal' status value rewards.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool deadNormalSV = false;



		// loot dialogue
		public BaseLootDialogueSettings lootDialogue = new SimpleLootDialogueSettings();


		// level up
		[ORKEditorInfo("Level Up Texts", "The texts used by level up notifications to show a combatant's status changes.\n" +
			"The order of the single texts can be changed by changing the total level up text.\n" +
			"All texts will be displayed in one message.", "",
			endFoldout=true)]
		public LevelUpText levelUp = new LevelUpText();

		public BattleEndSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetRealIDs()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("showGains") ||
				data.Contains<DataObject>("end") ||
				data.Contains<DataObject>("victoryGains"))
			{
				SimpleLootDialogueSettings tmpSettings = new SimpleLootDialogueSettings();
				this.lootDialogue = tmpSettings;
				this.lootDialogue.SetData(data);
				this.lootDialogueType = this.lootDialogue.GetType().ToString();

				DataObject tmpData = data.GetFile("victoryGains");
				if(tmpData != null)
				{
					tmpData.Get("showGains", ref tmpSettings.showVictoryGains);
				}
				tmpData = data.GetFile("combatantGains");
				if(tmpData != null)
				{
					tmpData.Get("showGains", ref tmpSettings.showCombatantGains);
				}
				tmpData = data.GetFile("levelUp");
				if(tmpData != null)
				{
					tmpData.Get("showLevelUp", ref tmpSettings.showLevelUpNotification);
					tmpSettings.levelUpNotification.SetData(tmpData);
				}
				tmpData = data.GetFile("end");
				if(tmpData != null)
				{
					bool tmp = false;
					tmpData.Get("useLevelUpBox", ref tmp);
					if(tmp)
					{
						tmpData.Get("levelUpBoxID", ref tmpSettings.levelUpNotification.guiBoxID);
					}
					else
					{
						tmpData.Get("guiBoxID", ref tmpSettings.levelUpNotification.guiBoxID);
					}

					data.Get("useTitle", ref tmpSettings.levelUpNotification.useTitle);
					if(tmpSettings.levelUpNotification.useTitle)
					{
						data.Get("title", out tmpSettings.levelUpNotification.title);
					}
				}
			}
			if(data.Contains<bool>("showGains"))
			{
				this.levelUp.SetData(data);
			}
		}

		public override void EditorAutoSetup(string fieldName)
		{
			if(this.lootDialogue == null ||
				!this.lootDialogue.IsType(this.lootDialogueType))
			{
				DataObject data = this.lootDialogue != null ?
					this.lootDialogue.GetData() : null;
				object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
					this.lootDialogueType, typeof(BaseLootDialogueSettings));
				if(tmpSettings is BaseLootDialogueSettings)
				{
					this.lootDialogue = (BaseLootDialogueSettings)tmpSettings;
					this.lootDialogue.SetData(data);
				}
				else
				{
					this.lootDialogue = new SimpleLootDialogueSettings();
					this.lootDialogue.SetData(data);
					this.lootDialogueType = this.lootDialogue.GetType().ToString();
				}
			}
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "battleEnd"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}

		public override int Copy(int index)
		{
			return -1;
		}

		public override void Remove(int index)
		{

		}

		public override void Move(int index, bool down)
		{

		}
	}
}
