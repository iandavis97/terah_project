
using UnityEngine;
using ORKFramework.Events;
using System.Collections;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GlobalEventsSettings : BaseSettings
	{
		public GlobalEvent[] data = new GlobalEvent[] {new GlobalEvent("Default Event")};


		// ingame
		private GlobalEvent[] globalEvent = new GlobalEvent[0];

		private GlobalEvent[] globalEventScene = new GlobalEvent[0];

		private List<GlobalEvent> calledGlobalEvents = new List<GlobalEvent>();

		public GlobalEventsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}

		public override void SetRealIDs()
		{
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "globalEvents"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].name;
			}
			else
			{
				return "GlobalEvent(" + index + ") not found";
			}
		}

		public override string[] GetNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = i + ": " + this.data[i].name;
				}
				else
				{
					names[i] = this.data[i].name;
				}
			}
			return names;
		}

		public override int Count
		{
			get { return this.data.Length; }
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			ArrayHelper.Add(ref this.data, new GlobalEvent("New"));
			DataHelper.Added(ORKDataType.GlobalEvent);
			return this.data.Length - 1;
		}

		public override int Copy(int index)
		{
			ArrayHelper.Add(ref this.data, this.GetCopy(index));
			DataHelper.Added(ORKDataType.GlobalEvent);
			return this.data.Length - 1;
		}

		public GlobalEvent GetCopy(int index)
		{
			GlobalEvent t = new GlobalEvent();
			if(index >= 0 && index < this.data.Length)
			{
				t.SetData(this.data[index].GetData());
			}
			return t;
		}

		public override void Remove(int index)
		{
			ArrayHelper.RemoveAt(ref this.data, index);
			DataHelper.Removed(ORKDataType.GlobalEvent, index);
		}

		public GlobalEvent Get(int index)
		{
			if(index >= 0 && index < this.Count)
			{
				return this.data[index];
			}
			else
			{
				return this.data[0];
			}
		}

		public override void Move(int index, bool down)
		{
			if(down)
			{
				ArrayHelper.MoveDown(ref this.data, index);
			}
			else
			{
				ArrayHelper.MoveUp(ref this.data, index);
			}
			DataHelper.Moved(ORKDataType.GlobalEvent, down, index);
		}


		/*
		============================================================================
		Ingame functions
		============================================================================
		*/
		public void ClearGlobalEvents()
		{
			this.globalEvent = new GlobalEvent[0];
			this.globalEventScene = new GlobalEvent[0];
			this.calledGlobalEvents = new List<GlobalEvent>();
		}

		public void InitGlobalEvents()
		{
			// auto/key events
			List<GlobalEvent> list = new List<GlobalEvent>();
			for(int i = 0; i < ORK.GlobalEvents.Count; i++)
			{
				if(ORK.GlobalEvents.Get(i).IsAutoType() ||
					ORK.GlobalEvents.Get(i).IsKeyType())
				{
					list.Add(ORK.GlobalEvents.GetCopy(i));
				}
			}
			this.globalEvent = list.ToArray();

			// scene change events
			list = new List<GlobalEvent>();
			for(int i = 0; i < ORK.GlobalEvents.Count; i++)
			{
				if(ORK.GlobalEvents.Get(i).IsSceneType())
				{
					list.Add(ORK.GlobalEvents.GetCopy(i));
				}
			}
			this.globalEventScene = list.ToArray();
		}

		public void CallGlobalEvent(int index, object startingObject)
		{
			if(index >= 0 && index < ORK.GlobalEvents.Count)
			{
				GlobalEvent evt = ORK.GlobalEvents.GetCopy(index);
				if(evt.Call(startingObject))
				{
					this.calledGlobalEvents.Add(evt);
				}
			}
		}

		public void SceneChangeEvents(bool inOldScene, bool beforeFade, SceneLoadType loadType)
		{
			for(int i = 0; i < this.globalEventScene.Length; i++)
			{
				if(this.globalEventScene[i].inOldScene == inOldScene &&
					this.globalEventScene[i].beforeFade == beforeFade &&
					(SceneLoadType.All == this.globalEventScene[i].sceneLoadType ||
						this.globalEventScene[i].sceneLoadType == loadType) &&
					this.globalEventScene[i].variables.CheckVariables())
				{
					this.globalEventScene[i].Call();
				}
			}
		}

		public void Tick()
		{
			float t = ORK.Game.DeltaTime;

			// autostart global events
			for(int i = 0; i < this.globalEvent.Length; i++)
			{
				this.globalEvent[i].Tick(t);
			}

			// scene global events
			for(int i = 0; i < this.globalEventScene.Length; i++)
			{
				this.globalEventScene[i].Tick(t);
			}

			// called global events
			for(int i = 0; i < this.calledGlobalEvents.Count; i++)
			{
				if(this.calledGlobalEvents[i].IsFinished())
				{
					this.calledGlobalEvents.RemoveAt(i--);
				}
				else
				{
					this.calledGlobalEvents[i].Tick(t);
				}
			}
		}
	}
}
