﻿
using UnityEngine;
using ORKFramework.Combatants;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleTargetSettings : BaseSettings
	{
		// target selection
		// target menu
		[ORKEditorHelp("Use Target Menu", "A menu based target selection is used.\n" +
			"Targets are listed as choices in a GUI box.", "")]
		[ORKEditorInfo("Target Selection", "The settings for the target selection.\n" +
			"The target selection is used when selecting the target for a base attack, ability or item.\n" +
			"You can combine the different target selections.", "",
			labelText="Target Menu")]
		public bool useTargetMenu = true;

		[ORKEditorHelp("Rotate To Target", "Rotate the user to the selected target during target selections.", "")]
		public bool rotateToTarget = false;

		[ORKEditorHelp("Grid Rotation", "Limit the rotation to the nearest grid rotation during grid battles.", "")]
		[ORKEditorLayout("rotateToTarget", true)]
		public bool rotateToTargetGridRotation = false;

		[ORKEditorHelp("Rotate Cursor Over", "The user only rotates to a target when first hovering the cursor over it.", "")]
		[ORKEditorLayout("targetCursorOverSelection", true, endCheckGroup=true, endGroups=2,
			setDefault=true, defaultValue=false)]
		public bool rotateToTargetCursorOver = false;
		
		// target keys
		[ORKEditorHelp("Next Target Key", "The key to select the next target.\n" +
			"This will move the selection down in the target menu.", "")]
		[ORKEditorInfo("Target Change Keys", "Define input keys that can be used to switch between available targets.\n" +
			"These keys are used during the target selection (e.g. when the target menu would be displayed).", "",
			ORKDataType.InputKey)]
		public int targetNextKey = 0;

		[ORKEditorHelp("Previous Target Key", "The key to select the previous target.\n" +
			"This will move the selection up in the target menu.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int targetPreviousKey = 0;

		[ORKEditorHelp("Nearest Target Key", "The key to select the target closest to the user.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int targetNearestKey = 0;

		[ORKEditorHelp("Target Range Key", "The key to toggle between 'Single' and 'Group' target range " +
			"for abilities/items that allow changing the target range.\n" +
			"This input key can be used during target selections (e.g. in the battle menu or menu screens).", "")]
		[ORKEditorInfo(ORKDataType.InputKey, endFoldout=true)]
		public int targetRangeKey = 0;
		
		// target cursor
		[ORKEditorHelp("Use Cursor", "A cursor game object is displayed at the selected target.", "")]
		[ORKEditorInfo("Target Cursor", "A cursor game object can be displayed on a selected target's game object.", "")]
		public bool useTargetCursor = false;

		[ORKEditorHelp("Prefab", "Select the prefab used as cursor object.", "")]
		[ORKEditorLayout("useTargetCursor", true)]
		public AssetSource<GameObject> cursorPrefab = new AssetSource<GameObject>();

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public MountSettings cursorMount = new MountSettings();
		
		// blink
		[ORKEditorHelp("Use Blink", "The selected target's game object will blink.", "")]
		[ORKEditorInfo("Blink Target Object", "The game object of the target can blink.", "")]
		public bool useBlink = false;

		[ORKEditorHelp("Blink Children", "All child game objects of the target object will blink.\n" +
			"If disabled, only the root object of the target will blink.", "")]
		[ORKEditorLayout("useBlink", true)]
		public bool blinkChildren = true;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public FadeColorSettings blink;
		
		// HUD blink
		[ORKEditorHelp("Use Blink", "The selected target's HUDs will blink.", "")]
		[ORKEditorInfo("Blink Target HUD", "The HUDs of the target can blink.", "")]
		public bool useBlinkHUD = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useBlinkHUD", true, endCheckGroup=true, autoInit=true)]
		public FadeColorSettings blinkHUD;
		
		// click combatant
		// raycast settings
		[ORKEditorHelp("Layer Mask", "Select the layer the raycast will use.\n" +
			"Only objects on this layer can be hit by the raycast.", "")]
		[ORKEditorInfo("Mouse/Touch Control", "Input settings for mouse and touch control.\n" +
			"A click/touch will use a raycast on that position to find a combatant.", "",
			labelText="Raycast Settings")]
		public LayerMask targetLayerMask = -1;

		[ORKEditorHelp("Distance", "The distance the raycast will use (from the camera).", "")]
		public float targetRayDistance = 100.0f;

		[ORKEditorHelp("Accept Only Selected", "Mouse/touch input can only accept already selected combatants.\n" +
			"E.g. first click will select, 2nd click (on selected combatant) will accept the combatant.", "")]
		public bool targetAcceptOnlySelected = false;

		[ORKEditorHelp("Use Grid Cell", "Selection also works on the grid cells of combatants in grid battles.", "")]
		public bool targetUseGridCell = false;

		[ORKEditorHelp("Cursor Over Selection", "Targets can be selected by hovering the cursor over the target's game object.", "")]
		public bool targetCursorOverSelection = false;

		[ORKEditorHelp("Cursor Move Only", "Only check for hover selection when the cursor has actually been moved.\n" +
			"If disabled, hover selection is checked at all times.", "")]
		[ORKEditorLayout("targetCursorOverSelection", true, endCheckGroup=true)]
		public bool targetCursorOverMouseMoveOnly = false;

		[ORKEditorInfo(endFoldout=true, endFolds=2, separator=true)]
		public MouseTouchControl targetMouseTouch = new MouseTouchControl();


		// target information dialogue
		[ORKEditorInfo("Target Information Dialogue", "Optionally display status changes that " +
			"will happen to the user and targets of an ability/item.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Target Information", "Adds a target information dialogue.", "",
			"Remove", "Removes this target information dialogue.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Target Information", "Displays status changes that will happen to the user and targets of an ability/item.", ""
		})]
		public TargetInformationChoice[] targetInformation = new TargetInformationChoice[0];


		// target confirmation dialogue
		[ORKEditorHelp("Show Target Confirmation", "Show a target confirmation dialogue after " +
			"selecting a target for an ability or item.\n" +
			"The ability/item will only be used when the target confirmation dialogue is accepted, " +
			"otherwise the target selection is resumed.", "")]
		[ORKEditorInfo("Target Confirmation Dialogue", "Optionally display a target confirmation dialogue " +
			"showing status changes that will happen to the user and targets of an ability/item.", "")]
		public bool showTargetConfirmation = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("showTargetConfirmation", true, endCheckGroup=true, autoInit=true)]
		public TargetConfirmationChoice targetConfirmation;


		// group targets
		[ORKEditorInfo("Group Target Settings", "Group targets are available to all combatants of a group.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Target Settings", "Adds target settings.", "",
			"Remove", "Removes this target settings.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Target Settings", "Define the input keys and targets that can be selected.", ""
		})]
		public TargetSelection[] groupTargetSelection = new TargetSelection[0];


		// individual targets
		[ORKEditorInfo("Individual Target Settings", "Individual targets are only available to the combatant who selected them.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Target Settings", "Adds target settings.", "",
			"Remove", "Removes this target settings.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Target Settings", "Define the input keys and targets that can be selected.", ""
		})]
		public TargetSelection[] individualTargetSelection = new TargetSelection[0];

		public BattleTargetSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<DataObject>("groupTarget"))
			{
				DataObject tmpData = data.GetFile("groupTarget");
				if(tmpData != null)
				{
					bool tmp = false;
					tmpData.Get("useGroupTarget", ref tmp);
					if(tmp)
					{
						this.groupTargetSelection = new TargetSelection[1];
						this.groupTargetSelection[0] = new TargetSelection();
						tmpData.Get("onlyInBattleRange", ref this.groupTargetSelection[0].onlyInBattleRange);
						tmpData.Get("noActionOnly", ref this.groupTargetSelection[0].noActionOnly);
						tmpData.Get("autoSelectTarget", ref this.groupTargetSelection[0].autoSelect);
						tmpData.Get("autoAttackTarget", ref this.groupTargetSelection[0].autoAttackTarget);
						tmpData.Get("aaPlayerOnly", ref this.groupTargetSelection[0].aaPlayerOnly);
						tmpData.Get("nextTargetKey", ref this.groupTargetSelection[0].nextKey);
						tmpData.Get("previousTargetKey", ref this.groupTargetSelection[0].previousKey);
						tmpData.Get("nearestTargetKey", ref this.groupTargetSelection[0].nearestKey);
						tmpData.Get("autoAttackTarget", ref this.groupTargetSelection[0].autoAttackTarget);
						tmpData.Get("clearTargetKey", ref this.groupTargetSelection[0].removeKey);
						tmpData.Get("allowTargetRemove", ref this.groupTargetSelection[0].allowClickRemove);
						tmpData.Get("useTargetCursor", ref this.groupTargetSelection[0].useTargetCursor);
						if(this.groupTargetSelection[0].useTargetCursor)
						{
							this.groupTargetSelection[0].cursorPrefab = new AssetSource<GameObject>();
							this.groupTargetSelection[0].cursorPrefab.Upgrade(tmpData, "cursorPrefab;");
						}

						this.groupTargetSelection[0].clickControl.SetData(tmpData.GetFile("groupMouseTouch"));
						this.groupTargetSelection[0].cursorMount.SetData(tmpData.GetFile("cursorMount"));
					}
				}
			}
			if(data.Contains<DataObject>("targetInformation"))
			{
				TargetInformationChoice tmp = new TargetInformationChoice();
				tmp.SetData(data.GetFile("targetInformation"));
				ArrayHelper.Add(ref this.targetInformation, tmp);
			}
			this.cursorPrefab.Upgrade(data, "cursorPrefab");
			if(data.Contains<DataObject>("camera"))
			{
				ORK.BattleCamera.SetData(data.GetFile("camera"));
			}
		}

		public override void SetRealIDs()
		{

		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "battleTargetSettings"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}

		public override int Copy(int index)
		{
			return -1;
		}

		public override void Remove(int index)
		{

		}

		public override void Move(int index, bool down)
		{

		}


		/*
		============================================================================
		Target information functions
		============================================================================
		*/
		public void ShowTargetInformation(Combatant user, List<Combatant> targets, IShortcut shortcut)
		{
			for(int i = 0; i < targetInformation.Length; i++)
			{
				this.targetInformation[i].Show(user, targets, shortcut);
			}
		}

		public void CursorOverTargetInformation(Combatant combatant, bool changed)
		{
			for(int i = 0; i < targetInformation.Length; i++)
			{
				this.targetInformation[i].CombatantCursorOver(combatant, changed);
			}
		}

		public void CloseTargetInformation()
		{
			for(int i = 0; i < targetInformation.Length; i++)
			{
				this.targetInformation[i].Close();
			}
		}
	}
}
