
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleSettings : BaseSettings
	{
		// base settings
		[ORKEditorHelp("Enemy Counter", "Enemies of the same type can have a counter " +
			"added to their name to differentiate them from another:\n" +
			"- None: No counter is added.\n" +
			"- Letters: Letters are used (A, B, C, ...).\n" +
			"- Numbers: Numbers are used (1, 2, 3, ...).\n" +
			"The enemy counter is only used in arena battles.", "")]
		[ORKEditorInfo("Base Settings", "Base battle system settings.", "",
			isEnumToolbar=true, toolbarWidth=75)]
		public EnemyCounting enemyCounter = EnemyCounting.None;

		[ORKEditorHelp("Play Damage Animation", "Combatants currently performing a battle action " +
			"(and by this a battle animation) will play their damage animation when receiving damage.\n" +
			"If disabled, damage animations will be ignored for combatants that are in action while receiving damage.", "")]
		public bool playDamageAnim = false;

		[ORKEditorHelp("Play Victory Animation", "The combatants that won the battle will play the victory animation type.\n" +
			"Disable this setting to not automatically play a victory animation, e.g. if you want to handle this in the battle end event.", "")]
		public bool playVictoryAnimation = true;


		// base defend rate
		[ORKEditorInfo("Base Defend Rate", "Define the base defence rate when using the defend command.\n" +
			"It's used as percent value - i.e. if the value is 100, " +
			"the damage will do 100 % of it's original damage, if the result is 50, the damage " +
			"will only do 50 % of it's original damage.", "",
			endFoldout=true)]
		public FloatValue defendRate = new FloatValue(50);

		// base counter chance
		[ORKEditorInfo("Base Counter Chance", "Define the base counter chance.\n" +
			"The counter chance decides if a combatant counters an attack (i.e. when received damage).\n" +
			"The counter is performed if a random float number between two values (default 0 and 100, you can change " +
			"this in the game settings) is less or equal to this value.\n" +
			"When using a formula, the attacked combatant (who will counter) will be used as the user in the calculation, " +
			"while the attacker is the target.\n" +
			"Each combatant can individually override this setting.", "",
			endFoldout=true)]
		public FloatValue counterChance = new FloatValue();

		// base block chance
		[ORKEditorInfo("Base Block Chance", "Define the base block chance.\n" +
			"Attacks and abilities can be blocked (if enabled) if a random float number between two values " +
			"(default 0 and 100, you can change this in the game settings) is less or equal to this value.\n" +
			"When using a formula, the attacked combatant will be used as the target in the calculation, " +
			"while the attacker is the user.\n" +
			"Each combatant can individually override this setting.", "",
			endFoldout=true)]
		public FloatValue blockChance = new FloatValue();

		// escape chance
		[ORKEditorInfo("Base Escape Chance", "Define the base escape chance when using the escape command.\n" +
			"The escape is performed if a random float number between two values " +
			"(default 0 and 100, you can change this in the game settings) " +
			"is less or equal to this value.\n" +
			"Each combatant can individually override this setting.", "",
			endFoldout=true)]
		public FloatValue escapeChance = new FloatValue(50);

		// experience factor
		[ORKEditorInfo("Base Experience Factor", "Define the base experience factor.\n" +
			"The experience factor influences the experience a combatant gains from battle. E.g.:\n" +
			"- factor 1: The combatant gets 100 % of the experience.\n" +
			"- factor 0.5: The combatant gets 50 % of the experience.\n" +
			"- factor 2: The combatant gets 200 % of the experience.\n" +
			"A negative experience factor is not possible, the smallest factor is 0.\n" +
			"Each combatant can individually override this setting.", "",
			endFoldout=true)]
		public FloatValue experienceFactor = new FloatValue(1);

		// random battle factor
		[ORKEditorInfo("Random Battle Factor", "Define the random battle factor.\n" +
			"The random battle factor is used to influence the chance of random battles occurring. " +
			"The factor is influenced by the player battle group's random battle factor bonuses.\n" +
			"When using a formula, the player combatant (i.e. leader of the player group) will be used as user and target.\n\n" +
			"E.g.:\n" +
			"The random battle chance is 10 %, the factor is 100 % - the final chance is 10 %." +
			"The chance is 10 %, the factor is 50 % - the final chance is 5 %.", "",
			endFoldout=true)]
		public FloatValue randomBattleFactor = new FloatValue(100);


		// TODO: ranges optional
		// ranges
		// battle range
		[ORKEditorHelp("Use Battle Range", "The battle range is used to determine participating combatants.\n" +
			"If disabled, all combatants will participate in battle.", "")]
		[ORKEditorInfo("Battle Range", "The distance (in world units) a combatant can " +
			"have to the player to participate in a battle.", "")]
		public bool useBattleRange = true;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useBattleRange", true, endCheckGroup=true)]
		public Range battleRange = new Range(20.0f);

		// AI settings
		[ORKEditorHelp("Use AI Range", "The AI range is used to determine if a combatant can perform AI actions.\n" +
			"If disabled, the distance to the player doesn't prevent performing AI actions.", "")]
		[ORKEditorInfo("AI Range", "The distance (in world units) a combatant can " +
			"have to the player to perform AI actions.", "")]
		public bool useAIRange = true;

		[ORKEditorHelp("AI Recheck Time (s)", "The time in seconds between AI range checks.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("useAIRange", true)]
		public float aiRecheckTime = 4.0f;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public Range aiRange = new Range(100.0f);

		// move AI range
		[ORKEditorHelp("Use Move AI Range", "The move AI range is used to determine if a combatant can use the move AI.\n" +
			"If disabled, the distance to the player doesn't prevent using the move AI.", "")]
		[ORKEditorInfo("Move AI Range", "The distance (in world units) a combatant can " +
			"have to the player to use the move AI.\n" +
			"This will be used while not in battle - " +
			"each battle system type can define it's own move AI settings.", "")]
		public bool useMoveAIRange = true;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useMoveAIRange", true, endCheckGroup=true)]
		public Range moveAIRange = new Range(100.0f);

		// auto join
		[ORKEditorInfo("Auto Join Settings", "Combatants within range of a starting battle can " +
			"automatically join the battle.\n" +
			"This setting can be overridden by individual 'Battle' components in the scene.\n" +
			"Note that this is only used in arena battles (i.e. using the 'Battle' component), " +
			"and not in real time area battles.", "",
			endFoldout=true, endFolds=2)]
		public AutoJoinBattle autoJoin = new AutoJoinBattle();


		// default use range
		[ORKEditorInfo("Default Use Range", "The default use range settings for using abilities and items.\n" +
			"The use range determines the maximum distance between user and target to allow using an ability or item. " +
			"The range can be defined for each battle system type." +
			"Can be overridden by each ability and item individually.", "", endFoldout=true)]
		public UseRangeSettings useRange = new UseRangeSettings();


		// level up
		[ORKEditorInfo("Level Up Settings", "A combatant can receive bonuses when reaching a new base or class level.", "",
			"Base Level Up", "Settings for base level ups.\n" +
			"Can be overridden by each combatant individually.", "", endFoldout=true)]
		public LevelUpBonus lvlUp = new LevelUpBonus();

		[ORKEditorInfo("Class Level Up", "Settings for class level ups.\n" +
			"Can be overridden by each class individually.", "", endFoldout=true, endFolds=2)]
		public LevelUpBonus cLvlUp = new LevelUpBonus();


		// battle advantages
		[ORKEditorInfo("Player Advantage", "Battle advantage settings for the player group.\n" +
			"Battle advantages can change 'Consumable' type status values, " +
			"status effects and the turn order ('Turn Based' type battles) or timebar ('Active Time' type battles) at the start of a battle.\n" +
			"Advantages are available in arena battles and are decided on a chance basis at the start of a battle.\n" +
			"Arenas can override the chances and block advantages completely.", "", endFoldout=true)]
		public BattleAdvantage playerAdvantage = new BattleAdvantage();

		[ORKEditorInfo("Enemy Advantage", "Battle advantage settings for the enemy group.\n" +
			"Battle advantages can change 'Consumable' type status values, " +
			"status effects and the turn order ('Turn Based' type battles) or timebar ('Active Time' type battles) at the start of a battle.\n" +
			"Advantages are available in arena battles and are decided on a chance basis at the start of a battle.\n" +
			"Arenas can override the chances and block advantages completely.", "", endFoldout=true)]
		public BattleAdvantage enemyAdvantage = new BattleAdvantage();


		// battle camera
		[ORKEditorInfo("Battle Camera", "The battle camera settings can override and " +
			"block camera changes made by battle animations.\n" +
			"The camera can be set to rotate around the arena and automatically look at users and targets " +
			"or use camera positions to show who's in action.\n" +
			"The battle camera is not available in 'Real Time' type battles.", "", endFoldout=true)]
		public BattleCamera camera = new BattleCamera();


		// menu settings
		[ORKEditorInfo("Battle Menu Settings", "Define the default battle menu settings.", "",
			ORKDataType.BattleMenu)]
		[ORKEditorHelp("Default Battle Menu", "The default battle menu.\n" +
			"Classes and combatants can define their own battle menu to replace this menu.", "")]
		public int menuID = 0;

		// turn based menu
		[ORKEditorHelp("Own Turn Based Menu", "Use a different battle menu in turn based battles.", "")]
		public bool useTurnBasedMenu = false;

		[ORKEditorHelp("Turn Based Menu", "Select the battle menu that will be used in turn based battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("useTurnBasedMenu", true, endCheckGroup=true)]
		public int turnBasedMenuID = 0;

		// active time menu
		[ORKEditorHelp("Own Active Time Menu", "Use a different battle menu in active time battles.", "")]
		public bool useActiveTimeMenu = false;

		[ORKEditorHelp("Active Time Menu", "Select the battle menu that will be used in active time battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("useActiveTimeMenu", true, endCheckGroup=true)]
		public int activeTimeMenuID = 0;

		// real time menu
		[ORKEditorHelp("Own Real Time Menu", "Use a different battle menu in real time battles.", "")]
		public bool useRealTimeMenu = false;

		[ORKEditorHelp("Real Time Menu", "Select the battle menu that will be used in real time battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("useRealTimeMenu", true, endCheckGroup=true)]
		public int realTimeMenuID = 0;

		// phase battle menu
		[ORKEditorHelp("Own Phase Menu", "Use a different battle menu in phase battles.", "")]
		public bool usePhaseMenu = false;

		[ORKEditorHelp("Phase Menu", "Select the battle menu that will be used in phase battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("usePhaseMenu", true, endCheckGroup=true)]
		public int phaseMenuID = 0;

		// drag/drop
		[ORKEditorHelp("Enable Drag", "The attack command, abilities and items can be " +
			"dragged from the menu on a target to use them.", "")]
		[ORKEditorInfo(separator=true, labelText="Control Settings")]
		public bool bmDrag = false;

		[ORKEditorHelp("Enable Double Click", "Double clicking on the attack command, " +
			"an ability or an item and clicking on a target uses the command on the target.", "")]
		public bool bmClick = false;

		[ORKEditorHelp("Click Count", "Define the number of clicks needed.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("bmClick", true, endCheckGroup=true)]
		public int bmClickCount = 2;

		[ORKEditorHelp("Enable Tooltip", "A tooltip HUD can be displayed when the mouse position is over a battle menu item.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool bmTooltip = false;


		// target settings
		// target selection
		// target menu
		[ORKEditorHelp("Use Target Menu", "A menu based target selection is used.\n" +
			"Targets are listed as choices in a GUI box.", "")]
		[ORKEditorInfo("Target Settings", "Settings for target selections and selecting group/individual targets.", "",
			"Target Selection", "The settings for the target selection.\n" +
			"The target selection is used when selecting the target for a base attack, ability or item.\n" +
			"You can combine the different target selections.", "",
			labelText="Target Menu")]
		public bool useTargetMenu = true;

		[ORKEditorHelp("Rotate To Target", "Rotate the user to the selected target during target selections.", "")]
		public bool rotateToTarget = false;

		[ORKEditorHelp("Grid Rotation", "Limit the rotation to the nearest grid rotation during grid battles.", "")]
		[ORKEditorLayout("rotateToTarget", true)]
		public bool rotateToTargetGridRotation = false;

		[ORKEditorHelp("Rotate Cursor Over", "The user only rotates to a target when first hovering the cursor over it.", "")]
		[ORKEditorLayout("targetCursorOverSelection", true, endCheckGroup=true, endGroups=2,
			setDefault=true, defaultValue=false)]
		public bool rotateToTargetCursorOver = false;

		// target keys
		[ORKEditorHelp("Next Target Key", "The key to select the next target.\n" +
			"This will move the selection down in the target menu.", "")]
		[ORKEditorInfo("Target Change Keys", "Define input keys that can be used to switch between available targets.\n" +
			"These keys are used during the target selection (e.g. when the target menu would be displayed).", "",
			ORKDataType.InputKey)]
		public int targetNextKey = 0;

		[ORKEditorHelp("Previous Target Key", "The key to select the previous target.\n" +
			"This will move the selection up in the target menu.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int targetPreviousKey = 0;

		[ORKEditorHelp("Nearest Target Key", "The key to select the target closest to the user.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int targetNearestKey = 0;

		[ORKEditorHelp("Target Range Key", "The key to toggle between 'Single' and 'Group' target range " +
			"for abilities/items that allow changing the target range.\n" +
			"This input key can be used during target selections (e.g. in the battle menu or menu screens).", "")]
		[ORKEditorInfo(ORKDataType.InputKey, endFoldout=true)]
		public int targetRangeKey = 0;

		// target cursor
		[ORKEditorHelp("Use Cursor", "A cursor game object is displayed at the selected target.", "")]
		[ORKEditorInfo("Target Cursor", "A cursor game object can be displayed on a selected target's game object.", "")]
		public bool useTargetCursor = false;

		[ORKEditorHelp("Prefab", "Select the prefab used as cursor object.", "")]
		[ORKEditorLayout("useTargetCursor", true)]
		public GameObject cursorPrefab;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public MountSettings cursorMount = new MountSettings();

		// blink
		[ORKEditorHelp("Use Blink", "The selected target's game object will blink.", "")]
		[ORKEditorInfo("Blink Target Object", "The game object of the target can blink.", "")]
		public bool useBlink = false;

		[ORKEditorHelp("Blink Children", "All child game objects of the target object will blink.\n" +
			"If disabled, only the root object of the target will blink.", "")]
		[ORKEditorLayout("useBlink", true)]
		public bool blinkChildren = true;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public FadeColorSettings blink;

		// HUD blink
		[ORKEditorHelp("Use Blink", "The selected target's HUDs will blink.", "")]
		[ORKEditorInfo("Blink Target HUD", "The HUDs of the target can blink.", "")]
		public bool useBlinkHUD = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useBlinkHUD", true, endCheckGroup=true, autoInit=true)]
		public FadeColorSettings blinkHUD;

		// click combatant
		// raycast settings
		[ORKEditorHelp("Layer Mask", "Select the layer the raycast will use.\n" +
			"Only objects on this layer can be hit by the raycast.", "")]
		[ORKEditorInfo("Mouse/Touch Control", "Input settings for mouse and touch control.\n" +
			"A click/touch will use a raycast on that position to find a combatant.", "",
			labelText="Raycast Settings")]
		public LayerMask targetLayerMask = -1;

		[ORKEditorHelp("Distance", "The distance the raycast will use (from the camera).", "")]
		public float targetRayDistance = 100.0f;

		[ORKEditorHelp("Accept Only Selected", "Mouse/touch input can only accept already selected combatants.\n" +
			"E.g. first click will select, 2nd click (on selected combatant) will accept the combatant.", "")]
		public bool targetAcceptOnlySelected = false;

		[ORKEditorHelp("Use Grid Cell", "Selection also works on the grid cells of combatants in grid battles.", "")]
		public bool targetUseGridCell = false;

		[ORKEditorHelp("Cursor Over Selection", "Targets can be selected by hovering the cursor over the target's game object.", "")]
		public bool targetCursorOverSelection = false;

		[ORKEditorHelp("Cursor Move Only", "Only check for hover selection when the cursor has actually been moved.\n" +
			"If disabled, hover selection is checked at all times.", "")]
		[ORKEditorLayout("targetCursorOverSelection", true, endCheckGroup=true)]
		public bool targetCursorOverMouseMoveOnly = false;

		[ORKEditorInfo(endFoldout=true, endFolds=2, separator=true)]
		public MouseTouchControl targetMouseTouch = new MouseTouchControl();


		// target information dialogue
		[ORKEditorInfo("Target Information Dialogue", "Optionally display status changes that " +
			"will happen to the user and targets of an ability/item.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Target Information", "Adds a target information dialogue.", "",
			"Remove", "Removes this target information dialogue.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Target Information", "Displays status changes that will happen to the user and targets of an ability/item.", ""
		})]
		public TargetInformationChoice[] targetInformation = new TargetInformationChoice[0];


		// target confirmation dialogue
		[ORKEditorHelp("Show Target Confirmation", "Show a target confirmation dialogue after " +
			"selecting a target for an ability or item.\n" +
			"The ability/item will only be used when the target confirmation dialogue is accepted, " +
			"otherwise the target selection is resumed.", "")]
		[ORKEditorInfo("Target Confirmation Dialogue", "Optionally display a target confirmation dialogue " +
			"showing status changes that will happen to the user and targets of an ability/item.", "")]
		public bool showTargetConfirmation = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("showTargetConfirmation", true, endCheckGroup=true, autoInit=true)]
		public TargetConfirmationChoice targetConfirmation;


		// group targets
		[ORKEditorInfo("Group Target Settings", "Group targets are available to all combatants of a group.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Target Settings", "Adds target settings.", "",
			"Remove", "Removes this target settings.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Target Settings", "Define the input keys and targets that can be selected.", ""
		})]
		public TargetSelection[] groupTargetSelection = new TargetSelection[0];


		// individual targets
		[ORKEditorInfo("Individual Target Settings", "Individual targets are only available to the combatant who selected them.", "",
			endFoldout=true, endFolds=2)]
		[ORKEditorArray(false, "Add Target Settings", "Adds target settings.", "",
			"Remove", "Removes this target settings.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Target Settings", "Define the input keys and targets that can be selected.", ""
		})]
		public TargetSelection[] individualTargetSelection = new TargetSelection[0];


		// default start turn events
		[ORKEditorInfo("Default Events", "Combatants can perform game events at the start and end of their turn.\n" +
			"Define the default events here, each combatant can individually override these events.", "",
			"Turn Start Events", "Define the game events that will be performed at the " +
			"start of a combatant's turn (after the grid cell events).\n" +
			"The events are separated into player group, ally group and enemy group combatants.\n" +
			"Each combatant can individually override these default events.", "",
			endFoldout=true)]
		public FactionEventSetting turnStartEvents = new FactionEventSetting();

		[ORKEditorInfo("Turn End Events", "Define the game events that will be performed at the " +
			"end of a combatant's turn (before the grid cell events).\n" +
			"The events are separated into player group, ally group and enemy group combatants.\n" +
			"Each combatant can individually override these default events.", "",
			endFoldout=true, endFolds=2)]
		public FactionEventSetting turnEndEvents = new FactionEventSetting();


		// default action combos
		[ORKEditorHelp("Action Combo", "Select the action combo that will be available.", "")]
		[ORKEditorInfo("Default Action Combos", "Define action combos that will be available for all combatants.\n" +
			"Combatants can optionally add or replace the default combos.", "",
			ORKDataType.ActionCombo, endFoldout=true, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Action Combo", "Adds an action combo.", "",
			"Remove", "Removes the action combo.", "", isHorizontal=true)]
		public int[] defaultActionCombo = new int[0];


		// general cast times
		[ORKEditorInfo("Cast Time Settings", "You can optionally use cast times for basic commands like defending or escaping.", "",
			"Default Ability Cast Time", "An ability can be casted for a set amount of time before it is used.\n" +
			"This is the default setting for all abilities, each individual ability can override it.\n"+
			"The cast time can be displayed in a HUD (either as a number or a bar).", "",
			endFoldout=true)]
		public CastTimeSettings abilityCastTime = new CastTimeSettings();

		[ORKEditorInfo("Default Item Cast Time", "An item can be casted for a set amount of time before it is used.\n" +
			"This is the default setting for all items, each individual item can override it.\n"+
			"The cast time can be displayed in a HUD (either as a number or a bar).", "",
			endFoldout=true)]
		public CastTimeSettings itemCastTime = new CastTimeSettings();

		[ORKEditorInfo("Defend Cast Time", "The defend command can be casted for a set amount of time before it is used.\n" +
			"The cast time can be displayed in a HUD (either as a number or a bar).", "",
			endFoldout=true)]
		public CastTimeSettings defendCastTime = new CastTimeSettings();

		[ORKEditorInfo("Escape Cast Time", "The escape command can be casted for a set amount of time before it is used.\n" +
			"The cast time can be displayed in a HUD (either as a number or a bar).", "",
			endFoldout=true)]
		public CastTimeSettings escapeCastTime = new CastTimeSettings();

		[ORKEditorInfo("None Cast Time", "The none command (doing nothing) can be casted for a set amount of time before it is used.\n" +
			"The cast time can be displayed in a HUD (either as a number or a bar).", "",
			endFoldout=true)]
		public CastTimeSettings noneCastTime = new CastTimeSettings();

		[ORKEditorInfo("Grid Move Cast Time", "The grid move command can be casted for a set amount of time before it is used.\n" +
			"The cast time can be displayed in a HUD (either as a number or a bar).", "",
			endFoldout=true, endFolds=2)]
		public CastTimeSettings gridMoveCastTime = new CastTimeSettings();


		// default battle animations
		[ORKEditorInfo("Battle Animations", "Define the battle events used to animate default actions, e.g. defend, escape or a combatant's death.\n" + 
			"Combatants can override the default animations.", "", 
			endFoldout=true)]
		public DefaultBattleAnimations battleAnimations = new DefaultBattleAnimations();

		public BattleSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<DataObject>("groupTarget"))
			{
				DataObject tmpData = data.GetFile("groupTarget");
				if(tmpData != null)
				{
					bool tmp = false;
					tmpData.Get("useGroupTarget", ref tmp);
					if(tmp)
					{
						this.groupTargetSelection = new TargetSelection[1];
						this.groupTargetSelection[0] = new TargetSelection();
						tmpData.Get("onlyInBattleRange", ref this.groupTargetSelection[0].onlyInBattleRange);
						tmpData.Get("noActionOnly", ref this.groupTargetSelection[0].noActionOnly);
						tmpData.Get("autoSelectTarget", ref this.groupTargetSelection[0].autoSelect);
						tmpData.Get("autoAttackTarget", ref this.groupTargetSelection[0].autoAttackTarget);
						tmpData.Get("aaPlayerOnly", ref this.groupTargetSelection[0].aaPlayerOnly);
						tmpData.Get("nextTargetKey", ref this.groupTargetSelection[0].nextKey);
						tmpData.Get("previousTargetKey", ref this.groupTargetSelection[0].previousKey);
						tmpData.Get("nearestTargetKey", ref this.groupTargetSelection[0].nearestKey);
						tmpData.Get("autoAttackTarget", ref this.groupTargetSelection[0].autoAttackTarget);
						tmpData.Get("clearTargetKey", ref this.groupTargetSelection[0].removeKey);
						tmpData.Get("allowTargetRemove", ref this.groupTargetSelection[0].allowClickRemove);
						tmpData.Get("useTargetCursor", ref this.groupTargetSelection[0].useTargetCursor);
						tmpData.Get("cursorPrefab", ref this.groupTargetSelection[0].cursorPrefab);

						this.groupTargetSelection[0].clickControl.SetData(tmpData.GetFile("groupMouseTouch"));
						this.groupTargetSelection[0].cursorMount.SetData(tmpData.GetFile("cursorMount"));
					}
				}
			}
			if(data.Contains<bool>("bmDoubleClick"))
			{
				data.Get("bmDoubleClick", ref this.bmClick);
			}
			if(data.Contains<DataObject>("targetInformation"))
			{
				TargetInformationChoice tmp = new TargetInformationChoice();
				tmp.SetData(data.GetFile("targetInformation"));
				ArrayHelper.Add(ref this.targetInformation, tmp);
			}
		}

		public override void SetRealIDs()
		{

		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "battleSettings"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}

		public override int Copy(int index)
		{
			return -1;
		}

		public override void Remove(int index)
		{

		}

		public override void Move(int index, bool down)
		{

		}


		/*
		============================================================================
		Target information functions
		============================================================================
		*/
		public void ShowTargetInformation(Combatant user, List<Combatant> targets, IShortcut shortcut)
		{
			for(int i = 0; i < targetInformation.Length; i++)
			{
				this.targetInformation[i].Show(user, targets, shortcut);
			}
		}

		public void CursorOverTargetInformation(Combatant combatant, bool changed)
		{
			for(int i = 0; i < targetInformation.Length; i++)
			{
				this.targetInformation[i].CombatantCursorOver(combatant, changed);
			}
		}

		public void CloseTargetInformation()
		{
			for(int i = 0; i < targetInformation.Length; i++)
			{
				this.targetInformation[i].Close();
			}
		}
	}
}
