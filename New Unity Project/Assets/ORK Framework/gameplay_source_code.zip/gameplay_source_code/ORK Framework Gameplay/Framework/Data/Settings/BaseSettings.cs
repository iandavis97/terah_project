
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace ORKFramework
{
	public abstract class BaseSettings : CoreSettings
	{
		public override void DataAdded(ORKDataType type, int index)
		{
			DataHelper.DataAdded(this, type, index);
			this.SetRealIDs();
		}
		
		public override void DataRemoved(ORKDataType type, int index, int index2)
		{
			DataHelper.DataRemoved(this, type, index, index2);
			this.SetRealIDs();
		}
		
		public override void DataMoved(ORKDataType type, bool down, int index, int index2)
		{
			DataHelper.DataMoved(this, type, down, index, index2);
			this.SetRealIDs();
		}

		public override void DataLoaded()
		{
			DataHelper.DataLoaded(this);
		}
	}
}
