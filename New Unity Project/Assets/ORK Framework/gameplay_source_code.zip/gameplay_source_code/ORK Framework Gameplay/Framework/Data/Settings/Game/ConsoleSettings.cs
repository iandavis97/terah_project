
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ConsoleSettings : BaseSettings
	{
		// base settings
		[ORKEditorHelp("Use Console", "Use the console.", "")]
		[ORKEditorInfo("Base Settings", "Define the base console settings.", "")]
		public bool useConsole = false;

		[ORKEditorHelp("Unity Console Output", "Print new console lines to the Unity console.\n" +
			"This is only done when playing in the Unity Editor and ignores 'Use Console'.", "")]
		public bool unityConsole = false;

		[ORKEditorHelp("Maximum Lines", "Define the maximum number of lines the console will display.", "")]
		[ORKEditorLimit(1, false)]
		public int maxLines = 50;

		// auto remove
		[ORKEditorHelp("Auto Remove Lines", "Automatically remove console lines after a defined amount of time.", "")]
		public bool autoRemoveLines = false;

		[ORKEditorHelp("Remove Every (s)", "The time in seconds between removing console lines.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("autoRemoveLines", true, endCheckGroup=true)]
		public float autoRemoveEvery = 3;


		// combatant consoles
		[ORKEditorHelp("Use Combatant Consoles", "Use combatant consoles.\n" +
			"Allows using consoles per combatant, automatically adding texts that concern a combatant to their console.\n" +
			"E.g. if a combatant is user or target of an action, the action text will be added to the combatant's console.", "")]
		[ORKEditorInfo(separator=true, labelText="Combatant Consoles")]
		public bool useCombatantConsoles = false;

		[ORKEditorHelp("Maximum Lines Combatant", "Define the maximum number of lines the combatant consoles will display.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("useCombatantConsoles", true, endCheckGroup=true)]
		public int maxLinesCombatant = 30;


		// text wrapping
		[ORKEditorHelp("Before Line Text", "Text added before each console line.\n" +
			"This text will be added after the 'Before Line Text' of the console type.", "")]
		[ORKEditorInfo("Before Line Text", "Text added before each console line.\n" +
			"This text will be added after the 'Before Line Text' of the console type.", "",
			endFoldout=true, isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] beforeLineText = ArrayHelper.CreateArray(ORK.Languages.Count, "");

		[ORKEditorHelp("After Line Text", "Text added after each console line.\n" +
			"This text will be added before the 'After Line Text' of the console type.", "")]
		[ORKEditorInfo("After Line Text", "Text added after each console line.\n" +
			"This text will be added before the 'After Line Text' of the console type.", "",
			endFoldout=true, isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] afterLineText = ArrayHelper.CreateArray(ORK.Languages.Count, "");


		// actions
		[ORKEditorHelp("Display Actions", "Action texts will be added to the console.\n" +
			"Actions are everything like using abilities or items, trying to escape, defending or dying.", "")]
		[ORKEditorInfo("Action Texts", "Define if and what texts will be added for using actions.\n" +
			"Actions are everything like using abilities or items, trying to escape, defending or dying.", "")]
		public bool displayActions = true;

		[ORKEditorInfo("Max. Player Distance", "The maximum distance (in world units) to the player to add action texts to the console.\n" +
			"Use this settings to stop far away combatants to spam the console with actions.", "",
			endFoldout=true)]
		[ORKEditorLimit(0.0f, false)]
		public ConsoleRange actionRange = new ConsoleRange();

		// target names
		[ORKEditorHelp("Own Target Names", "Override the default combatant name list settings " +
			"('Menus > Text Display Settings') for action texts.", "")]
		[ORKEditorInfo("Target Names", "Define how the name of multiple targets will be displayed.", "")]
		public bool ownActionTargetNames = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownActionTargetNames", true, endCheckGroup=true)]
		public CombatantNamesDisplay actionTargetNames = new CombatantNamesDisplay();

		// console action previews
		[ORKEditorInfo("Status Value Changes", "Define the text used to display status value changes " +
			"in ability and item action texts.", "",
			endFoldout=true)]
		public StatusValueChangeDisplay actionStatusValueChanges = new StatusValueChangeDisplay();

		// add action texts
		[ORKEditorInfo("Add Action Texts", "The add action texts will be added to the console " +
			"when an action has been selected by a combatant.", "",
			"Ability Text", "The text displayed for add ability actions.\n" +
			"Can be overridden for each ability individually.", "",
			endFoldout=true)]
		public ConsoleTextActionPreview actionAddAbility = new ConsoleTextActionPreview(false);

		[ORKEditorInfo("Item Text", "The text displayed for adding item actions.\n" +
			"Can be overridden for each item individually.", "",
			endFoldout=true)]
		public ConsoleTextActionPreview actionAddItem = new ConsoleTextActionPreview(false);

		[ORKEditorInfo("Defend Text", "The text displayed for adding defend actions (defend command).\n" +
			"Can be overridden for each combatant individually.", "",
			endFoldout=true)]
		public ConsoleTextActionSimple actionAddDefend = new ConsoleTextActionSimple(false);

		[ORKEditorInfo("Escape Text", "The text displayed for adding escape actions (escape command).\n" +
			"Can be overridden for each combatant individually.", "",
			endFoldout=true)]
		public ConsoleTextActionSimple actionAddEscape = new ConsoleTextActionSimple(false);

		[ORKEditorInfo("Death Text", "The text displayed for adding death actions (dying).\n" +
			"Can be overridden for each combatant individually.", "",
			endFoldout=true)]
		public ConsoleTextActionSimple actionAddDeath = new ConsoleTextActionSimple(false);

		[ORKEditorInfo("None Text", "The text displayed for adding none actions (doing nothing).\n" +
			"Can be overridden for each combatant individually.", "",
			endFoldout=true)]
		public ConsoleTextActionSimple actionAddNone = new ConsoleTextActionSimple(false);

		[ORKEditorInfo("Change Member Text", "The text displayed for adding change member actions.\n" +
			"Can be overridden for each combatant individually.", "",
			endFoldout=true)]
		public ConsoleTextActionSingle actionAddChangeMember = new ConsoleTextActionSingle(false);

		[ORKEditorInfo("Join Battle Text", "The text displayed for adding join battle actions.\n" +
			"Can be overridden for each combatant individually.", "",
			endFoldout=true)]
		public ConsoleTextActionSimple actionAddJoinBattle = new ConsoleTextActionSimple(false);

		[ORKEditorInfo("Grid Move Text", "The text displayed for adding grid move actions (move command).\n" +
			"Can be overridden for each combatant individually.", "",
			endFoldout=true, endFolds=2)]
		public ConsoleTextActionSimple actionAddGridMove = new ConsoleTextActionSimple(false);

		// perform action texts
		[ORKEditorInfo("Perform Action Texts", "The perform action texts will be added to the console " +
			"when an action starts performing (or casting).", "",
			"Ability Text", "The text displayed for using abilities.\n" +
			"Can be overridden for each ability individually.", "",
			endFoldout=true)]
		public ConsoleTextActionPreview actionAbility = new ConsoleTextActionPreview("%un uses %n on %tn.");

		[ORKEditorInfo("Cast Action Text", "The text displayed for casting an action.\n" +
			"Can be overridden for each ability or item individually.", "",
			endFoldout=true)]
		public ConsoleTextActionPreview actionCast = new ConsoleTextActionPreview("%un casts %n.");

		[ORKEditorInfo("Cancel Cast Text", "The text displayed for canceling an action cast.\n" +
			"Can be overridden for each ability or item individually.", "",
			endFoldout=true)]
		public ConsoleTextActionPreview actionCastCancel = new ConsoleTextActionPreview("%un cancels casting %n.");

		[ORKEditorInfo("Item Text", "The text displayed for using item actions.\n" +
			"Can be overridden for each item individually.", "",
			endFoldout=true)]
		public ConsoleTextActionPreview actionItem = new ConsoleTextActionPreview("%un uses %n on %tn.");

		[ORKEditorInfo("Defend Text", "The text displayed for using the defend command.\n" +
			"Can be overridden for each combatant individually.", "",
			endFoldout=true)]
		public ConsoleTextActionSimple actionDefend = new ConsoleTextActionSimple("%un defends himself.");

		[ORKEditorInfo("Escape Text", "The text displayed for using the escape command.\n" +
			"Can be overridden for each combatant individually.", "",
			endFoldout=true)]
		public ConsoleTextActionSimple actionEscape = new ConsoleTextActionSimple("%un tries to escape.");

		[ORKEditorInfo("Death Text", "The text displayed for dying.\n" +
			"Can be overridden for each combatant individually.", "",
			endFoldout=true)]
		public ConsoleTextActionSimple actionDeath = new ConsoleTextActionSimple("%un dies.");

		[ORKEditorInfo("None Text", "The text displayed for doing nothing.\n" +
			"Can be overridden for each combatant individually.", "",
			endFoldout=true)]
		public ConsoleTextActionSimple actionNone = new ConsoleTextActionSimple("%un does nothing.");

		[ORKEditorInfo("Change Member Text", "The text displayed for changing members.\n" +
			"Can be overridden for each combatant individually.", "",
			endFoldout=true)]
		public ConsoleTextActionSingle actionChangeMember = new ConsoleTextActionSingle("%un is exchanged for %tn.");

		[ORKEditorInfo("Join Battle Text", "The text displayed for joining a battle.\n" +
			"Can be overridden for each combatant individually.", "",
			endFoldout=true)]
		public ConsoleTextActionSimple actionJoinBattle = new ConsoleTextActionSimple("%un joins the battle.");

		[ORKEditorInfo("Grid Move Text", "The text displayed for moving on the grid (move command).\n" +
			"Can be overridden for each combatant individually.", "",
			endFoldout=true, endFolds=3)]
		public ConsoleTextActionSimple actionGridMove = new ConsoleTextActionSimple("%un moves.");


		// learning
		[ORKEditorHelp("Display Learning", "Learning texts will be added to the console.\n" +
			"Learning texts are everything like learning new ability trees, abilities, crafting recipes and logs.", "")]
		[ORKEditorInfo("Learning Texts", "Define if and what texts will be added for learning new things.\n" +
			"Learning texts are everything like learning new ability trees, abilities, crafting recipes and logs.", "")]
		public bool displayLearning = true;

		[ORKEditorInfo("Max. Player Distance", "The maximum distance (in world units) to the player to add learning texts to the console.\n" +
			"Use this settings to stop far away combatants to spam the console with learning texts.", "",
			endFoldout=true)]
		[ORKEditorLimit(0.0f, false)]
		public ConsoleRange learningRange = new ConsoleRange();

		// learning group names
		[ORKEditorHelp("Own Group Member Names", "Override the default combatant name list settings " +
			"('Menus > Text Display Settings') for learning texts.", "")]
		[ORKEditorInfo("Group Member Names", "Define how the name of multiple group members will be displayed.\n" +
			"This is used for group abilities.", "")]
		public bool ownLearningGroupNames = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownLearningGroupNames", true, endCheckGroup=true)]
		public CombatantNamesDisplay learningGroupNames = new CombatantNamesDisplay();

		// learning texts
		[ORKEditorInfo("Ability Tree Text", "The text displayed for learning a new ability tree.\n" +
			"Can be overridden for each ability tree individually.", "",
			endFoldout=true)]
		public ConsoleTextLearning learnAbilityTree = new ConsoleTextLearning("%un learns %n.");

		[ORKEditorInfo("Ability Text", "The text displayed for learning a new ability.\n" +
			"Can be overridden for each ability individually.", "",
			endFoldout=true)]
		public ConsoleTextLearning learnAbility = new ConsoleTextLearning("%un learns %n");

		[ORKEditorInfo("Group Ability Text", "The text displayed for learning a new group ability.\n" +
			"Can be overridden for each ability individually.", "",
			endFoldout=true)]
		public ConsoleTextGroupLearning learnGroupAbility = new ConsoleTextGroupLearning("%un learn %n");

		[ORKEditorInfo("Crafting Recipe Text", "The text displayed for adding a crafting recipe.\n" +
			"Can be overridden for each crafting recipe individually.", "",
			endFoldout=true)]
		public ConsoleTextCrafting learnCraftingRecipe = new ConsoleTextCrafting("%un receives %n.");

		[ORKEditorInfo("Log Text", "The text displayed for learning a new log.\n" +
			"Can be overridden for each log individually.", "",
			endFoldout=true)]
		public ConsoleTextLearning learnLog = new ConsoleTextLearning("%un learns %n.");

		[ORKEditorInfo("Log Update Text", "The text displayed for learning a new log text.\n" +
			"Can be overridden for each log text individually.\n" +
			"%n displays the name of the log.", "",
			endFoldout=true, endFolds=2)]
		public ConsoleTextLearning learnLogUpdate = new ConsoleTextLearning("%n updated.");


		// forgetting
		[ORKEditorHelp("Display Forgetting", "Forgetting texts will be added to the console.\n" +
			"Forgetting texts are everything like forgetting ability trees, abilities, crafting recipes and logs.", "")]
		[ORKEditorInfo("Forgetting Texts", "Define if and what texts will be added for forgetting learned things.\n" +
			"Forgetting texts are everything like forgetting ability trees, abilities, crafting recipes and logs.", "")]
		public bool displayForgetting = true;

		[ORKEditorInfo("Max. Player Distance", "The maximum distance (in world units) to the player to add forgetting texts to the console.\n" +
			"Use this settings to stop far away combatants to spam the console with forgetting texts.", "",
			endFoldout=true)]
		[ORKEditorLimit(0.0f, false)]
		public ConsoleRange forgettingRange = new ConsoleRange();

		// forget group names
		[ORKEditorHelp("Own Group Member Names", "Override the default combatant name list settings " +
			"('Menus > Text Display Settings') for forgetting texts.", "")]
		[ORKEditorInfo("Group Member Names", "Define how the name of multiple group members will be displayed.\n" +
			"This is used for group abilities.", "")]
		public bool ownForgettingGroupNames = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownForgettingGroupNames", true, endCheckGroup=true)]
		public CombatantNamesDisplay forgettingGroupNames = new CombatantNamesDisplay();

		// forgetting texts
		[ORKEditorInfo("Ability Tree Text", "The text displayed for forgetting an ability tree.\n" +
			"Can be overridden for each ability tree individually.", "",
			endFoldout=true)]
		public ConsoleTextLearning forgetAbilityTree = new ConsoleTextLearning("%un forgets %n.");

		[ORKEditorInfo("Ability Text", "The text displayed for forgetting an ability.\n" +
			"Can be overridden for each ability individually.", "",
			endFoldout=true)]
		public ConsoleTextLearning forgetAbility = new ConsoleTextLearning("%un forgets %n.");

		[ORKEditorInfo("Group Ability Text", "The text displayed for forgetting a group ability.\n" +
			"Can be overridden for each ability individually.", "",
			endFoldout=true)]
		public ConsoleTextGroupLearning forgetGroupAbility = new ConsoleTextGroupLearning("%un forget %n");

		[ORKEditorInfo("Crafting Recipe Text", "The text displayed for removing a crafting recipe.\n" +
			"Can be overridden for each crafting recipe individually.", "",
			endFoldout=true)]
		public ConsoleTextCrafting forgetCraftingRecipe = new ConsoleTextCrafting("%un removes %n.");

		[ORKEditorInfo("Log Text", "The text displayed for forgett a log.\n" +
			"Can be overridden for each log individually.", "",
			endFoldout=true)]
		public ConsoleTextLearning forgetLog = new ConsoleTextLearning("%un forgets %n.");

		[ORKEditorInfo("Log Update Text", "The text displayed for forgetting a log text.\n" +
			"Can be overridden for each log text individually.\n" +
			"%n displays the name of the log.", "",
			endFoldout=true, endFolds=2)]
		public ConsoleTextLearning forgetLogUpdate = new ConsoleTextLearning("%n updated.");


		// status
		[ORKEditorHelp("Display Status", "Status texts will be added to the console.\n" +
			"Status texts are everything like applying/removing status effects and changes to status values.", "")]
		[ORKEditorInfo("Status Texts", "Define if and what texts will be added for status changes.\n" +
			"Status texts are everything like applying/removing status effects and changes to status values.", "")]
		public bool displayStatus = true;

		[ORKEditorInfo("Max. Player Distance", "The maximum distance (in world units) to the player to add status texts to the console.\n" +
			"Use this settings to stop far away combatants to spam the console with status texts.", "",
			endFoldout=true)]
		[ORKEditorLimit(0.0f, false)]
		public ConsoleRange statusRange = new ConsoleRange();

		// status texts
		// status value
		[ORKEditorInfo("Increase Status Value Text", "The text displayed for increasing a status value.\n" +
			"Can be overridden for each status value individually.", "",
			endFoldout=true)]
		public ConsoleTextStatusValue statusIncreaseSV = new ConsoleTextStatusValue("%un +% %n.");

		[ORKEditorInfo("Decrease Status Value Text", "The text displayed for decreasing a status value.\n" +
			"Can be overridden for each status value individually.", "",
			endFoldout=true)]
		public ConsoleTextStatusValue statusDecreaseSV = new ConsoleTextStatusValue("%un -% %n.");

		[ORKEditorInfo("Set Status Value Text", "The text displayed for setting a status value.\n" +
			"Can be overridden for each status value individually.", "",
			endFoldout=true)]
		public ConsoleTextStatusValue statusSetSV = new ConsoleTextStatusValue("%un %n set to %.");

		// status effect
		[ORKEditorInfo("Apply Effect Text", "The text displayed for applying a status effect to a combatant.\n" +
			"Can be overridden for each status effect individually.", "",
			endFoldout=true)]
		public ConsoleTextStatusEffect statusApplyEffect = new ConsoleTextStatusEffect("%n added to %un.");

		[ORKEditorInfo("Reapply Effect Text", "The text displayed for reapplying a status effect to a combatant.\n" +
			"Can be overridden for each status effect individually.", "",
			endFoldout=true)]
		public ConsoleTextStatusEffect statusReapplyEffect = new ConsoleTextStatusEffect("%n renewed on %un.");

		[ORKEditorInfo("Miss Effect Text", "The text displayed for failing to apply a status effect to a combatant.\n" +
			"Can be overridden for each status effect individually.", "",
			endFoldout=true)]
		public ConsoleTextStatusEffect statusMissEffect = new ConsoleTextStatusEffect(false, "%n failed on %un.");

		[ORKEditorInfo("Remove Effect Text", "The text displayed for removing a status effect from a combatant.\n" +
			"Can be overridden for each status effect individually.", "",
			endFoldout=true, endFolds=2)]
		public ConsoleTextStatusEffect statusRemoveEffect = new ConsoleTextStatusEffect("%n removed from %un.");


		// level up
		[ORKEditorHelp("Display Level Up", "Level up texts will be added to the console.\n" +
			"Level up texts are displayed when a combatant reaches a new base/class level.", "")]
		[ORKEditorInfo("Level Up Texts", "Define if and what texts will be added for a combatant's level up.\n" +
			"Level up texts are displayed when a combatant reaches a new base/class level.", "")]
		public bool displayLevelUp = true;

		[ORKEditorInfo("Max. Player Distance", "The maximum distance (in world units) to the player to add level up texts to the console.\n" +
			"Use this settings to stop far away combatants to spam the console with level up texts.", "",
			endFoldout=true)]
		[ORKEditorLimit(0.0f, false)]
		public ConsoleRange levelUpRange = new ConsoleRange();

		// level up texts
		[ORKEditorInfo("Level Up Text", "The text displayed when a combatant's base level increases.\n" +
			"Can be overridden for each combatant individually.", "",
			endFoldout=true)]
		public ConsoleTextLevelUp levelUp = new ConsoleTextLevelUp("%un reaches level %.");

		[ORKEditorInfo("Class Level Up Text", "The text displayed when a combatant's class level increases.\n" +
			"Can be overridden for each combatant individually.", "",
			endFoldout=true)]
		public ConsoleTextLevelUp levelUpClass = new ConsoleTextLevelUp("%un reaches class level %.");

		[ORKEditorInfo("Ability Level Up Text", "The text displayed when an ability's level increases.\n" +
			"Can be overridden for each ability individually.", "",
			endFoldout=true)]
		public ConsoleTextLevelUp levelUpAbility = new ConsoleTextLevelUp("%un %n reaches level %.");

		[ORKEditorInfo("Weapon Level Up Text", "The text displayed when a weapon's level increases.\n" +
			"Can be overridden for each weapon individually.", "",
			endFoldout=true)]
		public ConsoleTextLevelUp levelUpWeapon = new ConsoleTextLevelUp("%un %n reaches level %.");

		[ORKEditorInfo("Armor Level Up Text", "The text displayed when an armor's level increases.\n" +
			"Can be overridden for each armor individually.", "",
			endFoldout=true, endFolds=2)]
		public ConsoleTextLevelUp levelUpArmor = new ConsoleTextLevelUp("%un %n reaches level %.");


		// inventory
		[ORKEditorHelp("Display Inventory", "Inventory texts will be added to the console.\n" +
			"Inventory texts are everything like adding/removing items, money, weapons or armors.\n" +
			"Please note that inventory texts are only displayed for the player group.", "")]
		[ORKEditorInfo("Inventory Texts", "Define if and what texts will be added for inventory changes.\n" +
			"Inventory texts are everything like adding/removing items, money, weapons or armors.\n" +
			"Please note that inventory texts are only displayed for the player group.", "")]
		public bool displayInventory = true;

		// owner names
		[ORKEditorHelp("Own Owner Names", "Override the default combatant name list settings " +
			"('Menus > Text Display Settings') for inventory texts.", "")]
		[ORKEditorInfo("Owner Names", "Define how the name of multiple inventory owners will be displayed.\n" +
			"This is used for 'Group' inventory.", "")]
		public bool ownInventoryOwnerNames = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownInventoryOwnerNames", true, endCheckGroup=true)]
		public CombatantNamesDisplay inventoryOwnerNames = new CombatantNamesDisplay();

		// inventory texts
		// items
		[ORKEditorInfo("Add Item Text", "The text displayed for adding an item to the inventory.\n" +
			"Can be overridden for each item individually.", "",
			endFoldout=true)]
		public ConsoleTextInventory inventoryAddItem = new ConsoleTextInventory("%un finds %n (%).");

		[ORKEditorInfo("Remove Item Text", "The text displayed for removing an item from the inventory.\n" +
			"Can be overridden for each item individually.", "",
			endFoldout=true)]
		public ConsoleTextInventory inventoryRemoveItem = new ConsoleTextInventory("%un drops %n (%).");

		// currency
		[ORKEditorInfo("Add Currency Text", "The text displayed for adding currency to the inventory.\n" +
			"Can be overridden for each currency individually.", "",
			endFoldout=true)]
		public ConsoleTextInventory inventoryAddCurrency = new ConsoleTextInventory("%un finds %n (%).");

		[ORKEditorInfo("Remove Currency Text", "The text displayed for removing currency from the inventory.\n" +
			"Can be overridden for each currency individually.", "",
			endFoldout=true)]
		public ConsoleTextInventory inventoryRemoveCurrency = new ConsoleTextInventory("%un drops %n (%).");

		[ORKEditorInfo("Set Currency Text", "The text displayed for setting currency to a quantity.\n" +
			"Can be overridden for each currency individually.", "",
			endFoldout=true)]
		public ConsoleTextInventory inventorySetCurrency = new ConsoleTextInventory("%un %n set to %.");

		// weapons
		[ORKEditorInfo("Add Weapon Text", "The text displayed for adding a weapon to the inventory.\n" +
			"Can be overridden for each weapon individually.", "",
			endFoldout=true)]
		public ConsoleTextInventory inventoryAddWeapon = new ConsoleTextInventory("%un finds %n (%).");

		[ORKEditorInfo("Remove Weapon Text", "The text displayed for removing a weapon from the inventory.\n" +
			"Can be overridden for each weapon individually.", "",
			endFoldout=true)]
		public ConsoleTextInventory inventoryRemoveWeapon = new ConsoleTextInventory("%un drops %n (%).");

		// weapons durability
		[ORKEditorInfo("Weapon +Durability Text", "The text displayed for a weapon's durability increasing.\n" +
			"Can be overridden for each weapon individually.", "",
			endFoldout=true)]
		public ConsoleTextDurability durabilityIncreaseWeapon = new ConsoleTextDurability("%un's %n increased to %.");

		[ORKEditorInfo("Weapon -Durability Text", "The text displayed for a weapon's durability decreasing.\n" +
			"Can be overridden for each weapon individually.", "",
			endFoldout=true)]
		public ConsoleTextDurability durabilityDecreaseWeapon = new ConsoleTextDurability("%un's %n dropped to %.");

		[ORKEditorInfo("Weapon Outworn Text", "The text displayed for a weapon's durability reaching 0 (i.e. being outworn).\n" +
			"Can be overridden for each weapon individually.", "",
			endFoldout=true)]
		public ConsoleTextDurability durabilityOutwornWeapon = new ConsoleTextDurability("%un's %n is outworn.");

		// armors
		[ORKEditorInfo("Add Armor Text", "The text displayed for adding an armor to the inventory.\n" +
			"Can be overridden for each armor individually.", "",
			endFoldout=true)]
		public ConsoleTextInventory inventoryAddArmor = new ConsoleTextInventory("%un finds %n (%).");

		[ORKEditorInfo("Remove Armor Text", "The text displayed for removing an armor from the inventory.\n" +
			"Can be overridden for each armor individually.", "",
			endFoldout=true)]
		public ConsoleTextInventory inventoryRemoveArmor = new ConsoleTextInventory("%un drops %n (%).");

		// armors durability
		[ORKEditorInfo("Armor +Durability Text", "The text displayed for an armor's durability increasing.\n" +
			"Can be overridden for each armor individually.", "",
			endFoldout=true)]
		public ConsoleTextDurability durabilityIncreaseArmor = new ConsoleTextDurability("%un's %n increased to %.");

		[ORKEditorInfo("Armor -Durability Text", "The text displayed for an armor's durability decreasing.\n" +
			"Can be overridden for each armor individually.", "",
			endFoldout=true)]
		public ConsoleTextDurability durabilityDecreaseArmor = new ConsoleTextDurability("%un's %n dropped to %.");

		[ORKEditorInfo("Armor Outworn Text", "The text displayed for an armor's durability reaching 0 (i.e. being outworn).\n" +
			"Can be overridden for each armor individually.", "",
			endFoldout=true)]
		public ConsoleTextDurability durabilityOutwornArmor = new ConsoleTextDurability("%un's %n is outworn.");

		// AI behaviours
		[ORKEditorInfo("Add AI Behaviour Text", "The text displayed for adding an AI behaviour to the player.\n" +
			"Can be overridden for each AI behaviour individually.", "",
			endFoldout=true)]
		public ConsoleTextAI aiBehaviourAdd = new ConsoleTextAI("%n (%) added.");

		[ORKEditorInfo("Remove AI Behaviour Text", "The text displayed for removing an AI behaviour from the player.\n" +
			"Can be overridden for each AI behaviour individually.", "",
			endFoldout=true)]
		public ConsoleTextAI aiBehaviourRemove = new ConsoleTextAI("%n (%) removed.");

		// AI rulesets
		[ORKEditorInfo("Add AI Ruleset Text", "The text displayed for adding an AI ruleset to the player.\n" +
			"Can be overridden for each AI ruleset individually.", "",
			endFoldout=true)]
		public ConsoleTextAI aiRulesetAdd = new ConsoleTextAI("%n (%) added.");

		[ORKEditorInfo("Remove AI Ruleset Text", "The text displayed for removing an AI ruleset from the player.\n" +
			"Can be overridden for each AI ruleset individually.", "",
			endFoldout=true, endFolds=2)]
		public ConsoleTextAI aiRulesetRemove = new ConsoleTextAI("%n (%) removed.");


		// quests
		[ORKEditorHelp("Display Quests", "Quest texts will be added to the console.\n" +
			"Quest texts are everything like adding a new quest, finishing/failing a quest/task or activating a new task.", "")]
		[ORKEditorInfo("Quest Texts", "Define if and what texts will be added for quest related things.\n" +
			"Quest texts are everything like adding a new quest, finishing/failing a quest/task or activating a new task.", "")]
		public bool displayQuests = true;

		[ORKEditorHelp("Display Initial Tasks", "Display a quest's initial tasks when adding the quest.\n" +
			"Initial tasks are tasks that will be activated when the quest is added.", "")]
		public bool displayInitialTasks = false;

		[ORKEditorInfo("Add Quest Text", "The text displayed for adding a new quest.\n" +
			"Can be overridden for each quest individually.", "",
			endFoldout=true)]
		public ConsoleTextLearning addQuest = new ConsoleTextLearning("'%n' added.");

		[ORKEditorInfo("Remove Quest Text", "The text displayed for removing a quest.\n" +
			"Can be overridden for each quest individually.", "",
			endFoldout=true)]
		public ConsoleTextLearning removeQuest = new ConsoleTextLearning("'%n' removed.");

		[ORKEditorInfo("Inactivate Quest Text", "The text displayed for inactivating a quest.\n" +
			"Can be overridden for each quest individually.", "",
			endFoldout=true)]
		public ConsoleTextLearning inactivateQuest = new ConsoleTextLearning("'%n' is inactive.");

		[ORKEditorInfo("Activate Quest Text", "The text displayed for activating a quest.\n" +
			"Can be overridden for each quest individually.", "",
			endFoldout=true)]
		public ConsoleTextLearning activateQuest = new ConsoleTextLearning("'%n' is active.");

		[ORKEditorInfo("Finish Quest Text", "The text displayed for finishing a quest.\n" +
			"Can be overridden for each quest individually.", "",
			endFoldout=true)]
		public ConsoleTextLearning finishQuest = new ConsoleTextLearning("'%n' finished.");

		[ORKEditorInfo("Fail Quest Text", "The text displayed for failing a quest.\n" +
			"Can be overridden for each quest individually.", "",
			endFoldout=true)]
		public ConsoleTextLearning failQuest = new ConsoleTextLearning("'%n' failed.");

		[ORKEditorInfo("Inactivate Task Text", "The text displayed for inactivating a task.\n" +
			"Can be overridden for each task individually.", "",
			endFoldout=true)]
		public ConsoleTextLearning inactivateTask = new ConsoleTextLearning("Task '%n' removed.");

		[ORKEditorInfo("Activate Task Text", "The text displayed for activating a task.\n" +
			"Can be overridden for each task individually.", "",
			endFoldout=true)]
		public ConsoleTextLearning activateTask = new ConsoleTextLearning("Task '%n' added.");

		[ORKEditorInfo("Finish Task Text", "The text displayed for finishing a task.\n" +
			"Can be overridden for each task individually.", "",
			endFoldout=true)]
		public ConsoleTextLearning finishTask = new ConsoleTextLearning("Task '%n' finished.");

		[ORKEditorInfo("Fail Task Text", "The text displayed for failing a task.\n" +
			"Can be overridden for each task individually.", "",
			endFoldout=true, endFolds=2)]
		public ConsoleTextLearning failTask = new ConsoleTextLearning("Task '%n' failed.");


		// research
		[ORKEditorHelp("Display Research", "Research texts will be added to the console.\n" +
			"Please note that research texts are only displayed for the player group.", "")]
		[ORKEditorInfo("Research Texts", "Define if and what texts will be added for research related things.\n" +
			"Research texts are everything like adding a new research tree, start or finish researching a research item.\n" +
			"Please note that research texts are only displayed for the player group.", "")]
		public bool displayResearch = true;

		[ORKEditorInfo("Add Research Tree Text", "The text displayed for adding a new research tree.\n" +
			"Can be overridden for each research tree individually.\n" +
			"%n displays the name of the research tree.", "",
			endFoldout=true)]
		public ConsoleTextLearning addResearchTree = new ConsoleTextLearning("%un learns %n.");

		[ORKEditorInfo("Remove Research Tree Text", "The text displayed for removing a research tree.\n" +
			"Can be overridden for each research tree individually.\n" +
			"%n displays the name of research tree.", "",
			endFoldout=true)]
		public ConsoleTextLearning removeResearchTree = new ConsoleTextLearning("%un forgets %n.");

		[ORKEditorInfo("Start Research Text", "The text displayed for starting research of a research item.\n" +
			"Can be overridden for each research tree individually.\n" +
			"%n displays the name of research item.", "",
			endFoldout=true)]
		public ConsoleTextResearchItem startResearch = new ConsoleTextResearchItem("%un started researching %n.");

		[ORKEditorInfo("Cancel Research Text", "The text displayed for canceling research of a research item.\n" +
			"Can be overridden for each research tree individually.\n" +
			"%n displays the name of research item.", "",
			endFoldout=true)]
		public ConsoleTextResearchItem cancelResearch = new ConsoleTextResearchItem("%un canceled researching %n.");

		[ORKEditorInfo("Finish Research Text", "The text displayed for finishing research of a research item.\n" +
			"Can be overridden for each research tree individually.\n" +
			"%n displays the name of research item.", "",
			endFoldout=true, endFolds=2)]
		public ConsoleTextResearchItem finishResearch = new ConsoleTextResearchItem("%un finished researching %n.");


		// player group
		[ORKEditorHelp("Display Player Group", "Player group texts will be added to the console.", "")]
		[ORKEditorInfo("Player Group Texts", "Define if and what texts will be added for player group related things.", "")]
		public bool displayPlayerGroup = true;

		[ORKEditorInfo("Join Group Text", "The text displayed for joining the player group.\n" +
			"Can be overridden for each combatant individually.", "",
			endFoldout=true)]
		public ConsoleTextCombatant joinGroup = new ConsoleTextCombatant("%n joins the group.");

		[ORKEditorInfo("Leave Group Text", "The text displayed for leaving the player group.\n" +
			"Can be overridden for each combatant individually.", "",
			endFoldout=true, endFolds=2)]
		public ConsoleTextCombatant leaveGroup = new ConsoleTextCombatant("%n leaves the group.");

		public ConsoleSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetRealIDs()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(!data.Contains<bool>("ownActionTargetNames"))
			{
				this.ownActionTargetNames = true;
				this.ownLearningGroupNames = true;
				this.ownForgettingGroupNames = true;
				this.ownInventoryOwnerNames = true;
			}
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "consoleSettings"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}

		public override int Copy(int index)
		{
			return -1;
		}

		public override void Remove(int index)
		{

		}

		public override void Move(int index, bool down)
		{

		}
	}
}
